import matplotlib
import matplotlib.pyplot as plt
from matplotlib import pyplot
from docx import Document
from docx.shared import Inches
from docx.shared import Pt
from tkinter import *
from tkinter import filedialog
from tkinter import messagebox
import numpy as np
import csv
import argparse
import os
import pandas as pd
import pixelcrunch as pc
import fivecentplots as fcp
import bokeh
import sys
import io
import multiprocessing
import VRG_Safety_Data
import VRG_Calculate
import VRG_Data_Frame
import VRG_Doc
import VRG_General_Data
import VRG_Image_Analysis
import VRG_Image_Utils
import VRG_Macro_Data
import VRG_OTPM_Data
import VRG_Pins_Data
import VRG_Power_Data
import VRG_Register_Data
import VRG_Stats_Arr
import VRG_Stats_ArrCenter
import VRG_Stats_ArrQuad1
import VRG_Stats_ArrQuad2
import VRG_Stats_ArrQuad3
import VRG_Stats_ArrQuad4
import VRG_Stats_ArrRoi1
import VRG_Stats_ArrRoi2
import VRG_Stats_ArrRoi3
import VRG_Stats_ArrRoi4
import VRG_Stats_ArrRoi5
import VRG_Stats_ArrRoi6
import VRG_Stats_ArrRoi7
import VRG_Stats_ArrRoi8
import VRG_Stats_ArrRoi9
import VRG_Stats_DBLC
import VRG_Stats_Frame
import VRG_Stats_Lag
import VRG_Stats_RNC
import VRG_Stats_Tilt
import VRG_Tempsensor_Data
import VRG_Reports
import time


    
'''
    SYS CHECK
'''
def SM_SYS_CHECK_POST_STARTUP(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'SYS_CHECK_POST_STARTUP'

        figTitle = 'SM_SYS_CHECK_POST_STARTUP'
        ylabel = 'Level (1 = Pass, 0 = Fail)'
        numDataCols = 2  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        # Convert objects to int32
        if df[d1].dtype == object:
            if ((df[d1] == 'TRUE') | (df[d1] == 'FALSE')).any():
                df[d1] = df[d1].eq('TRUE').mul(1)  # Replace OK with 1, Fail with 0

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_SYS_CHECK(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'SYS_CHECK'

        figTitle = 'SYS_CHECK'
        ylabel = 'Level (1 = Pass, 0 = Fail)'
        numDataCols = 2  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        # Convert objects to int32
        if df[d1].dtype == object:
            if ((df[d1] == 'TRUE') | (df[d1] == 'FALSE')).any():
                df[d1] = df[d1].eq('TRUE').mul(1)  # Replace OK with 1, Fail with 0

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_TEMP_FLAG(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'TempFlag'

        figTitle = 'TempFlag'
        ylabel = 'Level (1 = Pass, 0 = Fail)'
        numDataCols = 2  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        # Convert objects to int32
        if df[d1].dtype == object:
            if ((df[d1] == 'TRUE') | (df[d1] == 'FALSE')).any():
                df[d1] = df[d1].eq('TRUE').mul(1)  # Replace OK with 1, Fail with 0

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

'''
STARTUP SM'S
'''
def SM_RESET(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # When Reset is active (Low), external clock is propagated to SYS_CHECK.
        # The presence of clock toggling at the SYS_CHECK pin is a confirmation test for Reset.
        d1 = ''

        figTitle = ''
        ylabel = 'RegVal (Dec)'
        ylabel2 = ''
        numDataCols = 2  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 10
        yFontsize = 8
        xFontsize = 8
        legFontSize = 6
        df = dataFrame


    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_HOST_CHECK_GPIO(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'GPI_STATUS'
        d2 = 'GPI_STATUS__GPIO0_PIN_STATUS'
        d3 = 'GPI_STATUS__GPIO1_PIN_STATUS'
        d4 = 'GPI_STATUS__GPIO2_PIN_STATUS'
        d5 = 'GPI_STATUS__GPIO3_PIN_STATUS'
        d6 = 'GPI_STATUS__SADDR0_PIN_STATUS'
        d7 = 'GPI_STATUS__SADDR1_PIN_STATUS'
        d8 = 'GPI_STATUS__SADDR2_PIN_STATUS'
        d9 = 'GPI_STATUS_ASIC'
        d10 = 'GPI_STATUS_ASIC__GPIO0_PIN_STATUS_ASIC'
        d11 = 'GPI_STATUS_ASIC__GPIO4_PIN_STATUS_ASIC'
        d12 = 'GPI_STATUS_ASIC__SADDR0_PIN_STATUS_ASIC'
        d13 = 'GPI_STATUS_ASIC__SADDR1_PIN_STATUS_ASIC'
        d14 = 'GPI_STATUS_ASIC__SADDR2_PIN_STATUS_ASIC'
        d15 = 'GPI_STATUS_ASIC__SADDR3_PIN_STATUS_ASIC'

        figTitle = 'SM_HOST_CHECK_GPIO'
        ylabel = 'RegVal (Dec)'
        numDataCols = 16  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_POWERON_MBIST(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'MBIST_STARTUP_CONTROL'
        d2 = 'MBIST_STARTUP_RESULT'
        d3 = 'MBIST_STARTUP_STATUS'

        figTitle = 'SM_POWERON_MBIST'
        ylabel = 'RegVal (Dec)'
        numDataCols = 4  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 10
        yFontsize = 8
        xFontsize = 8
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols, 3):  # 1 to numDataCols by 2
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1)), eval("d" + str(x + 2))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)) + ' & ' + eval("d" + str(x + 2)),
                         show=showPlt,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + eval(
                        "d" + str(x + 2)) + '_' + timestamp + '.png')
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + eval(
                    "d" + str(x + 2)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols, 3):  # 1 to numDataCols by 2
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1)), eval("d" + str(x + 2))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)) + ' & ' + eval("d" + str(x + 2)),
                         legend=groupBy, show=showPlt,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + eval(
                        "d" + str(x + 2)) + '_' + timestamp + '.png')
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + eval(
                    "d" + str(x + 2)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_POWERON_MBIST_Expanded(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'MBIST_STARTUP_CONTROL'
        d2 = 'MBIST_STARTUP_RESULT'
        d3 = 'MBIST_STARTUP_STATUS'

        figTitle = 'SM_POWERON_MBIST_Expanded'
        ylabel = 'RegVal (Dec)'
        numDataCols = 4  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 10
        yFontsize = 8
        xFontsize = 8
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_POWERON_MBIST2(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'MBIST_STARTUP_CONTROL'
        d2 = 'MBIST_STARTUP_RESULT'
        d3 = 'MBIST_STARTUP_STATUS'

        figTitle = 'SM_POWERON_MBIST2'
        ylabel = 'RegVal (Dec)'
        numDataCols = 4  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 10
        yFontsize = 8
        xFontsize = 8
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols, 3): # 1 to numDataCols by 2
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1)), eval("d" + str(x + 2))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)) + ' & ' + eval("d" + str(x + 2)),
                         show=showPlt,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + eval("d" + str(x + 2)) + '_' + timestamp + '.png')
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + eval("d" + str(x + 2)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols, 3): # 1 to numDataCols by 2
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1)), eval("d" + str(x + 2))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)) + ' & ' + eval("d" + str(x + 2)),
                         legend=groupBy, show=showPlt,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + eval("d" + str(x + 2)) + '_' + timestamp + '.png')
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + eval("d" + str(x + 2)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_POWERON_MBIST2_Expanded(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'MBIST_STARTUP_CONTROL'
        d2 = 'MBIST_STARTUP_RESULT'
        d3 = 'MBIST_STARTUP_STATUS'

        figTitle = 'SM_POWERON_MBIST2_Expanded'
        ylabel = 'RegVal (Dec)'
        numDataCols = 4  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 10
        yFontsize = 8
        xFontsize = 8
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_M3ROM_UPLOAD_CRC(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'M3ROM_WRT_CHECKSUM'
        d2 = 'M3ROM_CALC_CHECKSUM'

        figTitle = 'SM_M3ROM_UPLOAD_CRC'
        ylabel = 'RegVal (Dec)'
        numDataCols = 3  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 10
        yFontsize = 8
        xFontsize = 8
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols, 2): # 1 to numDataCols by 2
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         show=showPlt,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols, 2): # 1 to numDataCols by 2
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         legend=groupBy, show=showPlt,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_M3ROM_UPLOAD_CRC_Expanded(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'M3ROM_WRT_CHECKSUM'
        d2 = 'M3ROM_CALC_CHECKSUM'

        figTitle = 'SM_M3ROM_UPLOAD_CRC_Expanded'
        ylabel = 'RegVal (Dec)'
        numDataCols = 3  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 10
        yFontsize = 8
        xFontsize = 8
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_M3ROM_UPLOAD_CRC_ASIC(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ASIC_M3ROM_WRT_CHECKSUM'
        d2 = 'ASIC_M3ROM_CALC_CHECKSUM'

        figTitle = 'SM_M3ROM_UPLOAD_CRC_ASIC'
        ylabel = 'RegVal (Dec)'
        numDataCols = 3  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 10
        yFontsize = 8
        xFontsize = 8
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols, 2): # 1 to numDataCols by 2
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         show=showPlt,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols, 2): # 1 to numDataCols by 2
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         legend=groupBy, show=showPlt,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')  # Add figure to report


    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_M3ROM_UPLOAD_CRC_ASIC_Expanded(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ASIC_M3ROM_WRT_CHECKSUM'
        d2 = 'ASIC_M3ROM_CALC_CHECKSUM'

        figTitle = 'SM_M3ROM_UPLOAD_CRC_ASIC_Expanded'
        ylabel = 'RegVal (Dec)'
        numDataCols = 3  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 10
        yFontsize = 8
        xFontsize = 8
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_OTPM_UPLOAD_CRC(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'OTPM_WRT_CHECKSUM'
        d2 = 'OTPM_CALC_CHECKSUM'

        figTitle = 'SM_OTPM_UPLOAD_CRC'
        ylabel = 'RegVal (Dec)'
        numDataCols = 3  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 10
        yFontsize = 8
        xFontsize = 8
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols, 2): # 1 to numDataCols by 2
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         show=showPlt,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols, 2): # 1 to numDataCols by 2
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         legend=groupBy, show=showPlt,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_OTPM_UPLOAD_CRC_Expanded(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'OTPM_WRT_CHECKSUM'
        d2 = 'OTPM_CALC_CHECKSUM'

        figTitle = 'SM_OTPM_UPLOAD_CRC_Expanded'
        ylabel = 'RegVal (Dec)'
        numDataCols = 3  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 10
        yFontsize = 8
        xFontsize = 8
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_PDIM_UPLOAD_CRC(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'PDIM_WRT_CHECKSUM'
        d2 = 'PDIM_CALC_CHECKSUM'

        figTitle = 'SM_PDIM_UPLOAD_CRC'
        ylabel = 'RegVal (Dec)'
        numDataCols = 3  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 10
        yFontsize = 8
        xFontsize = 8
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols, 2): # 1 to numDataCols by 2
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         show=showPlt,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols, 2): # 1 to numDataCols by 2
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         legend=groupBy, show=showPlt,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_PDIM_UPLOAD_CRC_Expanded(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'PDIM_WRT_CHECKSUM'
        d2 = 'PDIM_CALC_CHECKSUM'

        figTitle = 'SM_PDIM_UPLOAD_CRC_Expanded'
        ylabel = 'RegVal (Dec)'
        numDataCols = 3  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 10
        yFontsize = 8
        xFontsize = 8
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_STANDBY_REGISTER_CRC(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'IREG_WRT_CHECKSUM'
        d2 = 'IREG_CALC_CHECKSUM'

        figTitle = 'SM_STANDBY_REGISTER_CRC'
        ylabel = 'RegVal (Dec)'
        numDataCols = 3  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 10
        yFontsize = 8
        xFontsize = 8
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols, 2):  # 1 to numDataCols by 2
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         show=showPlt,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval(
                        "d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval(
                    "d" + str(x + 1)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols, 2):  # 1 to numDataCols by 2
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         legend=groupBy, show=showPlt,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval(
                        "d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval(
                    "d" + str(x + 1)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_STANDBY_REGISTER_CRC_Expanded(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'IREG_WRT_CHECKSUM'
        d2 = 'IREG_CALC_CHECKSUM'

        figTitle = 'SM_STANDBY_REGISTER_CRC_Expanded'
        ylabel = 'RegVal (Dec)'
        numDataCols = 3  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 10
        yFontsize = 8
        xFontsize = 8
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_OTPM_ECC(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'OTPM_STATUS'
        d2 = 'OTPM_STATUS__CHECK_BITS'
        d3 = 'OTPM_STATUS__SEC_USED'
        d4 = 'OTPM_STATUS__PARITY_FAILURE'
        d5 = 'OTPM_STATUS__OTPM_FULL'
        d6 = 'OTPM_STATUS__OTPM_INSUFFICIENT'
        d7 = 'OTPM_STATUS__OTPM_BUSY'
        d8 = 'OTPM_STATUS__SEC_COUNT'

        figTitle = 'SM_OTPM_ECC'
        ylabel = 'RegVal (Dec)'
        numDataCols = 9  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 10
        yFontsize = 8
        xFontsize = 8
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_STANDBY_BIST_MEMORY(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'MBIST_STARTUP_CONTROL'
        d2 = 'MBIST_STARTUP_RESULT'
        d3 = 'MBIST_STARTUP_STATUS'

        figTitle = 'SM_STANDBY_BIST_MEMORY'
        ylabel = 'RegVal (Dec)'
        numDataCols = 4  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 10
        yFontsize = 8
        xFontsize = 8
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report


        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols, 3): # 1 to numDataCols by 2
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1)), eval("d" + str(x + 2))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)) + ' & ' + eval("d" + str(x + 2)),
                         show=showPlt,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + eval("d" + str(x + 2)) + '_' + timestamp + '.png')
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + eval("d" + str(x + 2)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols, 3): # 1 to numDataCols by 2
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1)), eval("d" + str(x + 2))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)) + ' & ' + eval("d" + str(x + 2)),
                         legend=groupBy, show=showPlt,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + eval("d" + str(x + 2)) + '_' + timestamp + '.png')
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + eval("d" + str(x + 2)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_STANDBY_BIST_MEMORY_Expanded(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'MBIST_STARTUP_CONTROL'
        d2 = 'MBIST_STARTUP_RESULT'
        d3 = 'MBIST_STARTUP_STATUS'

        figTitle = 'SM_STANDBY_BIST_MEMORY_Expanded'
        ylabel = 'RegVal (Dec)'
        numDataCols = 4  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 10
        yFontsize = 8
        xFontsize = 8
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_STANDBY_TEST_FRAME(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:

        d1 = 'CRC_FR_DTR_WRT_CHECKSUM_HIGH'
        d2 = 'CRC_FR_DTR_CALC_CHECKSUM_HIGH'
        d3 = 'CRC_FR_DTR_WRT_CHECKSUM_HIGH__CRC_FR_WRT_CHECKSUM_HIGH'
        d4 = 'CRC_FR_DTR_CALC_CHECKSUM_HIGH__CRC_FR_CALC_CHECKSUM_HIGH'
        d5 = 'CRC_FR_WRT_CHECKSUM_LOW'
        d6 = 'CRC_FR_CALC_CHECKSUM_LOW'
        d7 = 'TPG_CONTROL'
        d8 = 'TPG_STDPAT_REGION1'
        d9 = 'TPG_STDPAT_REGION2'
        d10 = 'TPG_NOISE1_REGION'
        d11 = 'TPG_NOISE2_REGION'
        d12 = 'TPG_COLOR0_GR1_HI'
        d13 = 'TPG_COLOR0_GR1_LO'
        d14 = 'TPG_COLOR0_RED_HI'
        d15 = 'TPG_COLOR0_RED_LO'
        d16 = 'TPG_COLOR0_BLU_HI'
        d17 = 'TPG_COLOR0_BLU_LO'
        d18 = 'TPG_COLOR0_GR2_HI'
        d19 = 'TPG_COLOR0_GR2_LO'
        d20 = 'TPG_COLOR1_GR1_HI'
        d21 = 'TPG_COLOR1_GR1_LO'
        d22 = 'TPG_COLOR1_RED_HI'
        d23 = 'TPG_COLOR1_RED_LO'
        d24 = 'TPG_COLOR1_BLU_HI'
        d25 = 'TPG_COLOR1_BLU_LO'
        d26 = 'TPG_COLOR1_GR2_HI'
        d27 = 'TPG_COLOR1_GR2_LO'
        d28 = 'ASIL_PIN_ENABLES_02'
        d29 = 'ASIL_CHECK_ENABLES_02'
        d30 = 'ASIL_STATUS_02'
        d31 = 'ASIL_STATUS_02__ROW_FRAME_CRC_STATUS'

        figTitle = 'SM_STANDBY_TEST_FRAME'
        ylabel = 'RegVal (Dec)'
        numDataCols = 32  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, 7, 2):  # 1 to 5 to plot cnt vs cnt expected
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, 7, 2):  # 1 to 5 to plot cnt vs cnt expected
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         legend=groupBy, show=showPlt,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def ASIL_STARTUP_PIN_ENABLES(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ASIL_STARTUP_PIN_ENABLES' # Columns to find

        df = dataFrame

        # get data columns
        t1_cols = [x for x in df.columns[df.columns.str.contains(d1)]]

        figTitle = 'ASIL_STARTUP_PIN_ENABLES Registers'
        ylabel = 'RegVal (Dec)'
        numDataCols = len(t1_cols) + 1 # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        for dc in t1_cols: # loop through all column names
            if groupBy == None:  # Remove Legend= keyword
                # Plot each data frame column
                fcp.plot(df, x='Step', y=dc, title=dc, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + dc + '_' + timestamp + '.png')
                document.add_heading(dc, level=3)
                document.add_picture(pltPath + dc + '_' + timestamp + '.png')  # Add figure to report
            elif groupBy != None:
                # Plot each data frame column
                fcp.plot(df, x='Step', y=dc, title=dc, legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + dc + '_' + timestamp + '.png')
                document.add_heading(dc, level=3)
                document.add_picture(pltPath + dc + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for dc in t1_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def ASIL_STARTUP_ENABLES(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ASIL_STARTUP_ENABLES' # Columns to find

        df = dataFrame

        # get data columns
        t1_cols = [x for x in df.columns[df.columns.str.contains(d1)]]

        figTitle = 'ASIL_STARTUP_ENABLES Registers'
        ylabel = 'RegVal (Dec)'
        numDataCols = len(t1_cols) + 1 # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        for dc in t1_cols: # loop through all column names
            if groupBy == None:  # Remove Legend= keyword
                # Plot each data frame column
                fcp.plot(df, x='Step', y=dc, title=dc, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + dc + '_' + timestamp + '.png')
                document.add_heading(dc, level=3)
                document.add_picture(pltPath + dc + '_' + timestamp + '.png')  # Add figure to report
            elif groupBy != None:
                # Plot each data frame column
                fcp.plot(df, x='Step', y=dc, title=dc, legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + dc + '_' + timestamp + '.png')
                document.add_heading(dc, level=3)
                document.add_picture(pltPath + dc + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for dc in t1_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def ASIL_STARTUP_STATUS(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ASIL_STARTUP_STATUS' # Columns to find

        df = dataFrame

        # get data columns
        t1_cols = [x for x in df.columns[df.columns.str.contains(d1)]]

        figTitle = 'ASIL_STARTUP_STATUS Registers'
        ylabel = 'RegVal (Dec)'
        numDataCols = len(t1_cols) + 1 # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        for dc in t1_cols: # loop through all column names
            if groupBy == None:  # Remove Legend= keyword
                # Plot each data frame column
                fcp.plot(df, x='Step', y=dc, title=dc, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + dc + '_' + timestamp + '.png')
                document.add_heading(dc, level=3)
                document.add_picture(pltPath + dc + '_' + timestamp + '.png')  # Add figure to report
            elif groupBy != None:
                # Plot each data frame column
                fcp.plot(df, x='Step', y=dc, title=dc, legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + dc + '_' + timestamp + '.png')
                document.add_heading(dc, level=3)
                document.add_picture(pltPath + dc + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for dc in t1_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

'''
SM STARTUP
'''
def SM_Startup_Expanded_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    #expanded = plots 1 registers per plot
    figTitle = 'SM_Startup_Expanded_Plot'

    currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
    fractime = time.process_time()
    timestamp = currTime + '_' + str(fractime)

    document.add_heading(figTitle, level=2)  # Add section title to docx report

    # SM Startup Test Calls
    VRG_Safety_Data.SM_M3ROM_UPLOAD_CRC_Expanded(dataFrame, groupBy, document, pltPath, showPlt, **kwargs)
    VRG_Safety_Data.SM_OTPM_UPLOAD_CRC_Expanded(dataFrame, groupBy, document, pltPath, showPlt, **kwargs)
    VRG_Safety_Data.SM_PDIM_UPLOAD_CRC_Expanded(dataFrame, groupBy, document, pltPath, showPlt, **kwargs)
    VRG_Safety_Data.SM_STANDBY_REGISTER_CRC_Expanded(dataFrame, groupBy, document, pltPath, showPlt, **kwargs)
    VRG_Safety_Data.SM_POWERON_MBIST2_Expanded(dataFrame, groupBy, document, pltPath, showPlt, **kwargs)
    VRG_Safety_Data.SM_OTPM_ECC(dataFrame, groupBy, document, pltPath, showPlt, **kwargs)
    VRG_Safety_Data.ASIL_STARTUP_PIN_ENABLES(dataFrame, groupBy, document, pltPath, showPlt, **kwargs)
    VRG_Safety_Data.ASIL_STARTUP_ENABLES(dataFrame, groupBy, document, pltPath, showPlt, **kwargs)
    VRG_Safety_Data.ASIL_STARTUP_STATUS(dataFrame, groupBy, document, pltPath, showPlt, **kwargs)
    VRG_Safety_Data.SM_SYS_CHECK_POST_STARTUP(dataFrame, groupBy, document, pltPath, showPlt, **kwargs)

def SM_Startup_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):

        figTitle = 'SM_Startup_Plot'

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # SM Startup Test Calls
        VRG_Safety_Data.SM_M3ROM_UPLOAD_CRC(dataFrame, groupBy, document, pltPath, showPlt, **kwargs)
        VRG_Safety_Data.SM_OTPM_UPLOAD_CRC(dataFrame, groupBy, document, pltPath, showPlt, **kwargs)
        VRG_Safety_Data.SM_PDIM_UPLOAD_CRC(dataFrame, groupBy, document, pltPath, showPlt, **kwargs)
        VRG_Safety_Data.SM_STANDBY_REGISTER_CRC(dataFrame, groupBy, document, pltPath, showPlt, **kwargs)
        VRG_Safety_Data.SM_POWERON_MBIST2(dataFrame, groupBy, document, pltPath, showPlt,**kwargs)
        VRG_Safety_Data.SM_OTPM_ECC(dataFrame, groupBy, document, pltPath, showPlt, **kwargs)
        VRG_Safety_Data.ASIL_STARTUP_PIN_ENABLES(dataFrame, groupBy, document, pltPath, showPlt, **kwargs)
        VRG_Safety_Data.ASIL_STARTUP_ENABLES(dataFrame, groupBy, document, pltPath, showPlt, **kwargs)
        VRG_Safety_Data.ASIL_STARTUP_STATUS(dataFrame, groupBy, document, pltPath, showPlt, **kwargs)
        VRG_Safety_Data.SM_SYS_CHECK_POST_STARTUP(dataFrame, groupBy, document, pltPath, showPlt, **kwargs)

'''
SM STARTUP POST RUNTIME
'''
def SM_Startup_Runtime_Expanded_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    # expanded = plots 1 registers per plot
    try:
        # Column Names in CSV
        d1 = 'M3ROM_WRT_CHECKSUM_RUNTIME'
        d2 = 'M3ROM_CALC_CHECKSUM_RUNTIME'
        d3 = 'OTPM_WRT_CHECKSUM_RUNTIME'
        d4 = 'OTPM_CALC_CHECKSUM_RUNTIME'
        d5 = 'PDIM_WRT_CHECKSUM_RUNTIME'
        d6 = 'PDIM_CALC_CHECKSUM_RUNTIME'
        d7 = 'IREG_WRT_CHECKSUM_RUNTIME'
        d8 = 'IREG_CALC_CHECKSUM_RUNTIME'
        d9 = 'ASIC_M3ROM_WRT_CHECKSUM_RUNTIME'
        d10 = 'ASIC_M3ROM_CALC_CHECKSUM_RUNTIME'
        d11 = 'OTPM_WRT_CHECKSUM_SENSOR_RUNTIME'
        d12 = 'OTPM_CALC_CHECKSUM_SENSOR_RUNTIME'
        d13 = 'ASIL_STARTUP_PIN_ENABLES_00_RUNTIME'
        d14 = 'ASIL_STARTUP_ENABLES_00_RUNTIME'
        d15 = 'ASIL_STARTUP_STATUS_00_RUNTIME'
        d16 = 'SYS_CHECK_RUNTIME'

        figTitle = 'SM_Startup_Runtime_Expanded'
        ylabel = 'RegVal (Dec)'
        ylabel2 = 'SYS_CHECK Level (1 = High, 0 = Low)'
        numDataCols = 17  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 17
                if x != 16:  # All other results
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel,
                             title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                             legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
                elif x == 16:  # SysCheck
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 17
                if x != 16:  # All other results
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel,
                             title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                             legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
                elif x == 16:  # SysCheck
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_Startup_Runtime_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'M3ROM_WRT_CHECKSUM_RUNTIME'
        d2 = 'M3ROM_CALC_CHECKSUM_RUNTIME'
        d3 = 'OTPM_WRT_CHECKSUM_RUNTIME'
        d4 = 'OTPM_CALC_CHECKSUM_RUNTIME'
        d5 = 'PDIM_WRT_CHECKSUM_RUNTIME'
        d6 = 'PDIM_CALC_CHECKSUM_RUNTIME'
        d7 = 'IREG_WRT_CHECKSUM_RUNTIME'
        d8 = 'IREG_CALC_CHECKSUM_RUNTIME'
        d9 = 'ASIC_M3ROM_WRT_CHECKSUM_RUNTIME'
        d10 = 'ASIC_M3ROM_CALC_CHECKSUM_RUNTIME'
        d11 = 'OTPM_WRT_CHECKSUM_SENSOR_RUNTIME'
        d12 = 'OTPM_CALC_CHECKSUM_SENSOR_RUNTIME'
        d13 = 'ASIL_STARTUP_PIN_ENABLES_00_RUNTIME'
        d14 = 'ASIL_STARTUP_ENABLES_00_RUNTIME'
        d15 = 'ASIL_STARTUP_STATUS_00_RUNTIME'
        d16 = 'SYS_CHECK_RUNTIME'

        figTitle = 'SM_Startup_Runtime'
        ylabel = 'RegVal (Dec)'
        ylabel2 = 'SYS_CHECK Level'
        numDataCols = 17  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 10
        yFontsize = 8
        xFontsize = 8
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols, 2):  # 1 to 17
                if x != 15 and x != 16:  # All other results
                    fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                             title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), show=showPlt, inline=showPlt,
                             title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval(
                                 "d" + str(x + 1)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval(
                        "d" + str(x + 1)) + '_' + timestamp + '.png')  # Add figure to report
                elif x == 15:  # ASIL_STATUS
                    fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                             title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
                elif x == 16:  # SYS_CHECK
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols, 2):  # 1 to 17
                if x != 15 and x != 16:  # All other results
                    fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                             title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                             legend=groupBy, show=showPlt,
                             inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval(
                                 "d" + str(x + 1)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval(
                        "d" + str(x + 1)) + '_' + timestamp + '.png')  # Add figure to report
                elif x == 15:  # ASIL_STATUS
                    fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                             title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
                elif x == 16:  # SysCheck
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

'''
SM STARTUP VS SM STARTUP POST RUNTIME
'''
def SM_Startup_vs_Startup_Runtime_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'M3ROM_WRT_CHECKSUM'
        d2 = 'M3ROM_WRT_CHECKSUM_RUNTIME'
        d3 = 'M3ROM_CALC_CHECKSUM'
        d4 = 'M3ROM_CALC_CHECKSUM_RUNTIME'
        d5 = 'OTPM_WRT_CHECKSUM'
        d6 = 'OTPM_WRT_CHECKSUM_RUNTIME'
        d7 = 'OTPM_CALC_CHECKSUM'
        d8 = 'OTPM_CALC_CHECKSUM_RUNTIME'
        d9 = 'PDIM_WRT_CHECKSUM'
        d10 = 'PDIM_WRT_CHECKSUM_RUNTIME'
        d11 = 'PDIM_CALC_CHECKSUM'
        d12 = 'PDIM_CALC_CHECKSUM_RUNTIME'
        d13 = 'IREG_WRT_CHECKSUM'
        d14 = 'IREG_WRT_CHECKSUM_RUNTIME'
        d15 = 'IREG_CALC_CHECKSUM'
        d16 = 'IREG_CALC_CHECKSUM_RUNTIME'
        d17 = 'ASIC_M3ROM_WRT_CHECKSUM'
        d18 = 'ASIC_M3ROM_WRT_CHECKSUM_RUNTIME'
        d19 = 'ASIC_M3ROM_CALC_CHECKSUM'
        d20 = 'ASIC_M3ROM_CALC_CHECKSUM_RUNTIME'
        d21 = 'OTPM_WRT_CHECKSUM_SENSOR'
        d22 = 'OTPM_WRT_CHECKSUM_SENSOR_RUNTIME'
        d23 = 'OTPM_CALC_CHECKSUM_SENSOR'
        d24 = 'OTPM_CALC_CHECKSUM_SENSOR_RUNTIME'
        d25 = 'ASIL_STARTUP_PIN_ENABLES_00'
        d26 = 'ASIL_STARTUP_PIN_ENABLES_00_RUNTIME'
        d27 = 'ASIL_STARTUP_ENABLES_00'
        d28 = 'ASIL_STARTUP_ENABLES_00_RUNTIME'
        d29 = 'ASIL_STARTUP_STATUS_00'
        d30 = 'ASIL_STARTUP_STATUS_00_RUNTIME'
        d31 = 'SYS_CHECK_POST_STARTUP'
        d32 = 'SYS_CHECK_RUNTIME'

        figTitle = 'SM_Startup_vs_Startup_Runtime'
        ylabel = 'RegVal (Dec)'
        ylabel2 = 'SYS_CHECK Level'
        numDataCols = 33  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 10
        yFontsize = 8
        xFontsize = 8
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols, 2):  # 1 to 8
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs,
                         filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval(
                    "d" + str(x + 1)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols, 2):  # 1 to 8
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         legend=groupBy, show=showPlt,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs,
                         filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval(
                    "d" + str(x + 1)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found


'''
ATR SM'S
'''
def SM_ATR(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ATR_CHECK_CRT_CRC_VALUE'
        d2 = 'ATR_CHECK_CRT_CRC_EXPECT'
        d3 = 'ATR_CHECK_MT_EXPECT_ADCL'
        d4 = 'ATR_CHECK_MT_EXPECT_DCDS'
        d5 = 'ATR_CHECK_MT_EXPECT1'
        d6 = 'ATR_CHECK_MT_EXPECT2'
        d7 = 'ATR_CHECK_MT_EXPECT_B'
        d8 = 'ATR_CHECK_MT_EXPECT_W'
        d9 = 'ATR_CHECK_OT1_HI_THRESH'
        d10 = 'ATR_CHECK_OT1_LO_THRESH'
        d11 = 'ATR_CHECK_OT2_HI_THRESH'
        d12 = 'ATR_CHECK_OT2_LO_THRESH'
        d13 = 'ATR_CHECK_OT3_HI_THRESH'
        d14 = 'ATR_CHECK_OT3_LO_THRESH'
        d15 = 'ATR_CHECK_OT4_HI_THRESH'
        d16 = 'ATR_CHECK_OT4_LO_THRESH'
        d17 = 'ATR_CHECK_OT5_HI_THRESH'
        d18 = 'ATR_CHECK_OT5_LO_THRESH'
        d19 = 'ATR_CHECK_OT6_HI_THRESH'
        d20 = 'ATR_CHECK_OT6_LO_THRESH'
        d21 = 'ATR_CHECK_OT7_HI_THRESH'
        d22 = 'ATR_CHECK_OT7_LO_THRESH'
        d23 = 'ATR_CHECK_OT8_HI_THRESH'
        d24 = 'ATR_CHECK_OT8_LO_THRESH'
        d25 = 'ATR_CHECK_ZT_LO_THRESH'
        d26 = 'ATR_CHECK_ZT_HI_THRESH'
        d27 = 'TEST_CTRL'
        d28 = 'ATR_CHECK_GRD_HI_THRESH'
        d29 = 'ATR_CHECK_GRD_LO_THRESH'
        d30 = 'ATR_CHECK_PT_LO_THRESH'
        d31 = 'ATR_CHECK_PT_HI_THRESH'
        d32 = 'ATR_CHECK_MT_EXPECT_PIXOUT'
        d33 = 'ATR_CHECK_MT_EXPECT_EC_COMP'
        d34 = 'ATR_CHECK_MT_EXPECT_DCDS2'
        d35 = 'ASIL_PIN_ENABLES_01'
        d36 = 'ASIL_PIN_ENABLES_05'
        d37 = 'ASIL_PIN_ENABLES_06'
        d38 = 'ASIL_CHECK_ENABLES_01'
        d39 = 'ASIL_CHECK_ENABLES_05'
        d40 = 'ASIL_CHECK_ENABLES_06'
        d41 = 'ASIL_STATUS_01'
        d42 = 'ASIL_STATUS_01__FAIL_CRT'
        d43 = 'ASIL_STATUS_01__FAIL_OT1_PIXEL_LOW'
        d44 = 'ASIL_STATUS_01__FAIL_OT1_PIXEL_HIGH'
        d45 = 'ASIL_STATUS_01__FAIL_OT2_PIXEL_LOW'
        d46 = 'ASIL_STATUS_01__FAIL_OT2_PIXEL_HIGH'
        d47 = 'ASIL_STATUS_01__FAIL_ZEBRA_AB_PIXEL_LEGAL'
        d48 = 'ASIL_STATUS_01__FAIL_ZEBRA_AB_PIXEL_CORRECT'
        d49 = 'ASIL_STATUS_01__FAIL_ZEBRA_BA_PIXEL_LEGAL'
        d50 = 'ASIL_STATUS_01__FAIL_ZEBRA_BA_PIXEL_CORRECT'
        d51 = 'ASIL_STATUS_01__FAIL_PT1_BELOW_THRESHOLD'
        d52 = 'ASIL_STATUS_01__FAIL_PT2_ABOVE_THRESHOLD'
        d53 = 'ASIL_STATUS_05'
        d54 = 'ASIL_STATUS_05__FAIL_OT3_PIXEL_LOW'
        d55 = 'ASIL_STATUS_05__FAIL_OT3_PIXEL_HIGH'
        d56 = 'ASIL_STATUS_05__FAIL_OT4_PIXEL_LOW'
        d57 = 'ASIL_STATUS_05__FAIL_OT4_PIXEL_HIGH'
        d58 = 'ASIL_STATUS_05__FAIL_OT5_PIXEL_LOW'
        d59 = 'ASIL_STATUS_05__FAIL_OT5_PIXEL_HIGH'
        d60 = 'ASIL_STATUS_05__FAIL_GRD_PIXEL_LOW'
        d61 = 'ASIL_STATUS_05__FAIL_GRD_PIXEL_HIGH'
        d62 = 'ASIL_STATUS_06'
        d63 = 'ASIL_STATUS_06__FAIL_ADCL'
        d64 = 'ASIL_STATUS_06__FAIL_DCDS'
        d65 = 'ASIL_STATUS_06__FAIL_PIXOUT'
        d66 = 'ASIL_STATUS_06__FAIL_BW'
        d67 = 'ASIL_STATUS_06__FAIL_WB'
        d68 = 'ASIL_STATUS_06__FAIL_OT6_LOW'
        d69 = 'ASIL_STATUS_06__FAIL_OT6_HIGH'
        d70 = 'ASIL_STATUS_06__FAIL_OT7_LOW'
        d71 = 'ASIL_STATUS_06__FAIL_OT7_HIGH'
        d72 = 'ASIL_STATUS_06__FAIL_OT8_LOW'
        d73 = 'ASIL_STATUS_06__FAIL_OT8_HIGH'
        d74 = 'ASIL_STATUS_06__FAIL_EC_COMP'
        d75 = 'ASIL_STATUS_06__FAIL_DCDS2'

        figTitle = 'SM_ATR'
        ylabel = 'RegVal (Dec)'
        numDataCols = 76  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_ATR_COLUMN_ROM(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ATR_CHECK_CRT_CRC_VALUE'
        d2 = 'ATR_CHECK_CRT_CRC_EXPECT'
        d3 = 'ASIL_PIN_ENABLES_01'
        d4 = 'ASIL_CHECK_ENABLES_01'
        d5 = 'ASIL_STATUS_01'
        d6 = 'ASIL_STATUS_01__FAIL_CRT'

        figTitle = 'SM_ATR_COLUMN_ROM'
        ylabel = 'RegVal (Dec)'
        numDataCols = 7  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, 3, 2):  # 1 to 3 to plot similar thresholds
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, 3, 2):  # 1 to 3 to plot similar thresholds
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         legend=groupBy, show=showPlt,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_ATR_COLUMN_ROM_vs_Calculated_CRC(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ATR_Column_Rom_CRC'
        d2 = 'ATR_CHECK_CRT_CRC_VALUE'
        th1 = 'ATR_CHECK_CRT_CRC_EXPECT'

        figTitle = 'SM_ATR_COLUMN_ROM_vs_Calculated_CRC'
        ylabel = 'RegVal (Dec)'
        numDataCols = 3  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 10
        yFontsize = 6
        xFontsize = 8
        legFontSize = 6
        df = dataFrame
        ULcolor = '#ff0000'
        LLcolor = '#0000ff'

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), th1], title=eval("d" + str(x)) + ' vs. ' + th1,
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols, 2):  # 1 to N by 2
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1)), th1], title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)) + ' vs. ' + th1,
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), th1], title=eval("d" + str(x)) + ' vs. ' + th1, legend=groupBy,
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols, 2):  # 1 to N
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1)), th1], title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)) + ' vs. ' + th1,
                         legend=groupBy, show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_ATR_ADC_LATCH(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ATR_CHECK_MT_EXPECT_ADCL'
        d2 = 'ASIL_PIN_ENABLES_06'
        d3 = 'ASIL_CHECK_ENABLES_06'
        d4 = 'ASIL_STATUS_06'
        d5 = 'ASIL_STATUS_06__FAIL_ADCL'

        figTitle = 'SM_ATR_ADC_LATCH'
        ylabel = 'RegVal (Dec)'
        numDataCols = 6  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_ATR_ADC_LATCH_vs_Threshold(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ADC_LATCH mean'
        d2 = 'ADC_LATCH max'
        d3 = 'ADC_LATCH min'
        th1 = 'ATR_CHECK_MT_EXPECT_ADCL'

        figTitle = 'SM_ATR_ADC_LATCH_vs_Threshold'
        ylabel = 'RegVal (Dec)'
        numDataCols = 4  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 10
        yFontsize = 6
        xFontsize = 8
        legFontSize = 6
        df = dataFrame
        ULcolor = '#ff0000'
        LLcolor = '#0000ff'

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), th1], title=eval("d" + str(x)) + ' vs. ' + th1,
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), th1], title=eval("d" + str(x)) + ' vs. ' + th1, legend=groupBy,
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_ATR_DCDS(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ATR_CHECK_MT_EXPECT_DCDS'
        d2 = 'ASIL_PIN_ENABLES_06'
        d3 = 'ASIL_CHECK_ENABLES_06'
        d4 = 'ASIL_STATUS_06'
        d5 = 'ASIL_STATUS_06__FAIL_DCDS'

        figTitle = 'SM_ATR_DCDS'
        ylabel = 'RegVal (Dec)'
        numDataCols = 6  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_ATR_DCDS_vs_Threshold(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'DCDS_1 mean'
        d2 = 'DCDS_1 max'
        d3 = 'DCDS_1 min'
        th1 = 'ATR_CHECK_MT_EXPECT_DCDS'

        figTitle = 'SM_ATR_DCDS_vs_Threshold'
        ylabel = 'RegVal (Dec)'
        numDataCols = 4  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 10
        yFontsize = 6
        xFontsize = 8
        legFontSize = 6
        df = dataFrame
        ULcolor = '#ff0000'
        LLcolor = '#0000ff'

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), th1], title=eval("d" + str(x)) + ' vs. ' + th1,
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), th1], title=eval("d" + str(x)) + ' vs. ' + th1, legend=groupBy,
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_ATR_COLUMN_MEMORY_TEST_1(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ATR_CHECK_MT_EXPECT1'
        d2 = 'ASIL_PIN_ENABLES_06'
        d3 = 'ASIL_CHECK_ENABLES_06'
        d4 = 'ASIL_STATUS_06'
        d5 = 'ASIL_STATUS_06__FAIL_BW'
        d6 = 'ASIL_STATUS_06__FAIL_WB'

        figTitle = 'SM_ATR_COLUMN_MEMORY_TEST_1'
        ylabel = 'RegVal (Dec)'
        numDataCols = 7  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_ATR_COLUMN_MEMORY_TEST_1_vs_Threshold(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'COL_MEM_1 mean'
        d2 = 'COL_MEM_1 max'
        d3 = 'COL_MEM_1 min'
        th1 = 'ATR_CHECK_MT_EXPECT_B'
        th2 = 'ATR_CHECK_MT_EXPECT_W'

        figTitle = 'SM_ATR_COLUMN_MEMORY_TEST_1_vs_Threshold'
        ylabel = 'RegVal (Dec)'
        numDataCols = 4  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 10
        yFontsize = 6
        xFontsize = 8
        legFontSize = 6
        df = dataFrame
        ULcolor = '#ff0000'
        LLcolor = '#0000ff'

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), th1, th2], title=eval("d" + str(x)) + ' vs. ' + th1 + ' & ' + th2,
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), th1, th2], title=eval("d" + str(x)) + ' vs. ' + th1 + ' & ' + th2, legend=groupBy,
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_ATR_COLUMN_MEMORY_TEST_2(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ATR_CHECK_MT_EXPECT2'
        d2 = 'ASIL_PIN_ENABLES_06'
        d3 = 'ASIL_CHECK_ENABLES_06'
        d4 = 'ASIL_STATUS_06'
        d5 = 'ASIL_STATUS_06__FAIL_BW'
        d6 = 'ASIL_STATUS_06__FAIL_WB'

        figTitle = 'SM_ATR_COLUMN_MEMORY_TEST_2'
        ylabel = 'RegVal (Dec)'
        numDataCols = 7  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_ATR_COLUMN_MEMORY_TEST_2_vs_Threshold(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'COL_MEM_2 mean'
        d2 = 'COL_MEM_2 max'
        d3 = 'COL_MEM_2 min'
        th1 = 'ATR_CHECK_MT_EXPECT_B'
        th2 = 'ATR_CHECK_MT_EXPECT_W'

        figTitle = 'SM_ATR_COLUMN_MEMORY_TEST_2_vs_Threshold'
        ylabel = 'RegVal (Dec)'
        numDataCols = 4  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 10
        yFontsize = 6
        xFontsize = 8
        legFontSize = 6
        df = dataFrame
        ULcolor = '#ff0000'
        LLcolor = '#0000ff'

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), th1, th2], title=eval("d" + str(x)) + ' vs. ' + th1 + ' & ' + th2,
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), th1, th2], title=eval("d" + str(x)) + ' vs. ' + th1 + ' & ' + th2, legend=groupBy,
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_ATR_COLUMN_MEMORY_TEST_3(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ATR_CHECK_MT_EXPECT_B'
        d2 = 'ATR_CHECK_MT_EXPECT_W'
        d3 = 'ASIL_PIN_ENABLES_06'
        d4 = 'ASIL_CHECK_ENABLES_06'
        d5 = 'ASIL_STATUS_06'
        d6 = 'ASIL_STATUS_06__FAIL_BW'
        d7 = 'ASIL_STATUS_06__FAIL_WB'

        figTitle = 'SM_ATR_COLUMN_MEMORY_TEST_3'
        ylabel = 'RegVal (Dec)'
        numDataCols = 8  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, 3, 2):  # 1 to 3 to plot similar thresholds
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, 3, 2):  # 1 to 3 to plot similar thresholds
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         legend=groupBy, show=showPlt,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_ATR_COLUMN_MEMORY_TEST_3_vs_Threshold(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'COL_MEM_3 mean'
        d2 = 'COL_MEM_3 max'
        d3 = 'COL_MEM_3 min'
        th1 = 'ATR_CHECK_MT_EXPECT_PIXOUT'

        figTitle = 'SM_ATR_COLUMN_MEMORY_TEST_3_vs_Threshold'
        ylabel = 'RegVal (Dec)'
        numDataCols = 4  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 10
        yFontsize = 6
        xFontsize = 8
        legFontSize = 6
        df = dataFrame
        ULcolor = '#ff0000'
        LLcolor = '#0000ff'

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), th1], title=eval("d" + str(x)) + ' vs. ' + th1,
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), th1], title=eval("d" + str(x)) + ' vs. ' + th1, legend=groupBy,
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_ATR_ZEBRA_AB(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ATR_CHECK_ZT_LO_THRESH'
        d2 = 'ATR_CHECK_ZT_HI_THRESH'
        d3 = 'ASIL_PIN_ENABLES_01'
        d4 = 'ASIL_PIN_ENABLES_06'
        d5 = 'ASIL_CHECK_ENABLES_01'
        d6 = 'ASIL_CHECK_ENABLES_06'
        d7 = 'ASIL_STATUS_01'
        d8 = 'ASIL_STATUS_01__FAIL_ZEBRA_AB_PIXEL_LEGAL'
        d9 = 'ASIL_STATUS_01__FAIL_ZEBRA_AB_PIXEL_CORRECT'
        d10 = 'ASIL_STATUS_01__FAIL_ZEBRA_BA_PIXEL_LEGAL'
        d11 = 'ASIL_STATUS_01__FAIL_ZEBRA_BA_PIXEL_CORRECT'
        d12 = 'ASIL_STATUS_06'
        d13 = 'ASIL_STATUS_06__FAIL_BW'
        d14 = 'ASIL_STATUS_06__FAIL_WB'

        figTitle = 'SM_ATR_ZEBRA_AB'
        ylabel = 'RegVal (Dec)'
        numDataCols = 15  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, 3, 2):  # 1 to 3 to plot similar thresholds
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, 3, 2):  # 1 to 3 to plot similar thresholds
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         legend=groupBy, show=showPlt,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_ATR_ZEBRA_AB_vs_Threshold(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ZEBRA_BW mean'
        d2 = 'ZEBRA_BW max'
        d3 = 'ZEBRA_BW min'

        figTitle = 'SM_ATR_ZEBRA_AB_vs_Threshold'
        ylabel = 'RegVal (Dec)'
        numDataCols = 4  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 10
        yFontsize = 6
        xFontsize = 8
        legFontSize = 6
        df = dataFrame
        ULcolor = '#ff0000'
        LLcolor = '#0000ff'

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols, 3):  # 1 to numcols by 3
                n1 = eval("d" + str(x))
                n2 = eval("d" + str(x + 1))
                n3 = eval("d" + str(x + 2))
                dname1 = n1.split()
                dname2 = n2.split()
                dname3 = n3.split()
                if x != 1:  # All other ATR Results
                    fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1)), eval("d" + str(x + 2))],
                             title=dname1[0] + ' ' + dname1[1] + ', ' + dname2[1] + ', ' + dname3[1],
                             show=showPlt, inline=showPlt, label_y=ylabel,
                             title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                             legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + eval(
                            "d" + str(x + 2)) + '_' + timestamp + '.png')
                    document.add_heading(dname1[0] + ' ' + dname1[1] + ', ' + dname2[1] + ', ' + dname3[1], level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + eval("d" + str(x + 2))
                                         + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            for x in range(1, numDataCols, 3):  # 1 to numcols by 3
                n1 = eval("d" + str(x))
                n2 = eval("d" + str(x + 1))
                n3 = eval("d" + str(x + 2))
                dname1 = n1.split()
                dname2 = n2.split()
                dname3 = n3.split()
                if x != 1:  # All other ATR Results
                    fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1)), eval("d" + str(x + 2))],
                             title=dname1[0] + ' ' + dname1[1] + ', ' + dname2[1] + ', ' + dname3[1], legend=groupBy,
                             show=showPlt, inline=showPlt, label_y=ylabel,
                             title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                             legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + eval(
                            "d" + str(x + 2)) + '_' + timestamp + '.png')
                    document.add_heading(dname1[0] + ' ' + dname1[1] + ', ' + dname2[1] + ', ' + dname3[1], level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + eval("d" + str(x + 2))
                                         + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_ATR_ZEBRA_BA(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ATR_CHECK_ZT_LO_THRESH'
        d2 = 'ATR_CHECK_ZT_HI_THRESH'
        d3 = 'ASIL_PIN_ENABLES_01'
        d4 = 'ASIL_PIN_ENABLES_06'
        d5 = 'ASIL_CHECK_ENABLES_01'
        d6 = 'ASIL_CHECK_ENABLES_06'
        d7 = 'ASIL_STATUS_01'
        d8 = 'ASIL_STATUS_01__FAIL_ZEBRA_AB_PIXEL_LEGAL'
        d9 = 'ASIL_STATUS_01__FAIL_ZEBRA_AB_PIXEL_CORRECT'
        d10 = 'ASIL_STATUS_01__FAIL_ZEBRA_BA_PIXEL_LEGAL'
        d11 = 'ASIL_STATUS_01__FAIL_ZEBRA_BA_PIXEL_CORRECT'
        d12 = 'ASIL_STATUS_06'
        d13 = 'ASIL_STATUS_06__FAIL_BW'
        d14 = 'ASIL_STATUS_06__FAIL_WB'

        figTitle = 'SM_ATR_ZEBRA_BA'
        ylabel = 'RegVal (Dec)'
        numDataCols = 15  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, 3, 2):  # 1 to 3 to plot similar thresholds
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, 3, 2):  # 1 to 3 to plot similar thresholds
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         legend=groupBy, show=showPlt,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_ATR_ZEBRA_BA_vs_Threshold(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ZEBRA_WB mean'
        d2 = 'ZEBRA_WB max'
        d3 = 'ZEBRA_WB min'

        figTitle = 'SM_ATR_ZEBRA_BA_vs_Threshold'
        ylabel = 'RegVal (Dec)'
        numDataCols = 4  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 10
        yFontsize = 6
        xFontsize = 8
        legFontSize = 6
        df = dataFrame
        ULcolor = '#ff0000'
        LLcolor = '#0000ff'

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols, 3):  # 1 to numcols by 3
                n1 = eval("d" + str(x))
                n2 = eval("d" + str(x + 1))
                n3 = eval("d" + str(x + 2))
                dname1 = n1.split()
                dname2 = n2.split()
                dname3 = n3.split()
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1)), eval("d" + str(x + 2))],
                         title=dname1[0] + ' ' + dname1[1] + ', ' + dname2[1] + ', ' + dname3[1],
                         show=showPlt, inline=showPlt, label_y=ylabel,
                         title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                         legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + eval(
                        "d" + str(x + 2)) + '_' + timestamp + '.png')
                document.add_heading(dname1[0] + ' ' + dname1[1] + ', ' + dname2[1] + ', ' + dname3[1], level=3)
                document.add_picture(
                    pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + eval("d" + str(x + 2))
                    + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            for x in range(1, numDataCols, 3):  # 1 to numcols by 3
                n1 = eval("d" + str(x))
                n2 = eval("d" + str(x + 1))
                n3 = eval("d" + str(x + 2))
                dname1 = n1.split()
                dname2 = n2.split()
                dname3 = n3.split()
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1)), eval("d" + str(x + 2))],
                         title=dname1[0] + ' ' + dname1[1] + ', ' + dname2[1] + ', ' + dname3[1], legend=groupBy,
                         show=showPlt, inline=showPlt, label_y=ylabel,
                         title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                         legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + eval(
                        "d" + str(x + 2)) + '_' + timestamp + '.png')
                document.add_heading(dname1[0] + ' ' + dname1[1] + ', ' + dname2[1] + ', ' + dname3[1], level=3)
                document.add_picture(
                    pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + eval("d" + str(x + 2))
                    + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_ATR_OVERDRIVE_1(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ATR_CHECK_OT1_HI_THRESH'
        d2 = 'ATR_CHECK_OT1_LO_THRESH'
        d3 = 'ASIL_PIN_ENABLES_01'
        d4 = 'ASIL_CHECK_ENABLES_01'
        d5 = 'ASIL_STATUS_01'
        d6 = 'ASIL_STATUS_01__FAIL_OT1_PIXEL_LOW'
        d7 = 'ASIL_STATUS_01__FAIL_OT1_PIXEL_HIGH'

        figTitle = 'SM_ATR_OVERDRIVE_1'
        ylabel = 'RegVal (Dec)'
        numDataCols = 8  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, 3, 2):  # 1 to 3 to plot similar thresholds
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, 3, 2):  # 1 to 3 to plot similar thresholds
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         legend=groupBy, show=showPlt,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_ATR_OVERDRIVE_1_vs_Threshold(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'OVDRV_SHR_1 mean'
        d2 = 'OVDRV_SHR_1 max'
        d3 = 'OVDRV_SHR_1 min'
        th1 = 'ATR_CHECK_OT1_HI_THRESH'
        th2 = 'ATR_CHECK_OT1_LO_THRESH'

        figTitle = 'SM_ATR_OVERDRIVE_1_vs_Threshold'
        ylabel = 'RegVal (Dec)'
        numDataCols = 4  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 10
        yFontsize = 6
        xFontsize = 8
        legFontSize = 6
        df = dataFrame
        ULcolor = '#ff0000'
        LLcolor = '#0000ff'

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), th1, th2],
                         title=eval("d" + str(x)) + ' vs. ' + th1 + ' & ' + th2,
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), th1, th2],
                         title=eval("d" + str(x)) + ' vs. ' + th1 + ' & ' + th2, legend=groupBy,
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_ATR_OVERDRIVE_2(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ATR_CHECK_OT2_HI_THRESH'
        d2 = 'ATR_CHECK_OT2_LO_THRESH'
        d3 = 'ASIL_PIN_ENABLES_01'
        d4 = 'ASIL_CHECK_ENABLES_01'
        d5 = 'ASIL_STATUS_01'
        d6 = 'ASIL_STATUS_01__FAIL_OT2_PIXEL_LOW'
        d7 = 'ASIL_STATUS_01__FAIL_OT2_PIXEL_HIGH'

        figTitle = 'SM_ATR_OVERDRIVE_2'
        ylabel = 'RegVal (Dec)'
        numDataCols = 8  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, 3, 2):  # 1 to 3 to plot similar thresholds
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, 3, 2):  # 1 to 3 to plot similar thresholds
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         legend=groupBy, show=showPlt,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_ATR_OVERDRIVE_2_vs_Threshold(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'OVDRV_SHR_2 mean'
        d2 = 'OVDRV_SHR_2 max'
        d3 = 'OVDRV_SHR_2 min'
        th1 = 'ATR_CHECK_OT2_HI_THRESH'
        th2 = 'ATR_CHECK_OT2_LO_THRESH'

        figTitle = 'SM_ATR_OVERDRIVE_2_vs_Threshold'
        ylabel = 'RegVal (Dec)'
        numDataCols = 4  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 10
        yFontsize = 6
        xFontsize = 8
        legFontSize = 6
        df = dataFrame
        ULcolor = '#ff0000'
        LLcolor = '#0000ff'

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), th1, th2], title=eval("d" + str(x)) + ' vs. ' + th1 + ' & ' + th2,
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), th1, th2], title=eval("d" + str(x)) + ' vs. ' + th1 + ' & ' + th2, legend=groupBy,
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_ATR_OVERDRIVE_3(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ATR_CHECK_OT3_HI_THRESH'
        d2 = 'ATR_CHECK_OT3_LO_THRESH'
        d3 = 'ASIL_PIN_ENABLES_05'
        d4 = 'ASIL_CHECK_ENABLES_05'
        d5 = 'ASIL_STATUS_05'
        d6 = 'ASIL_STATUS_05__FAIL_OT3_PIXEL_LOW'
        d7 = 'ASIL_STATUS_05__FAIL_OT3_PIXEL_HIGH'

        figTitle = 'SM_ATR_OVERDRIVE_3'
        ylabel = 'RegVal (Dec)'
        numDataCols = 8  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, 3, 2):  # 1 to 3 to plot similar thresholds
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, 3, 2):  # 1 to 3 to plot similar thresholds
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         legend=groupBy, show=showPlt,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_ATR_OVERDRIVE_3_vs_Threshold(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'OVDRV_SHR_3 mean'
        d2 = 'OVDRV_SHR_3 max'
        d3 = 'OVDRV_SHR_3 min'
        th1 = 'ATR_CHECK_OT3_HI_THRESH'
        th2 = 'ATR_CHECK_OT3_LO_THRESH'

        figTitle = 'SM_ATR_OVERDRIVE_3_vs_Threshold'
        ylabel = 'RegVal (Dec)'
        numDataCols = 4  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 10
        yFontsize = 6
        xFontsize = 8
        legFontSize = 6
        df = dataFrame
        ULcolor = '#ff0000'
        LLcolor = '#0000ff'

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), th1, th2],
                         title=eval("d" + str(x)) + ' vs. ' + th1 + ' & ' + th2,
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), th1, th2],
                         title=eval("d" + str(x)) + ' vs. ' + th1 + ' & ' + th2, legend=groupBy,
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_ATR_OVERDRIVE_4(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ATR_CHECK_OT4_HI_THRESH'
        d2 = 'ATR_CHECK_OT4_LO_THRESH'
        d3 = 'ASIL_PIN_ENABLES_05'
        d4 = 'ASIL_CHECK_ENABLES_05'
        d5 = 'ASIL_STATUS_05'
        d6 = 'ASIL_STATUS_05__FAIL_OT4_PIXEL_LOW'
        d7 = 'ASIL_STATUS_05__FAIL_OT4_PIXEL_HIGH'

        figTitle = 'SM_ATR_OVERDRIVE_4'
        ylabel = 'RegVal (Dec)'
        numDataCols = 8  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, 3, 2):  # 1 to 3 to plot similar thresholds
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, 3, 2):  # 1 to 3 to plot similar thresholds
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         legend=groupBy, show=showPlt,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_ATR_OVERDRIVE_4_vs_Threshold(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'OVDRV_CODE_0 mean'
        d2 = 'OVDRV_CODE_0 max'
        d3 = 'OVDRV_CODE_0 min'
        th1 = 'ATR_CHECK_OT4_HI_THRESH'
        th2 = 'ATR_CHECK_OT4_LO_THRESH'

        figTitle = 'SM_ATR_OVERDRIVE_4_vs_Threshold'
        ylabel = 'RegVal (Dec)'
        numDataCols = 4  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 10
        yFontsize = 6
        xFontsize = 8
        legFontSize = 6
        df = dataFrame
        ULcolor = '#ff0000'
        LLcolor = '#0000ff'

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), th1, th2], title=eval("d" + str(x)) + ' vs. ' + th1 + ' & ' + th2,
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), th1, th2], title=eval("d" + str(x)) + ' vs. ' + th1 + ' & ' + th2, legend=groupBy,
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_ATR_OVERDRIVE_5(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ATR_CHECK_OT5_HI_THRESH'
        d2 = 'ATR_CHECK_OT5_LO_THRESH'
        d3 = 'ASIL_PIN_ENABLES_05'
        d4 = 'ASIL_CHECK_ENABLES_05'
        d5 = 'ASIL_STATUS_05'
        d6 = 'ASIL_STATUS_05__FAIL_OT5_PIXEL_LOW'
        d7 = 'ASIL_STATUS_05__FAIL_OT5_PIXEL_HIGH'

        figTitle = 'SM_ATR_OVERDRIVE_5'
        ylabel = 'RegVal (Dec)'
        numDataCols = 8  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, 3, 2):  # 1 to 3 to plot similar thresholds
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, 3, 2):  # 1 to 3 to plot similar thresholds
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         legend=groupBy, show=showPlt,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_ATR_OVERDRIVE_5_vs_Threshold(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'OVDRV_CODE_1 mean'
        d2 = 'OVDRV_CODE_1 max'
        d3 = 'OVDRV_CODE_1 min'
        th1 = 'ATR_CHECK_OT5_HI_THRESH'
        th2 = 'ATR_CHECK_OT5_LO_THRESH'

        figTitle = 'SM_ATR_OVERDRIVE_5_vs_Threshold'
        ylabel = 'RegVal (Dec)'
        numDataCols = 4  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 10
        yFontsize = 6
        xFontsize = 8
        legFontSize = 6
        df = dataFrame
        ULcolor = '#ff0000'
        LLcolor = '#0000ff'

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), th1, th2], title=eval("d" + str(x)) + ' vs. ' + th1 + ' & ' + th2,
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), th1, th2], title=eval("d" + str(x)) + ' vs. ' + th1 + ' & ' + th2, legend=groupBy,
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_ATR_OVERDRIVE_6(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ATR_CHECK_OT6_HI_THRESH'
        d2 = 'ATR_CHECK_OT6_LO_THRESH'
        d3 = 'ASIL_PIN_ENABLES_06'
        d4 = 'ASIL_CHECK_ENABLES_06'
        d5 = 'ASIL_STATUS_06'
        d6 = 'ASIL_STATUS_06__FAIL_OT6_LOW'
        d7 = 'ASIL_STATUS_06__FAIL_OT6_HIGH'

        figTitle = 'SM_ATR_OVERDRIVE_6'
        ylabel = 'RegVal (Dec)'
        numDataCols = 8  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, 3, 2):  # 1 to 3 to plot similar thresholds
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, 3, 2):  # 1 to 3 to plot similar thresholds
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         legend=groupBy, show=showPlt,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_ATR_OVERDRIVE_6_vs_Threshold(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'OVDRV_CODE_2 mean'
        d2 = 'OVDRV_CODE_2 max'
        d3 = 'OVDRV_CODE_2 min'
        th1 = 'ATR_CHECK_OT6_HI_THRESH'
        th2 = 'ATR_CHECK_OT6_LO_THRESH'

        figTitle = 'SM_ATR_OVERDRIVE_6_vs_Threshold'
        ylabel = 'RegVal (Dec)'
        numDataCols = 4  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 10
        yFontsize = 6
        xFontsize = 8
        legFontSize = 6
        df = dataFrame
        ULcolor = '#ff0000'
        LLcolor = '#0000ff'

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), th1, th2], title=eval("d" + str(x)) + ' vs. ' + th1 + ' & ' + th2,
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), th1, th2], title=eval("d" + str(x)) + ' vs. ' + th1 + ' & ' + th2, legend=groupBy,
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_ATR_OVERDRIVE_7(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ATR_CHECK_OT7_HI_THRESH'
        d2 = 'ATR_CHECK_OT7_LO_THRESH'
        d3 = 'ASIL_PIN_ENABLES_06'
        d4 = 'ASIL_CHECK_ENABLES_06'
        d5 = 'ASIL_STATUS_06'
        d6 = 'ASIL_STATUS_06__FAIL_OT7_LOW'
        d7 = 'ASIL_STATUS_06__FAIL_OT7_HIGH'

        figTitle = 'SM_ATR_OVERDRIVE_7'
        ylabel = 'RegVal (Dec)'
        numDataCols = 8  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, 3, 2):  # 1 to 3 to plot similar thresholds
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, 3, 2):  # 1 to 3 to plot similar thresholds
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         legend=groupBy, show=showPlt,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_ATR_OVERDRIVE_7_vs_Threshold(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'OVDRV_CODE_3 mean'
        d2 = 'OVDRV_CODE_3 max'
        d3 = 'OVDRV_CODE_3 min'
        th1 = 'ATR_CHECK_OT7_HI_THRESH'
        th2 = 'ATR_CHECK_OT7_LO_THRESH'

        figTitle = 'SM_ATR_OVERDRIVE_7_vs_Threshold'
        ylabel = 'RegVal (Dec)'
        numDataCols = 4  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 10
        yFontsize = 6
        xFontsize = 8
        legFontSize = 6
        df = dataFrame
        ULcolor = '#ff0000'
        LLcolor = '#0000ff'

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), th1, th2], title=eval("d" + str(x)) + ' vs. ' + th1 + ' & ' + th2,
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), th1, th2], title=eval("d" + str(x)) + ' vs. ' + th1 + ' & ' + th2, legend=groupBy,
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_ATR_OVERDRIVE_8(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ATR_CHECK_OT8_HI_THRESH'
        d2 = 'ATR_CHECK_OT8_LO_THRESH'
        d3 = 'ASIL_PIN_ENABLES_06'
        d4 = 'ASIL_CHECK_ENABLES_06'
        d5 = 'ASIL_STATUS_06'
        d6 = 'ASIL_STATUS_06__FAIL_OT8_LOW'
        d7 = 'ASIL_STATUS_06__FAIL_OT8_HIGH'

        figTitle = 'SM_ATR_OVERDRIVE_8'
        ylabel = 'RegVal (Dec)'
        numDataCols = 8  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, 3, 2):  # 1 to 3 to plot similar thresholds
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, 3, 2):  # 1 to 3 to plot similar thresholds
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         legend=groupBy, show=showPlt,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_ATR_OVERDRIVE_8_vs_Threshold(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'OVDRV_CODE_SHS mean'
        d2 = 'OVDRV_CODE_SHS max'
        d3 = 'OVDRV_CODE_SHS min'
        th1 = 'ATR_CHECK_OT8_HI_THRESH'
        th2 = 'ATR_CHECK_OT8_LO_THRESH'

        figTitle = 'SM_ATR_OVERDRIVE_8_vs_Threshold'
        ylabel = 'RegVal (Dec)'
        numDataCols = 4  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 10
        yFontsize = 6
        xFontsize = 8
        legFontSize = 6
        df = dataFrame
        ULcolor = '#ff0000'
        LLcolor = '#0000ff'

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), th1, th2], title=eval("d" + str(x)) + ' vs. ' + th1 + ' & ' + th2,
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), th1, th2], title=eval("d" + str(x)) + ' vs. ' + th1 + ' & ' + th2, legend=groupBy,
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_ATR_GRADIENT(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ATR_CHECK_GRD_HI_THRESH'
        d2 = 'ATR_CHECK_GRD_LO_THRESH'
        d3 = 'TEST_CTRL'
        d4 = 'ASIL_PIN_ENABLES_05'
        d5 = 'ASIL_CHECK_ENABLES_05'
        d6 = 'ASIL_STATUS_05'
        d7 = 'ASIL_STATUS_05__FAIL_GRD_PIXEL_LOW'
        d8 = 'ASIL_STATUS_05__FAIL_GRD_PIXEL_HIGH'

        figTitle = 'SM_ATR_GRADIENT'
        ylabel = 'RegVal (Dec)'
        numDataCols = 9  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, 3, 2):  # 1 to 3 to plot similar thresholds
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, 3, 2):  # 1 to 3 to plot similar thresholds
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         legend=groupBy, show=showPlt,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_ATR_VERT_PIXOUT_1(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ATR_CHECK_PT_HI_THRESH'
        d3 = 'ASIL_PIN_ENABLES_01'
        d4 = 'ASIL_CHECK_ENABLES_01'
        d5 = 'ASIL_STATUS_01'
        d6 = 'ASIL_STATUS_01__FAIL_PT1_BELOW_THRESHOLD'
        d7 = 'ASIL_STATUS_01__FAIL_PT2_ABOVE_THRESHOLD'

        figTitle = 'SM_ATR_VERT_PIXOUT_1'
        ylabel = 'RegVal (Dec)'
        numDataCols = 8  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_ATR_VERT_PIXOUT_1_vs_Threshold(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'VERT_TEST_1 mean'
        d2 = 'VERT_TEST_1 max'
        d3 = 'VERT_TEST_1 min'
        th1 = 'ATR_CHECK_PT_LO_THRESH'
        th2 = 'ATR_CHECK_PT_HI_THRESH'

        figTitle = 'SM_ATR_VERT_PIXOUT_1_vs_Threshold'
        ylabel = 'RegVal (Dec)'
        numDataCols = 4  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 10
        yFontsize = 6
        xFontsize = 8
        legFontSize = 6
        df = dataFrame
        ULcolor = '#ff0000'
        LLcolor = '#0000ff'

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), th1, th2], title=eval("d" + str(x)) + ' vs. ' + th1 + ' & ' + th2,
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), th1, th2], title=eval("d" + str(x)) + ' vs. ' + th1 + ' & ' + th2, legend=groupBy,
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_ATR_VERT_PIXOUT_2(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ATR_CHECK_PT_LO_THRESH'
        d3 = 'ASIL_PIN_ENABLES_01'
        d4 = 'ASIL_CHECK_ENABLES_01'
        d5 = 'ASIL_STATUS_01'
        d6 = 'ASIL_STATUS_01__FAIL_PT1_BELOW_THRESHOLD'
        d7 = 'ASIL_STATUS_01__FAIL_PT2_ABOVE_THRESHOLD'

        figTitle = 'SM_ATR_VERT_PIXOUT_2'
        ylabel = 'RegVal (Dec)'
        numDataCols = 8  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_ATR_VERT_PIXOUT_2_vs_Threshold(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'VERT_TEST_2 mean'
        d2 = 'VERT_TEST_2 max'
        d3 = 'VERT_TEST_2 min'
        th1 = 'ATR_CHECK_PT_LO_THRESH'
        th2 = 'ATR_CHECK_PT_HI_THRESH'

        figTitle = 'SM_ATR_VERT_PIXOUT_2_vs_Threshold'
        ylabel = 'RegVal (Dec)'
        numDataCols = 4  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 10
        yFontsize = 6
        xFontsize = 8
        legFontSize = 6
        df = dataFrame
        ULcolor = '#ff0000'
        LLcolor = '#0000ff'

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), th1, th2], title=eval("d" + str(x)) + ' vs. ' + th1 + ' & ' + th2,
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), th1, th2], title=eval("d" + str(x)) + ' vs. ' + th1 + ' & ' + th2, legend=groupBy,
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_ATR_ECL_COMPARATOR_LOGIC(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ATR_CHECK_MT_EXPECT_EC_COMP'
        d3 = 'ASIL_PIN_ENABLES_06'
        d4 = 'ASIL_CHECK_ENABLES_06'
        d5 = 'ASIL_STATUS_06'
        d6 = 'ASIL_STATUS_06__FAIL_EC_COMP'

        figTitle = 'SM_ATR_ECL_COMPARATOR_LOGIC'
        ylabel = 'RegVal (Dec)'
        numDataCols = 7  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_ATR_ECL_COMPARATOR_LOGIC_vs_Threshold(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ECL_COMP mean'
        d2 = 'ECL_COMP max'
        d3 = 'ECL_COMP min'
        th1 = 'ATR_CHECK_MT_EXPECT_EC_COMP'

        figTitle = 'SM_ATR_ECL_COMPARATOR_LOGIC_vs_Threshold'
        ylabel = 'RegVal (Dec)'
        numDataCols = 4  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 10
        yFontsize = 6
        xFontsize = 8
        legFontSize = 6
        df = dataFrame
        ULcolor = '#ff0000'
        LLcolor = '#0000ff'

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), th1], title=eval("d" + str(x)) + ' vs. ' + th1,
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), th1], title=eval("d" + str(x)) + ' vs. ' + th1, legend=groupBy,
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_ATR_DCDS2(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ATR_CHECK_MT_EXPECT_DCDS2'
        d2 = 'ASIL_PIN_ENABLES_06'
        d3 = 'ASIL_CHECK_ENABLES_06'
        d4 = 'ASIL_STATUS_06'
        d5 = 'ASIL_STATUS_06__FAIL_DCDS2'

        figTitle = 'SM_ATR_DCDS2'
        ylabel = 'RegVal (Dec)'
        numDataCols = 6  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_ATR_DCDS2_vs_Threshold(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'DCDS_2 mean'
        d2 = 'DCDS_2 max'
        d3 = 'DCDS_2 min'
        th1 = 'ATR_CHECK_MT_EXPECT_DCDS2'

        figTitle = 'SM_ATR_DCDS2_vs_Threshold'
        ylabel = 'RegVal (Dec)'
        numDataCols = 4  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 10
        yFontsize = 6
        xFontsize = 8
        legFontSize = 6
        df = dataFrame
        ULcolor = '#ff0000'
        LLcolor = '#0000ff'

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), th1], title=eval("d" + str(x)) + ' vs. ' + th1,
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), th1], title=eval("d" + str(x)) + ' vs. ' + th1, legend=groupBy,
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_ATR_FAULT_INJECTION(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'DAC_LD_34_35'
        d2 = 'DAC_LD_34_35__SREG_AE_FAULT_INJECT_EN'
        d3 = 'DAC_LD_34_35__SREG_AE_FULLFRAME_EN'
        d4 = 'DAC_LD_34_35__SREG_AE_ATR_TEST'
        d5 = 'DAC_LD_34_35__SREG_AE_ATR_TEST_ROW_EN'

        figTitle = 'SM_ATR_FAULT_INJECTION'
        ylabel = 'RegVal (Dec)'
        numDataCols = 6  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found


'''
BMON & VMON SM'S
'''
def SM_BMON_VMON_Supply_Voltage_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'VAA_V'
        d2 = 'VAA_PIX_V'
        d3 = 'VDD_V'
        d4 = 'VAA1V8_V'
        d5 = 'VAA2V8_V'
        d6 = 'VDD_IO_V'
        d7 = 'VDDIO_PHY_V'

        figTitle = 'Supply_Voltage'
        ylabel = 'Voltage [V]'
        numDataCols = 8  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_AHM_BOOSTER_BANDGAP_MONITOR(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'TEMPVSENS0_BOOST_MEAS_0'
        d2 = 'TEMPVSENS0_BOOST_MEAS_1'
        d3 = 'TEMPVSENS0_BOOST_MEAS_2'
        d4 = 'TEMPVSENS0_BOOST_MEAS_3'
        d5 = 'TEMPVSENS0_BOOST_MEAS_4'
        d6 = 'TEMPVSENS0_BOOST_MEAS_5'
        d7 = 'TEMPVSENS0_BOOST_MEAS_6'
        d8 = 'TEMPVSENS0_BOOST_MEAS_7'
        d9 = 'TEMPVSENS0_BOOST_MEAS_8'
        d10 = 'TEMPVSENS0_BOOST_MEAS_9'
        d11 = 'TEMPVSENS0_BOOST_MEAS_10'
        d12 = 'TEMPVSENS0_BOOST_MEAS_11'
        d13 = 'TEMPVSENS0_BOOST_MEAS_12'
        d14 = 'TEMPVSENS0_BOOST_MEAS_13'
        d15 = 'TEMPVSENS0_BOOST_MEAS_14'
        d16 = 'TEMPVSENS0_BOOST_MEAS_15'
        d17 = 'TEMPVSENS0_BOOST_MEAS_16'
        d18 = 'TEMPVSENS0_BOOST_MEAS_17'
        d19 = 'TEMPVSENS0_BOOST_MEAS_18'
        d20 = 'TEMPVSENS0_BOOST_MEAS_19'
        d21 = 'TEMPVSENS0_BOOST_MEAS_20'
        d22 = 'TEMPVSENS0_BOOST_MEAS_21'
        d23 = 'TEMPVSENS0_BOOST_MEAS_22'
        d24 = 'TEMPVSENS0_BOOST_MEAS_23'
        d25 = 'TEMPVSENS0_BOOST_MEAS_24'
        d26 = 'TEMPVSENS0_BOOST_MEAS_25'
        d27 = 'TEMPVSENS0_BOOST_MEAS_26'
        d28 = 'TEMPVSENS0_BOOST_MEAS_27'
        d29 = 'TEMPVSENS0_BOOST_MEAS_28'
        d30 = 'TEMPVSENS0_BOOST_MEAS_29'
        d31 = 'TEMPVSENS0_BOOST_MEAS_30'
        d32 = 'TEMPVSENS0_BOOST_MEAS_31'
        d33 = 'TEMPVSENS0_BOOST_MEAS_32'
        d34 = 'TEMPVSENS0_BOOST_MEAS_33'
        d35 = 'TEMPVSENS0_BOOST_MEAS_34'
        d36 = 'TEMPVSENS0_BOOST_MEAS_35'
        d37 = 'TEMPVSENS0_BOOST_MEAS_36'
        d38 = 'TEMPVSENS0_BOOST_MEAS_37'
        d39 = 'TEMPVSENS0_BOOST_MEAS_38'
        d40 = 'TEMPVSENS0_BOOST_MEAS_39'
        d41 = 'TEMPVSENS0_BOOST_MEAS_40'
        d42 = 'TEMPVSENS0_BOOST_MEAS_41'
        d43 = 'TEMPVSENS0_BOOST_MEAS_42'
        d44 = 'TEMPVSENS0_BOOST_MEAS_43'
        d45 = 'TEMPVSENS0_BOOST_MEAS_44'
        d46 = 'TEMPVSENS0_BOOST_MEAS_45'
        d47 = 'TEMPVSENS0_BOOST_MEAS_46'
        d48 = 'TEMPVSENS0_BOOST_MEAS_47'
        d49 = 'TEMPVSENS0_BOOST_MEAS_48'

        figTitle = 'SM_AHM_BOOSTER_BANDGAP_MONITOR'
        ylabel = 'RegVal (Dec)'
        numDataCols = 50  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_AHM_BOOSTER_BANDGAP_MONITOR_NAMES(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'VHI_BMON_0'
        d2 = 'VCONN_FDHI_BMON_1'
        d3 = 'VCONN_LGHI_BMON_2'
        d4 = 'VCONN_LGSTHI_BMON_3'
        d5 = 'VCONN_VDDHI_BMON_4'
        d6 = 'VROW_SELHI_BMON_5'
        d7 = 'VSGHI_BMON_6'
        d8 = 'VTX0HI_BMON_7'
        d9 = 'VTX1HI_BMON_8'
        d10 = 'VTX_LGHI_BMON_9'
        d11 = 'VDDHILOGICL_BMON_10'
        d12 = 'VLO_BMON_11'
        d13 = 'VCONN_FDLO_BMON_12'
        d14 = 'VCONN_LGLO_BMON_13'
        d15 = 'VCONN_LGSTLO_BMON_14'
        d16 = 'VCONN_VDDLO_BMON_15'
        d17 = 'VSGLO_BMON_16'
        d18 = 'VTX0LO_BMON_17'
        d19 = 'VTX1LO_BMON_18'
        d20 = 'VTX_LGLO_BMON_19'
        d21 = 'VCONN_FDLO_SEL_BMON_20'
        d22 = 'VCONN_LGLO_SEL_BMON_21'
        d23 = 'VCONN_LGSTLO_SEL_BMON_22'
        d24 = 'VCONN_VDDLO_SEL_BMON_23'
        d25 = 'VSGLO_SEL_BMON_24'
        d26 = 'VTX0LO_SEL_BMON_25'
        d27 = 'VTX1LO_SEL_BMON_26'
        d28 = 'VTX_LGLO_SEL_BMON_27'
        d29 = 'VSSLOGIC_BMON_28'
        d30 = 'VLOPWELL_BMON_29'
        d31 = 'VSSHILOGIC_BMON_30'
        d32 = 'VCONN_LGMID_BMON_31'
        d33 = 'VTX_LGMID_BMON_32'
        d34 = 'VTX1MID_BMON_33'
        d35 = 'VAA_BMON_34'
        d36 = 'VAAPIX_BMON_35'
        d37 = 'VDDIO_BMON_36'
        d38 = 'V1P8_BMON_37'
        d39 = 'V1P8LOGIC_BMON_38'
        d40 = 'V1P8_MIPI_BMON_39'
        d41 = 'DVDD1V2_BMON_40'

        figTitle = 'SM_AHM_BOOSTER_BANDGAP_MONITOR_NAMES'
        ylabel = 'RegVal (Dec)'
        numDataCols = 42  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_AHM_BOOSTER_BANDGAP_MONITOR_NAMES_vs_Time_Plot(dataFrame, groupCol, groupVal, document, pltPath, showPlt, **kwargs):
    try:

        if groupCol == None and groupVal == None:  #Dont group data frame
            df = dataFrame
        elif groupCol != None and groupVal != None: #Group data frame by col and value
            df = VRG_Data_Frame.newdataframe(dataFrame, groupCol, groupVal)

        d1 = 'VHI_BMON_0 Read'
        d2 = 'VCONN_FDHI_BMON_1 Read'
        d3 = 'VCONN_LGHI_BMON_2 Read'
        d4 = 'VCONN_LGSTHI_BMON_3 Read'
        d5 = 'VCONN_VDDHI_BMON_4 Read'
        d6 = 'VROW_SELHI_BMON_5 Read'
        d7 = 'VSGHI_BMON_6 Read'
        d8 = 'VTX0HI_BMON_7 Read'
        d9 = 'VTX1HI_BMON_8 Read'
        d10 = 'VTX_LGHI_BMON_9 Read'
        d11 = 'VDDHILOGICL_BMON_10 Read'
        d12 = 'VLO_BMON_11 Read'
        d13 = 'VCONN_FDLO_BMON_12 Read'
        d14 = 'VCONN_LGLO_BMON_13 Read'
        d15 = 'VCONN_LGSTLO_BMON_14 Read'
        d16 = 'VCONN_VDDLO_BMON_15 Read'
        d17 = 'VSGLO_BMON_16 Read'
        d18 = 'VTX0LO_BMON_17 Read'
        d19 = 'VTX1LO_BMON_18 Read'
        d20 = 'VTX_LGLO_BMON_19 Read'
        d21 = 'VCONN_FDLO_SEL_BMON_20 Read'
        d22 = 'VCONN_LGLO_SEL_BMON_21 Read'
        d23 = 'VCONN_LGSTLO_SEL_BMON_22 Read'
        d24 = 'VCONN_VDDLO_SEL_BMON_23 Read'
        d25 = 'VSGLO_SEL_BMON_24 Read'
        d26 = 'VTX0LO_SEL_BMON_25 Read'
        d27 = 'VTX1LO_SEL_BMON_26 Read'
        d28 = 'VTX_LGLO_SEL_BMON_27 Read'
        d29 = 'VSSLOGIC_BMON_28 Read'
        d30 = 'VLOPWELL_BMON_29 Read'
        d31 = 'VSSHILOGIC_BMON_30 Read'
        d32 = 'VCONN_LGMID_BMON_31 Read'
        d33 = 'VTX_LGMID_BMON_32 Read'
        d34 = 'VTX1MID_BMON_33 Read'
        d35 = 'VAA_BMON_34 Read'
        d36 = 'VAAPIX_BMON_35 Read'
        d37 = 'VDDIO_BMON_36 Read'
        d38 = 'V1P8_BMON_37 Read'
        d39 = 'V1P8LOGIC_BMON_38 Read'
        d40 = 'V1P8_MIPI_BMON_39 Read'
        d41 = 'DVDD1V2_BMON_40 Read'

        # get data columns
        t1_cols = [x for x in df.columns[df.columns.str.contains(d1)]]
        t2_cols = [x for x in df.columns[df.columns.str.contains(d2)]]
        t3_cols = [x for x in df.columns[df.columns.str.contains(d3)]]
        t4_cols = [x for x in df.columns[df.columns.str.contains(d4)]]
        t5_cols = [x for x in df.columns[df.columns.str.contains(d5)]]
        t6_cols = [x for x in df.columns[df.columns.str.contains(d6)]]
        t7_cols = [x for x in df.columns[df.columns.str.contains(d7)]]
        t8_cols = [x for x in df.columns[df.columns.str.contains(d8)]]
        t9_cols = [x for x in df.columns[df.columns.str.contains(d9)]]
        t10_cols = [x for x in df.columns[df.columns.str.contains(d10)]]
        t11_cols = [x for x in df.columns[df.columns.str.contains(d11)]]
        t12_cols = [x for x in df.columns[df.columns.str.contains(d12)]]
        t13_cols = [x for x in df.columns[df.columns.str.contains(d13)]]
        t14_cols = [x for x in df.columns[df.columns.str.contains(d14)]]
        t15_cols = [x for x in df.columns[df.columns.str.contains(d15)]]
        t16_cols = [x for x in df.columns[df.columns.str.contains(d16)]]
        t17_cols = [x for x in df.columns[df.columns.str.contains(d17)]]
        t18_cols = [x for x in df.columns[df.columns.str.contains(d18)]]
        t19_cols = [x for x in df.columns[df.columns.str.contains(d19)]]
        t20_cols = [x for x in df.columns[df.columns.str.contains(d20)]]
        t21_cols = [x for x in df.columns[df.columns.str.contains(d21)]]
        t22_cols = [x for x in df.columns[df.columns.str.contains(d22)]]
        t23_cols = [x for x in df.columns[df.columns.str.contains(d23)]]
        t24_cols = [x for x in df.columns[df.columns.str.contains(d24)]]
        t25_cols = [x for x in df.columns[df.columns.str.contains(d25)]]
        t26_cols = [x for x in df.columns[df.columns.str.contains(d26)]]
        t27_cols = [x for x in df.columns[df.columns.str.contains(d27)]]
        t28_cols = [x for x in df.columns[df.columns.str.contains(d28)]]
        t29_cols = [x for x in df.columns[df.columns.str.contains(d29)]]
        t30_cols = [x for x in df.columns[df.columns.str.contains(d30)]]
        t31_cols = [x for x in df.columns[df.columns.str.contains(d31)]]
        t32_cols = [x for x in df.columns[df.columns.str.contains(d32)]]
        t33_cols = [x for x in df.columns[df.columns.str.contains(d33)]]
        t34_cols = [x for x in df.columns[df.columns.str.contains(d34)]]
        t35_cols = [x for x in df.columns[df.columns.str.contains(d35)]]
        t36_cols = [x for x in df.columns[df.columns.str.contains(d36)]]
        t37_cols = [x for x in df.columns[df.columns.str.contains(d37)]]
        t38_cols = [x for x in df.columns[df.columns.str.contains(d38)]]
        t39_cols = [x for x in df.columns[df.columns.str.contains(d39)]]
        t40_cols = [x for x in df.columns[df.columns.str.contains(d40)]]
        t41_cols = [x for x in df.columns[df.columns.str.contains(d41)]]

        # subset df
        t1 = df[t1_cols]
        t2 = df[t2_cols]
        t3 = df[t3_cols]
        t4 = df[t4_cols]
        t5 = df[t5_cols]
        t6 = df[t6_cols]
        t7 = df[t7_cols]
        t8 = df[t8_cols]
        t9 = df[t9_cols]
        t10 = df[t10_cols]
        t11 = df[t11_cols]
        t12 = df[t12_cols]
        t13 = df[t13_cols]
        t14 = df[t14_cols]
        t15 = df[t15_cols]
        t16 = df[t16_cols]
        t17 = df[t17_cols]
        t18 = df[t18_cols]
        t19 = df[t19_cols]
        t20 = df[t20_cols]
        t21 = df[t21_cols]
        t22 = df[t22_cols]
        t23 = df[t23_cols]
        t24 = df[t24_cols]
        t25 = df[t25_cols]
        t26 = df[t26_cols]
        t27 = df[t27_cols]
        t28 = df[t28_cols]
        t29 = df[t29_cols]
        t30 = df[t30_cols]
        t31 = df[t31_cols]
        t32 = df[t32_cols]
        t33 = df[t33_cols]
        t34 = df[t34_cols]
        t35 = df[t35_cols]
        t36 = df[t36_cols]
        t37 = df[t37_cols]
        t38 = df[t38_cols]
        t39 = df[t39_cols]
        t40 = df[t40_cols]
        t41 = df[t41_cols]

        # rename columns to get read number
        for dc in t1_cols:
            t1 = t1.rename(columns={dc: dc.split(' ')[2]})
        for dc in t2_cols:
            t2 = t2.rename(columns={dc: dc.split(' ')[2]})
        for dc in t3_cols:
            t3 = t3.rename(columns={dc: dc.split(' ')[2]})
        for dc in t4_cols:
            t4 = t4.rename(columns={dc: dc.split(' ')[2]})
        for dc in t5_cols:
            t5 = t5.rename(columns={dc: dc.split(' ')[2]})
        for dc in t6_cols:
            t6 = t6.rename(columns={dc: dc.split(' ')[2]})
        for dc in t7_cols:
            t7 = t7.rename(columns={dc: dc.split(' ')[2]})
        for dc in t8_cols:
            t8 = t8.rename(columns={dc: dc.split(' ')[2]})
        for dc in t9_cols:
            t9 = t9.rename(columns={dc: dc.split(' ')[2]})
        for dc in t10_cols:
            t10 = t10.rename(columns={dc: dc.split(' ')[2]})
        for dc in t11_cols:
            t11 = t11.rename(columns={dc: dc.split(' ')[2]})
        for dc in t12_cols:
            t12 = t12.rename(columns={dc: dc.split(' ')[2]})
        for dc in t13_cols:
            t13 = t13.rename(columns={dc: dc.split(' ')[2]})
        for dc in t14_cols:
            t14 = t14.rename(columns={dc: dc.split(' ')[2]})
        for dc in t15_cols:
            t15 = t15.rename(columns={dc: dc.split(' ')[2]})
        for dc in t16_cols:
            t16 = t16.rename(columns={dc: dc.split(' ')[2]})
        for dc in t17_cols:
            t17 = t17.rename(columns={dc: dc.split(' ')[2]})
        for dc in t18_cols:
            t18 = t18.rename(columns={dc: dc.split(' ')[2]})
        for dc in t19_cols:
            t19 = t19.rename(columns={dc: dc.split(' ')[2]})
        for dc in t20_cols:
            t20 = t20.rename(columns={dc: dc.split(' ')[2]})
        for dc in t21_cols:
            t21 = t21.rename(columns={dc: dc.split(' ')[2]})
        for dc in t22_cols:
            t22 = t22.rename(columns={dc: dc.split(' ')[2]})
        for dc in t23_cols:
            t23 = t23.rename(columns={dc: dc.split(' ')[2]})
        for dc in t24_cols:
            t24 = t24.rename(columns={dc: dc.split(' ')[2]})
        for dc in t25_cols:
            t25 = t25.rename(columns={dc: dc.split(' ')[2]})
        for dc in t26_cols:
            t26 = t26.rename(columns={dc: dc.split(' ')[2]})
        for dc in t27_cols:
            t27 = t27.rename(columns={dc: dc.split(' ')[2]})
        for dc in t28_cols:
            t28 = t28.rename(columns={dc: dc.split(' ')[2]})
        for dc in t29_cols:
            t29 = t29.rename(columns={dc: dc.split(' ')[2]})
        for dc in t30_cols:
            t30 = t30.rename(columns={dc: dc.split(' ')[2]})
        for dc in t31_cols:
            t31 = t31.rename(columns={dc: dc.split(' ')[2]})
        for dc in t32_cols:
            t32 = t32.rename(columns={dc: dc.split(' ')[2]})
        for dc in t33_cols:
            t33 = t33.rename(columns={dc: dc.split(' ')[2]})
        for dc in t34_cols:
            t34 = t34.rename(columns={dc: dc.split(' ')[2]})
        for dc in t35_cols:
            t35 = t35.rename(columns={dc: dc.split(' ')[2]})
        for dc in t36_cols:
            t36 = t36.rename(columns={dc: dc.split(' ')[2]})
        for dc in t37_cols:
            t37 = t37.rename(columns={dc: dc.split(' ')[2]})
        for dc in t38_cols:
            t38 = t38.rename(columns={dc: dc.split(' ')[2]})
        for dc in t39_cols:
            t39 = t39.rename(columns={dc: dc.split(' ')[2]})
        for dc in t40_cols:
            t40 = t40.rename(columns={dc: dc.split(' ')[2]})
        for dc in t41_cols:
            t41 = t41.rename(columns={dc: dc.split(' ')[2]})

        # transpose
        t1 = t1.T
        t2 = t2.T
        t3 = t3.T
        t4 = t4.T
        t5 = t5.T
        t6 = t6.T
        t7 = t7.T
        t8 = t8.T
        t9 = t9.T
        t10 = t10.T
        t11 = t11.T
        t12 = t12.T
        t13 = t13.T
        t14 = t14.T
        t15 = t15.T
        t16 = t16.T
        t17 = t17.T
        t18 = t18.T
        t19 = t19.T
        t20 = t20.T
        t21 = t21.T
        t22 = t22.T
        t23 = t23.T
        t24 = t24.T
        t25 = t25.T
        t26 = t26.T
        t27 = t27.T
        t28 = t28.T
        t29 = t29.T
        t30 = t30.T
        t31 = t31.T
        t32 = t32.T
        t33 = t33.T
        t34 = t34.T
        t35 = t35.T
        t36 = t36.T
        t37 = t37.T
        t38 = t38.T
        t39 = t39.T
        t40 = t40.T
        t41 = t41.T

        # add an index column
        t1['Read Num'] = t1.index
        t2['Read Num'] = t2.index
        t3['Read Num'] = t3.index
        t4['Read Num'] = t4.index
        t5['Read Num'] = t5.index
        t6['Read Num'] = t6.index
        t7['Read Num'] = t7.index
        t8['Read Num'] = t8.index
        t9['Read Num'] = t9.index
        t10['Read Num'] = t10.index
        t11['Read Num'] = t11.index
        t12['Read Num'] = t12.index
        t13['Read Num'] = t13.index
        t14['Read Num'] = t14.index
        t15['Read Num'] = t15.index
        t16['Read Num'] = t16.index
        t17['Read Num'] = t17.index
        t18['Read Num'] = t18.index
        t19['Read Num'] = t19.index
        t20['Read Num'] = t20.index
        t21['Read Num'] = t21.index
        t22['Read Num'] = t22.index
        t23['Read Num'] = t23.index
        t24['Read Num'] = t24.index
        t25['Read Num'] = t25.index
        t26['Read Num'] = t26.index
        t27['Read Num'] = t27.index
        t28['Read Num'] = t28.index
        t29['Read Num'] = t29.index
        t30['Read Num'] = t30.index
        t31['Read Num'] = t31.index
        t32['Read Num'] = t32.index
        t33['Read Num'] = t33.index
        t34['Read Num'] = t34.index
        t35['Read Num'] = t35.index
        t36['Read Num'] = t36.index
        t37['Read Num'] = t37.index
        t38['Read Num'] = t38.index
        t39['Read Num'] = t39.index
        t40['Read Num'] = t40.index
        t41['Read Num'] = t41.index

        colList = []
        for index in df.index:
            colList.append(index)

        figTitle = 'SM_AHM_BOOSTER_BANDGAP_MONITOR_vs_Time_Plot'
        numDataCols = 42
        titleFontSize = 12
        yFontsize = 8
        xFontsize = 8
        legFontSize = 6

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupCol == None and groupVal == None:  # No Dataframe grouping
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(eval("t" + str(x)), x='Read Num', y=colList, title=eval("d" + str(x)), legend_title="Test #", show=showPlt,
                         inline=showPlt, label_y=eval("d" + str(x)), title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupCol != None and groupVal != None: # Data frame grouped by col and val
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(eval("t" + str(x)), x='Read Num', y=colList, title=eval("d" + str(x)) + " Groupedby: " + groupCol + ' = ' + str(groupVal), show=showPlt,
                         inline=showPlt, legend_title="Test #", label_y=eval("d" + str(x)), title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        if eval("d" + str(x)) in df.columns:
            document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
        else:
            document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupCol == None:
            document.add_heading("groupCol Not Used", level=3)
        elif groupCol != None:
            if groupCol in df.columns:
                document.add_heading("groupCol Found: " + groupCol, level=3)  # Add Groupby found
                if groupVal == None:
                    document.add_heading("groupVal Missing", level=3)
                elif groupVal != None:
                    if groupCol in df[eval("d" + str(x))].unique():
                        document.add_heading("groupVal Found: " + groupVal, level=3)  # Add Groupby found
                    else:
                        document.add_heading("groupVal Not Found: " + groupVal, level=3)  # Add Groupby not found
            else:
                document.add_heading("groupCol Not Found: " + groupCol, level=3)  # Add Groupby not found

def SM_CHIP_SUPPLY_VOLTAGE_MONITOR(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'TEMPVSENS0_BOOST_MEAS_34'
        d2 = 'TEMPVSENS0_BOOST_MEAS_35'
        d3 = 'TEMPVSENS0_BOOST_MEAS_36'
        d4 = 'TEMPVSENS0_BOOST_MEAS_37'
        d5 = 'TEMPVSENS0_BOOST_MEAS_38'
        d6 = 'TEMPVSENS0_BOOST_MEAS_39'
        d7 = 'TEMPVSENS0_BOOST_MEAS_40'

        figTitle = 'SM_CHIP_SUPPLY_VOLTAGE_MONITOR'
        ylabel = 'RegVal (Dec)'
        numDataCols = 8  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_CHIP_SUPPLY_VOLTAGE_MONITOR_NAMES(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'VAA_BMON_34'
        d2 = 'VAAPIX_BMON_35'
        d3 = 'VDDIO_BMON_36'
        d4 = 'V1P8_BMON_37'
        d5 = 'V1P8LOGIC_BMON_38'
        d6 = 'V1P8_MIPI_BMON_39'
        d7 = 'DVDD1V2_BMON_40'

        figTitle = 'SM_CHIP_SUPPLY_VOLTAGE_MONITOR_NAMES'
        ylabel = 'RegVal (Dec)'
        numDataCols = 8  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_CHIP_SUPPLY_VOLTAGE_MONITOR_NAMES_vs_Time_Plot(dataFrame, groupCol, groupVal, document, pltPath, showPlt, **kwargs):
    try:

        if groupCol == None and groupVal == None:  #Dont group data frame
            df = dataFrame
        elif groupCol != None and groupVal != None: #Group data frame by col and value
            df = VRG_Data_Frame.newdataframe(dataFrame, groupCol, groupVal)

        d1 = 'VAA_BMON_34 Read'
        d2 = 'VAAPIX_BMON_35 Read'
        d3 = 'VDDIO_BMON_36 Read'
        d4 = 'V1P8_BMON_37 Read'
        d5 = 'V1P8LOGIC_BMON_38 Read'
        d6 = 'V1P8_MIPI_BMON_39 Read'
        d7 = 'DVDD1V2_BMON_40 Read'

        # get data columns
        t1_cols = [x for x in df.columns[df.columns.str.contains(d1)]]
        t2_cols = [x for x in df.columns[df.columns.str.contains(d2)]]
        t3_cols = [x for x in df.columns[df.columns.str.contains(d3)]]
        t4_cols = [x for x in df.columns[df.columns.str.contains(d4)]]
        t5_cols = [x for x in df.columns[df.columns.str.contains(d5)]]
        t6_cols = [x for x in df.columns[df.columns.str.contains(d6)]]
        t7_cols = [x for x in df.columns[df.columns.str.contains(d7)]]

        # subset df
        t1 = df[t1_cols]
        t2 = df[t2_cols]
        t3 = df[t3_cols]
        t4 = df[t4_cols]
        t5 = df[t5_cols]
        t6 = df[t6_cols]
        t7 = df[t7_cols]

        # rename columns to get read number
        for dc in t1_cols:
            t1 = t1.rename(columns={dc: dc.split(' ')[2]})
        for dc in t2_cols:
            t2 = t2.rename(columns={dc: dc.split(' ')[2]})
        for dc in t3_cols:
            t3 = t3.rename(columns={dc: dc.split(' ')[2]})
        for dc in t4_cols:
            t4 = t4.rename(columns={dc: dc.split(' ')[2]})
        for dc in t5_cols:
            t5 = t5.rename(columns={dc: dc.split(' ')[2]})
        for dc in t6_cols:
            t6 = t6.rename(columns={dc: dc.split(' ')[2]})
        for dc in t7_cols:
            t7 = t7.rename(columns={dc: dc.split(' ')[2]})

        # transpose
        t1 = t1.T
        t2 = t2.T
        t3 = t3.T
        t4 = t4.T
        t5 = t5.T
        t6 = t6.T
        t7 = t7.T

        # add an index column
        t1['Read Num'] = t1.index
        t2['Read Num'] = t2.index
        t3['Read Num'] = t3.index
        t4['Read Num'] = t4.index
        t5['Read Num'] = t5.index
        t6['Read Num'] = t6.index
        t7['Read Num'] = t7.index

        colList = []
        for index in df.index:
            colList.append(index)

        figTitle = 'SM_CHIP_SUPPLY_VOLTAGE_MONITOR_vs_Time_Plot'
        numDataCols = 8
        titleFontSize = 12
        yFontsize = 8
        xFontsize = 8
        legFontSize = 6

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupCol == None and groupVal == None:  # No Dataframe grouping
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(eval("t" + str(x)), x='Read Num', y=colList, title=eval("d" + str(x)), legend_title="Test #", show=showPlt,
                         inline=showPlt, label_y=eval("d" + str(x)), title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupCol != None and groupVal != None: # Data frame grouped by col and val
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(eval("t" + str(x)), x='Read Num', y=colList, title=eval("d" + str(x)) + " Groupedby: " + groupCol + ' = ' + str(groupVal), show=showPlt,
                         inline=showPlt, legend_title="Test #", label_y=eval("d" + str(x)), title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        if eval("d" + str(x)) in df.columns:
            document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
        else:
            document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupCol == None:
            document.add_heading("groupCol Not Used", level=3)
        elif groupCol != None:
            if groupCol in df.columns:
                document.add_heading("groupCol Found: " + groupCol, level=3)  # Add Groupby found
                if groupVal == None:
                    document.add_heading("groupVal Missing", level=3)
                elif groupVal != None:
                    if groupCol in df[eval("d" + str(x))].unique():
                        document.add_heading("groupVal Found: " + groupVal, level=3)  # Add Groupby found
                    else:
                        document.add_heading("groupVal Not Found: " + groupVal, level=3)  # Add Groupby not found
            else:
                document.add_heading("groupCol Not Found: " + groupCol, level=3)  # Add Groupby not found

def SM_CHIP_SUPPLY_VOLTAGE_MONITOR_NAMES_vs_Supply_Voltage(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'VAA_V'
        d2 = 'VAA_BMON_34'
        d3 = 'VAA_PIX_V'
        d4 = 'VAAPIX_BMON_35'
        d5 = 'VDD_IO_V'
        d6 = 'VDDIO_BMON_36'
        d7 = 'VAA1V8_V'
        d8 = 'V1P8_BMON_37'
        d9 = 'VAA1V8_V'
        d10 = 'V1P8LOGIC_BMON_38'
        d11 = 'VDDIO_PHY_V'
        d12 = 'V1P8_MIPI_BMON_39'
        d13 = 'VDD_V'
        d14 = 'DVDD1V2_BMON_40'

        figTitle = 'SM_CHIP_SUPPY_VOLTAGE_MONITOR_vs_Supply_Voltage'
        numDataCols = 15  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols, 2):  # 1 to 8
                fcp.plot(df, x=eval("d" + str(x)), y=eval("d" + str(x + 1)), title=eval("d" + str(x)) + ' vs. ' + eval("d" + str(x + 1)),
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols, 2):  # 1 to 8
                fcp.plot(df, x=eval("d" + str(x)), y=eval("d" + str(x + 1)), title=eval("d" + str(x)) + ' vs. ' + eval("d" + str(x + 1)),
                         legend=groupBy, show=showPlt,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found


'''
TEMP SENSOR SM'S
'''
def SM_TEMP_SENSOR(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'TEMPSENS1_CTRL_REG'
        d2 = 'TEMPVSENS1_TMG_CTRL'
        d3 = 'TEMPVSENS1_FLAG_CTRL'
        d4 = 'TEMPVSENS1_EN_CTRL'
        d5 = 'TEMPVSENS1_TMG_CTRL_K0'
        d6 = 'TEMPVSENS1_TMG_CTRL_K1'
        d7 = 'TEMPVSENS1_TMG_CTRL_K0__TEMPSENS1_RED_TEMP_CODE_K'
        d8 = 'TEMPVSENS1_TMG_CTRL_K1__TEMPSENS1_YELLOW_OFF_RED_K'
        d9 = 'TEMPVSENS1_TMG_CTRL_K1__TEMPSENS1_YELLOW_HYST_K'
        d10 = 'TEMPVSENS1_STATUS__TEMPVSENS1_YELLOW_FLAG'
        d11 = 'TEMPVSENS1_STATUS__TEMPVSENS1_RED_FLAG'
        d12 = 'TEMPVSENS1_STATUS__TEMPVSENS1_YELLOW_FLAG_GATED'
        d13 = 'TEMPVSENS1_STATUS__TEMPVSENS1_RED_FLAG_GATED'
        d14 = 'TEMPVSENS1_STATUS'
        d15 = 'TempFlag'

        figTitle = 'SM_TEMP_SENSOR'
        ylabel = 'RegVal (Dec)'
        ylabel2 = 'Level (1 = Pass, 0 = Fail)'
        numDataCols = 16  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 10
        xFontsize = 10
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):
                if x < 15:  # All other results
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                        inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                        label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                        **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
                elif x == 15:  # Kelvin
                    # Convert objects to int32
                    if df[eval("d" + str(x))].dtype == object:
                        if ((df[eval("d" + str(x))] == 'TRUE') | (df[d1] == 'FALSE')).any():
                            df[eval("d" + str(x))] = df[eval("d" + str(x))].eq('TRUE').mul(1)  # Replace OK with 1, Fail with 0
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                        inline=showPlt, label_y=ylabel2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                        label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                        **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):
                if x < 15:  # All other results
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
                elif x == 15:  # Kelvin
                    # Convert objects to int32
                    if df[eval("d" + str(x))].dtype == object:
                        if ((df[eval("d" + str(x))] == 'TRUE') | (df[d1] == 'FALSE')).any():
                            df[eval("d" + str(x))] = df[eval("d" + str(x))].eq('TRUE').mul(1)  # Replace OK with 1, Fail with 0
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found


'''
RRC SM'S
'''
def SM_AHM_ROW_ROM(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'RRC_CHECK_ADDR_CRC_EXPECT'
        d2 = 'RRC_CHECK_ADDR_CRC_VALUE'
        d3 = 'RRC_CHECK_LO_THRESH'
        d4 = 'RRC_CHECK_HI_THRESH'
        d5 = 'ASIL_PIN_ENABLES_01'
        d6 = 'ASIL_PIN_ENABLES_09'
        d7 = 'ASIL_CHECK_ENABLES_01'
        d8 = 'ASIL_CHECK_ENABLES_09'
        d9 = 'ASIL_STATUS_01__FAIL_RRC_PIXEL_LEGAL'
        d10 = 'ASIL_STATUS_01__FAIL_RRC_ADDRESS'
        d11 = 'ASIL_STATUS_01__FAIL_RRC_DCG'
        d12 = 'ASIL_STATUS_09'
        d13 = 'ASIL_STATUS_09__FAIL_RRC_LEGAL_12'
        d14 = 'ASIL_STATUS_09__FAIL_RRC_LEGAL_13'
        d15 = 'ASIL_STATUS_09__FAIL_RRC_LEGAL_14'
        d16 = 'ASIL_STATUS_09__FAIL_RRC_LEGAL_15'
        d17 = 'ASIL_STATUS_09__FAIL_RRC_LEGAL_16'
        d18 = 'ASIL_STATUS_09__FAIL_RRC_LEGAL_17'
        d19 = 'ASIL_STATUS_09__FAIL_RRC_LEGAL_18'
        d20 = 'ASIL_STATUS_09__FAIL_RRC_LEGAL_19'
        d21 = 'ASIL_STATUS_09__FAIL_RRC_LEGAL_20'
        d22 = 'ASIL_STATUS_09__FAIL_RRC_LEGAL_21'
        d23 = 'ASIL_STATUS_09__FAIL_RRC_LEGAL_22'
        d24 = 'ASIL_STATUS_09__FAIL_RRC_LEGAL_23'

        figTitle = 'SM_AHM_ROW_ROM'
        ylabel = 'RegVal (Dec)'
        numDataCols = 24  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, 5, 2):  # 1 to 5 to plot cnt vs cnt expected
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, 5, 2):  # 1 to 5 to plot cnt vs cnt expected
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         legend=groupBy, show=showPlt,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_AHM_ROW_ROM_FAULT_INJECTION(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'DAC_LD_34_35'
        d2 = 'DAC_LD_34_35__SREG_AE_FAULT_INJECT_EN'
        d3 = 'DAC_LD_34_35__SREG_AE_FULLFRAME_EN'
        d4 = 'DAC_LD_34_35__SREG_AE_ATR_TEST'
        d5 = 'DAC_LD_34_35__SREG_AE_ATR_TEST_ROW_EN'

        figTitle = 'SM_AHM_ROW_ROM_FAULT_INJECTION'
        ylabel = 'RegVal (Dec)'
        numDataCols = 6  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found


'''
DTR SM'S
'''
def SM_DTR(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'CRC_FR_DTR_WRT_CHECKSUM_HIGH'
        d2 = 'CRC_FR_DTR_CALC_CHECKSUM_HIGH'
        d3 = 'CRC_FR_DTR_WRT_CHECKSUM_HIGH__CRC_DTR_WRT_CHECKSUM_HIGH'
        d4 = 'CRC_FR_DTR_CALC_CHECKSUM_HIGH__CRC_DTR_CALC_CHECKSUM_HIGH'
        d5 = 'CRC_DTR_WRT_CHECKSUM_LOW'
        d6 = 'CRC_DTR_CALC_CHECKSUM_LOW'
        d7 = 'TPG_CONTROL'
        d8 = 'TPG_STDPAT_REGION1'
        d9 = 'TPG_STDPAT_REGION2'
        d10 = 'TPG_NOISE1_REGION'
        d11 = 'TPG_NOISE2_REGION'
        d12 = 'TPG_COLOR0_GR1_HI'
        d13 = 'TPG_COLOR0_GR1_LO'
        d14 = 'TPG_COLOR0_RED_HI'
        d15 = 'TPG_COLOR0_RED_LO'
        d16 = 'TPG_COLOR0_BLU_HI'
        d17 = 'TPG_COLOR0_BLU_LO'
        d18 = 'TPG_COLOR0_GR2_HI'
        d19 = 'TPG_COLOR0_GR2_LO'
        d20 = 'TPG_COLOR1_GR1_HI'
        d21 = 'TPG_COLOR1_GR1_LO'
        d22 = 'TPG_COLOR1_RED_HI'
        d23 = 'TPG_COLOR1_RED_LO'
        d24 = 'TPG_COLOR1_BLU_HI'
        d25 = 'TPG_COLOR1_BLU_LO'
        d26 = 'TPG_COLOR1_GR2_HI'
        d27 = 'TPG_COLOR1_GR2_LO'
        d28 = 'TPG_HDR_RATIOS'
        d29 = 'TPG_PD0_PD1_RATIOS'
        d30 = 'TPG_LFM2_RATIOS'
        d31 = 'PROCESS_DTR'
        d32 = 'DTR_BOUND_X0'
        d33 = 'DTR_BOUND_X1'
        d34 = 'DTR_BOUND_Y0'
        d35 = 'DTR_BOUND_Y1'
        d36 = 'ASIL_PIN_ENABLES_02'
        d37 = 'ASIL_CHECK_ENABLES_02'
        d38 = 'ASIL_STATUS_02'
        d39 = 'ASIL_STATUS_02__DTR_CRC_STATUS'

        figTitle = 'SM_DTR'
        ylabel = 'RegVal (Dec)'
        numDataCols = 40  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, 7, 2):  # 1 to 5 to plot cnt vs cnt expected
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, 7, 2):  # 1 to 5 to plot cnt vs cnt expected
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         legend=groupBy, show=showPlt,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_DTR_MEC(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'MEC_SM_FAULT_CONTROL'
        d2 = 'MEC_SM_RATIO_FAULT_CONTROL'
        d3 = 'MEC_SM_RATIO_OFFSET'
        d4 = 'SM_TEST_PAT_WIDTH'
        d5 = 'SM_TEST_RATIO_21'
        d6 = 'SM_TEST_RATIO_32'
        d7 = 'SM_TEST_RATIO_43'
        d8 = 'SM_TEST_PAT_START'
        d9 = 'SM_TEST_PAT_ST_M'
        d10 = 'SM_TEST_LIN_FACTOR'
        d11 = 'MEC_SM_ERR_COUNT_LSB'
        d12 = 'MEC_SM_ERR_COUNT_MSB'
        d13 = 'MEC_SM_ERR_HIGH_LSB'
        d14 = 'MEC_SM_ERR_HIGH_MSB'
        d15 = 'MEC_SM_ERR_LOW_LSB'
        d16 = 'MEC_SM_ERR_LOW_MSB'
        d17 = 'MEC_SM_ERR_STATUS'
        d18 = 'MEC_SM_ERR_TH'
        d19 = 'ASIL_STATUS_06__FAIL_MEC_SM'

        figTitle = 'SM_DTR_MEC'
        ylabel = 'RegVal (Dec)'
        numDataCols = 20  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found


'''
IMAGE DATA SM'S
'''
def SM_IMAGE_DATA_CRC(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'CRC_FR_DTR_WRT_CHECKSUM_HIGH'
        d2 = 'CRC_FR_DTR_CALC_CHECKSUM_HIGH'
        d3 = 'CRC_FR_DTR_WRT_CHECKSUM_HIGH__CRC_FR_WRT_CHECKSUM_HIGH'
        d4 = 'CRC_FR_DTR_CALC_CHECKSUM_HIGH__CRC_FR_CALC_CHECKSUM_HIGH'
        d5 = 'CRC_FR_WRT_CHECKSUM_LOW'
        d6 = 'CRC_FR_CALC_CHECKSUM_LOW'
        d7 = 'ASIL_PIN_ENABLES_02'
        d8 = 'ASIL_CHECK_ENABLES_02'
        d9 = 'ASIL_PIN_ENABLES_02__ROW_FRAME_CRC_PIN_ENABLE'
        d10 = 'ASIL_CHECK_ENABLES_02__ROW_FRAME_CRC_ENABLE'
        d11 = 'ASIL_STATUS_02'
        d12 = 'ASIL_STATUS_02__ROW_FRAME_CRC_STATUS'

        figTitle = 'SM_IMAGE_DATA_CRC'
        ylabel = 'RegVal (Dec)'
        numDataCols = 13  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, 7, 2):  # 1 to 7 to plot cnt vs cnt expected
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, 7, 2):  # 1 to 7 to plot cnt vs cnt expected
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         legend=groupBy, show=showPlt,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_MIPI_HISPI_CRC(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'HISPI_CONTROL'
        d2 = 'HISPI_STATUS'
        d3 = 'HISPI_STATUS__HISPI_CHECKSUM_VALID'
        d4 = 'HISPI_CRC_0'
        d5 = 'HISPI_CRC_1'
        d6 = 'HISPI_CRC_2'
        d7 = 'HISPI_CRC_3'
        d8 = 'SENSOR_HISPI_CONTROL'
        d9 = 'SENSOR_HISPI_STATUS'
        d10 = 'SENSOR_HISPI_STATUS__SENSOR_HISPI_CHECKSUM_VALID'
        d11 = 'SENSOR_HISPI_CRC_0'
        d12 = 'SENSOR_HISPI_CRC_1'
        d13 = 'SENSOR_HISPI_CRC_2'
        d14 = 'SENSOR_HISPI_CRC_3'

        figTitle = 'SM_MIPI_HISPI_CRC'
        ylabel = 'RegVal (Dec)'
        numDataCols = 15  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found


'''
CLOCK COUNTING SM'S
'''
def SM_CLOCK_COUNTING(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ASIL_EXT_CLK_COUNT_MSB_EXPECT'
        d2 = 'ASIL_EXT_CLK_COUNT_MSB'
        d3 = 'ASIL_EXT_CLK_COUNT_LSB_EXPECT'
        d4 = 'ASIL_EXT_CLK_COUNT_LSB'
        d5 = 'ASIL_CLK_PIX_COUNT_MSB_EXPECT'
        d6 = 'ASIL_CLK_PIX_COUNT_MSB'
        d7 = 'ASIL_CLK_PIX_COUNT_LSB_EXPECT'
        d8 = 'ASIL_CLK_PIX_COUNT_LSB'
        d9 = 'ASIL_CLK_OP_COUNT_MSB_EXPECT'
        d10 = 'ASIL_CLK_OP_COUNT_MSB'
        d11 = 'ASIL_CLK_OP_COUNT_LSB_EXPECT'
        d12 = 'ASIL_CLK_OP_COUNT_LSB'
        d13 = 'ASIL_CLK_REG_COUNT_MSB_EXPECT'
        d14 = 'ASIL_CLK_REG_COUNT_MSB'
        d15 = 'ASIL_CLK_REG_COUNT_LSB_EXPECT'
        d16 = 'ASIL_CLK_REG_COUNT_LSB'
        d17 = 'ASIL_CLK_PIX_COUNT_100_EXT_EXPECT'
        d18 = 'ASIL_CLK_PIX_COUNT_100_EXT'
        d19 = 'ASIL_CLK_OP_COUNT_100_EXT_EXPECT'
        d20 = 'ASIL_CLK_OP_COUNT_100_EXT'
        d21 = 'ASIL_CLK_REG_COUNT_100_EXT_EXPECT'
        d22 = 'ASIL_CLK_REG_COUNT_100_EXT'
        d23 = 'ASIL_ASIC_EXT_CLK_COUNT_MSB_EXPECT'
        d24 = 'ASIL_ASIC_EXT_CLK_COUNT_MSB'
        d25 = 'ASIL_ASIC_EXT_CLK_COUNT_LSB_EXPECT'
        d26 = 'ASIL_ASIC_EXT_CLK_COUNT_LSB'
        d27 = 'ASIL_ASIC_CLK_PIX_COUNT_MSB_EXPECT'
        d28 = 'ASIL_ASIC_CLK_PIX_COUNT_MSB'
        d29 = 'ASIL_ASIC_CLK_PIX_COUNT_LSB_EXPECT'
        d30 = 'ASIL_ASIC_CLK_PIX_COUNT_LSB'
        d31 = 'ASIL_ASIC_CLK_OP_COUNT_MSB_EXPECT'
        d32 = 'ASIL_ASIC_CLK_OP_COUNT_MSB'
        d33 = 'ASIL_ASIC_CLK_OP_COUNT_LSB_EXPECT'
        d34 = 'ASIL_ASIC_CLK_OP_COUNT_LSB'
        d35 = 'ASIL_ASIC_CLK_REG_COUNT_MSB_EXPECT'
        d36 = 'ASIL_ASIC_CLK_REG_COUNT_MSB'
        d37 = 'ASIL_ASIC_CLK_REG_COUNT_LSB_EXPECT'
        d38 = 'ASIL_ASIC_CLK_REG_COUNT_LSB'
        d39 = 'ASIL_ASIC_CLK_PIX_COUNT_100_EXT_EXPECT'
        d40 = 'ASIL_ASIC_CLK_PIX_COUNT_100_EXT'
        d41 = 'ASIL_ASIC_CLK_OP_COUNT_100_EXT_EXPECT'
        d42 = 'ASIL_ASIC_CLK_OP_COUNT_100_EXT'
        d43 = 'ASIL_ASIC_CLK_REG_COUNT_100_EXT_EXPECT'
        d44 = 'ASIL_ASIC_CLK_REG_COUNT_100_EXT'
        d45 = 'ASIL_PIN_ENABLES_00'
        d46 = 'ASIL_CHECK_ENABLES_00'
        d47 = 'ASIL_STATUS_00'
        d48 = 'ASIL_STATUS_00__ASIL_STATUS_DATA_FORMAT_ERROR'
        d49 = 'ASIL_STATUS_00__ASIL_STATUS_BO_1V2_PARAM'
        d50 = 'ASIL_STATUS_00__ASIL_STATUS_BO_1V8_PARAM'
        d51 = 'ASIL_STATUS_00__ASIL_STATUS_BO_2V8_PARAM'
        d52 = 'ASIL_STATUS_00__ASIL_STATUS_EXT_CLK_PARAM'
        d53 = 'ASIL_STATUS_00__ASIL_STATUS_CLK_PIX_PARAM'
        d54 = 'ASIL_STATUS_00__ASIL_STATUS_CLK_OP_PARAM'
        d55 = 'ASIL_STATUS_00__ASIL_STATUS_CLK_REG_PARAM'
        d56 = 'ASIL_STATUS_00__ASIL_STATUS_CLK_PIX_100_PARAM'
        d57 = 'ASIL_STATUS_00__ASIL_STATUS_CLK_OP_100_PARAM'
        d58 = 'ASIL_STATUS_00__ASIL_STATUS_CLK_REG_100_PARAM'

        figTitle = 'SM_CLOCK_COUNTING'
        ylabel = 'RegVal (Dec)'
        numDataCols = 59  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, 45, 2):  # 1 to 23 to plot clk cnt vs cnt expected
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))], title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, 45, 2):  # 1 to 23 to plot clk cnt vs cnt expected
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))], title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         legend=groupBy, show=showPlt,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_CLOCK_COUNTING_vs_Time_Plot(dataFrame, groupCol, groupVal, document, pltPath, showPlt, **kwargs):
    try:

        if groupCol == None and groupVal == None:  # Dont group data frame
            df = dataFrame
        elif groupCol != None and groupVal != None:  # Group data frame by col and value
            df = VRG_Data_Frame.newdataframe(dataFrame, groupCol, groupVal)

        d1 = 'ASIL_EXT_CLK_COUNT_MSB Read'
        d2 = 'ASIL_EXT_CLK_COUNT_LSB Read'
        d3 = 'ASIL_CLK_PIX_COUNT_MSB Read'
        d4 = 'ASIL_CLK_PIX_COUNT_LSB Read'
        d5 = 'ASIL_CLK_OP_COUNT_MSB Read'
        d6 = 'ASIL_CLK_OP_COUNT_LSB Read'
        d7 = 'ASIL_CLK_REG_COUNT_MSB Read'
        d8 = 'ASIL_CLK_REG_COUNT_LSB Read'
        d9 = 'ASIL_CLK_PIX_COUNT_100_EXT Read'
        d10 = 'ASIL_CLK_OP_COUNT_100_EXT Read'
        d11 = 'ASIL_CLK_REG_COUNT_100_EXT Read'
        d12 = 'ASIL_ASIC_EXT_CLK_COUNT_MSB Read'
        d13 = 'ASIL_ASIC_EXT_CLK_COUNT_LSB Read'
        d14 = 'ASIL_ASIC_CLK_PIX_COUNT_MSB Read'
        d15 = 'ASIL_ASIC_CLK_PIX_COUNT_LSB Read'
        d16 = 'ASIL_ASIC_CLK_OP_COUNT_MSB Read'
        d17 = 'ASIL_ASIC_CLK_OP_COUNT_LSB Read'
        d18 = 'ASIL_ASIC_CLK_REG_COUNT_MSB Read'
        d19 = 'ASIL_ASIC_CLK_REG_COUNT_LSB Read'
        d20 = 'ASIL_ASIC_CLK_PIX_COUNT_100_EXT Read'
        d21 = 'ASIL_ASIC_CLK_OP_COUNT_100_EXT Read'
        d22 = 'ASIL_ASIC_CLK_REG_COUNT_100_EXT Read'

        # get data columns
        t1_cols = [x for x in df.columns[df.columns.str.contains(d1)]]
        t2_cols = [x for x in df.columns[df.columns.str.contains(d2)]]
        t3_cols = [x for x in df.columns[df.columns.str.contains(d3)]]
        t4_cols = [x for x in df.columns[df.columns.str.contains(d4)]]
        t5_cols = [x for x in df.columns[df.columns.str.contains(d5)]]
        t6_cols = [x for x in df.columns[df.columns.str.contains(d6)]]
        t7_cols = [x for x in df.columns[df.columns.str.contains(d7)]]
        t8_cols = [x for x in df.columns[df.columns.str.contains(d8)]]
        t9_cols = [x for x in df.columns[df.columns.str.contains(d9)]]
        t10_cols = [x for x in df.columns[df.columns.str.contains(d10)]]
        t11_cols = [x for x in df.columns[df.columns.str.contains(d11)]]
        t12_cols = [x for x in df.columns[df.columns.str.contains(d12)]]
        t13_cols = [x for x in df.columns[df.columns.str.contains(d13)]]
        t14_cols = [x for x in df.columns[df.columns.str.contains(d14)]]
        t15_cols = [x for x in df.columns[df.columns.str.contains(d15)]]
        t16_cols = [x for x in df.columns[df.columns.str.contains(d16)]]
        t17_cols = [x for x in df.columns[df.columns.str.contains(d17)]]
        t18_cols = [x for x in df.columns[df.columns.str.contains(d18)]]
        t19_cols = [x for x in df.columns[df.columns.str.contains(d19)]]
        t20_cols = [x for x in df.columns[df.columns.str.contains(d20)]]
        t21_cols = [x for x in df.columns[df.columns.str.contains(d21)]]
        t22_cols = [x for x in df.columns[df.columns.str.contains(d22)]]

        # subset df
        t1 = df[t1_cols]
        t2 = df[t2_cols]
        t3 = df[t3_cols]
        t4 = df[t4_cols]
        t5 = df[t5_cols]
        t6 = df[t6_cols]
        t7 = df[t7_cols]
        t8 = df[t8_cols]
        t9 = df[t9_cols]
        t10 = df[t10_cols]
        t11 = df[t11_cols]
        t12 = df[t12_cols]
        t13 = df[t13_cols]
        t14 = df[t14_cols]
        t15 = df[t15_cols]
        t16 = df[t16_cols]
        t17 = df[t17_cols]
        t18 = df[t18_cols]
        t19 = df[t19_cols]
        t20 = df[t20_cols]
        t21 = df[t21_cols]
        t22 = df[t22_cols]

        # rename columns to get read number
        for dc in t1_cols:
            t1 = t1.rename(columns={dc: dc.split(' ')[2]})
        for dc in t2_cols:
            t2 = t2.rename(columns={dc: dc.split(' ')[2]})
        for dc in t3_cols:
            t3 = t3.rename(columns={dc: dc.split(' ')[2]})
        for dc in t4_cols:
            t4 = t4.rename(columns={dc: dc.split(' ')[2]})
        for dc in t5_cols:
            t5 = t5.rename(columns={dc: dc.split(' ')[2]})
        for dc in t6_cols:
            t6 = t6.rename(columns={dc: dc.split(' ')[2]})
        for dc in t7_cols:
            t7 = t7.rename(columns={dc: dc.split(' ')[2]})
        for dc in t8_cols:
            t8 = t8.rename(columns={dc: dc.split(' ')[2]})
        for dc in t9_cols:
            t9 = t9.rename(columns={dc: dc.split(' ')[2]})
        for dc in t10_cols:
            t10 = t10.rename(columns={dc: dc.split(' ')[2]})
        for dc in t11_cols:
            t11 = t11.rename(columns={dc: dc.split(' ')[2]})
        for dc in t12_cols:
            t12 = t12.rename(columns={dc: dc.split(' ')[2]})
        for dc in t13_cols:
            t13 = t13.rename(columns={dc: dc.split(' ')[2]})
        for dc in t14_cols:
            t14 = t14.rename(columns={dc: dc.split(' ')[2]})
        for dc in t15_cols:
            t15 = t15.rename(columns={dc: dc.split(' ')[2]})
        for dc in t16_cols:
            t16 = t16.rename(columns={dc: dc.split(' ')[2]})
        for dc in t17_cols:
            t17 = t17.rename(columns={dc: dc.split(' ')[2]})
        for dc in t18_cols:
            t18 = t18.rename(columns={dc: dc.split(' ')[2]})
        for dc in t19_cols:
            t19 = t19.rename(columns={dc: dc.split(' ')[2]})
        for dc in t20_cols:
            t20 = t20.rename(columns={dc: dc.split(' ')[2]})
        for dc in t21_cols:
            t21 = t21.rename(columns={dc: dc.split(' ')[2]})
        for dc in t22_cols:
            t22 = t22.rename(columns={dc: dc.split(' ')[2]})

        # transpose
        t1 = t1.T
        t2 = t2.T
        t3 = t3.T
        t4 = t4.T
        t5 = t5.T
        t6 = t6.T
        t7 = t7.T
        t8 = t8.T
        t9 = t9.T
        t10 = t10.T
        t11 = t11.T
        t12 = t12.T
        t13 = t13.T
        t14 = t14.T
        t15 = t15.T
        t16 = t16.T
        t17 = t17.T
        t18 = t18.T
        t19 = t19.T
        t20 = t20.T
        t21 = t21.T
        t22 = t22.T

        # add an index column
        t1['Read Num'] = t1.index
        t2['Read Num'] = t2.index
        t3['Read Num'] = t3.index
        t4['Read Num'] = t4.index
        t5['Read Num'] = t5.index
        t6['Read Num'] = t6.index
        t7['Read Num'] = t7.index
        t8['Read Num'] = t8.index
        t9['Read Num'] = t9.index
        t10['Read Num'] = t10.index
        t11['Read Num'] = t11.index
        t12['Read Num'] = t12.index
        t13['Read Num'] = t13.index
        t14['Read Num'] = t14.index
        t15['Read Num'] = t15.index
        t16['Read Num'] = t16.index
        t17['Read Num'] = t17.index
        t18['Read Num'] = t18.index
        t19['Read Num'] = t19.index
        t20['Read Num'] = t20.index
        t21['Read Num'] = t21.index
        t22['Read Num'] = t22.index

        colList = []
        for index in df.index:
            colList.append(index)

        figTitle = 'SM_CLOCK_COUNTING_vs_Time_Plot'
        numDataCols = 23
        titleFontSize = 12
        yFontsize = 8
        xFontsize = 8
        legFontSize = 6

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupCol == None and groupVal == None:  # No Dataframe grouping
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(eval("t" + str(x)), x='Read Num', y=colList, title=eval("d" + str(x)), legend_title="Test #",
                         show=showPlt,
                         inline=showPlt, label_y=eval("d" + str(x)), title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupCol != None and groupVal != None:  # Data frame grouped by col and val
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(eval("t" + str(x)), x='Read Num', y=colList,
                         title=eval("d" + str(x)) + " Groupedby: " + groupCol + ' = ' + str(groupVal), show=showPlt,
                         inline=showPlt, legend_title="Test #", label_y=eval("d" + str(x)), title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        if eval("d" + str(x)) in df.columns:
            document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
        else:
            document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupCol == None:
            document.add_heading("groupCol Not Used", level=3)
        elif groupCol != None:
            if groupCol in df.columns:
                document.add_heading("groupCol Found: " + groupCol, level=3)  # Add Groupby found
                if groupVal == None:
                    document.add_heading("groupVal Missing", level=3)
                elif groupVal != None:
                    if groupCol in df[eval("d" + str(x))].unique():
                        document.add_heading("groupVal Found: " + groupVal, level=3)  # Add Groupby found
                    else:
                        document.add_heading("groupVal Not Found: " + groupVal, level=3)  # Add Groupby not found
            else:
                document.add_heading("groupCol Not Found: " + groupCol, level=3)  # Add Groupby not found

def SM_CLOCK_COUNTING_Conversions(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'SMCLKCNT_ExtClk(MHz)'
        d2 = 'SMCLKCNT_ASIL_EXT_CLK (MHz)'
        d3 = 'SMCLKCNT_VtPixClk(MHz)'
        d4 = 'SMCLKCNT_ASIL_PIX_CLK (MHz)'
        d5 = 'SMCLKCNT_VtPixClk(MHz)'
        d6 = 'SMCLKCNT_ASIL_PIX_CLK_100 (MHz)'
        d7 = 'SMCLKCNT_OpPixClk(MHz)'
        d8 = 'SMCLKCNT_ASIL_OP_CLK (MHz)'
        d9 = 'SMCLKCNT_OpPixClk(MHz)'
        d10 = 'SMCLKCNT_ASIL_OP_CLK_100 (MHz)'
        d11 = 'SMCLKCNT_RegClk(MHz)'
        d12 = 'SMCLKCNT_ASIL_REG_CLK (MHz)'
        d13 = 'SMCLKCNT_RegClk(MHz)'
        d14 = 'SMCLKCNT_ASIL_REG_CLK_100 (MHz)'
        d15 = 'SMCLKCNT_ExtClk(MHz)'
        d16 = 'SMCLKCNT_ASIL_ASIC_EXT_CLK (MHz)'
        d17 = 'SMCLKCNT_VtPixClk_ASIC(MHz)'
        d18 = 'SMCLKCNT_ASIL_ASIC_PIX_CLK (MHz)'
        d19 = 'SMCLKCNT_VtPixClk_ASIC(MHz)'
        d20 = 'SMCLKCNT_ASIL_ASIC_PIX_CLK_100 (MHz)'
        d21 = 'SMCLKCNT_OpPixClk_ASIC(MHz)'
        d22 = 'SMCLKCNT_ASIL_ASIC_OP_CLK (MHz)'
        d23 = 'SMCLKCNT_OpPixClk_ASIC(MHz)'
        d24 = 'SMCLKCNT_ASIL_ASIC_OP_CLK_100 (MHz)'
        d25 = 'SMCLKCNT_RegClk_ASIC(MHz)'
        d26 = 'SMCLKCNT_ASIL_ASIC_REG_CLK (MHz)'
        d27 = 'SMCLKCNT_RegClk_ASIC(MHz)'
        d28 = 'SMCLKCNT_ASIL_ASIC_REG_CLK_100 (MHz)'
        d29 = 'SMCLKCNT_ASIL_EXT_CLK_COUNT'
        d30 = 'SMCLKCNT_ASIL_EXT_CLK_COUNT_EXPECT_CALC'
        d31 = 'SMCLKCNT_ASIL_CLK_PIX_COUNT'
        d32 = 'SMCLKCNT_ASIL_CLK_PIX_COUNT_EXPECT_CALC'
        d33 = 'SMCLKCNT_ASIL_CLK_OP_COUNT'
        d34 = 'SMCLKCNT_ASIL_CLK_OP_COUNT_EXPECT_CALC'
        d35 = 'SMCLKCNT_ASIL_CLK_REG_COUNT'
        d36 = 'SMCLKCNT_ASIL_CLK_REG_COUNT_EXPECT_CALC'
        d37 = 'SMCLKCNT_ASIL_CLK_PIX_COUNT_100_EXT'
        d38 = 'SMCLKCNT_ASIL_CLK_PIX_COUNT_100_EXT_EXPECT_CALC'
        d39 = 'SMCLKCNT_ASIL_CLK_OP_COUNT_100_EXT'
        d40 = 'SMCLKCNT_ASIL_CLK_OP_COUNT_100_EXT_EXPECT_CALC'
        d41 = 'SMCLKCNT_ASIL_CLK_REG_COUNT_100_EXT'
        d42 = 'SMCLKCNT_ASIL_CLK_REG_COUNT_100_EXT_EXPECT_CALC'
        d43 = 'SMCLKCNT_ASIL_ASIC_EXT_CLK_COUNT'
        d44 = 'SMCLKCNT_ASIL_ASIC_EXT_CLK_COUNT_EXPECT_CALC'
        d45 = 'SMCLKCNT_ASIL_ASIC_CLK_PIX_COUNT'
        d46 = 'SMCLKCNT_ASIL_ASIC_CLK_PIX_COUNT_EXPECT_CALC'
        d47 = 'SMCLKCNT_ASIL_ASIC_CLK_OP_COUNT'
        d48 = 'SMCLKCNT_ASIL_ASIC_CLK_OP_COUNT_EXPECT_CALC'
        d49 = 'SMCLKCNT_ASIL_ASIC_CLK_REG_COUNT'
        d50 = 'SMCLKCNT_ASIL_ASIC_CLK_REG_COUNT_EXPECT_CALC'
        d51 = 'SMCLKCNT_ASIL_ASIC_CLK_PIX_COUNT_100_EXT'
        d52 = 'SMCLKCNT_ASIL_ASIC_CLK_PIX_COUNT_100_EXT_EXPECT_CALC'
        d53 = 'SMCLKCNT_ASIL_ASIC_CLK_OP_COUNT_100_EXT'
        d54 = 'SMCLKCNT_ASIL_ASIC_CLK_OP_COUNT_100_EXT_EXPECT_CALC'
        d55 = 'SMCLKCNT_ASIL_ASIC_CLK_REG_COUNT_100_EXT'
        d56 = 'SMCLKCNT_ASIL_ASIC_CLK_REG_COUNT_100_EXT_EXPECT_CALC'
        d57 = 'SMCLKCNT_ASIL_EXT_COUNT_DIFF'
        d58 = 'SMCLKCNT_ASIL_CLK_PIX_COUNT_DIFF'
        d59 = 'SMCLKCNT_ASIL_CLK_OP_COUNT_DIFF'
        d60 = 'SMCLKCNT_ASIL_CLK_REG_COUNT_DIFF'
        d61 = 'SMCLKCNT_ASIL_CLK_PIX_COUNT_100_EXT_DIFF'
        d62 = 'SMCLKCNT_ASIL_CLK_OP_COUNT_100_EXT_DIFF'
        d63 = 'SMCLKCNT_ASIL_CLK_REG_COUNT_100_EXT_DIFF'
        d64 = 'SMCLKCNT_ASIL_ASIC_EXT_COUNT_DIFF'
        d65 = 'SMCLKCNT_ASIL_ASIC_CLK_PIX_COUNT_DIFF'
        d66 = 'SMCLKCNT_ASIL_ASIC_CLK_OP_COUNT_DIFF'
        d67 = 'SMCLKCNT_ASIL_ASIC_CLK_REG_COUNT_DIFF'
        d68 = 'SMCLKCNT_ASIL_ASIC_CLK_PIX_COUNT_100_EXT_DIFF'
        d69 = 'SMCLKCNT_ASIL_ASIC_CLK_OP_COUNT_100_EXT_DIFF'
        d70 = 'SMCLKCNT_ASIL_ASIC_CLK_REG_COUNT_100_EXT_DIFF'
        d71 = 'SMCLKCNT_FrameTime(s)'

        figTitle = 'SM_CLOCK_COUNTING_Conversions'
        numDataCols1 = 57  # Number of columns + 1 to loop through (last col + 1)
        numDataCols2 = 72
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols1, 2):  # 1 to N
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))], title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize, **kwargs,
                         filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')  # Add figure to report
            for x in range(numDataCols1 + 1, numDataCols2):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols1, 2):  # 1 to N
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))], title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         legend=groupBy, show=showPlt,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')  # Add figure to report
            for x in range(numDataCols1 + 1, numDataCols2):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols2):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_CLOCK_COUNTING_Conversions_Expanded(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'SMCLKCNT_FrameTime(s)'
        d2 = 'SMCLKCNT_ExtClk(MHz)'
        d3 = 'SMCLKCNT_PFD(MHz)'
        d4 = 'SMCLKCNT_VCO(MHz)'
        d5 = 'SMCLKCNT_VtPixClk(MHz)'
        d6 = 'SMCLKCNT_OpPixClk(MHz)'
        d7 = 'SMCLKCNT_RegClk(MHz)'
        d8 = 'SMCLKCNT_PFD_ASIC(MHz)'
        d9 = 'SMCLKCNT_VCO_ASIC(MHz)'
        d10 = 'SMCLKCNT_VtPixClk_ASIC(MHz)'
        d11 = 'SMCLKCNT_OpPixClk_ASIC(MHz)'
        d12 = 'SMCLKCNT_RegClk_ASIC(MHz)'
        d13 = 'SMCLKCNT_ASIL_EXT_CLK (MHz)'
        d14 = 'SMCLKCNT_ASIL_PIX_CLK (MHz)'
        d15 = 'SMCLKCNT_ASIL_OP_CLK (MHz)'
        d16 = 'SMCLKCNT_ASIL_REG_CLK (MHz)'
        d17 = 'SMCLKCNT_ASIL_PIX_CLK_100 (MHz)'
        d18 = 'SMCLKCNT_ASIL_OP_CLK_100 (MHz)'
        d19 = 'SMCLKCNT_ASIL_REG_CLK_100 (MHz)'
        d20 = 'SMCLKCNT_ASIL_ASIC_EXT_CLK (MHz)'
        d21 = 'SMCLKCNT_ASIL_ASIC_PIX_CLK (MHz)'
        d22 = 'SMCLKCNT_ASIL_ASIC_OP_CLK (MHz)'
        d23 = 'SMCLKCNT_ASIL_ASIC_REG_CLK (MHz)'
        d24 = 'SMCLKCNT_ASIL_ASIC_PIX_CLK_100 (MHz)'
        d25 = 'SMCLKCNT_ASIL_ASIC_OP_CLK_100 (MHz)'
        d26 = 'SMCLKCNT_ASIL_ASIC_REG_CLK_100 (MHz)'
        d27 = 'SMCLKCNT_ASIL_EXT_CLK_COUNT'
        d28 = 'SMCLKCNT_ASIL_CLK_PIX_COUNT'
        d29 = 'SMCLKCNT_ASIL_CLK_OP_COUNT'
        d30 = 'SMCLKCNT_ASIL_CLK_REG_COUNT'
        d31 = 'SMCLKCNT_ASIL_CLK_PIX_COUNT_100_EXT'
        d32 = 'SMCLKCNT_ASIL_CLK_OP_COUNT_100_EXT'
        d33 = 'SMCLKCNT_ASIL_CLK_REG_COUNT_100_EXT'
        d34 = 'SMCLKCNT_ASIL_ASIC_EXT_CLK_COUNT'
        d35 = 'SMCLKCNT_ASIL_ASIC_CLK_PIX_COUNT'
        d36 = 'SMCLKCNT_ASIL_ASIC_CLK_OP_COUNT'
        d37 = 'SMCLKCNT_ASIL_ASIC_CLK_REG_COUNT'
        d38 = 'SMCLKCNT_ASIL_ASIC_CLK_PIX_COUNT_100_EXT'
        d39 = 'SMCLKCNT_ASIL_ASIC_CLK_OP_COUNT_100_EXT'
        d40 = 'SMCLKCNT_ASIL_ASIC_CLK_REG_COUNT_100_EXT'
        d41 = 'SMCLKCNT_ASIL_EXT_CLK_COUNT_EXPECT_CALC'
        d42 = 'SMCLKCNT_ASIL_CLK_PIX_COUNT_EXPECT_CALC'
        d43 = 'SMCLKCNT_ASIL_CLK_OP_COUNT_EXPECT_CALC'
        d44 = 'SMCLKCNT_ASIL_CLK_REG_COUNT_EXPECT_CALC'
        d45 = 'SMCLKCNT_ASIL_CLK_PIX_COUNT_100_EXT_EXPECT_CALC'
        d46 = 'SMCLKCNT_ASIL_CLK_OP_COUNT_100_EXT_EXPECT_CALC'
        d47 = 'SMCLKCNT_ASIL_CLK_REG_COUNT_100_EXT_EXPECT_CALC'
        d48 = 'SMCLKCNT_ASIL_ASIC_EXT_CLK_COUNT_EXPECT_CALC'
        d49 = 'SMCLKCNT_ASIL_ASIC_CLK_PIX_COUNT_EXPECT_CALC'
        d50 = 'SMCLKCNT_ASIL_ASIC_CLK_OP_COUNT_EXPECT_CALC'
        d51 = 'SMCLKCNT_ASIL_ASIC_CLK_REG_COUNT_EXPECT_CALC'
        d52 = 'SMCLKCNT_ASIL_ASIC_CLK_PIX_COUNT_100_EXT_EXPECT_CALC'
        d53 = 'SMCLKCNT_ASIL_ASIC_CLK_OP_COUNT_100_EXT_EXPECT_CALC'
        d54 = 'SMCLKCNT_ASIL_ASIC_CLK_REG_COUNT_100_EXT_EXPECT_CALC'
        d55 = 'SMCLKCNT_ASIL_EXT_COUNT_DIFF'
        d56 = 'SMCLKCNT_ASIL_CLK_PIX_COUNT_DIFF'
        d57 = 'SMCLKCNT_ASIL_CLK_OP_COUNT_DIFF'
        d58 = 'SMCLKCNT_ASIL_CLK_REG_COUNT_DIFF'
        d59 = 'SMCLKCNT_ASIL_CLK_PIX_COUNT_100_EXT_DIFF'
        d60 = 'SMCLKCNT_ASIL_CLK_OP_COUNT_100_EXT_DIFF'
        d61 = 'SMCLKCNT_ASIL_CLK_REG_COUNT_100_EXT_DIFF'
        d62 = 'SMCLKCNT_ASIL_ASIC_EXT_COUNT_DIFF'
        d63 = 'SMCLKCNT_ASIL_ASIC_CLK_PIX_COUNT_DIFF'
        d64 = 'SMCLKCNT_ASIL_ASIC_CLK_OP_COUNT_DIFF'
        d65 = 'SMCLKCNT_ASIL_ASIC_CLK_REG_COUNT_DIFF'
        d66 = 'SMCLKCNT_ASIL_ASIC_CLK_PIX_COUNT_100_EXT_DIFF'
        d67 = 'SMCLKCNT_ASIL_ASIC_CLK_OP_COUNT_100_EXT_DIFF'
        d68 = 'SMCLKCNT_ASIL_ASIC_CLK_REG_COUNT_100_EXT_DIFF'

        figTitle = 'SM_CLOCK_COUNTING_Conversions_Expanded'
        ylabel = 'MHz'
        numDataCols = 69  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                if x < 27:
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
                if x >= 27:
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                if x < 27:
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
                if x >= 27:
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_COUNT_EXTCLK(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ASIL_EXT_CLK_COUNT_MSB_EXPECT'
        d2 = 'ASIL_EXT_CLK_COUNT_MSB'
        d3 = 'ASIL_EXT_CLK_COUNT_LSB_EXPECT'
        d4 = 'ASIL_EXT_CLK_COUNT_LSB'
        d5 = 'ASIL_PIN_ENABLES_00'
        d6 = 'ASIL_CHECK_ENABLES_00'
        d7 = 'ASIL_STATUS_00'
        d8 = 'ASIL_STATUS_00__ASIL_STATUS_EXT_CLK_PARAM'

        figTitle = 'SM_COUNT_EXTCLK'
        ylabel = 'RegVal (Dec)'
        numDataCols = 9  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, 5, 2):  # 1 to 5 to plot clk cnt vs cnt expected
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, 5, 2):  # 1 to 5 to plot clk cnt vs cnt expected
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         legend=groupBy, show=showPlt,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_COUNT_CLK_PIX(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ASIL_CLK_PIX_COUNT_MSB_EXPECT'
        d2 = 'ASIL_CLK_PIX_COUNT_MSB'
        d3 = 'ASIL_CLK_PIX_COUNT_LSB_EXPECT'
        d4 = 'ASIL_CLK_PIX_COUNT_LSB'
        d5 = 'ASIL_CLK_PIX_COUNT_100_EXT_EXPECT'
        d6 = 'ASIL_CLK_PIX_COUNT_100_EXT'
        d7 = 'ASIL_PIN_ENABLES_00'
        d8 = 'ASIL_CHECK_ENABLES_00'
        d9 = 'ASIL_STATUS_00'
        d10 = 'ASIL_STATUS_00__ASIL_STATUS_CLK_PIX_PARAM'
        d11 = 'ASIL_STATUS_00__ASIL_STATUS_CLK_PIX_100_PARAM'

        figTitle = 'SM_COUNT_CLK_PIX'
        ylabel = 'RegVal (Dec)'
        numDataCols = 12  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, 7, 2):  # 1 to 7 to plot clk cnt vs cnt expected
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, 7, 2):  # 1 to 7 to plot clk cnt vs cnt expected
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         legend=groupBy, show=showPlt,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_COUNT_CLK_REG(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ASIL_CLK_REG_COUNT_MSB_EXPECT'
        d2 = 'ASIL_CLK_REG_COUNT_MSB'
        d3 = 'ASIL_CLK_REG_COUNT_LSB_EXPECT'
        d4 = 'ASIL_CLK_REG_COUNT_LSB'
        d5 = 'ASIL_CLK_REG_COUNT_100_EXT_EXPECT'
        d6 = 'ASIL_CLK_REG_COUNT_100_EXT'
        d7 = 'ASIL_PIN_ENABLES_00'
        d8 = 'ASIL_CHECK_ENABLES_00'
        d9 = 'ASIL_STATUS_00'
        d10 = 'ASIL_STATUS_00__ASIL_STATUS_CLK_REG_PARAM'
        d11 = 'ASIL_STATUS_00__ASIL_STATUS_CLK_REG_100_PARAM'

        figTitle = 'SM_COUNT_CLK_REG'
        ylabel = 'RegVal (Dec)'
        numDataCols = 12  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, 7, 2):  # 1 to 7 to plot clk cnt vs cnt expected
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, 7, 2):  # 1 to 7 to plot clk cnt vs cnt expected
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         legend=groupBy, show=showPlt,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_COUNT_CLK_OP(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ASIL_CLK_OP_COUNT_MSB_EXPECT'
        d2 = 'ASIL_CLK_OP_COUNT_MSB'
        d3 = 'ASIL_CLK_OP_COUNT_LSB_EXPECT'
        d4 = 'ASIL_CLK_OP_COUNT_LSB'
        d5 = 'ASIL_CLK_OP_COUNT_100_EXT_EXPECT'
        d6 = 'ASIL_CLK_OP_COUNT_100_EXT'
        d7 = 'ASIL_PIN_ENABLES_00'
        d8 = 'ASIL_CHECK_ENABLES_00'
        d9 = 'ASIL_STATUS_00'
        d10 = 'ASIL_STATUS_00__ASIL_STATUS_CLK_OP_PARAM'
        d11 = 'ASIL_STATUS_00__ASIL_STATUS_CLK_OP_100_PARAM'

        figTitle = 'SM_COUNT_CLK_OP'
        ylabel = 'RegVal (Dec)'
        numDataCols = 12  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, 7, 2):  # 1 to 7 to plot clk cnt vs cnt expected
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, 7, 2):  # 1 to 7 to plot clk cnt vs cnt expected
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         legend=groupBy, show=showPlt,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_COUNT_EXTCLK_ASIC(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ASIL_ASIC_EXT_CLK_COUNT_MSB'
        d2 = 'ASIL_ASIC_EXT_CLK_COUNT_LSB'
        d3 = 'ASIL_PIN_ENABLES_00'
        d4 = 'ASIL_CHECK_ENABLES_00'
        d5 = 'ASIL_STATUS_00'
        d6 = 'ASIL_STATUS_00__ASIL_STATUS_EXT_CLK_PARAM'

        figTitle = 'SM_COUNT_EXTCLK_ASIC'
        ylabel = 'RegVal (Dec)'
        numDataCols = 7  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_COUNT_CLK_PIX_ASIC(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ASIL_ASIC_CLK_PIX_COUNT_MSB'
        d2 = 'ASIL_ASIC_CLK_PIX_COUNT_LSB'
        d3 = 'ASIL_PIN_ENABLES_00'
        d4 = 'ASIL_CHECK_ENABLES_00'
        d5 = 'ASIL_STATUS_00'
        d6 = 'ASIL_STATUS_00__ASIL_STATUS_CLK_PIX_PARAM'
        d7 = 'ASIL_STATUS_00__ASIL_STATUS_CLK_PIX_100_PARAM'

        figTitle = 'SM_COUNT_CLK_PIX_ASIC'
        ylabel = 'RegVal (Dec)'
        numDataCols = 8  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_COUNT_CLK_REG_ASIC(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ASIL_ASIC_CLK_REG_COUNT_MSB'
        d2 = 'ASIL_ASIC_CLK_REG_COUNT_LSB'
        d3 = 'ASIL_PIN_ENABLES_00'
        d4 = 'ASIL_CHECK_ENABLES_00'
        d5 = 'ASIL_STATUS_00'
        d6 = 'ASIL_STATUS_00__ASIL_STATUS_CLK_REG_PARAM'
        d7 = 'ASIL_STATUS_00__ASIL_STATUS_CLK_REG_100_PARAM'

        figTitle = 'SM_COUNT_CLK_REG_ASIC'
        ylabel = 'RegVal (Dec)'
        numDataCols = 8  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_COUNT_CLK_OP_ASIC(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ASIL_ASIC_CLK_OP_COUNT_MSB'
        d2 = 'ASIL_ASIC_CLK_OP_COUNT_LSB'
        d3 = 'ASIL_PIN_ENABLES_00'
        d4 = 'ASIL_CHECK_ENABLES_00'
        d5 = 'ASIL_STATUS_00'
        d6 = 'ASIL_STATUS_00__ASIL_STATUS_CLK_OP_PARAM'
        d7 = 'ASIL_STATUS_00__ASIL_STATUS_CLK_OP_100_PARAM'

        figTitle = 'SM_COUNT_CLK_OP_ASIC'
        ylabel = 'RegVal (Dec)'
        numDataCols = 8  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found


'''
EMBEDDED DATA & STATS SM'S
'''
def SM_EMBEDDED_DATA_CRC(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'CRC_EMB_WRT_CHECKSUM'
        d2 = 'CRC_EMB_CALC_CHECKSUM'
        d3 = 'ASIL_PIN_ENABLES_02'
        d4 = 'ASIL_CHECK_ENABLES_02'
        d5 = 'ASIL_STATUS_02__AUX_SEQUENCER_ECC_EMB_CRC_STATUS'

        figTitle = 'SM_EMBEDDED_DATA_CRC'
        ylabel = 'RegVal (Dec)'
        numDataCols = 6  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, 3, 2):  # 1 to 3 to plot similar thresholds
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, 3, 2):  # 1 to 3 to plot similar thresholds
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         legend=groupBy, show=showPlt,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_EMBEDDED_DATA_CRC_vs_Time_Plot(dataFrame, groupCol, groupVal, document, pltPath, showPlt, **kwargs):
    try:
        if groupCol == None and groupVal == None:  #Dont group data frame
            df = dataFrame
        elif groupCol != None and groupVal != None: #Group data frame by col and value
            df = VRG_Data_Frame.newdataframe(dataFrame, groupCol, groupVal)

        d1 = 'CRC_EMB_CALC_CHECKSUM Read'

        figTitle = 'Tempsensor_Reg_vs_Time'
        numDataCols = 2
        titleFontSize = 12
        yFontsize = 8
        xFontsize = 8
        legFontSize = 6

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        t1_cols = [x for x in df.columns[df.columns.str.contains(d1)]]
        t1 = df[t1_cols]

        for dc in t1_cols:
            t1 = t1.rename(columns={dc: dc.split(' ')[2]})

        t1 = t1.T
        t1['Read Num'] = t1.index

        colList = []
        for index in df.index:
            colList.append(index)

        if groupCol == None and groupVal == None:  # No Dataframe grouping
            fcp.plot(t1, x='Read Num', y=colList, title=d1, legend_title="Test #", label_y=d1, show=showPlt,
                     inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_heading(d1, level=3)
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
        elif groupCol != None and groupVal != None: # Data frame grouped by col and val
            fcp.plot(t1, x='Read Num', y=colList, title=d1 + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                     legend_title="Test #", label_y=d1, show=showPlt,
                     inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_heading(d1 + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for dc in t1_cols:  # 1 to 4
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        if groupCol == None:
            document.add_heading("groupCol Not Used", level=3)
        elif groupCol != None:
            if groupCol in df.columns:
                document.add_heading("groupCol Found: " + groupCol, level=3)  # Add Groupby found
                if groupVal == None:
                    document.add_heading("groupVal Missing", level=3)
                elif groupVal != None:
                    if groupCol in df[groupCol].unique():
                        document.add_heading("groupVal Found: " + groupVal, level=3)  # Add Groupby found
                    else:
                        document.add_heading("groupVal Not Found: " + groupVal, level=3)  # Add Groupby not found
            else:
                document.add_heading("groupCol Not Found: " + groupCol, level=3)  # Add Groupby not found

def EMBEDDED_DATA_Mismatch_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
         # Column Name to find
        d1 = 'Mismatch_Emb_'

        df = dataFrame

        # get data columns
        t1_cols = [x for x in df.columns[df.columns.str.contains(d1)]]

        figTitle = 'EMBEDDED_DATA_Mismatch_Plot'
        ylabel = 'RegVal (Dec)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        for dc in t1_cols: # loop through all column names
            if groupBy == None:  # Remove Legend= keyword
                # Plot each data frame column
                fcp.plot(df, x='Step', y=dc, title=dc, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + dc + '_' + timestamp + '.png')
                document.add_heading(dc, level=3)
                document.add_picture(pltPath + dc + '_' + timestamp + '.png')  # Add figure to report
            elif groupBy != None:
                # Plot each data frame column
                fcp.plot(df, x='Step', y=dc, title=dc, legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + dc + '_' + timestamp + '.png')
                document.add_heading(dc, level=3)
                document.add_picture(pltPath + dc + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def EMBEDDED_DATA_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'EMB_DATA_2000'
        d2 = 'EMB_DATA_2002'
        d3 = 'EMB_DATA_2004'
        d4 = 'EMB_DATA_2006'
        d5 = 'EMB_DATA_2008'
        d6 = 'EMB_DATA_200A'
        d7 = 'EMB_DATA_200C'
        d8 = 'EMB_DATA_200E'
        d9 = 'EMB_DATA_2010'
        d10 = 'EMB_DATA_2012'
        d11 = 'EMB_DATA_2014'
        d12 = 'EMB_DATA_2016'
        d13 = 'EMB_DATA_2018'
        d14 = 'EMB_DATA_201A'
        d15 = 'EMB_DATA_201C'
        d16 = 'EMB_DATA_2020'
        d17 = 'EMB_DATA_2022'
        d18 = 'EMB_DATA_2024'
        d19 = 'EMB_DATA_2026'
        d20 = 'EMB_DATA_2028'
        d21 = 'EMB_DATA_202A'
        d22 = 'EMB_DATA_202C'
        d23 = 'EMB_DATA_202E'
        d24 = 'EMB_DATA_2030'
        d25 = 'EMB_DATA_2032'
        d26 = 'EMB_DATA_2034'
        d27 = 'EMB_DATA_2036'
        d28 = 'EMB_DATA_2038'
        d29 = 'EMB_DATA_203A'
        d30 = 'EMB_DATA_203C'
        d31 = 'EMB_DATA_203E'
        d32 = 'EMB_DATA_2040'
        d33 = 'EMB_DATA_2042'
        d34 = 'EMB_DATA_2044'
        d35 = 'EMB_DATA_2046'
        d36 = 'EMB_DATA_2048'
        d37 = 'EMB_DATA_204A'
        d38 = 'EMB_DATA_204C'
        d39 = 'EMB_DATA_204E'
        d40 = 'EMB_DATA_2050'
        d41 = 'EMB_DATA_2054'
        d42 = 'EMB_DATA_2056'
        d43 = 'EMB_DATA_2058'
        d44 = 'EMB_DATA_205A'
        d45 = 'EMB_DATA_205C'
        d46 = 'EMB_DATA_205E'
        d47 = 'EMB_DATA_2060'
        d48 = 'EMB_DATA_2062'
        d49 = 'EMB_DATA_2064'
        d50 = 'EMB_DATA_2066'
        d51 = 'EMB_DATA_2068'
        d52 = 'EMB_DATA_206A'
        d53 = 'EMB_DATA_206C'
        d54 = 'EMB_DATA_206E'
        d55 = 'EMB_DATA_2070'
        d56 = 'EMB_DATA_2072'
        d57 = 'EMB_DATA_2074'
        d58 = 'EMB_DATA_2076'
        d59 = 'EMB_DATA_2078'
        d60 = 'EMB_DATA_207A'
        d61 = 'EMB_DATA_2080'
        d62 = 'EMB_DATA_2082'
        d63 = 'EMB_DATA_2084'
        d64 = 'EMB_DATA_2086'
        d65 = 'EMB_DATA_2088'
        d66 = 'EMB_DATA_208A'
        d67 = 'EMB_DATA_208C'
        d68 = 'EMB_DATA_208E'
        d69 = 'EMB_DATA_2090'
        d70 = 'EMB_DATA_2092'
        d71 = 'EMB_DATA_2094'
        d72 = 'EMB_DATA_2096'
        d73 = 'EMB_DATA_2098'
        d74 = 'EMB_DATA_209A'
        d75 = 'EMB_DATA_209C'
        d76 = 'EMB_DATA_209E'
        d77 = 'EMB_DATA_20B0'
        d78 = 'EMB_DATA_20B2'
        d79 = 'EMB_DATA_20B4'
        d80 = 'EMB_DATA_20B6'
        d81 = 'EMB_DATA_20B8'
        d82 = 'EMB_DATA_20BA'
        d83 = 'EMB_DATA_20BC'
        d84 = 'EMB_DATA_20BE'
        d85 = 'EMB_DATA_20C0'
        d86 = 'EMB_DATA_20C2'
        d87 = 'EMB_DATA_20C4'
        d88 = 'EMB_DATA_20C6'
        d89 = 'EMB_DATA_20C8'
        d90 = 'EMB_DATA_20CA'
        d91 = 'EMB_DATA_20CC'
        d92 = 'EMB_DATA_20CE'
        d93 = 'EMB_DATA_20D0'
        d94 = 'EMB_DATA_20D2'
        d95 = 'EMB_DATA_20D4'
        d96 = 'EMB_DATA_20D6'
        d97 = 'EMB_DATA_20D8'
        d98 = 'EMB_DATA_20DA'
        d99 = 'EMB_DATA_20DC'
        d100 = 'EMB_DATA_20DE'
        d101 = 'EMB_DATA_20E0'
        d102 = 'EMB_DATA_20E2'
        d103 = 'EMB_DATA_20E4'
        d104 = 'EMB_DATA_20E6'
        d105 = 'EMB_DATA_20E8'
        d106 = 'EMB_DATA_20EA'
        d107 = 'EMB_DATA_20EC'
        d108 = 'EMB_DATA_20EE'
        d109 = 'EMB_DATA_20F0'
        d110 = 'EMB_DATA_20F2'
        d111 = 'EMB_DATA_20F4'
        d112 = 'EMB_DATA_20F6'
        d113 = 'EMB_DATA_20F8'
        d114 = 'EMB_DATA_20FA'
        d115 = 'EMB_DATA_20FC'
        d116 = 'EMB_DATA_2300'
        d117 = 'EMB_DATA_2302'
        d118 = 'EMB_DATA_2304'
        d119 = 'EMB_DATA_2306'
        d120 = 'EMB_DATA_2308'
        d121 = 'EMB_DATA_230A'
        d122 = 'EMB_DATA_230C'
        d123 = 'EMB_DATA_230E'
        d124 = 'EMB_DATA_2310'
        d125 = 'EMB_DATA_2312'
        d126 = 'EMB_DATA_2314'
        d127 = 'EMB_DATA_2316'
        d128 = 'EMB_DATA_2318'
        d129 = 'EMB_DATA_231A'
        d130 = 'EMB_DATA_231C'
        d131 = 'EMB_DATA_231E'
        d132 = 'EMB_DATA_23E0'
        d133 = 'EMB_DATA_23E2'
        d134 = 'EMB_DATA_23E4'
        d135 = 'EMB_DATA_23E6'
        d136 = 'EMB_DATA_2520'
        d137 = 'EMB_DATA_2522'
        d138 = 'EMB_DATA_2524'
        d139 = 'EMB_DATA_2526'
        d140 = 'EMB_DATA_2528'
        d141 = 'EMB_DATA_252A'
        d142 = 'EMB_DATA_252C'
        d143 = 'EMB_DATA_252E'
        d144 = 'EMB_DATA_2530'
        d145 = 'EMB_DATA_2538'
        d146 = 'EMB_DATA_253A'
        d147 = 'EMB_DATA_253C'
        d148 = 'EMB_DATA_253E'
        d149 = 'EMB_DATA_2540'
        d150 = 'EMB_DATA_2542'
        d151 = 'EMB_DATA_2544'
        d152 = 'EMB_DATA_2546'
        d153 = 'EMB_DATA_2548'
        d154 = 'EMB_DATA_254A'
        d155 = 'EMB_DATA_254C'
        d156 = 'EMB_DATA_254E'
        d157 = 'EMB_DATA_2550'
        d158 = 'EMB_DATA_2552'
        d159 = 'EMB_DATA_2554'
        d160 = 'EMB_DATA_2556'
        d161 = 'EMB_DATA_2558'
        d162 = 'EMB_DATA_255A'
        d163 = 'EMB_DATA_255C'
        d164 = 'EMB_DATA_255E'
        d165 = 'EMB_DATA_2560'
        d166 = 'EMB_DATA_2562'
        d167 = 'EMB_DATA_2564'
        d168 = 'EMB_DATA_2566'
        d169 = 'EMB_DATA_2568'
        d170 = 'EMB_DATA_25CE'
        d171 = 'EMB_DATA_25D0'
        d172 = 'EMB_DATA_25D2'
        d173 = 'EMB_DATA_25D4'
        d174 = 'EMB_DATA_25D6'
        d175 = 'EMB_DATA_25D8'
        d176 = 'EMB_DATA_25DA'
        d177 = 'EMB_DATA_25DC'
        d178 = 'EMB_DATA_25DE'
        d179 = 'EMB_DATA_25E0'
        d180 = 'EMB_DATA_25E2'
        d181 = 'EMB_DATA_25E4'
        d182 = 'EMB_DATA_25E6'
        d183 = 'EMB_DATA_25E8'
        d184 = 'EMB_DATA_25EA'
        d185 = 'EMB_DATA_25EC'
        d186 = 'EMB_DATA_25EE'
        d187 = 'EMB_DATA_25F0'
        d188 = 'EMB_DATA_25F2'
        d189 = 'EMB_DATA_25F4'
        d190 = 'EMB_DATA_25F6'
        d191 = 'EMB_DATA_25F8'
        d192 = 'EMB_DATA_25FA'
        d193 = 'EMB_DATA_25FC'
        d194 = 'EMB_DATA_25FE'
        d195 = 'EMB_DATA_2E00'
        d196 = 'EMB_DATA_2E02'
        d197 = 'EMB_DATA_2E04'
        d198 = 'EMB_DATA_2E06'
        d199 = 'EMB_DATA_2E08'
        d200 = 'EMB_DATA_2E0A'
        d201 = 'EMB_DATA_2E0C'
        d202 = 'EMB_DATA_2E0E'
        d203 = 'EMB_DATA_2E10'
        d204 = 'EMB_DATA_2E12'
        d205 = 'EMB_DATA_2E14'
        d206 = 'EMB_DATA_2E16'
        d207 = 'EMB_DATA_2E18'
        d208 = 'EMB_DATA_2E1A'
        d209 = 'EMB_DATA_2E1C'
        d210 = 'EMB_DATA_2E1E'
        d211 = 'EMB_DATA_2E20'
        d212 = 'EMB_DATA_2E22'
        d213 = 'EMB_DATA_2E24'
        d214 = 'EMB_DATA_2E26'
        d215 = 'EMB_DATA_2E28'
        d216 = 'EMB_DATA_2E2A'
        d217 = 'EMB_DATA_2E2C'
        d218 = 'EMB_DATA_2E2E'
        d219 = 'EMB_DATA_2E30'
        d220 = 'EMB_DATA_2E32'
        d221 = 'EMB_DATA_2E34'
        d222 = 'EMB_DATA_2E36'
        d223 = 'EMB_DATA_2E38'
        d224 = 'EMB_DATA_2E3A'
        d225 = 'EMB_DATA_2E3C'
        d226 = 'EMB_DATA_2E3E'
        d227 = 'EMB_DATA_2E40'
        d228 = 'EMB_DATA_2E42'
        d229 = 'EMB_DATA_2E44'
        d230 = 'EMB_DATA_2E46'
        d231 = 'EMB_DATA_2E48'
        d232 = 'EMB_DATA_2E4A'
        d233 = 'EMB_DATA_2E4C'
        d234 = 'EMB_DATA_2E4E'
        d235 = 'EMB_DATA_2E50'
        d236 = 'EMB_DATA_2E52'
        d237 = 'EMB_DATA_2E54'
        d238 = 'EMB_DATA_2E56'
        d239 = 'EMB_DATA_2E58'
        d240 = 'EMB_DATA_2E5A'
        d241 = 'EMB_DATA_2E5C'
        d242 = 'EMB_DATA_2E5E'
        d243 = 'EMB_DATA_2E60'
        d244 = 'EMB_DATA_2E62'
        d245 = 'EMB_DATA_2E64'
        d246 = 'EMB_DATA_2E66'
        d247 = 'EMB_DATA_2E68'
        d248 = 'EMB_DATA_2E6A'
        d249 = 'EMB_DATA_2E6C'
        d250 = 'EMB_DATA_2E6E'
        d251 = 'EMB_DATA_2E70'
        d252 = 'EMB_DATA_2E72'
        d253 = 'EMB_DATA_2E74'
        d254 = 'EMB_DATA_2E76'
        d255 = 'EMB_DATA_2E78'
        d256 = 'EMB_DATA_2E7A'
        d257 = 'EMB_DATA_2E7C'
        d258 = 'EMB_DATA_2E7E'
        d259 = 'EMB_DATA_2E80'
        d260 = 'EMB_DATA_2F10'
        d261 = 'EMB_DATA_2F12'
        d262 = 'EMB_DATA_2F14'
        d263 = 'EMB_DATA_2F16'
        d264 = 'EMB_DATA_2F18'
        d265 = 'EMB_DATA_2F1A'
        d266 = 'EMB_DATA_2F1C'
        d267 = 'EMB_DATA_2F1E'
        d268 = 'EMB_DATA_2F20'
        d269 = 'EMB_DATA_2F22'
        d270 = 'EMB_DATA_2F24'
        d271 = 'EMB_DATA_2F26'
        d272 = 'EMB_DATA_2F28'
        d273 = 'EMB_DATA_2F2A'
        d274 = 'EMB_DATA_2F2C'
        d275 = 'EMB_DATA_2F2E'
        d276 = 'EMB_DATA_2F30'
        d277 = 'EMB_DATA_2F3A'
        d278 = 'EMB_DATA_2F3C'
        d279 = 'EMB_DATA_2F40'
        d280 = 'EMB_DATA_2F42'
        d281 = 'EMB_DATA_2F44'
        d282 = 'EMB_DATA_2F46'
        d283 = 'EMB_DATA_2F4C'
        d284 = 'EMB_DATA_2F4E'
        d285 = 'EMB_DATA_2F50'
        d286 = 'EMB_DATA_2F52'
        d287 = 'EMB_DATA_2F54'
        d288 = 'EMB_DATA_2F56'
        d289 = 'EMB_DATA_2F58'
        d290 = 'EMB_DATA_2F5A'
        d291 = 'EMB_DATA_2F5C'
        d292 = 'EMB_DATA_2F5E'
        d293 = 'EMB_DATA_2F60'
        d294 = 'EMB_DATA_2F62'
        d295 = 'EMB_DATA_2F64'
        d296 = 'EMB_DATA_3000'
        d297 = 'EMB_DATA_3002'
        d298 = 'EMB_DATA_3004'
        d299 = 'EMB_DATA_3006'
        d300 = 'EMB_DATA_3008'
        d301 = 'EMB_DATA_300A'
        d302 = 'EMB_DATA_300C'
        d303 = 'EMB_DATA_300E'
        d304 = 'EMB_DATA_3010'
        d305 = 'EMB_DATA_3012'
        d306 = 'EMB_DATA_3014'
        d307 = 'EMB_DATA_3016'
        d308 = 'EMB_DATA_3018'
        d309 = 'EMB_DATA_301A'
        d310 = 'EMB_DATA_301C'
        d311 = 'EMB_DATA_301E'
        d312 = 'EMB_DATA_3020'
        d313 = 'EMB_DATA_3022'
        d314 = 'EMB_DATA_3024'
        d315 = 'EMB_DATA_3026'
        d316 = 'EMB_DATA_3028'
        d317 = 'EMB_DATA_302A'
        d318 = 'EMB_DATA_302C'
        d319 = 'EMB_DATA_302E'
        d320 = 'EMB_DATA_3030'
        d321 = 'EMB_DATA_3032'
        d322 = 'EMB_DATA_3034'
        d323 = 'EMB_DATA_3036'
        d324 = 'EMB_DATA_3038'
        d325 = 'EMB_DATA_303A'
        d326 = 'EMB_DATA_303C'
        d327 = 'EMB_DATA_303E'
        d328 = 'EMB_DATA_3040'
        d329 = 'EMB_DATA_3042'
        d330 = 'EMB_DATA_3044'
        d331 = 'EMB_DATA_3046'
        d332 = 'EMB_DATA_3048'
        d333 = 'EMB_DATA_304A'
        d334 = 'EMB_DATA_304C'
        d335 = 'EMB_DATA_3050'
        d336 = 'EMB_DATA_3052'
        d337 = 'EMB_DATA_3054'
        d338 = 'EMB_DATA_3056'
        d339 = 'EMB_DATA_3058'
        d340 = 'EMB_DATA_305A'
        d341 = 'EMB_DATA_305C'
        d342 = 'EMB_DATA_305E'
        d343 = 'EMB_DATA_3060'
        d344 = 'EMB_DATA_3062'
        d345 = 'EMB_DATA_3064'
        d346 = 'EMB_DATA_3066'
        d347 = 'EMB_DATA_306E'
        d348 = 'EMB_DATA_3070'
        d349 = 'EMB_DATA_3072'
        d350 = 'EMB_DATA_3074'
        d351 = 'EMB_DATA_3076'
        d352 = 'EMB_DATA_3078'
        d353 = 'EMB_DATA_307A'
        d354 = 'EMB_DATA_307C'
        d355 = 'EMB_DATA_3082'
        d356 = 'EMB_DATA_3084'
        d357 = 'EMB_DATA_3086'
        d358 = 'EMB_DATA_308A'
        d359 = 'EMB_DATA_308C'
        d360 = 'EMB_DATA_308E'
        d361 = 'EMB_DATA_3090'
        d362 = 'EMB_DATA_3092'
        d363 = 'EMB_DATA_3094'
        d364 = 'EMB_DATA_3096'
        d365 = 'EMB_DATA_3098'
        d366 = 'EMB_DATA_309A'
        d367 = 'EMB_DATA_309C'
        d368 = 'EMB_DATA_309E'
        d369 = 'EMB_DATA_30A0'
        d370 = 'EMB_DATA_30A2'
        d371 = 'EMB_DATA_30A4'
        d372 = 'EMB_DATA_30A6'
        d373 = 'EMB_DATA_30A8'
        d374 = 'EMB_DATA_30AA'
        d375 = 'EMB_DATA_30AC'
        d376 = 'EMB_DATA_30AE'
        d377 = 'EMB_DATA_30B0'
        d378 = 'EMB_DATA_30B4'
        d379 = 'EMB_DATA_30B8'
        d380 = 'EMB_DATA_30BA'
        d381 = 'EMB_DATA_30BC'
        d382 = 'EMB_DATA_30BE'
        d383 = 'EMB_DATA_30C0'
        d384 = 'EMB_DATA_30C2'
        d385 = 'EMB_DATA_30C4'
        d386 = 'EMB_DATA_30C6'
        d387 = 'EMB_DATA_30C8'
        d388 = 'EMB_DATA_30CA'
        d389 = 'EMB_DATA_30CC'
        d390 = 'EMB_DATA_30CE'
        d391 = 'EMB_DATA_30D0'
        d392 = 'EMB_DATA_30D2'
        d393 = 'EMB_DATA_30DA'
        d394 = 'EMB_DATA_30DC'
        d395 = 'EMB_DATA_30DE'
        d396 = 'EMB_DATA_30E0'
        d397 = 'EMB_DATA_30E2'
        d398 = 'EMB_DATA_30E4'
        d399 = 'EMB_DATA_30E6'
        d400 = 'EMB_DATA_30E8'
        d401 = 'EMB_DATA_30EA'
        d402 = 'EMB_DATA_30EC'
        d403 = 'EMB_DATA_30EE'
        d404 = 'EMB_DATA_30F0'
        d405 = 'EMB_DATA_30FE'
        d406 = 'EMB_DATA_3100'
        d407 = 'EMB_DATA_3102'
        d408 = 'EMB_DATA_3104'
        d409 = 'EMB_DATA_3106'
        d410 = 'EMB_DATA_3108'
        d411 = 'EMB_DATA_310A'
        d412 = 'EMB_DATA_310C'
        d413 = 'EMB_DATA_3110'
        d414 = 'EMB_DATA_3112'
        d415 = 'EMB_DATA_3114'
        d416 = 'EMB_DATA_313A'
        d417 = 'EMB_DATA_313C'
        d418 = 'EMB_DATA_313E'
        d419 = 'EMB_DATA_3140'
        d420 = 'EMB_DATA_3142'
        d421 = 'EMB_DATA_3144'
        d422 = 'EMB_DATA_3146'
        d423 = 'EMB_DATA_3148'
        d424 = 'EMB_DATA_314A'
        d425 = 'EMB_DATA_314C'
        d426 = 'EMB_DATA_314E'
        d427 = 'EMB_DATA_315C'
        d428 = 'EMB_DATA_315E'
        d429 = 'EMB_DATA_3160'
        d430 = 'EMB_DATA_3162'
        d431 = 'EMB_DATA_3164'
        d432 = 'EMB_DATA_3176'
        d433 = 'EMB_DATA_3178'
        d434 = 'EMB_DATA_317A'
        d435 = 'EMB_DATA_317C'
        d436 = 'EMB_DATA_317E'
        d437 = 'EMB_DATA_3180'
        d438 = 'EMB_DATA_3182'
        d439 = 'EMB_DATA_3184'
        d440 = 'EMB_DATA_3186'
        d441 = 'EMB_DATA_3188'
        d442 = 'EMB_DATA_318A'
        d443 = 'EMB_DATA_318C'
        d444 = 'EMB_DATA_318E'
        d445 = 'EMB_DATA_3190'
        d446 = 'EMB_DATA_3192'
        d447 = 'EMB_DATA_3194'
        d448 = 'EMB_DATA_3196'
        d449 = 'EMB_DATA_3198'
        d450 = 'EMB_DATA_319A'
        d451 = 'EMB_DATA_319C'
        d452 = 'EMB_DATA_319E'
        d453 = 'EMB_DATA_31A0'
        d454 = 'EMB_DATA_31A2'
        d455 = 'EMB_DATA_31A4'
        d456 = 'EMB_DATA_31A6'
        d457 = 'EMB_DATA_31A8'
        d458 = 'EMB_DATA_31AA'
        d459 = 'EMB_DATA_31AC'
        d460 = 'EMB_DATA_31AE'
        d461 = 'EMB_DATA_31B0'
        d462 = 'EMB_DATA_31B2'
        d463 = 'EMB_DATA_31B4'
        d464 = 'EMB_DATA_31B6'
        d465 = 'EMB_DATA_31B8'
        d466 = 'EMB_DATA_31BA'
        d467 = 'EMB_DATA_31BC'
        d468 = 'EMB_DATA_31BE'
        d469 = 'EMB_DATA_31C0'
        d470 = 'EMB_DATA_31C2'
        d471 = 'EMB_DATA_31C4'
        d472 = 'EMB_DATA_31C6'
        d473 = 'EMB_DATA_31C8'
        d474 = 'EMB_DATA_31CA'
        d475 = 'EMB_DATA_31CC'
        d476 = 'EMB_DATA_31CE'
        d477 = 'EMB_DATA_31D0'
        d478 = 'EMB_DATA_31D2'
        d479 = 'EMB_DATA_31D4'
        d480 = 'EMB_DATA_31D6'
        d481 = 'EMB_DATA_31D8'
        d482 = 'EMB_DATA_31DA'
        d483 = 'EMB_DATA_31DC'
        d484 = 'EMB_DATA_31DE'
        d485 = 'EMB_DATA_31E0'
        d486 = 'EMB_DATA_31E2'
        d487 = 'EMB_DATA_31E4'
        d488 = 'EMB_DATA_31E6'
        d489 = 'EMB_DATA_31E8'
        d490 = 'EMB_DATA_31EA'
        d491 = 'EMB_DATA_31EC'
        d492 = 'EMB_DATA_31EE'
        d493 = 'EMB_DATA_31F0'
        d494 = 'EMB_DATA_31F2'
        d495 = 'EMB_DATA_31F4'
        d496 = 'EMB_DATA_31F6'
        d497 = 'EMB_DATA_31F8'
        d498 = 'EMB_DATA_31FA'
        d499 = 'EMB_DATA_31FC'
        d500 = 'EMB_DATA_31FE'
        d501 = 'EMB_DATA_3200'
        d502 = 'EMB_DATA_3202'
        d503 = 'EMB_DATA_3204'
        d504 = 'EMB_DATA_3206'
        d505 = 'EMB_DATA_3208'
        d506 = 'EMB_DATA_320A'
        d507 = 'EMB_DATA_320C'
        d508 = 'EMB_DATA_320E'
        d509 = 'EMB_DATA_3210'
        d510 = 'EMB_DATA_3212'
        d511 = 'EMB_DATA_3214'
        d512 = 'EMB_DATA_3216'
        d513 = 'EMB_DATA_3218'
        d514 = 'EMB_DATA_321A'
        d515 = 'EMB_DATA_321C'
        d516 = 'EMB_DATA_321E'
        d517 = 'EMB_DATA_3220'
        d518 = 'EMB_DATA_3222'
        d519 = 'EMB_DATA_3224'
        d520 = 'EMB_DATA_3226'
        d521 = 'EMB_DATA_3228'
        d522 = 'EMB_DATA_322A'
        d523 = 'EMB_DATA_322C'
        d524 = 'EMB_DATA_322E'
        d525 = 'EMB_DATA_3230'
        d526 = 'EMB_DATA_3232'
        d527 = 'EMB_DATA_3234'
        d528 = 'EMB_DATA_3236'
        d529 = 'EMB_DATA_3238'
        d530 = 'EMB_DATA_323A'
        d531 = 'EMB_DATA_323C'
        d532 = 'EMB_DATA_323E'
        d533 = 'EMB_DATA_3240'
        d534 = 'EMB_DATA_3242'
        d535 = 'EMB_DATA_3244'
        d536 = 'EMB_DATA_3246'
        d537 = 'EMB_DATA_3248'
        d538 = 'EMB_DATA_324A'
        d539 = 'EMB_DATA_324C'
        d540 = 'EMB_DATA_324E'
        d541 = 'EMB_DATA_325A'
        d542 = 'EMB_DATA_325C'
        d543 = 'EMB_DATA_325E'
        d544 = 'EMB_DATA_3264'
        d545 = 'EMB_DATA_3266'
        d546 = 'EMB_DATA_3268'
        d547 = 'EMB_DATA_326A'
        d548 = 'EMB_DATA_326C'
        d549 = 'EMB_DATA_3270'
        d550 = 'EMB_DATA_3272'
        d551 = 'EMB_DATA_3274'
        d552 = 'EMB_DATA_3276'
        d553 = 'EMB_DATA_3278'
        d554 = 'EMB_DATA_327A'
        d555 = 'EMB_DATA_327C'
        d556 = 'EMB_DATA_327E'
        d557 = 'EMB_DATA_3280'
        d558 = 'EMB_DATA_3282'
        d559 = 'EMB_DATA_3284'
        d560 = 'EMB_DATA_3286'
        d561 = 'EMB_DATA_3288'
        d562 = 'EMB_DATA_328A'
        d563 = 'EMB_DATA_328C'
        d564 = 'EMB_DATA_328E'
        d565 = 'EMB_DATA_3290'
        d566 = 'EMB_DATA_3292'
        d567 = 'EMB_DATA_3294'
        d568 = 'EMB_DATA_3296'
        d569 = 'EMB_DATA_3298'
        d570 = 'EMB_DATA_329A'
        d571 = 'EMB_DATA_329C'
        d572 = 'EMB_DATA_329E'
        d573 = 'EMB_DATA_32A0'
        d574 = 'EMB_DATA_32A2'
        d575 = 'EMB_DATA_32A4'
        d576 = 'EMB_DATA_32A6'
        d577 = 'EMB_DATA_32A8'
        d578 = 'EMB_DATA_32AE'
        d579 = 'EMB_DATA_32B0'
        d580 = 'EMB_DATA_32B2'
        d581 = 'EMB_DATA_32B4'
        d582 = 'EMB_DATA_32B6'
        d583 = 'EMB_DATA_32B8'
        d584 = 'EMB_DATA_32BA'
        d585 = 'EMB_DATA_32BC'
        d586 = 'EMB_DATA_32BE'
        d587 = 'EMB_DATA_32C0'
        d588 = 'EMB_DATA_32C2'
        d589 = 'EMB_DATA_32C4'
        d590 = 'EMB_DATA_32C6'
        d591 = 'EMB_DATA_32C8'
        d592 = 'EMB_DATA_32CA'
        d593 = 'EMB_DATA_32CC'
        d594 = 'EMB_DATA_32CE'
        d595 = 'EMB_DATA_32D0'
        d596 = 'EMB_DATA_32D2'
        d597 = 'EMB_DATA_32D4'
        d598 = 'EMB_DATA_32D6'
        d599 = 'EMB_DATA_32D8'
        d600 = 'EMB_DATA_32DA'
        d601 = 'EMB_DATA_32DC'
        d602 = 'EMB_DATA_32DE'
        d603 = 'EMB_DATA_32E0'
        d604 = 'EMB_DATA_32E2'
        d605 = 'EMB_DATA_32E6'
        d606 = 'EMB_DATA_32E8'
        d607 = 'EMB_DATA_32EA'
        d608 = 'EMB_DATA_32EC'
        d609 = 'EMB_DATA_32F0'
        d610 = 'EMB_DATA_32F2'
        d611 = 'EMB_DATA_32F4'
        d612 = 'EMB_DATA_32F6'
        d613 = 'EMB_DATA_32F8'
        d614 = 'EMB_DATA_32FA'
        d615 = 'EMB_DATA_32FC'
        d616 = 'EMB_DATA_32FE'
        d617 = 'EMB_DATA_3300'
        d618 = 'EMB_DATA_3302'
        d619 = 'EMB_DATA_3304'
        d620 = 'EMB_DATA_3306'
        d621 = 'EMB_DATA_3308'
        d622 = 'EMB_DATA_330A'
        d623 = 'EMB_DATA_330C'
        d624 = 'EMB_DATA_330E'
        d625 = 'EMB_DATA_3310'
        d626 = 'EMB_DATA_3312'
        d627 = 'EMB_DATA_3316'
        d628 = 'EMB_DATA_3318'
        d629 = 'EMB_DATA_331A'
        d630 = 'EMB_DATA_331C'
        d631 = 'EMB_DATA_331E'
        d632 = 'EMB_DATA_3320'
        d633 = 'EMB_DATA_3322'
        d634 = 'EMB_DATA_3324'
        d635 = 'EMB_DATA_3326'
        d636 = 'EMB_DATA_3328'
        d637 = 'EMB_DATA_332A'
        d638 = 'EMB_DATA_332C'
        d639 = 'EMB_DATA_332E'
        d640 = 'EMB_DATA_3330'
        d641 = 'EMB_DATA_3332'
        d642 = 'EMB_DATA_3334'
        d643 = 'EMB_DATA_3336'
        d644 = 'EMB_DATA_3338'
        d645 = 'EMB_DATA_333A'
        d646 = 'EMB_DATA_333C'
        d647 = 'EMB_DATA_333E'
        d648 = 'EMB_DATA_3340'
        d649 = 'EMB_DATA_3342'
        d650 = 'EMB_DATA_3344'
        d651 = 'EMB_DATA_3346'
        d652 = 'EMB_DATA_3348'
        d653 = 'EMB_DATA_334A'
        d654 = 'EMB_DATA_334C'
        d655 = 'EMB_DATA_334E'
        d656 = 'EMB_DATA_3350'
        d657 = 'EMB_DATA_3352'
        d658 = 'EMB_DATA_3354'
        d659 = 'EMB_DATA_3356'
        d660 = 'EMB_DATA_3358'
        d661 = 'EMB_DATA_335C'
        d662 = 'EMB_DATA_335E'
        d663 = 'EMB_DATA_3360'
        d664 = 'EMB_DATA_3362'
        d665 = 'EMB_DATA_3364'
        d666 = 'EMB_DATA_3366'
        d667 = 'EMB_DATA_3368'
        d668 = 'EMB_DATA_336A'
        d669 = 'EMB_DATA_336C'
        d670 = 'EMB_DATA_336E'
        d671 = 'EMB_DATA_3370'
        d672 = 'EMB_DATA_3372'
        d673 = 'EMB_DATA_3374'
        d674 = 'EMB_DATA_3376'
        d675 = 'EMB_DATA_3378'
        d676 = 'EMB_DATA_337A'
        d677 = 'EMB_DATA_337C'
        d678 = 'EMB_DATA_337E'
        d679 = 'EMB_DATA_3380'
        d680 = 'EMB_DATA_3382'
        d681 = 'EMB_DATA_3384'
        d682 = 'EMB_DATA_3386'
        d683 = 'EMB_DATA_3388'
        d684 = 'EMB_DATA_338A'
        d685 = 'EMB_DATA_338C'
        d686 = 'EMB_DATA_338E'
        d687 = 'EMB_DATA_3390'
        d688 = 'EMB_DATA_3392'
        d689 = 'EMB_DATA_3394'
        d690 = 'EMB_DATA_3396'
        d691 = 'EMB_DATA_3398'
        d692 = 'EMB_DATA_339A'
        d693 = 'EMB_DATA_339C'
        d694 = 'EMB_DATA_339E'
        d695 = 'EMB_DATA_33A0'
        d696 = 'EMB_DATA_33A2'
        d697 = 'EMB_DATA_33A4'
        d698 = 'EMB_DATA_33A6'
        d699 = 'EMB_DATA_33A8'
        d700 = 'EMB_DATA_33AA'
        d701 = 'EMB_DATA_33AC'
        d702 = 'EMB_DATA_33AE'
        d703 = 'EMB_DATA_33B0'
        d704 = 'EMB_DATA_33B2'
        d705 = 'EMB_DATA_33B4'
        d706 = 'EMB_DATA_33B6'
        d707 = 'EMB_DATA_33B8'
        d708 = 'EMB_DATA_33BA'
        d709 = 'EMB_DATA_33BC'
        d710 = 'EMB_DATA_33C0'
        d711 = 'EMB_DATA_33C2'
        d712 = 'EMB_DATA_33C4'
        d713 = 'EMB_DATA_33C6'
        d714 = 'EMB_DATA_33C8'
        d715 = 'EMB_DATA_33CA'
        d716 = 'EMB_DATA_33CC'
        d717 = 'EMB_DATA_33CE'
        d718 = 'EMB_DATA_33D0'
        d719 = 'EMB_DATA_33D2'
        d720 = 'EMB_DATA_33D4'
        d721 = 'EMB_DATA_33D6'
        d722 = 'EMB_DATA_33D8'
        d723 = 'EMB_DATA_33DA'
        d724 = 'EMB_DATA_33DE'
        d725 = 'EMB_DATA_33E0'
        d726 = 'EMB_DATA_33E2'
        d727 = 'EMB_DATA_33E4'
        d728 = 'EMB_DATA_33EE'
        d729 = 'EMB_DATA_33F0'
        d730 = 'EMB_DATA_33F2'
        d731 = 'EMB_DATA_3400'
        d732 = 'EMB_DATA_3402'
        d733 = 'EMB_DATA_3404'
        d734 = 'EMB_DATA_3406'
        d735 = 'EMB_DATA_3408'
        d736 = 'EMB_DATA_340A'
        d737 = 'EMB_DATA_340C'
        d738 = 'EMB_DATA_340E'
        d739 = 'EMB_DATA_3410'
        d740 = 'EMB_DATA_3412'
        d741 = 'EMB_DATA_3418'
        d742 = 'EMB_DATA_341A'
        d743 = 'EMB_DATA_3420'
        d744 = 'EMB_DATA_3422'
        d745 = 'EMB_DATA_3424'
        d746 = 'EMB_DATA_3426'
        d747 = 'EMB_DATA_3428'
        d748 = 'EMB_DATA_342A'
        d749 = 'EMB_DATA_342C'
        d750 = 'EMB_DATA_342E'
        d751 = 'EMB_DATA_3430'
        d752 = 'EMB_DATA_3432'
        d753 = 'EMB_DATA_3434'
        d754 = 'EMB_DATA_3436'
        d755 = 'EMB_DATA_3438'
        d756 = 'EMB_DATA_343A'
        d757 = 'EMB_DATA_343C'
        d758 = 'EMB_DATA_343E'
        d759 = 'EMB_DATA_3440'
        d760 = 'EMB_DATA_3442'
        d761 = 'EMB_DATA_3444'
        d762 = 'EMB_DATA_3446'
        d763 = 'EMB_DATA_3448'
        d764 = 'EMB_DATA_344A'
        d765 = 'EMB_DATA_344C'
        d766 = 'EMB_DATA_344E'
        d767 = 'EMB_DATA_3450'
        d768 = 'EMB_DATA_3452'
        d769 = 'EMB_DATA_3454'
        d770 = 'EMB_DATA_3456'
        d771 = 'EMB_DATA_3458'
        d772 = 'EMB_DATA_345A'
        d773 = 'EMB_DATA_345C'
        d774 = 'EMB_DATA_345E'
        d775 = 'EMB_DATA_3460'
        d776 = 'EMB_DATA_3462'
        d777 = 'EMB_DATA_3464'
        d778 = 'EMB_DATA_3466'
        d779 = 'EMB_DATA_3468'
        d780 = 'EMB_DATA_346A'
        d781 = 'EMB_DATA_346C'
        d782 = 'EMB_DATA_346E'
        d783 = 'EMB_DATA_3470'
        d784 = 'EMB_DATA_3472'
        d785 = 'EMB_DATA_3474'
        d786 = 'EMB_DATA_3476'
        d787 = 'EMB_DATA_3478'
        d788 = 'EMB_DATA_347A'
        d789 = 'EMB_DATA_347C'
        d790 = 'EMB_DATA_347E'
        d791 = 'EMB_DATA_3480'
        d792 = 'EMB_DATA_3482'
        d793 = 'EMB_DATA_3484'
        d794 = 'EMB_DATA_3486'
        d795 = 'EMB_DATA_3488'
        d796 = 'EMB_DATA_348A'
        d797 = 'EMB_DATA_348C'
        d798 = 'EMB_DATA_3492'
        d799 = 'EMB_DATA_3494'
        d800 = 'EMB_DATA_3496'
        d801 = 'EMB_DATA_3498'
        d802 = 'EMB_DATA_349A'
        d803 = 'EMB_DATA_349C'
        d804 = 'EMB_DATA_349E'
        d805 = 'EMB_DATA_34A0'
        d806 = 'EMB_DATA_34A2'
        d807 = 'EMB_DATA_34A4'
        d808 = 'EMB_DATA_34A6'
        d809 = 'EMB_DATA_34A8'
        d810 = 'EMB_DATA_34AA'
        d811 = 'EMB_DATA_34AC'
        d812 = 'EMB_DATA_34AE'
        d813 = 'EMB_DATA_34B0'
        d814 = 'EMB_DATA_34B2'
        d815 = 'EMB_DATA_34B4'
        d816 = 'EMB_DATA_34B6'
        d817 = 'EMB_DATA_34B8'
        d818 = 'EMB_DATA_34BA'
        d819 = 'EMB_DATA_34BC'
        d820 = 'EMB_DATA_34BE'
        d821 = 'EMB_DATA_34C0'
        d822 = 'EMB_DATA_34C2'
        d823 = 'EMB_DATA_34C4'
        d824 = 'EMB_DATA_34C6'
        d825 = 'EMB_DATA_34C8'
        d826 = 'EMB_DATA_34CA'
        d827 = 'EMB_DATA_34CC'
        d828 = 'EMB_DATA_34CE'
        d829 = 'EMB_DATA_34D4'
        d830 = 'EMB_DATA_34D6'
        d831 = 'EMB_DATA_34D8'
        d832 = 'EMB_DATA_34DA'
        d833 = 'EMB_DATA_34DC'
        d834 = 'EMB_DATA_34DE'
        d835 = 'EMB_DATA_34E0'
        d836 = 'EMB_DATA_34E2'
        d837 = 'EMB_DATA_34E4'
        d838 = 'EMB_DATA_34E6'
        d839 = 'EMB_DATA_34E8'
        d840 = 'EMB_DATA_34EA'
        d841 = 'EMB_DATA_34EC'
        d842 = 'EMB_DATA_34EE'
        d843 = 'EMB_DATA_34F0'
        d844 = 'EMB_DATA_34F2'
        d845 = 'EMB_DATA_34F4'
        d846 = 'EMB_DATA_34F6'
        d847 = 'EMB_DATA_34F8'
        d848 = 'EMB_DATA_34FA'
        d849 = 'EMB_DATA_34FC'
        d850 = 'EMB_DATA_3500'
        d851 = 'EMB_DATA_3502'
        d852 = 'EMB_DATA_3504'
        d853 = 'EMB_DATA_3506'
        d854 = 'EMB_DATA_3508'
        d855 = 'EMB_DATA_350A'
        d856 = 'EMB_DATA_350C'
        d857 = 'EMB_DATA_350E'
        d858 = 'EMB_DATA_3510'
        d859 = 'EMB_DATA_3512'
        d860 = 'EMB_DATA_3514'
        d861 = 'EMB_DATA_3516'
        d862 = 'EMB_DATA_3518'
        d863 = 'EMB_DATA_351A'
        d864 = 'EMB_DATA_351C'
        d865 = 'EMB_DATA_351E'
        d866 = 'EMB_DATA_3520'
        d867 = 'EMB_DATA_3522'
        d868 = 'EMB_DATA_3524'
        d869 = 'EMB_DATA_3526'
        d870 = 'EMB_DATA_3528'
        d871 = 'EMB_DATA_352A'
        d872 = 'EMB_DATA_352C'
        d873 = 'EMB_DATA_352E'
        d874 = 'EMB_DATA_3530'
        d875 = 'EMB_DATA_3532'
        d876 = 'EMB_DATA_3534'
        d877 = 'EMB_DATA_3536'
        d878 = 'EMB_DATA_3538'
        d879 = 'EMB_DATA_353A'
        d880 = 'EMB_DATA_353C'
        d881 = 'EMB_DATA_353E'
        d882 = 'EMB_DATA_3540'
        d883 = 'EMB_DATA_3542'
        d884 = 'EMB_DATA_3544'
        d885 = 'EMB_DATA_3546'
        d886 = 'EMB_DATA_3548'
        d887 = 'EMB_DATA_354A'
        d888 = 'EMB_DATA_354C'
        d889 = 'EMB_DATA_354E'
        d890 = 'EMB_DATA_3550'
        d891 = 'EMB_DATA_3552'
        d892 = 'EMB_DATA_3554'
        d893 = 'EMB_DATA_3556'
        d894 = 'EMB_DATA_3558'
        d895 = 'EMB_DATA_355A'
        d896 = 'EMB_DATA_355C'
        d897 = 'EMB_DATA_355E'
        d898 = 'EMB_DATA_3560'
        d899 = 'EMB_DATA_3562'
        d900 = 'EMB_DATA_3564'
        d901 = 'EMB_DATA_3566'
        d902 = 'EMB_DATA_3568'
        d903 = 'EMB_DATA_356A'
        d904 = 'EMB_DATA_356C'
        d905 = 'EMB_DATA_356E'
        d906 = 'EMB_DATA_3570'
        d907 = 'EMB_DATA_3572'
        d908 = 'EMB_DATA_3574'
        d909 = 'EMB_DATA_3576'
        d910 = 'EMB_DATA_3578'
        d911 = 'EMB_DATA_357A'
        d912 = 'EMB_DATA_357C'
        d913 = 'EMB_DATA_357E'
        d914 = 'EMB_DATA_3580'
        d915 = 'EMB_DATA_3582'
        d916 = 'EMB_DATA_3584'
        d917 = 'EMB_DATA_3586'
        d918 = 'EMB_DATA_35A0'
        d919 = 'EMB_DATA_35A2'
        d920 = 'EMB_DATA_35A4'
        d921 = 'EMB_DATA_35A6'
        d922 = 'EMB_DATA_35A8'
        d923 = 'EMB_DATA_35AA'
        d924 = 'EMB_DATA_35AC'
        d925 = 'EMB_DATA_35AE'
        d926 = 'EMB_DATA_35F0'
        d927 = 'EMB_DATA_35F2'
        d928 = 'EMB_DATA_35F4'
        d929 = 'EMB_DATA_35F6'
        d930 = 'EMB_DATA_35F8'
        d931 = 'EMB_DATA_35FA'
        d932 = 'EMB_DATA_36B0'
        d933 = 'EMB_DATA_36B2'
        d934 = 'EMB_DATA_36B4'
        d935 = 'EMB_DATA_36B6'
        d936 = 'EMB_DATA_36B8'
        d937 = 'EMB_DATA_36BA'
        d938 = 'EMB_DATA_36BC'
        d939 = 'EMB_DATA_36BE'
        d940 = 'EMB_DATA_36E8'
        d941 = 'EMB_DATA_36EA'
        d942 = 'EMB_DATA_36EC'
        d943 = 'EMB_DATA_36EE'
        d944 = 'EMB_DATA_36F0'
        d945 = 'EMB_DATA_3750'
        d946 = 'EMB_DATA_3752'
        d947 = 'EMB_DATA_3760'
        d948 = 'EMB_DATA_3762'
        d949 = 'EMB_DATA_3764'
        d950 = 'EMB_DATA_3772'
        d951 = 'EMB_DATA_3774'
        d952 = 'EMB_DATA_3782'
        d953 = 'EMB_DATA_3784'
        d954 = 'EMB_DATA_37B0'
        d955 = 'EMB_DATA_37B2'
        d956 = 'EMB_DATA_37B4'
        d957 = 'EMB_DATA_37B6'
        d958 = 'EMB_DATA_3800'
        d959 = 'EMB_DATA_3802'
        d960 = 'EMB_DATA_3804'
        d961 = 'EMB_DATA_3806'
        d962 = 'EMB_DATA_3808'
        d963 = 'EMB_DATA_380A'
        d964 = 'EMB_DATA_380C'
        d965 = 'EMB_DATA_380E'
        d966 = 'EMB_DATA_3810'
        d967 = 'EMB_DATA_3812'
        d968 = 'EMB_DATA_3814'
        d969 = 'EMB_DATA_3816'
        d970 = 'EMB_DATA_3818'
        d971 = 'EMB_DATA_381A'
        d972 = 'EMB_DATA_381C'
        d973 = 'EMB_DATA_381E'
        d974 = 'EMB_DATA_3820'
        d975 = 'EMB_DATA_3822'
        d976 = 'EMB_DATA_3824'
        d977 = 'EMB_DATA_3826'
        d978 = 'EMB_DATA_3828'
        d979 = 'EMB_DATA_382A'
        d980 = 'EMB_DATA_382C'
        d981 = 'EMB_DATA_382E'
        d982 = 'EMB_DATA_3830'
        d983 = 'EMB_DATA_3832'
        d984 = 'EMB_DATA_3834'
        d985 = 'EMB_DATA_3836'
        d986 = 'EMB_DATA_3838'
        d987 = 'EMB_DATA_383A'
        d988 = 'EMB_DATA_383C'
        d989 = 'EMB_DATA_383E'
        d990 = 'EMB_DATA_3840'
        d991 = 'EMB_DATA_3842'
        d992 = 'EMB_DATA_3844'
        d993 = 'EMB_DATA_3846'
        d994 = 'EMB_DATA_3848'
        d995 = 'EMB_DATA_384A'
        d996 = 'EMB_DATA_384C'
        d997 = 'EMB_DATA_384E'
        d998 = 'EMB_DATA_3850'
        d999 = 'EMB_DATA_3852'
        d1000 = 'EMB_DATA_3854'
        d1001 = 'EMB_DATA_3856'
        d1002 = 'EMB_DATA_3858'
        d1003 = 'EMB_DATA_385A'
        d1004 = 'EMB_DATA_385C'
        d1005 = 'EMB_DATA_385E'
        d1006 = 'EMB_DATA_3860'
        d1007 = 'EMB_DATA_3862'
        d1008 = 'EMB_DATA_3864'
        d1009 = 'EMB_DATA_3866'
        d1010 = 'EMB_DATA_3868'
        d1011 = 'EMB_DATA_386A'
        d1012 = 'EMB_DATA_386C'
        d1013 = 'EMB_DATA_386E'
        d1014 = 'EMB_DATA_3870'
        d1015 = 'EMB_DATA_3872'
        d1016 = 'EMB_DATA_3874'
        d1017 = 'EMB_DATA_3876'
        d1018 = 'EMB_DATA_3878'
        d1019 = 'EMB_DATA_387A'
        d1020 = 'EMB_DATA_387C'
        d1021 = 'EMB_DATA_387E'
        d1022 = 'EMB_DATA_3C00'
        d1023 = 'EMB_DATA_3C04'
        d1024 = 'EMB_DATA_3C06'
        d1025 = 'EMB_DATA_3C08'
        d1026 = 'EMB_DATA_3C0A'
        d1027 = 'EMB_DATA_3C0C'
        d1028 = 'EMB_DATA_3C10'
        d1029 = 'EMB_DATA_3C12'
        d1030 = 'EMB_DATA_3C14'
        d1031 = 'EMB_DATA_3C16'
        d1032 = 'EMB_DATA_3C18'
        d1033 = 'EMB_DATA_3C1A'
        d1034 = 'EMB_DATA_3C1C'
        d1035 = 'EMB_DATA_3C1E'
        d1036 = 'EMB_DATA_3C20'
        d1037 = 'EMB_DATA_3C22'
        d1038 = 'EMB_DATA_3C24'
        d1039 = 'EMB_DATA_3C26'
        d1040 = 'EMB_DATA_3C28'
        d1041 = 'EMB_DATA_3C2A'
        d1042 = 'EMB_DATA_3C2C'
        d1043 = 'EMB_DATA_3C2E'
        d1044 = 'EMB_DATA_3C30'
        d1045 = 'EMB_DATA_3C32'
        d1046 = 'EMB_DATA_3C34'
        d1047 = 'EMB_DATA_3C36'
        d1048 = 'EMB_DATA_3C38'
        d1049 = 'EMB_DATA_3C40'
        d1050 = 'EMB_DATA_3C42'
        d1051 = 'EMB_DATA_3C44'
        d1052 = 'EMB_DATA_3C46'
        d1053 = 'EMB_DATA_3C48'
        d1054 = 'EMB_DATA_3C4A'
        d1055 = 'EMB_DATA_3C4C'
        d1056 = 'EMB_DATA_3C4E'
        d1057 = 'EMB_DATA_3C50'
        d1058 = 'EMB_DATA_3C52'
        d1059 = 'EMB_DATA_3C54'
        d1060 = 'EMB_DATA_3C56'
        d1061 = 'EMB_DATA_3C58'
        d1062 = 'EMB_DATA_3C5A'
        d1063 = 'EMB_DATA_3C5C'
        d1064 = 'EMB_DATA_3C60'
        d1065 = 'EMB_DATA_3C62'
        d1066 = 'EMB_DATA_3C64'
        d1067 = 'EMB_DATA_3C66'
        d1068 = 'EMB_DATA_3C68'
        d1069 = 'EMB_DATA_3C6A'
        d1070 = 'EMB_DATA_3C6C'
        d1071 = 'EMB_DATA_3C7E'
        d1072 = 'EMB_DATA_3C80'
        d1073 = 'EMB_DATA_3C82'
        d1074 = 'EMB_DATA_3C84'
        d1075 = 'EMB_DATA_3C86'
        d1076 = 'EMB_DATA_3D00'
        d1077 = 'EMB_DATA_3D02'
        d1078 = 'EMB_DATA_3D04'
        d1079 = 'EMB_DATA_3D08'
        d1080 = 'EMB_DATA_3D0A'
        d1081 = 'EMB_DATA_3D0C'
        d1082 = 'EMB_DATA_3D0E'
        d1083 = 'EMB_DATA_3D10'
        d1084 = 'EMB_DATA_3D12'
        d1085 = 'EMB_DATA_3D14'
        d1086 = 'EMB_DATA_3D16'
        d1087 = 'EMB_DATA_3D18'
        d1088 = 'EMB_DATA_3D1A'
        d1089 = 'EMB_DATA_3D1C'
        d1090 = 'EMB_DATA_3D1E'
        d1091 = 'EMB_DATA_3D20'
        d1092 = 'EMB_DATA_3D22'
        d1093 = 'EMB_DATA_3D24'
        d1094 = 'EMB_DATA_3D26'
        d1095 = 'EMB_DATA_3D28'
        d1096 = 'EMB_DATA_3D2A'
        d1097 = 'EMB_DATA_3D2C'
        d1098 = 'EMB_DATA_3D2E'
        d1099 = 'EMB_DATA_3D30'
        d1100 = 'EMB_DATA_3D32'
        d1101 = 'EMB_DATA_3D34'
        d1102 = 'EMB_DATA_3D36'
        d1103 = 'EMB_DATA_3D38'
        d1104 = 'EMB_DATA_3D3A'
        d1105 = 'EMB_DATA_3D3C'
        d1106 = 'EMB_DATA_3D3E'
        d1107 = 'EMB_DATA_3D40'
        d1108 = 'EMB_DATA_3D42'
        d1109 = 'EMB_DATA_3D44'
        d1110 = 'EMB_DATA_3D46'
        d1111 = 'EMB_DATA_3D48'
        d1112 = 'EMB_DATA_3D4A'
        d1113 = 'EMB_DATA_3D4C'
        d1114 = 'EMB_DATA_3D4E'
        d1115 = 'EMB_DATA_3D50'
        d1116 = 'EMB_DATA_3D52'
        d1117 = 'EMB_DATA_3D54'
        d1118 = 'EMB_DATA_3D56'
        d1119 = 'EMB_DATA_3D58'
        d1120 = 'EMB_DATA_3D5A'
        d1121 = 'EMB_DATA_3D5C'
        d1122 = 'EMB_DATA_3D64'
        d1123 = 'EMB_DATA_3D66'
        d1124 = 'EMB_DATA_3D68'
        d1125 = 'EMB_DATA_3D6A'
        d1126 = 'EMB_DATA_3D6C'
        d1127 = 'EMB_DATA_3D6E'
        d1128 = 'EMB_DATA_3D70'
        d1129 = 'EMB_DATA_3D72'
        d1130 = 'EMB_DATA_3D74'
        d1131 = 'EMB_DATA_3D76'
        d1132 = 'EMB_DATA_3D78'
        d1133 = 'EMB_DATA_3D7A'
        d1134 = 'EMB_DATA_3D7C'
        d1135 = 'EMB_DATA_3D7E'
        d1136 = 'EMB_DATA_3D80'
        d1137 = 'EMB_DATA_3D82'
        d1138 = 'EMB_DATA_3D84'
        d1139 = 'EMB_DATA_3D86'
        d1140 = 'EMB_DATA_3D88'
        d1141 = 'EMB_DATA_3D8A'
        d1142 = 'EMB_DATA_3D8C'
        d1143 = 'EMB_DATA_3D8E'
        d1144 = 'EMB_DATA_3D90'
        d1145 = 'EMB_DATA_3D92'
        d1146 = 'EMB_DATA_3D94'
        d1147 = 'EMB_DATA_3D96'
        d1148 = 'EMB_DATA_3D98'
        d1149 = 'EMB_DATA_3D9A'
        d1150 = 'EMB_DATA_3D9C'
        d1151 = 'EMB_DATA_3D9E'
        d1152 = 'EMB_DATA_3DA0'
        d1153 = 'EMB_DATA_3DA2'
        d1154 = 'EMB_DATA_3DA4'
        d1155 = 'EMB_DATA_3DA6'
        d1156 = 'EMB_DATA_3DA8'
        d1157 = 'EMB_DATA_3DAA'
        d1158 = 'EMB_DATA_3DAC'
        d1159 = 'EMB_DATA_3DAE'
        d1160 = 'EMB_DATA_3DB0'
        d1161 = 'EMB_DATA_3DB2'
        d1162 = 'EMB_DATA_3DB4'
        d1163 = 'EMB_DATA_3DB6'
        d1164 = 'EMB_DATA_3DB8'
        d1165 = 'EMB_DATA_3DBA'
        d1166 = 'EMB_DATA_3DBC'
        d1167 = 'EMB_DATA_3DBE'
        d1168 = 'EMB_DATA_3DC0'
        d1169 = 'EMB_DATA_3DC2'
        d1170 = 'EMB_DATA_3DC4'
        d1171 = 'EMB_DATA_3DC6'
        d1172 = 'EMB_DATA_3DC8'
        d1173 = 'EMB_DATA_3DCA'
        d1174 = 'EMB_DATA_3DCC'
        d1175 = 'EMB_DATA_3DCE'
        d1176 = 'EMB_DATA_3DD0'
        d1177 = 'EMB_DATA_3DD2'
        d1178 = 'EMB_DATA_3DD4'
        d1179 = 'EMB_DATA_3DD6'
        d1180 = 'EMB_DATA_3DD8'
        d1181 = 'EMB_DATA_3DDA'
        d1182 = 'EMB_DATA_3DDC'
        d1183 = 'EMB_DATA_3DDE'
        d1184 = 'EMB_DATA_3DE0'
        d1185 = 'EMB_DATA_3DE2'
        d1186 = 'EMB_DATA_3DE4'
        d1187 = 'EMB_DATA_3DE6'
        d1188 = 'EMB_DATA_3E00'
        d1189 = 'EMB_DATA_3E02'
        d1190 = 'EMB_DATA_3E04'
        d1191 = 'EMB_DATA_3E06'
        d1192 = 'EMB_DATA_3E08'
        d1193 = 'EMB_DATA_3E0A'
        d1194 = 'EMB_DATA_3E0C'
        d1195 = 'EMB_DATA_3E0E'
        d1196 = 'EMB_DATA_3E10'
        d1197 = 'EMB_DATA_3E12'
        d1198 = 'EMB_DATA_3E14'
        d1199 = 'EMB_DATA_3E16'
        d1200 = 'EMB_DATA_3E18'
        d1201 = 'EMB_DATA_3E1A'
        d1202 = 'EMB_DATA_3E1C'
        d1203 = 'EMB_DATA_3E1E'
        d1204 = 'EMB_DATA_3E20'
        d1205 = 'EMB_DATA_3E22'
        d1206 = 'EMB_DATA_3E24'
        d1207 = 'EMB_DATA_3E26'
        d1208 = 'EMB_DATA_3E28'
        d1209 = 'EMB_DATA_3E2A'
        d1210 = 'EMB_DATA_3E2C'
        d1211 = 'EMB_DATA_3E2E'
        d1212 = 'EMB_DATA_3E30'
        d1213 = 'EMB_DATA_3E32'
        d1214 = 'EMB_DATA_3E34'
        d1215 = 'EMB_DATA_3E36'
        d1216 = 'EMB_DATA_3E3E'
        d1217 = 'EMB_DATA_3E40'
        d1218 = 'EMB_DATA_3E42'
        d1219 = 'EMB_DATA_3E44'
        d1220 = 'EMB_DATA_3E46'
        d1221 = 'EMB_DATA_3E48'
        d1222 = 'EMB_DATA_3E4A'
        d1223 = 'EMB_DATA_3E4C'
        d1224 = 'EMB_DATA_3E4E'
        d1225 = 'EMB_DATA_3E50'
        d1226 = 'EMB_DATA_3E52'
        d1227 = 'EMB_DATA_3E54'
        d1228 = 'EMB_DATA_3E56'
        d1229 = 'EMB_DATA_3E64'
        d1230 = 'EMB_DATA_3E66'
        d1231 = 'EMB_DATA_3E68'
        d1232 = 'EMB_DATA_3E6A'
        d1233 = 'EMB_DATA_3E6C'
        d1234 = 'EMB_DATA_3E6E'
        d1235 = 'EMB_DATA_3E70'
        d1236 = 'EMB_DATA_3E72'
        d1237 = 'EMB_DATA_3E74'
        d1238 = 'EMB_DATA_3E76'
        d1239 = 'EMB_DATA_3E78'
        d1240 = 'EMB_DATA_3E7A'
        d1241 = 'EMB_DATA_3E7C'
        d1242 = 'EMB_DATA_3E7E'
        d1243 = 'EMB_DATA_3E80'
        d1244 = 'EMB_DATA_3E82'
        d1245 = 'EMB_DATA_3E84'
        d1246 = 'EMB_DATA_3E86'
        d1247 = 'EMB_DATA_3E88'
        d1248 = 'EMB_DATA_3E8A'
        d1249 = 'EMB_DATA_3E8C'
        d1250 = 'EMB_DATA_3E8E'
        d1251 = 'EMB_DATA_3E90'
        d1252 = 'EMB_DATA_3E92'
        d1253 = 'EMB_DATA_3E94'
        d1254 = 'EMB_DATA_3E96'
        d1255 = 'EMB_DATA_3E98'
        d1256 = 'EMB_DATA_3E9A'
        d1257 = 'EMB_DATA_3E9C'
        d1258 = 'EMB_DATA_3E9E'
        d1259 = 'EMB_DATA_3EA0'
        d1260 = 'EMB_DATA_3EA2'
        d1261 = 'EMB_DATA_3EA4'
        d1262 = 'EMB_DATA_3EA6'
        d1263 = 'EMB_DATA_3EA8'
        d1264 = 'EMB_DATA_3EAA'
        d1265 = 'EMB_DATA_3EAC'
        d1266 = 'EMB_DATA_3EAE'
        d1267 = 'EMB_DATA_3EB0'
        d1268 = 'EMB_DATA_3EB2'
        d1269 = 'EMB_DATA_3EB4'
        d1270 = 'EMB_DATA_3EB6'
        d1271 = 'EMB_DATA_3EB8'
        d1272 = 'EMB_DATA_3EBA'
        d1273 = 'EMB_DATA_3EBC'
        d1274 = 'EMB_DATA_3EBE'
        d1275 = 'EMB_DATA_3EC0'
        d1276 = 'EMB_DATA_3EC2'
        d1277 = 'EMB_DATA_3EE0'
        d1278 = 'EMB_DATA_3EE2'
        d1279 = 'EMB_DATA_3EF0'
        d1280 = 'EMB_DATA_3EF2'
        d1281 = 'EMB_DATA_3EF8'
        d1282 = 'EMB_DATA_3EFA'
        d1283 = 'EMB_DATA_3EFC'
        d1284 = 'EMB_DATA_3EFE'
        d1285 = 'EMB_DATA_3F1A'
        d1286 = 'EMB_DATA_3F1C'
        d1287 = 'EMB_DATA_3F1E'
        d1288 = 'EMB_DATA_3F20'
        d1289 = 'EMB_DATA_3F22'
        d1290 = 'EMB_DATA_3F24'
        d1291 = 'EMB_DATA_3F26'
        d1292 = 'EMB_DATA_3F28'
        d1293 = 'EMB_DATA_3F2A'
        d1294 = 'EMB_DATA_3F2C'
        d1295 = 'EMB_DATA_3F2E'
        d1296 = 'EMB_DATA_3F30'
        d1297 = 'EMB_DATA_3F32'
        d1298 = 'EMB_DATA_3F34'
        d1299 = 'EMB_DATA_3F36'
        d1300 = 'EMB_DATA_3F38'
        d1301 = 'EMB_DATA_3F3A'
        d1302 = 'EMB_DATA_3F3C'
        d1303 = 'EMB_DATA_3F3E'
        d1304 = 'EMB_DATA_3F40'
        d1305 = 'EMB_DATA_3F42'
        d1306 = 'EMB_DATA_3F44'
        d1307 = 'EMB_DATA_3F48'
        d1308 = 'EMB_DATA_3F4A'
        d1309 = 'EMB_DATA_3F4C'
        d1310 = 'EMB_DATA_3F4E'
        d1311 = 'EMB_DATA_3F50'
        d1312 = 'EMB_DATA_3F52'
        d1313 = 'EMB_DATA_3F54'
        d1314 = 'EMB_DATA_3F56'
        d1315 = 'EMB_DATA_3F58'
        d1316 = 'EMB_DATA_3F5A'
        d1317 = 'EMB_DATA_3F5C'
        d1318 = 'EMB_DATA_3F5E'
        d1319 = 'EMB_DATA_3F60'
        d1320 = 'EMB_DATA_3F62'
        d1321 = 'EMB_DATA_3F64'
        d1322 = 'EMB_DATA_3F66'
        d1323 = 'EMB_DATA_3F68'
        d1324 = 'EMB_DATA_3F6A'
        d1325 = 'EMB_DATA_3F6C'
        d1326 = 'EMB_DATA_3F6E'
        d1327 = 'EMB_DATA_3F70'
        d1328 = 'EMB_DATA_3F72'
        d1329 = 'EMB_DATA_3F74'
        d1330 = 'EMB_DATA_3F76'
        d1331 = 'EMB_DATA_3F78'
        d1332 = 'EMB_DATA_3F7A'
        d1333 = 'EMB_DATA_3F80'
        d1334 = 'EMB_DATA_3F82'
        d1335 = 'EMB_DATA_3F84'
        d1336 = 'EMB_DATA_3F86'
        d1337 = 'EMB_DATA_3F88'
        d1338 = 'EMB_DATA_3F8A'
        d1339 = 'EMB_DATA_3F8C'
        d1340 = 'EMB_DATA_3F8E'
        d1341 = 'EMB_DATA_3F90'
        d1342 = 'EMB_DATA_3F92'
        d1343 = 'EMB_DATA_3F94'
        d1344 = 'EMB_DATA_3F96'
        d1345 = 'EMB_DATA_3F98'
        d1346 = 'EMB_DATA_3F9A'
        d1347 = 'EMB_DATA_3F9C'
        d1348 = 'EMB_DATA_3F9E'
        d1349 = 'EMB_DATA_3FA0'
        d1350 = 'EMB_DATA_3FA2'
        d1351 = 'EMB_DATA_3FA4'
        d1352 = 'EMB_DATA_3FA6'
        d1353 = 'EMB_DATA_3FA8'
        d1354 = 'EMB_DATA_3FAA'
        d1355 = 'EMB_DATA_3FAC'
        d1356 = 'EMB_DATA_3FAE'
        d1357 = 'EMB_DATA_3FB0'
        d1358 = 'EMB_DATA_3FB2'
        d1359 = 'EMB_DATA_3FB4'
        d1360 = 'EMB_DATA_3FB6'
        d1361 = 'EMB_DATA_3FB8'
        d1362 = 'EMB_DATA_3FBA'
        d1363 = 'EMB_DATA_3FBC'
        d1364 = 'EMB_DATA_3FBE'
        d1365 = 'EMB_DATA_3FC0'
        d1366 = 'EMB_DATA_3FC2'
        d1367 = 'EMB_DATA_3FC4'
        d1368 = 'EMB_DATA_3FC6'
        d1369 = 'EMB_DATA_3FC8'
        d1370 = 'EMB_DATA_3FCA'
        d1371 = 'EMB_DATA_4400'
        d1372 = 'EMB_DATA_4402'
        d1373 = 'EMB_DATA_4404'
        d1374 = 'EMB_DATA_4406'
        d1375 = 'EMB_DATA_4408'
        d1376 = 'EMB_DATA_440A'
        d1377 = 'EMB_DATA_440C'
        d1378 = 'EMB_DATA_440E'
        d1379 = 'EMB_DATA_4410'
        d1380 = 'EMB_DATA_4412'
        d1381 = 'EMB_DATA_4414'
        d1382 = 'EMB_DATA_4416'
        d1383 = 'EMB_DATA_4418'
        d1384 = 'EMB_DATA_441A'
        d1385 = 'EMB_DATA_441C'
        d1386 = 'EMB_DATA_441E'
        d1387 = 'EMB_DATA_4420'
        d1388 = 'EMB_DATA_4422'
        d1389 = 'EMB_DATA_4424'
        d1390 = 'EMB_DATA_4426'
        d1391 = 'EMB_DATA_4428'
        d1392 = 'EMB_DATA_442A'
        d1393 = 'EMB_DATA_442C'
        d1394 = 'EMB_DATA_442E'
        d1395 = 'EMB_DATA_4430'
        d1396 = 'EMB_DATA_4432'
        d1397 = 'EMB_DATA_4434'
        d1398 = 'EMB_DATA_4436'
        d1399 = 'EMB_DATA_4438'
        d1400 = 'EMB_DATA_443A'
        d1401 = 'EMB_DATA_443C'
        d1402 = 'EMB_DATA_443E'
        d1403 = 'EMB_DATA_4440'
        d1404 = 'EMB_DATA_4442'
        d1405 = 'EMB_DATA_4444'
        d1406 = 'EMB_DATA_4446'
        d1407 = 'EMB_DATA_4448'
        d1408 = 'EMB_DATA_444A'
        d1409 = 'EMB_DATA_4500'
        d1410 = 'EMB_DATA_4502'
        d1411 = 'EMB_DATA_4504'
        d1412 = 'EMB_DATA_4506'
        d1413 = 'EMB_DATA_4508'
        d1414 = 'EMB_DATA_450A'
        d1415 = 'EMB_DATA_450C'
        d1416 = 'EMB_DATA_450E'
        d1417 = 'EMB_DATA_4510'
        d1418 = 'EMB_DATA_4F90'
        d1419 = 'EMB_DATA_5000'
        d1420 = 'EMB_DATA_5002'
        d1421 = 'EMB_DATA_5004'
        d1422 = 'EMB_DATA_5006'
        d1423 = 'EMB_DATA_5008'
        d1424 = 'EMB_DATA_500A'
        d1425 = 'EMB_DATA_500C'
        d1426 = 'EMB_DATA_500E'
        d1427 = 'EMB_DATA_5010'
        d1428 = 'EMB_DATA_5012'
        d1429 = 'EMB_DATA_5014'
        d1430 = 'EMB_DATA_5016'
        d1431 = 'EMB_DATA_5018'
        d1432 = 'EMB_DATA_501A'
        d1433 = 'EMB_DATA_501C'
        d1434 = 'EMB_DATA_501E'
        d1435 = 'EMB_DATA_5020'
        d1436 = 'EMB_DATA_5022'
        d1437 = 'EMB_DATA_5024'
        d1438 = 'EMB_DATA_5026'
        d1439 = 'EMB_DATA_5030'
        d1440 = 'EMB_DATA_5032'
        d1441 = 'EMB_DATA_5034'
        d1442 = 'EMB_DATA_5036'
        d1443 = 'EMB_DATA_5038'
        d1444 = 'EMB_DATA_503A'
        d1445 = 'EMB_DATA_503C'
        d1446 = 'EMB_DATA_503E'
        d1447 = 'EMB_DATA_5040'
        d1448 = 'EMB_DATA_5082'
        d1449 = 'EMB_DATA_5084'
        d1450 = 'EMB_DATA_5086'
        d1451 = 'EMB_DATA_5088'
        d1452 = 'EMB_DATA_508E'
        d1453 = 'EMB_DATA_5090'
        d1454 = 'EMB_DATA_5092'
        d1455 = 'EMB_DATA_5094'
        d1456 = 'EMB_DATA_509A'
        d1457 = 'EMB_DATA_50A0'
        d1458 = 'EMB_DATA_50A2'
        d1459 = 'EMB_DATA_50A4'
        d1460 = 'EMB_DATA_50A6'
        d1461 = 'EMB_DATA_50A8'
        d1462 = 'EMB_DATA_50AA'
        d1463 = 'EMB_DATA_50AC'
        d1464 = 'EMB_DATA_50AE'
        d1465 = 'EMB_DATA_50B0'
        d1466 = 'EMB_DATA_50B2'
        d1467 = 'EMB_DATA_50B4'
        d1468 = 'EMB_DATA_50B6'
        d1469 = 'EMB_DATA_50B8'
        d1470 = 'EMB_DATA_50BA'
        d1471 = 'EMB_DATA_50BC'
        d1472 = 'EMB_DATA_50BE'
        d1473 = 'EMB_DATA_50C0'
        d1474 = 'EMB_DATA_50C2'
        d1475 = 'EMB_DATA_50C4'
        d1476 = 'EMB_DATA_50C6'
        d1477 = 'EMB_DATA_50C8'
        d1478 = 'EMB_DATA_50CA'
        d1479 = 'EMB_DATA_50CC'
        d1480 = 'EMB_DATA_50CE'
        d1481 = 'EMB_DATA_50D0'
        d1482 = 'EMB_DATA_50D2'
        d1483 = 'EMB_DATA_50D4'
        d1484 = 'EMB_DATA_50DA'
        d1485 = 'EMB_DATA_50DC'
        d1486 = 'EMB_DATA_50DE'
        d1487 = 'EMB_DATA_50E0'
        d1488 = 'EMB_DATA_50E2'
        d1489 = 'EMB_DATA_50E4'
        d1490 = 'EMB_DATA_50E6'
        d1491 = 'EMB_DATA_50E8'
        d1492 = 'EMB_DATA_50EA'
        d1493 = 'EMB_DATA_51CC'
        d1494 = 'EMB_DATA_51CE'
        d1495 = 'EMB_DATA_51D0'
        d1496 = 'EMB_DATA_51D2'
        d1497 = 'EMB_DATA_51D4'
        d1498 = 'EMB_DATA_51D6'
        d1499 = 'EMB_DATA_5400'
        d1500 = 'EMB_DATA_5402'
        d1501 = 'EMB_DATA_5404'
        d1502 = 'EMB_DATA_5406'
        d1503 = 'EMB_DATA_5408'
        d1504 = 'EMB_DATA_540A'
        d1505 = 'EMB_DATA_540C'
        d1506 = 'EMB_DATA_540E'
        d1507 = 'EMB_DATA_5410'
        d1508 = 'EMB_DATA_5412'
        d1509 = 'EMB_DATA_5414'
        d1510 = 'EMB_DATA_5416'
        d1511 = 'EMB_DATA_5418'
        d1512 = 'EMB_DATA_541A'
        d1513 = 'EMB_DATA_541C'
        d1514 = 'EMB_DATA_541E'
        d1515 = 'EMB_DATA_5420'
        d1516 = 'EMB_DATA_5422'
        d1517 = 'EMB_DATA_5424'
        d1518 = 'EMB_DATA_5426'
        d1519 = 'EMB_DATA_5430'
        d1520 = 'EMB_DATA_5432'
        d1521 = 'EMB_DATA_5434'
        d1522 = 'EMB_DATA_5436'
        d1523 = 'EMB_DATA_5438'
        d1524 = 'EMB_DATA_543A'
        d1525 = 'EMB_DATA_543C'
        d1526 = 'EMB_DATA_543E'
        d1527 = 'EMB_DATA_5440'
        d1528 = 'EMB_DATA_5482'
        d1529 = 'EMB_DATA_5484'
        d1530 = 'EMB_DATA_5486'
        d1531 = 'EMB_DATA_5488'
        d1532 = 'EMB_DATA_548E'
        d1533 = 'EMB_DATA_5490'
        d1534 = 'EMB_DATA_5492'
        d1535 = 'EMB_DATA_5494'
        d1536 = 'EMB_DATA_549A'
        d1537 = 'EMB_DATA_549C'
        d1538 = 'EMB_DATA_549E'
        d1539 = 'EMB_DATA_54A0'
        d1540 = 'EMB_DATA_54A2'
        d1541 = 'EMB_DATA_54A4'
        d1542 = 'EMB_DATA_54A6'
        d1543 = 'EMB_DATA_54A8'
        d1544 = 'EMB_DATA_54AA'
        d1545 = 'EMB_DATA_54B4'
        d1546 = 'EMB_DATA_54B6'
        d1547 = 'EMB_DATA_54B8'
        d1548 = 'EMB_DATA_54BA'
        d1549 = 'EMB_DATA_54BC'
        d1550 = 'EMB_DATA_54BE'
        d1551 = 'EMB_DATA_54C0'
        d1552 = 'EMB_DATA_54C2'
        d1553 = 'EMB_DATA_54C4'
        d1554 = 'EMB_DATA_5500'
        d1555 = 'EMB_DATA_5502'
        d1556 = 'EMB_DATA_5504'
        d1557 = 'EMB_DATA_5506'
        d1558 = 'EMB_DATA_5524'
        d1559 = 'EMB_DATA_5526'
        d1560 = 'EMB_DATA_5528'
        d1561 = 'EMB_DATA_552A'
        d1562 = 'EMB_DATA_552C'
        d1563 = 'EMB_DATA_552E'
        d1564 = 'EMB_DATA_5530'
        d1565 = 'EMB_DATA_5532'
        d1566 = 'EMB_DATA_5534'
        d1567 = 'EMB_DATA_5536'
        d1568 = 'EMB_DATA_5538'
        d1569 = 'EMB_DATA_553A'
        d1570 = 'EMB_DATA_553C'
        d1571 = 'EMB_DATA_553E'
        d1572 = 'EMB_DATA_5540'
        d1573 = 'EMB_DATA_5542'
        d1574 = 'EMB_DATA_5544'
        d1575 = 'EMB_DATA_5546'
        d1576 = 'EMB_DATA_5548'
        d1577 = 'EMB_DATA_554A'
        d1578 = 'EMB_DATA_554C'
        d1579 = 'EMB_DATA_554E'
        d1580 = 'EMB_DATA_5550'
        d1581 = 'EMB_DATA_5552'
        d1582 = 'EMB_DATA_5554'
        d1583 = 'EMB_DATA_5556'
        d1584 = 'EMB_DATA_5558'
        d1585 = 'EMB_DATA_555A'
        d1586 = 'EMB_DATA_555C'
        d1587 = 'EMB_DATA_555E'
        d1588 = 'EMB_DATA_5560'
        d1589 = 'EMB_DATA_5562'
        d1590 = 'EMB_DATA_5564'
        d1591 = 'EMB_DATA_5566'
        d1592 = 'EMB_DATA_5568'
        d1593 = 'EMB_DATA_556A'
        d1594 = 'EMB_DATA_5580'
        d1595 = 'EMB_DATA_5582'
        d1596 = 'EMB_DATA_5584'
        d1597 = 'EMB_DATA_5586'
        d1598 = 'EMB_DATA_5588'
        d1599 = 'EMB_DATA_558A'
        d1600 = 'EMB_DATA_558C'
        d1601 = 'EMB_DATA_558E'
        d1602 = 'EMB_DATA_5590'
        d1603 = 'EMB_DATA_5592'
        d1604 = 'EMB_DATA_5594'
        d1605 = 'EMB_DATA_5596'
        d1606 = 'EMB_DATA_5598'
        d1607 = 'EMB_DATA_559A'
        d1608 = 'EMB_DATA_559C'
        d1609 = 'EMB_DATA_559E'
        d1610 = 'EMB_DATA_55A0'
        d1611 = 'EMB_DATA_55A2'
        d1612 = 'EMB_DATA_55A4'
        d1613 = 'EMB_DATA_55A6'
        d1614 = 'EMB_DATA_55A8'
        d1615 = 'EMB_DATA_55AA'
        d1616 = 'EMB_DATA_55AC'
        d1617 = 'EMB_DATA_55B0'
        d1618 = 'EMB_DATA_55B2'
        d1619 = 'EMB_DATA_55B4'
        d1620 = 'EMB_DATA_55B6'
        d1621 = 'EMB_DATA_55B8'
        d1622 = 'EMB_DATA_55BA'
        d1623 = 'EMB_DATA_55BC'
        d1624 = 'EMB_DATA_55BE'
        d1625 = 'EMB_DATA_55E8'
        d1626 = 'EMB_DATA_55F6'
        d1627 = 'EMB_DATA_5600'
        d1628 = 'EMB_DATA_5602'
        d1629 = 'EMB_DATA_5604'
        d1630 = 'EMB_DATA_5606'
        d1631 = 'EMB_DATA_5608'
        d1632 = 'EMB_DATA_560A'
        d1633 = 'EMB_DATA_560C'
        d1634 = 'EMB_DATA_560E'
        d1635 = 'EMB_DATA_5610'
        d1636 = 'EMB_DATA_5612'
        d1637 = 'EMB_DATA_5614'
        d1638 = 'EMB_DATA_5616'
        d1639 = 'EMB_DATA_5618'
        d1640 = 'EMB_DATA_561A'
        d1641 = 'EMB_DATA_561C'
        d1642 = 'EMB_DATA_561E'
        d1643 = 'EMB_DATA_5620'
        d1644 = 'EMB_DATA_5622'
        d1645 = 'EMB_DATA_5624'
        d1646 = 'EMB_DATA_5626'
        d1647 = 'EMB_DATA_5628'
        d1648 = 'EMB_DATA_562A'
        d1649 = 'EMB_DATA_562C'
        d1650 = 'EMB_DATA_562E'
        d1651 = 'EMB_DATA_5630'
        d1652 = 'EMB_DATA_5632'
        d1653 = 'EMB_DATA_5634'
        d1654 = 'EMB_DATA_5636'
        d1655 = 'EMB_DATA_5638'
        d1656 = 'EMB_DATA_563A'
        d1657 = 'EMB_DATA_563C'
        d1658 = 'EMB_DATA_563E'
        d1659 = 'EMB_DATA_5640'
        d1660 = 'EMB_DATA_5642'
        d1661 = 'EMB_DATA_5644'
        d1662 = 'EMB_DATA_5646'
        d1663 = 'EMB_DATA_5648'
        d1664 = 'EMB_DATA_564A'
        d1665 = 'EMB_DATA_564C'
        d1666 = 'EMB_DATA_564E'
        d1667 = 'EMB_DATA_5650'
        d1668 = 'EMB_DATA_5652'
        d1669 = 'EMB_DATA_5654'
        d1670 = 'EMB_DATA_5656'
        d1671 = 'EMB_DATA_5658'
        d1672 = 'EMB_DATA_565A'
        d1673 = 'EMB_DATA_565C'
        d1674 = 'EMB_DATA_565E'
        d1675 = 'EMB_DATA_5660'
        d1676 = 'EMB_DATA_5662'
        d1677 = 'EMB_DATA_5664'
        d1678 = 'EMB_DATA_5666'
        d1679 = 'EMB_DATA_5668'
        d1680 = 'EMB_DATA_566A'
        d1681 = 'EMB_DATA_566C'
        d1682 = 'EMB_DATA_566E'
        d1683 = 'EMB_DATA_5670'
        d1684 = 'EMB_DATA_5672'
        d1685 = 'EMB_DATA_5674'
        d1686 = 'EMB_DATA_5676'
        d1687 = 'EMB_DATA_5678'
        d1688 = 'EMB_DATA_567A'
        d1689 = 'EMB_DATA_567C'
        d1690 = 'EMB_DATA_567E'
        d1691 = 'EMB_DATA_5680'
        d1692 = 'EMB_DATA_5682'
        d1693 = 'EMB_DATA_5684'
        d1694 = 'EMB_DATA_5686'
        d1695 = 'EMB_DATA_5688'
        d1696 = 'EMB_DATA_568A'
        d1697 = 'EMB_DATA_568C'
        d1698 = 'EMB_DATA_568E'
        d1699 = 'EMB_DATA_5690'
        d1700 = 'EMB_DATA_5692'
        d1701 = 'EMB_DATA_5694'
        d1702 = 'EMB_DATA_5696'
        d1703 = 'EMB_DATA_5698'
        d1704 = 'EMB_DATA_569A'
        d1705 = 'EMB_DATA_569C'
        d1706 = 'EMB_DATA_569E'
        d1707 = 'EMB_DATA_56A0'
        d1708 = 'EMB_DATA_56A2'
        d1709 = 'EMB_DATA_56A4'
        d1710 = 'EMB_DATA_56A6'
        d1711 = 'EMB_DATA_56A8'
        d1712 = 'EMB_DATA_56AA'
        d1713 = 'EMB_DATA_56AC'
        d1714 = 'EMB_DATA_56AE'
        d1715 = 'EMB_DATA_56B0'
        d1716 = 'EMB_DATA_56B2'
        d1717 = 'EMB_DATA_56B4'
        d1718 = 'EMB_DATA_56B6'
        d1719 = 'EMB_DATA_56B8'
        d1720 = 'EMB_DATA_56BA'
        d1721 = 'EMB_DATA_56BC'
        d1722 = 'EMB_DATA_56BE'
        d1723 = 'EMB_DATA_56C0'
        d1724 = 'EMB_DATA_56C2'
        d1725 = 'EMB_DATA_56C4'
        d1726 = 'EMB_DATA_56C6'
        d1727 = 'EMB_DATA_56C8'
        d1728 = 'EMB_DATA_56CA'
        d1729 = 'EMB_DATA_56CC'
        d1730 = 'EMB_DATA_56CE'
        d1731 = 'EMB_DATA_56D0'
        d1732 = 'EMB_DATA_56D2'
        d1733 = 'EMB_DATA_56D4'
        d1734 = 'EMB_DATA_56D6'
        d1735 = 'EMB_DATA_56D8'
        d1736 = 'EMB_DATA_56DA'
        d1737 = 'EMB_DATA_56DC'
        d1738 = 'EMB_DATA_56DE'
        d1739 = 'EMB_DATA_56E0'
        d1740 = 'EMB_DATA_56E2'
        d1741 = 'EMB_DATA_56E4'
        d1742 = 'EMB_DATA_56E6'
        d1743 = 'EMB_DATA_56E8'
        d1744 = 'EMB_DATA_56EA'
        d1745 = 'EMB_DATA_56EC'
        d1746 = 'EMB_DATA_56EE'
        d1747 = 'EMB_DATA_56F0'
        d1748 = 'EMB_DATA_56F2'
        d1749 = 'EMB_DATA_56F4'
        d1750 = 'EMB_DATA_56F6'
        d1751 = 'EMB_DATA_56F8'
        d1752 = 'EMB_DATA_56FA'
        d1753 = 'EMB_DATA_56FC'
        d1754 = 'EMB_DATA_56FE'
        d1755 = 'EMB_DATA_5700'
        d1756 = 'EMB_DATA_5702'
        d1757 = 'EMB_DATA_5704'
        d1758 = 'EMB_DATA_5706'
        d1759 = 'EMB_DATA_5708'
        d1760 = 'EMB_DATA_570A'
        d1761 = 'EMB_DATA_570C'
        d1762 = 'EMB_DATA_570E'
        d1763 = 'EMB_DATA_5710'
        d1764 = 'EMB_DATA_5712'
        d1765 = 'EMB_DATA_5714'
        d1766 = 'EMB_DATA_5716'
        d1767 = 'EMB_DATA_5718'
        d1768 = 'EMB_DATA_571A'
        d1769 = 'EMB_DATA_571C'
        d1770 = 'EMB_DATA_571E'
        d1771 = 'EMB_DATA_5720'
        d1772 = 'EMB_DATA_5722'
        d1773 = 'EMB_DATA_5724'
        d1774 = 'EMB_DATA_5726'
        d1775 = 'EMB_DATA_5728'
        d1776 = 'EMB_DATA_572A'
        d1777 = 'EMB_DATA_572C'
        d1778 = 'EMB_DATA_572E'
        d1779 = 'EMB_DATA_5730'
        d1780 = 'EMB_DATA_5732'
        d1781 = 'EMB_DATA_5734'
        d1782 = 'EMB_DATA_5736'
        d1783 = 'EMB_DATA_5738'
        d1784 = 'EMB_DATA_573A'
        d1785 = 'EMB_DATA_573C'
        d1786 = 'EMB_DATA_573E'
        d1787 = 'EMB_DATA_5740'
        d1788 = 'EMB_DATA_5742'
        d1789 = 'EMB_DATA_5744'
        d1790 = 'EMB_DATA_5746'
        d1791 = 'EMB_DATA_5748'
        d1792 = 'EMB_DATA_5752'
        d1793 = 'EMB_DATA_5754'
        d1794 = 'EMB_DATA_5756'
        d1795 = 'EMB_DATA_5758'
        d1796 = 'EMB_DATA_575A'
        d1797 = 'EMB_DATA_575C'
        d1798 = 'EMB_DATA_575E'
        d1799 = 'EMB_DATA_5760'
        d1800 = 'EMB_DATA_5762'
        d1801 = 'EMB_DATA_5764'
        d1802 = 'EMB_DATA_5766'
        d1803 = 'EMB_DATA_5768'
        d1804 = 'EMB_DATA_576A'
        d1805 = 'EMB_DATA_576C'
        d1806 = 'EMB_DATA_5800'
        d1807 = 'EMB_DATA_5802'
        d1808 = 'EMB_DATA_5804'
        d1809 = 'EMB_DATA_580A'
        d1810 = 'EMB_DATA_580C'
        d1811 = 'EMB_DATA_580E'
        d1812 = 'EMB_DATA_5810'
        d1813 = 'EMB_DATA_5812'
        d1814 = 'EMB_DATA_5814'
        d1815 = 'EMB_DATA_5816'
        d1816 = 'EMB_DATA_5818'
        d1817 = 'EMB_DATA_581A'
        d1818 = 'EMB_DATA_581C'
        d1819 = 'EMB_DATA_581E'
        d1820 = 'EMB_DATA_5820'
        d1821 = 'EMB_DATA_5822'
        d1822 = 'EMB_DATA_5824'
        d1823 = 'EMB_DATA_5826'
        d1824 = 'EMB_DATA_5828'
        d1825 = 'EMB_DATA_582A'
        d1826 = 'EMB_DATA_582C'
        d1827 = 'EMB_DATA_582E'
        d1828 = 'EMB_DATA_5830'
        d1829 = 'EMB_DATA_5832'
        d1830 = 'EMB_DATA_5834'
        d1831 = 'EMB_DATA_5836'
        d1832 = 'EMB_DATA_5838'
        d1833 = 'EMB_DATA_583A'
        d1834 = 'EMB_DATA_583C'
        d1835 = 'EMB_DATA_583E'
        d1836 = 'EMB_DATA_5840'
        d1837 = 'EMB_DATA_5842'
        d1838 = 'EMB_DATA_5844'
        d1839 = 'EMB_DATA_5846'
        d1840 = 'EMB_DATA_5848'
        d1841 = 'EMB_DATA_584A'
        d1842 = 'EMB_DATA_584C'
        d1843 = 'EMB_DATA_584E'
        d1844 = 'EMB_DATA_5850'
        d1845 = 'EMB_DATA_5852'
        d1846 = 'EMB_DATA_5854'
        d1847 = 'EMB_DATA_5856'
        d1848 = 'EMB_DATA_5858'
        d1849 = 'EMB_DATA_585A'
        d1850 = 'EMB_DATA_585C'
        d1851 = 'EMB_DATA_585E'
        d1852 = 'EMB_DATA_5860'
        d1853 = 'EMB_DATA_5862'
        d1854 = 'EMB_DATA_5864'
        d1855 = 'EMB_DATA_5866'
        d1856 = 'EMB_DATA_5868'
        d1857 = 'EMB_DATA_586A'
        d1858 = 'EMB_DATA_586C'
        d1859 = 'EMB_DATA_586E'
        d1860 = 'EMB_DATA_5870'
        d1861 = 'EMB_DATA_5872'
        d1862 = 'EMB_DATA_5874'
        d1863 = 'EMB_DATA_5876'
        d1864 = 'EMB_DATA_5878'
        d1865 = 'EMB_DATA_587A'
        d1866 = 'EMB_DATA_587C'
        d1867 = 'EMB_DATA_587E'
        d1868 = 'EMB_DATA_5880'
        d1869 = 'EMB_DATA_5882'
        d1870 = 'EMB_DATA_5884'
        d1871 = 'EMB_DATA_5886'
        d1872 = 'EMB_DATA_5888'
        d1873 = 'EMB_DATA_588A'
        d1874 = 'EMB_DATA_588C'
        d1875 = 'EMB_DATA_588E'
        d1876 = 'EMB_DATA_5890'
        d1877 = 'EMB_DATA_5892'
        d1878 = 'EMB_DATA_589C'
        d1879 = 'EMB_DATA_589E'
        d1880 = 'EMB_DATA_58A0'
        d1881 = 'EMB_DATA_58A2'
        d1882 = 'EMB_DATA_58A4'
        d1883 = 'EMB_DATA_58A6'
        d1884 = 'EMB_DATA_58A8'
        d1885 = 'EMB_DATA_58AA'
        d1886 = 'EMB_DATA_58AC'
        d1887 = 'EMB_DATA_58E0'
        d1888 = 'EMB_DATA_58E2'
        d1889 = 'EMB_DATA_58E4'
        d1890 = 'EMB_DATA_58E6'
        d1891 = 'EMB_DATA_58E8'
        d1892 = 'EMB_DATA_58EA'
        d1893 = 'EMB_DATA_58EC'
        d1894 = 'EMB_DATA_58EE'
        d1895 = 'EMB_DATA_58F0'
        d1896 = 'EMB_DATA_58F2'
        d1897 = 'EMB_DATA_58FA'
        d1898 = 'EMB_DATA_5912'
        d1899 = 'EMB_DATA_5914'
        d1900 = 'EMB_DATA_5916'
        d1901 = 'EMB_DATA_5918'
        d1902 = 'EMB_DATA_591E'
        d1903 = 'EMB_DATA_5920'
        d1904 = 'EMB_DATA_5922'
        d1905 = 'EMB_DATA_5924'
        d1906 = 'EMB_DATA_5926'
        d1907 = 'EMB_DATA_5928'
        d1908 = 'EMB_DATA_592A'
        d1909 = 'EMB_DATA_592C'
        d1910 = 'EMB_DATA_592E'
        d1911 = 'EMB_DATA_5930'
        d1912 = 'EMB_DATA_5932'
        d1913 = 'EMB_DATA_5934'
        d1914 = 'EMB_DATA_5936'
        d1915 = 'EMB_DATA_5938'
        d1916 = 'EMB_DATA_593A'
        d1917 = 'EMB_DATA_593C'
        d1918 = 'EMB_DATA_593E'
        d1919 = 'EMB_DATA_5940'
        d1920 = 'EMB_DATA_5942'
        d1921 = 'EMB_DATA_5944'
        d1922 = 'EMB_DATA_5946'
        d1923 = 'EMB_DATA_5948'
        d1924 = 'EMB_DATA_594A'
        d1925 = 'EMB_DATA_594C'
        d1926 = 'EMB_DATA_594E'
        d1927 = 'EMB_DATA_5950'
        d1928 = 'EMB_DATA_5952'
        d1929 = 'EMB_DATA_5954'
        d1930 = 'EMB_DATA_5956'
        d1931 = 'EMB_DATA_5958'
        d1932 = 'EMB_DATA_595A'
        d1933 = 'EMB_DATA_5960'
        d1934 = 'EMB_DATA_5962'
        d1935 = 'EMB_DATA_5964'
        d1936 = 'EMB_DATA_5966'
        d1937 = 'EMB_DATA_5968'
        d1938 = 'EMB_DATA_596A'
        d1939 = 'EMB_DATA_596C'
        d1940 = 'EMB_DATA_596E'
        d1941 = 'EMB_DATA_5970'
        d1942 = 'EMB_DATA_5980'
        d1943 = 'EMB_DATA_5982'
        d1944 = 'EMB_DATA_5984'
        d1945 = 'EMB_DATA_5986'
        d1946 = 'EMB_DATA_5988'
        d1947 = 'EMB_DATA_598A'
        d1948 = 'EMB_DATA_598C'
        d1949 = 'EMB_DATA_598E'
        d1950 = 'EMB_DATA_5990'
        d1951 = 'EMB_DATA_5992'
        d1952 = 'EMB_DATA_6050'
        d1953 = 'EMB_DATA_6052'
        d1954 = 'EMB_DATA_6054'
        d1955 = 'EMB_DATA_6056'
        d1956 = 'EMB_DATA_6058'
        d1957 = 'EMB_DATA_605A'
        d1958 = 'EMB_DATA_605C'
        d1959 = 'EMB_DATA_605E'
        d1960 = 'EMB_DATA_6060'
        d1961 = 'EMB_DATA_6074'
        d1962 = 'EMB_DATA_6076'
        d1963 = 'EMB_DATA_6078'
        d1964 = 'EMB_DATA_607A'
        d1965 = 'EMB_DATA_607C'
        d1966 = 'EMB_DATA_607E'
        d1967 = 'EMB_DATA_6080'
        d1968 = 'EMB_DATA_6082'
        d1969 = 'EMB_DATA_6084'
        d1970 = 'EMB_DATA_6098'
        d1971 = 'EMB_DATA_609A'
        d1972 = 'EMB_DATA_609C'
        d1973 = 'EMB_DATA_609E'
        d1974 = 'EMB_DATA_60A0'
        d1975 = 'EMB_DATA_60A2'
        d1976 = 'EMB_DATA_60A4'
        d1977 = 'EMB_DATA_60A6'
        d1978 = 'EMB_DATA_60A8'
        d1979 = 'EMB_DATA_60BC'
        d1980 = 'EMB_DATA_60BE'
        d1981 = 'EMB_DATA_60C0'
        d1982 = 'EMB_DATA_60C2'
        d1983 = 'EMB_DATA_60C4'
        d1984 = 'EMB_DATA_60C6'
        d1985 = 'EMB_DATA_60C8'
        d1986 = 'EMB_DATA_60CA'
        d1987 = 'EMB_DATA_60CC'
        d1988 = 'EMB_DATA_60E0'
        d1989 = 'EMB_DATA_60E2'
        d1990 = 'EMB_DATA_60E4'
        d1991 = 'EMB_DATA_60E6'
        d1992 = 'EMB_DATA_60E8'
        d1993 = 'EMB_DATA_60EA'
        d1994 = 'EMB_DATA_60EC'
        d1995 = 'EMB_DATA_60EE'
        d1996 = 'EMB_DATA_60F0'
        d1997 = 'EMB_DATA_6104'
        d1998 = 'EMB_DATA_6106'
        d1999 = 'EMB_DATA_6108'
        d2000 = 'EMB_DATA_610A'
        d2001 = 'EMB_DATA_610C'
        d2002 = 'EMB_DATA_610E'
        d2003 = 'EMB_DATA_6110'
        d2004 = 'EMB_DATA_6112'
        d2005 = 'EMB_DATA_6114'
        d2006 = 'EMB_DATA_6178'
        d2007 = 'EMB_DATA_617A'
        d2008 = 'EMB_DATA_617C'
        d2009 = 'EMB_DATA_617E'
        d2010 = 'EMB_DATA_6180'
        d2011 = 'EMB_DATA_6182'
        d2012 = 'EMB_DATA_6184'
        d2013 = 'EMB_DATA_6186'
        d2014 = 'EMB_DATA_6188'
        d2015 = 'EMB_DATA_618A'
        d2016 = 'EMB_DATA_618C'
        d2017 = 'EMB_DATA_618E'
        d2018 = 'EMB_DATA_61A2'
        d2019 = 'EMB_DATA_61A4'
        d2020 = 'EMB_DATA_61A6'
        d2021 = 'EMB_DATA_61A8'
        d2022 = 'EMB_DATA_61AA'
        d2023 = 'EMB_DATA_61AC'
        d2024 = 'EMB_DATA_61AE'
        d2025 = 'EMB_DATA_61B0'
        d2026 = 'EMB_DATA_61B2'
        d2027 = 'EMB_DATA_61C6'
        d2028 = 'EMB_DATA_61C8'
        d2029 = 'EMB_DATA_61CA'
        d2030 = 'EMB_DATA_61CC'
        d2031 = 'EMB_DATA_61CE'
        d2032 = 'EMB_DATA_61D0'
        d2033 = 'EMB_DATA_61D2'
        d2034 = 'EMB_DATA_61D4'
        d2035 = 'EMB_DATA_61D6'
        d2036 = 'EMB_DATA_61EA'
        d2037 = 'EMB_DATA_61EC'
        d2038 = 'EMB_DATA_61EE'
        d2039 = 'EMB_DATA_61F0'
        d2040 = 'EMB_DATA_61F2'
        d2041 = 'EMB_DATA_61F4'
        d2042 = 'EMB_DATA_61F6'
        d2043 = 'EMB_DATA_61F8'
        d2044 = 'EMB_DATA_61FA'
        d2045 = 'EMB_DATA_620E'
        d2046 = 'EMB_DATA_6210'
        d2047 = 'EMB_DATA_6212'
        d2048 = 'EMB_DATA_6214'
        d2049 = 'EMB_DATA_6216'
        d2050 = 'EMB_DATA_6218'
        d2051 = 'EMB_DATA_621A'
        d2052 = 'EMB_DATA_621C'
        d2053 = 'EMB_DATA_621E'
        d2054 = 'EMB_DATA_6232'
        d2055 = 'EMB_DATA_6234'
        d2056 = 'EMB_DATA_6236'
        d2057 = 'EMB_DATA_6238'
        d2058 = 'EMB_DATA_623A'
        d2059 = 'EMB_DATA_623C'
        d2060 = 'EMB_DATA_623E'
        d2062 = 'EMB_DATA_6242'
        d2061 = 'EMB_DATA_6240'
        d2063 = 'EMB_DATA_6244'

        figTitle = 'EMBEDDED_DATA_Plot'
        ylabel = 'RegVal (Dec)'
        numDataCols = 2064  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, 3, 2):  # 1 to 3 to plot similar thresholds
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs,
                         filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, 3, 2):  # 1 to 3 to plot similar thresholds
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         legend=groupBy, show=showPlt,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs,
                         filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def EMBEDDED_STATS_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'EMB_STAT_DataFormat'
        d2 = 'EMB_STAT_WordCount1'
        d3 = 'EMB_STAT_FrameCount'
        d4 = 'EMB_STAT_FrameId'
        d5 = 'EMB_STAT_WordCount2'
        d6 = 'EMB_STAT_Mean'
        d7 = 'EMB_STAT_HistBegin'
        d8 = 'EMB_STAT_HistEnd'
        d9 = 'EMB_STAT_LowEndMean'
        d10 = 'EMB_STAT_PercLowEnd'
        d11 = 'EMB_STAT_NormAbsDev'
        d12 = 'EMB_STAT_Histogram Bin0'
        d13 = 'EMB_STAT_Histogram Bin1'
        d14 = 'EMB_STAT_Histogram Bin2'
        d15 = 'EMB_STAT_Histogram Bin3'
        d16 = 'EMB_STAT_Histogram Bin4'
        d17 = 'EMB_STAT_Histogram Bin5'
        d18 = 'EMB_STAT_Histogram Bin6'
        d19 = 'EMB_STAT_Histogram Bin7'
        d20 = 'EMB_STAT_Histogram Bin8'
        d21 = 'EMB_STAT_Histogram Bin9'
        d22 = 'EMB_STAT_Histogram Bin10'
        d23 = 'EMB_STAT_Histogram Bin11'
        d24 = 'EMB_STAT_Histogram Bin12'
        d25 = 'EMB_STAT_Histogram Bin13'
        d26 = 'EMB_STAT_Histogram Bin14'
        d27 = 'EMB_STAT_Histogram Bin15'
        d28 = 'EMB_STAT_Histogram Bin16'
        d29 = 'EMB_STAT_Histogram Bin17'
        d30 = 'EMB_STAT_Histogram Bin18'
        d31 = 'EMB_STAT_Histogram Bin19'
        d32 = 'EMB_STAT_Histogram Bin20'
        d33 = 'EMB_STAT_Histogram Bin21'
        d34 = 'EMB_STAT_Histogram Bin22'
        d35 = 'EMB_STAT_Histogram Bin23'
        d36 = 'EMB_STAT_Histogram Bin24'
        d37 = 'EMB_STAT_Histogram Bin25'
        d38 = 'EMB_STAT_Histogram Bin26'
        d39 = 'EMB_STAT_Histogram Bin27'
        d40 = 'EMB_STAT_Histogram Bin28'
        d41 = 'EMB_STAT_Histogram Bin29'
        d42 = 'EMB_STAT_Histogram Bin30'
        d43 = 'EMB_STAT_Histogram Bin31'
        d44 = 'EMB_STAT_Histogram Bin32'
        d45 = 'EMB_STAT_Histogram Bin33'
        d46 = 'EMB_STAT_Histogram Bin34'
        d47 = 'EMB_STAT_Histogram Bin35'
        d48 = 'EMB_STAT_Histogram Bin36'
        d49 = 'EMB_STAT_Histogram Bin37'
        d50 = 'EMB_STAT_Histogram Bin38'
        d51 = 'EMB_STAT_Histogram Bin39'
        d52 = 'EMB_STAT_Histogram Bin40'
        d53 = 'EMB_STAT_Histogram Bin41'
        d54 = 'EMB_STAT_Histogram Bin42'
        d55 = 'EMB_STAT_Histogram Bin43'
        d56 = 'EMB_STAT_Histogram Bin44'
        d57 = 'EMB_STAT_Histogram Bin45'
        d58 = 'EMB_STAT_Histogram Bin46'
        d59 = 'EMB_STAT_Histogram Bin47'
        d60 = 'EMB_STAT_Histogram Bin48'
        d61 = 'EMB_STAT_Histogram Bin49'
        d62 = 'EMB_STAT_Histogram Bin50'
        d63 = 'EMB_STAT_Histogram Bin51'
        d64 = 'EMB_STAT_Histogram Bin52'
        d65 = 'EMB_STAT_Histogram Bin53'
        d66 = 'EMB_STAT_Histogram Bin54'
        d67 = 'EMB_STAT_Histogram Bin55'
        d68 = 'EMB_STAT_Histogram Bin56'
        d69 = 'EMB_STAT_Histogram Bin57'
        d70 = 'EMB_STAT_Histogram Bin58'
        d71 = 'EMB_STAT_Histogram Bin59'
        d72 = 'EMB_STAT_Histogram Bin60'
        d73 = 'EMB_STAT_Histogram Bin61'
        d74 = 'EMB_STAT_Histogram Bin62'
        d75 = 'EMB_STAT_Histogram Bin63'
        d76 = 'EMB_STAT_Histogram Bin64'
        d77 = 'EMB_STAT_Histogram Bin65'
        d78 = 'EMB_STAT_Histogram Bin66'
        d79 = 'EMB_STAT_Histogram Bin67'
        d80 = 'EMB_STAT_Histogram Bin68'
        d81 = 'EMB_STAT_Histogram Bin69'
        d82 = 'EMB_STAT_Histogram Bin70'
        d83 = 'EMB_STAT_Histogram Bin71'
        d84 = 'EMB_STAT_Histogram Bin72'
        d85 = 'EMB_STAT_Histogram Bin73'
        d86 = 'EMB_STAT_Histogram Bin74'
        d87 = 'EMB_STAT_Histogram Bin75'
        d88 = 'EMB_STAT_Histogram Bin76'
        d89 = 'EMB_STAT_Histogram Bin77'
        d90 = 'EMB_STAT_Histogram Bin78'
        d91 = 'EMB_STAT_Histogram Bin79'
        d92 = 'EMB_STAT_Histogram Bin80'
        d93 = 'EMB_STAT_Histogram Bin81'
        d94 = 'EMB_STAT_Histogram Bin82'
        d95 = 'EMB_STAT_Histogram Bin83'
        d96 = 'EMB_STAT_Histogram Bin84'
        d97 = 'EMB_STAT_Histogram Bin85'
        d98 = 'EMB_STAT_Histogram Bin86'
        d99 = 'EMB_STAT_Histogram Bin87'
        d100 = 'EMB_STAT_Histogram Bin88'
        d101 = 'EMB_STAT_Histogram Bin89'
        d102 = 'EMB_STAT_Histogram Bin90'
        d103 = 'EMB_STAT_Histogram Bin91'
        d104 = 'EMB_STAT_Histogram Bin92'
        d105 = 'EMB_STAT_Histogram Bin93'
        d106 = 'EMB_STAT_Histogram Bin94'
        d107 = 'EMB_STAT_Histogram Bin95'
        d108 = 'EMB_STAT_Histogram Bin96'
        d109 = 'EMB_STAT_Histogram Bin97'
        d110 = 'EMB_STAT_Histogram Bin98'
        d111 = 'EMB_STAT_Histogram Bin99'
        d112 = 'EMB_STAT_Histogram Bin100'
        d113 = 'EMB_STAT_Histogram Bin101'
        d114 = 'EMB_STAT_Histogram Bin102'
        d115 = 'EMB_STAT_Histogram Bin103'
        d116 = 'EMB_STAT_Histogram Bin104'
        d117 = 'EMB_STAT_Histogram Bin105'
        d118 = 'EMB_STAT_Histogram Bin106'
        d119 = 'EMB_STAT_Histogram Bin107'
        d120 = 'EMB_STAT_Histogram Bin108'
        d121 = 'EMB_STAT_Histogram Bin109'
        d122 = 'EMB_STAT_Histogram Bin110'
        d123 = 'EMB_STAT_Histogram Bin111'
        d124 = 'EMB_STAT_Histogram Bin112'
        d125 = 'EMB_STAT_Histogram Bin113'
        d126 = 'EMB_STAT_Histogram Bin114'
        d127 = 'EMB_STAT_Histogram Bin115'
        d128 = 'EMB_STAT_Histogram Bin116'
        d129 = 'EMB_STAT_Histogram Bin117'
        d130 = 'EMB_STAT_Histogram Bin118'
        d131 = 'EMB_STAT_Histogram Bin119'
        d132 = 'EMB_STAT_Histogram Bin120'
        d133 = 'EMB_STAT_Histogram Bin121'
        d134 = 'EMB_STAT_Histogram Bin122'
        d135 = 'EMB_STAT_Histogram Bin123'
        d136 = 'EMB_STAT_Histogram Bin124'
        d137 = 'EMB_STAT_Histogram Bin125'
        d138 = 'EMB_STAT_Histogram Bin126'
        d139 = 'EMB_STAT_Histogram Bin127'
        d140 = 'EMB_STAT_Histogram Bin128'
        d141 = 'EMB_STAT_Histogram Bin129'
        d142 = 'EMB_STAT_Histogram Bin130'
        d143 = 'EMB_STAT_Histogram Bin131'
        d144 = 'EMB_STAT_Histogram Bin132'
        d145 = 'EMB_STAT_Histogram Bin133'
        d146 = 'EMB_STAT_Histogram Bin134'
        d147 = 'EMB_STAT_Histogram Bin135'
        d148 = 'EMB_STAT_Histogram Bin136'
        d149 = 'EMB_STAT_Histogram Bin137'
        d150 = 'EMB_STAT_Histogram Bin138'
        d151 = 'EMB_STAT_Histogram Bin139'
        d152 = 'EMB_STAT_Histogram Bin140'
        d153 = 'EMB_STAT_Histogram Bin141'
        d154 = 'EMB_STAT_Histogram Bin142'
        d155 = 'EMB_STAT_Histogram Bin143'
        d156 = 'EMB_STAT_Histogram Bin144'
        d157 = 'EMB_STAT_Histogram Bin145'
        d158 = 'EMB_STAT_Histogram Bin146'
        d159 = 'EMB_STAT_Histogram Bin147'
        d160 = 'EMB_STAT_Histogram Bin148'
        d161 = 'EMB_STAT_Histogram Bin149'
        d162 = 'EMB_STAT_Histogram Bin150'
        d163 = 'EMB_STAT_Histogram Bin151'
        d164 = 'EMB_STAT_Histogram Bin152'
        d165 = 'EMB_STAT_Histogram Bin153'
        d166 = 'EMB_STAT_Histogram Bin154'
        d167 = 'EMB_STAT_Histogram Bin155'
        d168 = 'EMB_STAT_Histogram Bin156'
        d169 = 'EMB_STAT_Histogram Bin157'
        d170 = 'EMB_STAT_Histogram Bin158'
        d171 = 'EMB_STAT_Histogram Bin159'
        d172 = 'EMB_STAT_Histogram Bin160'
        d173 = 'EMB_STAT_Histogram Bin161'
        d174 = 'EMB_STAT_Histogram Bin162'
        d175 = 'EMB_STAT_Histogram Bin163'
        d176 = 'EMB_STAT_Histogram Bin164'
        d177 = 'EMB_STAT_Histogram Bin165'
        d178 = 'EMB_STAT_Histogram Bin166'
        d179 = 'EMB_STAT_Histogram Bin167'
        d180 = 'EMB_STAT_Histogram Bin168'
        d181 = 'EMB_STAT_Histogram Bin169'
        d182 = 'EMB_STAT_Histogram Bin170'
        d183 = 'EMB_STAT_Histogram Bin171'
        d184 = 'EMB_STAT_Histogram Bin172'
        d185 = 'EMB_STAT_Histogram Bin173'
        d186 = 'EMB_STAT_Histogram Bin174'
        d187 = 'EMB_STAT_Histogram Bin175'
        d188 = 'EMB_STAT_Histogram Bin176'
        d189 = 'EMB_STAT_Histogram Bin177'
        d190 = 'EMB_STAT_Histogram Bin178'
        d191 = 'EMB_STAT_Histogram Bin179'
        d192 = 'EMB_STAT_Histogram Bin180'
        d193 = 'EMB_STAT_Histogram Bin181'
        d194 = 'EMB_STAT_Histogram Bin182'
        d195 = 'EMB_STAT_Histogram Bin183'
        d196 = 'EMB_STAT_Histogram Bin184'
        d197 = 'EMB_STAT_Histogram Bin185'
        d198 = 'EMB_STAT_Histogram Bin186'
        d199 = 'EMB_STAT_Histogram Bin187'
        d200 = 'EMB_STAT_Histogram Bin188'
        d201 = 'EMB_STAT_Histogram Bin189'
        d202 = 'EMB_STAT_Histogram Bin190'
        d203 = 'EMB_STAT_Histogram Bin191'
        d204 = 'EMB_STAT_Histogram Bin192'
        d205 = 'EMB_STAT_Histogram Bin193'
        d206 = 'EMB_STAT_Histogram Bin194'
        d207 = 'EMB_STAT_Histogram Bin195'
        d208 = 'EMB_STAT_Histogram Bin196'
        d209 = 'EMB_STAT_Histogram Bin197'
        d210 = 'EMB_STAT_Histogram Bin198'
        d211 = 'EMB_STAT_Histogram Bin199'
        d212 = 'EMB_STAT_Histogram Bin200'
        d213 = 'EMB_STAT_Histogram Bin201'
        d214 = 'EMB_STAT_Histogram Bin202'
        d215 = 'EMB_STAT_Histogram Bin203'
        d216 = 'EMB_STAT_Histogram Bin204'
        d217 = 'EMB_STAT_Histogram Bin205'
        d218 = 'EMB_STAT_Histogram Bin206'
        d219 = 'EMB_STAT_Histogram Bin207'
        d220 = 'EMB_STAT_Histogram Bin208'
        d221 = 'EMB_STAT_Histogram Bin209'
        d222 = 'EMB_STAT_Histogram Bin210'
        d223 = 'EMB_STAT_Histogram Bin211'
        d224 = 'EMB_STAT_Histogram Bin212'
        d225 = 'EMB_STAT_Histogram Bin213'
        d226 = 'EMB_STAT_Histogram Bin214'
        d227 = 'EMB_STAT_Histogram Bin215'
        d228 = 'EMB_STAT_Histogram Bin216'
        d229 = 'EMB_STAT_Histogram Bin217'
        d230 = 'EMB_STAT_Histogram Bin218'
        d231 = 'EMB_STAT_Histogram Bin219'
        d232 = 'EMB_STAT_Histogram Bin220'
        d233 = 'EMB_STAT_Histogram Bin221'
        d234 = 'EMB_STAT_Histogram Bin222'
        d235 = 'EMB_STAT_Histogram Bin223'
        d236 = 'EMB_STAT_Histogram Bin224'
        d237 = 'EMB_STAT_Histogram Bin225'
        d238 = 'EMB_STAT_Histogram Bin226'
        d239 = 'EMB_STAT_Histogram Bin227'
        d240 = 'EMB_STAT_Histogram Bin228'
        d241 = 'EMB_STAT_Histogram Bin229'
        d242 = 'EMB_STAT_Histogram Bin230'
        d243 = 'EMB_STAT_Histogram Bin231'

        figTitle = 'EMBEDDED_STATS_Plot'
        ylabel = 'RegVal (Dec)'
        numDataCols = 244  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, 3, 2):  # 1 to 3 to plot similar thresholds
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs,
                         filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, 3, 2):  # 1 to 3 to plot similar thresholds
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         legend=groupBy, show=showPlt,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs,
                         filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def EMBEDDED_STATS_Register_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'AE_MEAN_H'
        d2 = 'AE_MEAN_L'
        d3 = 'AE_HIST_BEGIN_H'
        d4 = 'AE_HIST_BEGIN_L'
        d5 = 'AE_HIST_END_H'
        d6 = 'AE_HIST_END_L'
        d7 = 'AE_LOW_END_MEAN_H'
        d8 = 'AE_LOW_END_MEAN_L'
        d9 = 'AE_PERC_LOW_END'
        d10 = 'AE_NORM_ABS_DEV'
        d11 = 'AE_MEAN2_H'
        d12 = 'AE_MEAN2_L'
        d13 = 'AE_HIST2_BEGIN_H'
        d14 = 'AE_HIST2_BEGIN_L'
        d15 = 'AE_HIST2_END_H'
        d16 = 'AE_HIST2_END_L'
        d17 = 'AE_LOW2_END_MEAN_H'
        d18 = 'AE_LOW2_END_MEAN_L'
        d19 = 'AE_PERC2_LOW_END'
        d20 = 'AE_NORM2_ABS_DEV'
        d21 = 'AE_MEAN3_H'
        d22 = 'AE_MEAN3_L'
        d23 = 'AE_HIST3_BEGIN_H'
        d24 = 'AE_HIST3_BEGIN_L'
        d25 = 'AE_HIST3_END_H'
        d26 = 'AE_HIST3_END_L'
        d27 = 'AE_LOW3_END_MEAN_H'
        d28 = 'AE_LOW3_END_MEAN_L'
        d29 = 'AE_PERC3_LOW_END'
        d30 = 'AE_NORM3_ABS_DEV'
        d31 = 'AE_COARSE_INTEGRATION_TIME'
        d32 = 'AE_STATS_STATUS'
        d33 = 'AE_X0_Y0_MEAN_H'
        d34 = 'AE_X0_Y0_MEAN_L'
        d35 = 'AE_X0_Y1_MEAN_H'
        d36 = 'AE_X0_Y1_MEAN_L'
        d37 = 'AE_X0_Y2_MEAN_H'
        d38 = 'AE_X0_Y2_MEAN_L'
        d39 = 'AE_X0_Y3_MEAN_H'
        d40 = 'AE_X0_Y3_MEAN_L'
        d41 = 'AE_X1_Y0_MEAN_H'
        d42 = 'AE_X1_Y0_MEAN_L'
        d43 = 'AE_X1_Y1_MEAN_H'
        d44 = 'AE_X1_Y1_MEAN_L'
        d45 = 'AE_X1_Y2_MEAN_H'
        d46 = 'AE_X1_Y2_MEAN_L'
        d47 = 'AE_X1_Y3_MEAN_H'
        d48 = 'AE_X1_Y3_MEAN_L'
        d49 = 'AE_X2_Y0_MEAN_H'
        d50 = 'AE_X2_Y0_MEAN_L'
        d51 = 'AE_X2_Y1_MEAN_H'
        d52 = 'AE_X2_Y1_MEAN_L'
        d53 = 'AE_X2_Y2_MEAN_H'
        d54 = 'AE_X2_Y2_MEAN_L'
        d55 = 'AE_X2_Y3_MEAN_H'
        d56 = 'AE_X2_Y3_MEAN_L'
        d57 = 'AE_X3_Y0_MEAN_H'
        d58 = 'AE_X3_Y0_MEAN_L'
        d59 = 'AE_X3_Y1_MEAN_H'
        d60 = 'AE_X3_Y1_MEAN_L'
        d61 = 'AE_X3_Y2_MEAN_H'
        d62 = 'AE_X3_Y2_MEAN_L'
        d63 = 'AE_X3_Y3_MEAN_H'
        d64 = 'AE_X3_Y3_MEAN_L'

        figTitle = 'EMBEDDED_STATS_Register_Plot'
        ylabel = 'RegVal (Dec)'
        numDataCols = 65  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, 3, 2):  # 1 to 3 to plot similar thresholds
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs,
                         filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, 3, 2):  # 1 to 3 to plot similar thresholds
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         legend=groupBy, show=showPlt,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs,
                         filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_STATS_MON_EXT(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        #obtain stats data from stats rows to get pixel count #
        d1 = 'AE_STATS_CONTROL'
        d2 = 'AE_STATS_CONTROL2'
        d3 = 'AE_ROI_X_START_OFFSET'
        d4 = 'AE_ROI_Y_START_OFFSET'
        d5 = 'AE_ROI_X_SIZE'
        d6 = 'AE_ROI_Y_SIZE'
        d7 = 'AE_ROI2_X_START_OFFSET'
        d8 = 'AE_ROI2_Y_START_OFFSET'
        d9 = 'AE_ROI2_X_SIZE'
        d10 = 'AE_ROI2_Y_SIZE'
        d11 = 'AE_ROI3_X_START_OFFSET'
        d12 = 'AE_ROI3_Y_START_OFFSET'
        d13 = 'AE_ROI3_X_SIZE'
        d14 = 'AE_ROI3_Y_SIZE'
        d15 = 'AE_X1_START_OFFSET'
        d16 = 'AE_X2_START_OFFSET'
        d17 = 'AE_X3_START_OFFSET'
        d18 = 'AE_Y1_START_OFFSET'
        d19 = 'AE_Y2_START_OFFSET'
        d20 = 'AE_Y3_START_OFFSET'

        figTitle = 'SM_STATS_MON_EXT'
        ylabel = 'RegVal (Dec)'
        numDataCols = 21  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, 15, 2):  # 1 to 3 to plot similar thresholds
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, 15, 2):  # 1 to 3 to plot similar thresholds
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         legend=groupBy, show=showPlt,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found


'''
ECC CHECK SM'S
'''
def SM_STATS_RAM_ECC(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ASIL_PIN_ENABLES_04'
        d2 = 'ASIL_CHECK_ENABLES_04'
        d3 = 'ASIL_STATUS_04'
        d4 = 'ASIL_STATUS_04__STATS1_RAM_SEC'
        d5 = 'ASIL_STATUS_04__STATS1_RAM_DED'
        d6 = 'ASIL_STATUS_04__STATS2_RAM_SEC'
        d7 = 'ASIL_STATUS_04__STATS2_RAM_DED'
        d8 = 'ASIL_STATUS_04__STATS3_RAM_SEC'
        d9 = 'ASIL_STATUS_04__STATS3_RAM_DED'
        d10 = 'ASIL_STATUS_04__STATS4_RAM_SEC'
        d11 = 'ASIL_STATUS_04__STATS4_RAM_DED'
        d12 = 'ASIL_STATUS_04__STATS5_RAM_SEC'
        d13 = 'ASIL_STATUS_04__STATS5_RAM_DED'
        d14 = 'ASIL_STATUS_04__STATS6_RAM_SEC'
        d15 = 'ASIL_STATUS_04__STATS6_RAM_DED'

        figTitle = 'SM_STATS_RAM_ECC'
        ylabel = 'RegVal (Dec)'
        numDataCols = 16  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_ECC_BLACK_LEVEL_RAM(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ASIL_CHECK_ENABLES_02_DBLC_RAM_ECC_DED_ENABLE'
        d2 = 'ASIL_CHECK_ENABLES_02__DBLC_RAM_ECC_SEC_ENABLE'
        d3 = 'ASIL_CHECK_ENABLES_02__DBLC_STATE_PARITY_ENABLE'
        d4 = 'ASIL_PIN_ENABLES_02'
        d5 = 'ASIL_CHECK_ENABLES_02'
        d6 = 'ASIL_STATUS_02'
        d7 = 'ASIL_STATUS_02__DBLC_RAM_ECC_DED_STATUS'
        d8 = 'ASIL_STATUS_02__DBLC_RAM_ECC_SEC_STATUS'
        d9 = 'ASIL_STATUS_02__DBLC_STATE_PARITY_STATUS'

        figTitle = 'SM_ECC_BLACK_LEVEL_RAM'
        ylabel = 'RegVal (Dec)'
        numDataCols = 10  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_ECC_SEQUENCER_RAM(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ASIL_PIN_ENABLES_02'
        d2 = 'ASIL_CHECK_ENABLES_02'
        d3 = 'ASIL_STATUS_02'
        d4 = 'ASIL_STATUS_02__AUX_SEQUENCER_ECC_STATUS'
        d5 = 'ASIL_STATUS_02__SEQUENCER_ECC_STATUS'

        figTitle = 'SM_ECC_SEQUENCER_RAM'
        ylabel = 'RegVal (Dec)'
        numDataCols = 6  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_ECC_CONTEXT_RAM(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ASIL_PIN_ENABLES_04'
        d2 = 'ASIL_CHECK_ENABLES_04'
        d3 = 'ASIL_STATUS_04'
        d4 = 'ASIL_STATUS_04__CTX_RAM_SEC'
        d5 = 'ASIL_STATUS_04__CTX_RAM_DED'

        figTitle = 'SM_ECC_CONTEXT_RAM'
        ylabel = 'RegVal (Dec)'
        numDataCols = 6  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_ECC_TPG_RAM(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ASIL_PIN_ENABLES_02'
        d2 = 'ASIL_CHECK_ENABLES_02'
        d3 = 'ASIL_STATUS_02'
        d4 = 'ASIL_STATUS_02__TPG_RAM_ECC_SEC'
        d5 = 'ASIL_STATUS_02__TPG_RAM_ECC_DED'

        figTitle = 'SM_ECC_TPG_RAM'
        ylabel = 'RegVal (Dec)'
        numDataCols = 6  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found


'''
REGISTER ACCESS CHECK SM'S
'''
def SM_I2C_CRC(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'I2C_RD_CHECKSUM'
        d2 = 'I2C_WRT_CHECKSUM'
        d3 = 'I2C_WRT_CHECKSUM_ASIC'
        d4 = 'CALC_I2C_RD_CHECKSUM'
        d5 = 'CALC_I2C_WRT_CHECKSUM'
        d6 = 'INVERSE_I2C_WRT_CHECKSUM'

        figTitle = 'SM_I2C_CRC'
        ylabel = 'RegVal (Dec)'
        numDataCols = 3  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_I2C_CRC_ALGORITHM(crc_prior, value):
    CRC_WIDTH = 16
    CRC_POLY = 0x1021
    crc_new = crc_prior
    for bit in range(CRC_WIDTH-1, -1, -1):
        tmp = 0
        if (((crc_new >> (CRC_WIDTH-1)) & 1) ^ ((value >> bit) & 1)):
            tmp = CRC_POLY
        crc_new = (((crc_new << 1) & (2**(CRC_WIDTH)-1)) ^ tmp);
    return crc_new

def SM_DOUBLE_LOCK(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'LOCK_CONTROL'

        figTitle = 'SM_DOUBLE_LOCK'
        ylabel = 'RegVal (Dec)'
        numDataCols = 2  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_DIGITAL_FRAMECOUNTER(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'FRAME_COUNT_'
        d2 = 'FRAME_COUNT2_'
        d3 = 'MIPI_CONFIG_STATUS'
        d4 = 'MIPI_CONFIG_STATUS__FRAME_CNT_EN'
        d5 = 'MIPI_CONFIG_STATUS__FRAME_CNT_RST'

        figTitle = 'SM_DIGITAL_FRAMECOUNTER'
        ylabel = 'RegVal (Dec)'
        numDataCols = 6  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_DIGITAL_FRAMECOUNTER_vs_Time_Plot(dataFrame, groupCol, groupVal, document, pltPath, showPlt, **kwargs):
    try:
        if groupCol == None and groupVal == None:  # Dont group data frame
            df = dataFrame
        elif groupCol != None and groupVal != None:  # Group data frame by col and value
            df = VRG_Data_Frame.newdataframe(dataFrame, groupCol, groupVal)

        d1 = 'FRAME_COUNT_ Read'

        # get data columns
        t1_cols = [x for x in df.columns[df.columns.str.contains(d1)]]

        # subset df
        t1 = df[t1_cols]

        # rename columns to get read number
        for dc in t1_cols:
            t1 = t1.rename(columns={dc: dc.split(' ')[2]})

        # transpose
        t1 = t1.T

        # add an index column
        t1['Read Num'] = t1.index

        colList = []
        for index in df.index:
            colList.append(index)

        figTitle = 'SM_DIGITAL_FRAMECOUNTER_vs_Time_Plot'
        numDataCols = 2
        titleFontSize = 12
        yFontsize = 8
        xFontsize = 8
        legFontSize = 6

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupCol == None and groupVal == None:  # No Dataframe grouping
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(eval("t" + str(x)), x='Read Num', y=colList, title=eval("d" + str(x)), legend_title="Test #",
                         show=showPlt,
                         inline=showPlt, label_y=eval("d" + str(x)), title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupCol != None and groupVal != None:  # Data frame grouped by col and val
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(eval("t" + str(x)), x='Read Num', y=colList,
                         title=eval("d" + str(x)) + " Groupedby: " + groupCol + ' = ' + str(groupVal), show=showPlt,
                         inline=showPlt, legend_title="Test #", label_y=eval("d" + str(x)), title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for dc in t1_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        if groupCol == None:
            document.add_heading("groupCol Not Used", level=3)
        elif groupCol != None:
            if groupCol in df.columns:
                document.add_heading("groupCol Found: " + groupCol, level=3)  # Add Groupby found
                if groupVal == None:
                    document.add_heading("groupVal Missing", level=3)
                elif groupVal != None:
                    if groupCol in df[groupCol].unique():
                        document.add_heading("groupVal Found: " + groupVal, level=3)  # Add Groupby found
                    else:
                        document.add_heading("groupVal Not Found: " + groupVal, level=3)  # Add Groupby not found
            else:
                document.add_heading("groupCol Not Found: " + groupCol, level=3)  # Add Groupby not found

def SM_DIGITAL_FRAMECOUNTER_vs_TestNo_Plot(dataFrame, groupCol, groupVal, document, pltPath, showPlt, **kwargs):
    try:

        if groupCol == None and groupVal == None:  #Dont group data frame
            df = dataFrame
        elif groupCol != None and groupVal != None: #Group data frame by col and value
            df = VRG_Data_Frame.newdataframe(dataFrame, groupCol, groupVal)

        d1 = 'FRAME_COUNT_ Read'

        # get data columns
        t1_cols = [x for x in df.columns[df.columns.str.contains(d1)]]

        # subset df
        t1 = df[t1_cols]

        # rename columns to get read number
        for dc in t1_cols:
            t1 = t1.rename(columns={dc: dc.split(' ')[2]})

        # transpose
        t1 = t1.T

        # add an index column
        t1['Read Num'] = t1.index

        figTitle = 'SM_DIGITAL_FRAMECOUNTER_vs_TestNo_Plot'
        numDataCols = len(df.index)  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 12
        yFontsize = 8
        xFontsize = 8
        legFontSize = 6

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupCol == None and groupVal == None:  # No Dataframe grouping
            document.add_heading(d1 + " vs. Test #", level=2)
            for x in range(1, numDataCols):
                fcp.plot(t1, x='Read Num', y=x, title="Test #" + str(x), show=showPlt,
                         inline=showPlt, label_y=d1, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
                document.add_heading(d1 + " Test #" + str(x), level=3)
                document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
        elif groupCol != None and groupVal != None: # Data frame grouped by col and val
            document.add_heading(d1 + " vs. Test # Groupedby: " + groupCol + ' = ' + str(groupVal), level=2)
            for x in range(1, numDataCols):
                fcp.plot(t1, x='Read Num', y=x, title="Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal), show=showPlt,
                         inline=showPlt, label_y=d1, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
                document.add_heading(d1 + " Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
                document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for dc in t1_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        if groupCol == None:
            document.add_heading("groupCol Not Used", level=3)
        elif groupCol != None:
            if groupCol in df.columns:
                document.add_heading("groupCol Found: " + groupCol, level=3)  # Add Groupby found
                if groupVal == None:
                    document.add_heading("groupVal Missing", level=3)
                elif groupVal != None:
                    if groupCol in df[groupCol].unique():
                        document.add_heading("groupVal Found: " + groupVal, level=3)  # Add Groupby found
                    else:
                        document.add_heading("groupVal Not Found: " + groupVal, level=3)  # Add Groupby not found
            else:
                document.add_heading("groupCol Not Found: " + groupCol, level=3)  # Add Groupby not found


'''
CRC CHECK SM'S
'''
def SM_PDI_RAM_CRC(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'PIX_DEF_ID_BASE_RAM'
        d2 = 'SENSOR_RAM_D_COUNT'
        d3 = 'PIX_DEF_ID_BASE_RAM_ASIC'
        d4 = 'FUSE_PIXEL_DEFECT_COUNT'

        figTitle = 'SM_PDI_RAM_CRC'
        ylabel = 'RegVal (Dec)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_CDS_MEM_CRC_BTM(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'DCDS_CRC_FAULT_CONTROL_BTM'
        d2 = 'DCDS_CRC_FAULT_FRAMES_BTM'
        d3 = 'DCDS_CRC_FAULTS_PER_FRAME_BTM'
        d4 = 'ASIL_STATUS_03'
        d5 = 'ASIL_STATUS_03__DCDS_BTM_MEMORY_CRC_FAULT'

        figTitle = 'SM_CDS_MEM_CRC_BTM'
        ylabel = 'RegVal (Dec)'
        numDataCols = 6  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_CDS_MEM_CRC_TOP(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'DCDS_CRC_FAULT_CONTROL_TOP'
        d2 = 'DCDS_CRC_FAULT_FRAMES_TOP'
        d3 = 'DCDS_CRC_FAULTS_PER_FRAME_TOP'
        d4 = 'ASIL_STATUS_03'
        d5 = 'ASIL_STATUS_03__DCDS_TOP_MEMORY_CRC_FAULT'

        figTitle = 'SM_CDS_MEM_CRC_TOP'
        ylabel = 'RegVal (Dec)'
        numDataCols = 6  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_OFL_MEM_CRC(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'LFM2_CRC_FAULT_CONTROL'
        d2 = 'LFM2_CRC_FAULT_FRAMES'
        d3 = 'LFM2_CRC_FAULTS_PER_FRAME'
        d4 = 'ASIL_STATUS_03__LFM2_MEMORY_CRC_FAULT'

        figTitle = 'SM_OFL_MEM_CRC'
        ylabel = 'RegVal (Dec)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_DELAY_BUFFER_RAM_CRC(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'DELAY_BUFFER_CRC_FAULT_CONTROL'
        d2 = 'DELAY_BUFFER_CRC_FAULT_FRAMES'
        d3 = 'DELAY_BUFFER_CRC_FAULTS_PER_FRAME'
        d4 = 'ASIL_STATUS_03__DELAY_BUFFER_CRC_FAULT'

        figTitle = 'SM_DELAY_BUFFER_RAM_CRC'
        ylabel = 'RegVal (Dec)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_DEF_CORR_RAM_CRC(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ASIL_PIN_ENABLES_00'
        d2 = 'ASIL_CHECK_ENABLES_00'
        d3 = 'ASIL_STATUS_00'
        d4 = 'T1_SM_STATUS'
        d5 = 'T4_SM_STATUS'

        figTitle = 'SM_DEF_CORR_RAM_CRC'
        ylabel = 'RegVal (Dec)'
        numDataCols = 6  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_MEC_RAM_CRC(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'MEC_CRC_FAULT_CONTROL'
        d2 = 'MEC_CRC_FAULT_FRAMES'
        d3 = 'MEC_CRC_FAULTS_PER_FRAME'
        d4 = 'ASIL_STATUS_03'
        d5 = 'ASIL_STATUS_03__MEC_MEMORY_CRC_FAULT'

        figTitle = 'SM_MEC_RAM_CRC'
        ylabel = 'RegVal (Dec)'
        numDataCols = 6  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_ADDR_STATE_CRC(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ASIL_PIN_ENABLES_02__ADDRESS_SM_CRC_PIN_ENABLE'
        d2 = 'ASIL_CHECK_ENABLES_02__ADDRESS_SM_CRC_ENABLE'
        d3 = 'ASIL_STATUS_02'
        d4 = 'ASIL_STATUS_02__ADDRESS_SM_CRC_STATUS'

        figTitle = 'SM_ADDR_STATE_CRC'
        ylabel = 'RegVal (Dec)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_ODP_BUFFER_CRC(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ODP_CRC_FAULT_CONTROL'
        d2 = 'ODP_CRC_FAULT_FRAMES'
        d3 = 'ODP_CRC_FAULTS_PER_FRAME'
        d4 = 'ASIL_STATUS_03'
        d5 = 'ASIL_STATUS_03__ODP_MEMORY_CRC_FAULT'

        figTitle = 'SM_ODP_BUFFER_CRC'
        ylabel = 'RegVal (Dec)'
        numDataCols = 6  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_SENSOR_DATAPATH_BUFFER_CRC(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'FOR_CRC_FAULT_CONTROL'
        d2 = 'FOT_CRC_FAULTS_PER_FRAME'
        d3 = 'FOR_CRC_FAULT_FRAMES'

        figTitle = 'SM_SENSOR_DATAPATH_BUFFER_CRC'
        ylabel = 'RegVal (Dec)'
        numDataCols = 4  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_ASIC_DATAPATH_BUFFER_CRC(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'FOR_CRC_FAULT_CONTROL'
        d2 = 'FOT_ASIC_CRC_FAULTS_PER_FRAME'
        d3 = 'FOR_ASIC_CRC_FAULT_FRAMES'

        figTitle = 'SM_ASIC_DATAPATH_BUFFER_CRC'
        ylabel = 'RegVal (Dec)'
        numDataCols = 4  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_24_TO_16_BUFFER_CRC(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'CONV_CRC_FAULT_CONTROL'
        d2 = 'CONV_CRC_FAULT_FRAMES'
        d3 = 'CONV_CRC_FAULTS_PER_FRAME'
        d4 = 'ASIL_STATUS_03'
        d5 = 'ASIL_STATUS_03__CONV_MEMORY_CRC_FAULT'

        figTitle = 'SM_24_TO_16_BUFFER_CRC'
        ylabel = 'RegVal (Dec)'
        numDataCols = 6  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_BIN2_RAM_CRC(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ODP_SKIP_BIN_CRC_FAULT_CONTROL'
        d2 = 'ODP_SKIP_BIN_CRC_FAULT_FRAMES'
        d3 = 'ODP_SKIP_BIN_CRC_FAULTS_PER_FRAME'
        d4 = 'ASIL_STATUS_03'
        d5 = 'ASIL_STATUS_03__ODP_SKIP_BIN_MEM_CRC_FAULT'

        figTitle = 'SM_BIN2_RAM_CRC'
        ylabel = 'RegVal (Dec)'
        numDataCols = 6  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_SENSOR_HISPI_TX_RX_CRC(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'DEFRAMER_FAULT_CTRL'
        d2 = 'DEFRAMER_CTRL2'
        d3 = 'DEFRAMER_ERROR_STATUS'
        d4 = 'DEFRAMER_ERROR_STATUS__CRC_ERROR'
        d5 = 'ASIL_STATUS_03'
        d6 = 'ASIL_STATUS_03__DEFRAMER_FAULT'

        figTitle = 'SM_SENSOR_HISPI_TX_RX_CRC'
        ylabel = 'RegVal (Dec)'
        numDataCols = 7  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_HISPI_RX_MEMORY_CRC(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'DEFRAMER_FAULT_CTRL'
        d2 = 'DEFRAMER_CTRL2'
        d3 = 'DEFRAMER_ERROR_STATUS'
        d4 = 'DEFRAMER_ERROR_STATUS__CRC_ERROR'
        d5 = 'ASIL_STATUS_03'
        d6 = 'ASIL_STATUS_03__DEFRAMER_FAULT'

        figTitle = 'SM_SENSOR_HISPI_TX_RX_CRC'
        ylabel = 'RegVal (Dec)'
        numDataCols = 7  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_HISPI_LINE_CRC(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'DEFRAMER_FAULT_CTRL'
        d2 = 'DEFRAMER_CTRL2'
        d3 = 'DEFRAMER_ERROR_STATUS'
        d4 = 'DEFRAMER_ERROR_STATUS__CRC_ERROR'
        d5 = 'ASIL_STATUS_03'
        d6 = 'ASIL_STATUS_03__DEFRAMER_FAULT'

        figTitle = 'SM_SENSOR_HISPI_TX_RX_CRC'
        ylabel = 'RegVal (Dec)'
        numDataCols = 7  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_HISPI_RX_ERROR(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'DEFRAMER_FAULT_CTRL'
        d2 = 'DEFRAMER_CTRL2'
        d3 = 'DEFRAMER_ERROR_STATUS'
        d4 = 'DEFRAMER_ERROR_STATUS__CRC_ERROR'
        d5 = 'ASIL_STATUS_03'
        d6 = 'ASIL_STATUS_03__DEFRAMER_FAULT'

        figTitle = 'SM_SENSOR_HISPI_TX_RX_CRC'
        ylabel = 'RegVal (Dec)'
        numDataCols = 7  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found


'''
CHALLENGE RESPONSE SM'S
'''
def SM_MASTER_STATE_CHA_RES(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'MASTER_FSM_REQ_CODE'
        d2 = 'MASTER_FSM_RSP_CODE'
        d3 = 'MASTER_FSM_STATUS'
        d4 = 'MASTER_FSM_FULL_STATUS_HI'
        d5 = 'MASTER_FSM_FULL_STATUS_LO'
        d6 = 'CALC_MASTER_FSM_RSP_CODE'

        figTitle = 'SM_MASTER_STATE_CHA_RES'
        ylabel = 'RegVal (Dec)'
        numDataCols = 7  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found


'''
ANALOG TO DIGITAL SM'S
'''
def SM_AHM_SREG_READBACK(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # d1 = 'STATC_ERR_EN'
        # d2 = 'STATC_ERR'
        d1 = 'RegWr01_STATC_ERR_EN'
        d2 = 'RegVal_STATC_ERR'

        figTitle = 'SM_AHM_SREG_READBACK'
        ylabel = 'RegVal (Dec)'
        numDataCols = 3  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

'''
INVALID IMAGE SM'S
'''
def SM_HOST_CHECK_INVALID_IMAGE(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        #Protocol Signal Level receiver errors
        #Clock checks
        #Data checks
        #CRC and ECC Header Checks
        #Number of lines received in a Frame
        #Number of Pixels per line received.
        #Frame Rate
        VRG_TimingData.Calc_FPS_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs)
        VRG_TimingData.Calc_Sensor_Data_Rate_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs)
        VRG_TimingData.Calc_ASIC_Data_Rate_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs)
        VRG_TimingData.PLL_Clock_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs)
        VRG_TimingData.I2C_Status_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs)
        VRG_TimingData.Sensor_FPS_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs)
        VRG_General_Data.FrameHeight_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs)
        VRG_General_Data.FrameWidth_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs)

        d1 = 'Y_ADDR_START_'
        d2 = 'X_ADDR_START_'
        d3 = 'Y_ADDR_END_'
        d4 = 'X_ADDR_END_'
        d5 = 'FRAME_LENGTH_LINES_'
        d6 = 'LINE_LENGTH_PCK_'
        d7 = 'MIPI_CONFIG_STATUS__FRAME_CNT_EN'
        d8 = 'MIPI_CONFIG_STATUS__FRAME_CNT_RST'
        d9 = 'FRAME_COUNT_'
        d10 = 'FRAME_COUNT2_'
        d11 = 'HISPI_CONTROL'
        d12 = 'HISPI_STATUS'
        d13 = 'HISPI_STATUS__HISPI_CHECKSUM_VALID'
        d14 = 'HISPI_CRC_0'
        d15 = 'HISPI_CRC_1'
        d16 = 'HISPI_CRC_2'
        d17 = 'HISPI_CRC_3'
        d18 = 'SENSOR_HISPI_CONTROL'
        d19 = 'SENSOR_HISPI_STATUS'
        d20 = 'SENSOR_HISPI_STATUS__SENSOR_HISPI_CHECKSUM_VALID'
        d21 = 'SENSOR_HISPI_CRC_0'
        d22 = 'SENSOR_HISPI_CRC_1'
        d23 = 'SENSOR_HISPI_CRC_2'
        d24 = 'SENSOR_HISPI_CRC_3'
        d25 = 'MipiStatus'
        d26 = 'MipiStatus__SpEccError'
        d27 = 'MipiStatus__LpEccError'
        d28 = 'MipiStatus__TxPllLocked'

        figTitle = 'SM_HOST_CHECK_INVALID_IMAGE'
        ylabel = 'RegVal (Dec)'
        numDataCols = 29  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_DATA_FORMAT(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'DATA_FORMAT_BITS'
        d2 = 'DATA_FORMAT_ACTUAL'
        d3 = 'ASIL_PIN_ENABLES_00__ASIL_PIN_DATA_FORMAT'
        d4 = 'ASIL_CHECK_ENABLES_00__ASIL_CHECK_DATA_FORMAT_ENABLE'
        d5 = 'ASIL_STATUS_00__ASIL_STATUS_DATA_FORMAT_ERROR'

        figTitle = 'SM_DATA_FORMAT'
        ylabel = 'RegVal (Dec)'
        numDataCols = 6  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found


'''
SM ATR IMAGE DATA VALIDATION
'''
def SM_Analog_Test_Rows_Expanded_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV

        d1 = 'ATR_Column_Rom_CRC'
        d2 = 'COLUMN_ROM max'
        d3 = 'COLUMN_ROM mean'
        d4 = 'COLUMN_ROM min'
        d5 = 'COLUMN_ROM std'
        d6 = 'ADC_LATCH max'
        d7 = 'ADC_LATCH mean'
        d8 = 'ADC_LATCH min'
        d9 = 'ADC_LATCH std'
        d10 = 'DCDS_1 max'
        d11 = 'DCDS_1 mean'
        d12 = 'DCDS_1 min'
        d13 = 'DCDS_1 std'
        d14 = 'COL_MEM_1 max'
        d15 = 'COL_MEM_1 mean'
        d16 = 'COL_MEM_1 min'
        d17 = 'COL_MEM_1 std'
        d18 = 'COL_MEM_2 max'
        d19 = 'COL_MEM_2 mean'
        d20 = 'COL_MEM_2 min'
        d21 = 'COL_MEM_2 std'
        d22 = 'COL_MEM_3 max'
        d23 = 'COL_MEM_3 mean'
        d24 = 'COL_MEM_3 min'
        d25 = 'COL_MEM_3 std'
        d26 = 'OVDRV_SHR_1 max'
        d27 = 'OVDRV_SHR_1 mean'
        d28 = 'OVDRV_SHR_1 min'
        d29 = 'OVDRV_SHR_1 std'
        d30 = 'OVDRV_SHR_2 max'
        d31 = 'OVDRV_SHR_2 mean'
        d32 = 'OVDRV_SHR_2 min'
        d33 = 'OVDRV_SHR_2 std'
        d34 = 'OVDRV_SHR_3 max'
        d35 = 'OVDRV_SHR_3 mean'
        d36 = 'OVDRV_SHR_3 min'
        d37 = 'OVDRV_SHR_3 std'
        d38 = 'OVDRV_CODE_0 max'
        d39 = 'OVDRV_CODE_0 mean'
        d40 = 'OVDRV_CODE_0 min'
        d41 = 'OVDRV_CODE_0 std'
        d42 = 'OVDRV_CODE_1 max'
        d43 = 'OVDRV_CODE_1 mean'
        d44 = 'OVDRV_CODE_1 min'
        d45 = 'OVDRV_CODE_1 std'
        d46 = 'OVDRV_CODE_2 max'
        d47 = 'OVDRV_CODE_2 mean'
        d48 = 'OVDRV_CODE_2 min'
        d49 = 'OVDRV_CODE_2 std'
        d50 = 'OVDRV_CODE_3 max'
        d51 = 'OVDRV_CODE_3 mean'
        d52 = 'OVDRV_CODE_3 min'
        d53 = 'OVDRV_CODE_3 std'
        d54 = 'OVDRV_CODE_SHS max'
        d55 = 'OVDRV_CODE_SHS mean'
        d56 = 'OVDRV_CODE_SHS min'
        d57 = 'OVDRV_CODE_SHS std'
        d58 = 'ZEBRA_BW max'
        d59 = 'ZEBRA_BW mean'
        d60 = 'ZEBRA_BW min'
        d61 = 'ZEBRA_BW std'
        d62 = 'ZEBRA_WB max'
        d63 = 'ZEBRA_WB mean'
        d64 = 'ZEBRA_WB min'
        d65 = 'ZEBRA_WB std'
        d66 = 'VERT_TEST_1 max'
        d67 = 'VERT_TEST_1 mean'
        d68 = 'VERT_TEST_1 min'
        d69 = 'VERT_TEST_1 std'
        d70 = 'VERT_TEST_2 max'
        d71 = 'VERT_TEST_2 mean'
        d72 = 'VERT_TEST_2 min'
        d73 = 'VERT_TEST_2 std'
        d74 = 'ECL_COMP max'
        d75 = 'ECL_COMP mean'
        d76 = 'ECL_COMP min'
        d77 = 'ECL_COMP std'
        d78 = 'DCDS_2 max'
        d79 = 'DCDS_2 mean'
        d80 = 'DCDS_2 min'
        d81 = 'DCDS_2 std'


        # d66 = 'FRAMECOUNTER max'
        # d67 = 'FRAMECOUNTER mean'
        # d68 = 'FRAMECOUNTER min'
        # d69 = 'FRAMECOUNTER std'
        # d70 = 'VAAPIX_GRADIENT max'
        # d71 = 'VAAPIX_GRADIENT mean'
        # d72 = 'VAAPIX_GRADIENT min'
        # d73 = 'VAAPIX_GRADIENT std'

        figTitle = 'SM_Analog_Test_Rows_Stats_Expanded'
        ylabel = 'DN'
        ylabel2 = 'CRC Val'
        numDataCols = 82  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 89
                if x != 1:  # All other ATR Results
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel,
                             title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                             legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
                elif x == 1:  # Column Rom CRC
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols): # 1 to 89
                if x != 1:  # All other ATR Results
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel,
                             title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                             legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
                elif x == 1:  # Column Rom CRC
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_Analog_Test_Rows_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV

        sd1 = 'ATR_Column_Rom_CRC'

        d1 = 'COLUMN_ROM max'
        d2 = 'COLUMN_ROM mean'
        d3 = 'COLUMN_ROM min'
        d4 = 'COLUMN_ROM std'
        d5 = 'ADC_LATCH max'
        d6 = 'ADC_LATCH mean'
        d7 = 'ADC_LATCH min'
        d8 = 'ADC_LATCH std'
        d9 =  'DCDS_1 max'
        d10 = 'DCDS_1 mean'
        d11 = 'DCDS_1 min'
        d12 = 'DCDS_1 std'
        d13 = 'COL_MEM_1 max'
        d14 = 'COL_MEM_1 mean'
        d15 = 'COL_MEM_1 min'
        d16 = 'COL_MEM_1 std'
        d17 = 'COL_MEM_2 max'
        d18 = 'COL_MEM_2 mean'
        d19 = 'COL_MEM_2 min'
        d20 = 'COL_MEM_2 std'
        d21 = 'COL_MEM_3 max'
        d22 = 'COL_MEM_3 mean'
        d23 = 'COL_MEM_3 min'
        d24 = 'COL_MEM_3 std'
        d25 = 'OVDRV_SHR_1 max'
        d26 = 'OVDRV_SHR_1 mean'
        d27 = 'OVDRV_SHR_1 min'
        d28 = 'OVDRV_SHR_1 std'
        d29 = 'OVDRV_SHR_2 max'
        d30 = 'OVDRV_SHR_2 mean'
        d31 = 'OVDRV_SHR_2 min'
        d32 = 'OVDRV_SHR_2 std'
        d33 = 'OVDRV_SHR_3 max'
        d34 = 'OVDRV_SHR_3 mean'
        d35 = 'OVDRV_SHR_3 min'
        d36 = 'OVDRV_SHR_3 std'
        d37 = 'OVDRV_CODE_0 max'
        d38 = 'OVDRV_CODE_0 mean'
        d39 = 'OVDRV_CODE_0 min'
        d40 = 'OVDRV_CODE_0 std'
        d41 = 'OVDRV_CODE_1 max'
        d42 = 'OVDRV_CODE_1 mean'
        d43 = 'OVDRV_CODE_1 min'
        d44 = 'OVDRV_CODE_1 std'
        d45 = 'OVDRV_CODE_2 max'
        d46 = 'OVDRV_CODE_2 mean'
        d47 = 'OVDRV_CODE_2 min'
        d48 = 'OVDRV_CODE_2 std'
        d49 = 'OVDRV_CODE_3 max'
        d50 = 'OVDRV_CODE_3 mean'
        d51 = 'OVDRV_CODE_3 min'
        d52 = 'OVDRV_CODE_3 std'
        d53 = 'OVDRV_CODE_SHS max'
        d54 = 'OVDRV_CODE_SHS mean'
        d55 = 'OVDRV_CODE_SHS min'
        d56 = 'OVDRV_CODE_SHS std'
        d57 = 'ZEBRA_BW max'
        d58 = 'ZEBRA_BW mean'
        d59 = 'ZEBRA_BW min'
        d60 = 'ZEBRA_BW std'
        d61 = 'ZEBRA_WB max'
        d62 = 'ZEBRA_WB mean'
        d63 = 'ZEBRA_WB min'
        d64 = 'ZEBRA_WB std'
        d65 = 'VERT_TEST_1 max'
        d66 = 'VERT_TEST_1 mean'
        d67 = 'VERT_TEST_1 min'
        d68 = 'VERT_TEST_1 std'
        d69 = 'VERT_TEST_2 max'
        d70 = 'VERT_TEST_2 mean'
        d71 = 'VERT_TEST_2 min'
        d72 = 'VERT_TEST_2 std'
        d73 = 'ECL_COMP max'
        d74 = 'ECL_COMP mean'
        d75 = 'ECL_COMP min'
        d76 = 'ECL_COMP std'
        d77 = 'DCDS_2 max'
        d78 = 'DCDS_2 mean'
        d79 = 'DCDS_2 min'
        d80 = 'DCDS_2 std'


        figTitle = 'SM_Analog_Test_Rows_Stats'
        ylabel = 'DN'
        ylabel2 = 'CRC Val'
        numDataCols = 81  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols, 4): # 1 to numcols by 4
                n1 = eval("d" + str(x))
                n2 = eval("d" + str(x + 1))
                n3 = eval("d" + str(x + 2))
                n4 = eval("d" + str(x + 3))
                dname1 = n1.split()
                dname2 = n2.split()
                dname3 = n3.split()
                dname4 = n4.split()
                if x != 1:  # All other ATR Results
                    fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1)), eval("d" + str(x + 2)), eval("d" + str(x + 3))],
                             title=dname1[0] + ' ' + dname1[1] + ', ' + dname2[1] + ', ' + dname3[1] + ', ' + dname4[1],
                             show=showPlt, inline=showPlt, label_y=ylabel,
                             title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                             legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + eval("d" + str(x + 2)) + '_' + eval("d" + str(x + 3)) + '_' + timestamp + '.png')
                    document.add_heading(dname1[0] + ' ' + dname1[1] + ', ' + dname2[1] + ', ' + dname3[1] + ', ' + dname4[1], level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + eval("d" + str(x + 2)) + '_' + eval("d" + str(x + 3)) + '_' + timestamp + '.png')  # Add figure to report
                elif x == 1:  # Column Rom CRC
                    fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1)), eval("d" + str(x + 2)), eval("d" + str(x + 3))],
                             title=dname1[0] + ' ' + dname1[1] + ', ' + dname2[1] + ', ' + dname3[1] + ', ' + dname4[1],
                             show=showPlt, inline=showPlt, label_y=ylabel,
                             title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                             legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + eval("d" + str(x + 2)) + '_' + eval("d" + str(x + 3)) + '_' + timestamp + '.png')
                    document.add_heading(dname1[0] + ' ' + dname1[1] + ', ' + dname2[1] + ', ' + dname3[1] + ', ' + dname4[1], level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + eval("d" + str(x + 2)) + '_' + eval("d" + str(x + 3)) + '_' + timestamp + '.png')  # Add figure to report            # Plot secondary data (sd) for Column Rom CRC
                    fcp.plot(df, x='Step', y=eval("sd" + str(x)), title=eval("sd" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("sd" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("sd" + str(x)), level=3)
                    document.add_picture(pltPath + eval("sd" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols, 4): # 1 to numcols by 4
                n1 = eval("d" + str(x))
                n2 = eval("d" + str(x + 1))
                n3 = eval("d" + str(x + 2))
                n4 = eval("d" + str(x + 3))
                dname1 = n1.split()
                dname2 = n2.split()
                dname3 = n3.split()
                dname4 = n4.split()
                if x != 1:  # All other ATR Results
                    fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1)), eval("d" + str(x + 2)), eval("d" + str(x + 3))],
                             title=dname1[0] + ' ' + dname1[1] + ', ' + dname2[1] + ', ' + dname3[1] + ', ' + dname4[1],
                             legend=groupBy, show=showPlt, inline=showPlt, label_y=ylabel,
                             title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                             legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + eval("d" + str(x + 2)) + '_' + eval("d" + str(x + 3)) + '_' + timestamp + '.png')
                    document.add_heading(dname1[0] + ' ' + dname1[1] + ', ' + dname2[1] + ', ' + dname3[1] + ', ' + dname4[1], level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + eval("d" + str(x + 2)) + '_' + eval("d" + str(x + 3)) + '_' + timestamp + '.png')  # Add figure to report
                elif x == 1:  # Column Rom CRC
                    fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1)), eval("d" + str(x + 2)), eval("d" + str(x + 3))],
                             title=dname1[0] + ' ' + dname1[1] + ', ' + dname2[1] + ', ' + dname3[1] + ', ' + dname4[1],
                             legend=groupBy, show=showPlt, inline=showPlt, label_y=ylabel,
                             title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                             legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + eval("d" + str(x + 2)) + '_' + eval("d" + str(x + 3)) + '_' + timestamp + '.png')
                    document.add_heading(dname1[0] + ' ' + dname1[1] + ', ' + dname2[1] + ', ' + dname3[1] + ', ' + dname4[1], level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + eval("d" + str(x + 2)) + '_' + eval("d" + str(x + 3)) + '_' + timestamp + '.png')  # Add figure to report            # Plot secondary data (sd) for Column Rom CRC
                    fcp.plot(df, x='Step', y=eval("sd" + str(x)), title=eval("sd" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("sd" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("sd" + str(x)), level=3)
                    document.add_picture(pltPath + eval("sd" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_Analog_Test_Rows_vs_Thresholds_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):

    figTitle = 'SM_Analog_Test_Rows_vs_Thresholds_Plot'

    currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
    fractime = time.process_time()
    timestamp = currTime + '_' + str(fractime)

    document.add_heading(figTitle, level=2)  # Add section title to docx report

    # ATR Image Data vs. Thresholds
    VRG_Safety_Data.SM_ATR_COLUMN_ROM_vs_Calculated_CRC(dataFrame, groupBy, document, pltPath, showPlt, **kwargs)
    VRG_Safety_Data.SM_ATR_ADC_LATCH_vs_Threshold(dataFrame, groupBy, document, pltPath, showPlt, **kwargs)
    VRG_Safety_Data.SM_ATR_DCDS_vs_Threshold(dataFrame, groupBy, document, pltPath, showPlt, **kwargs)
    VRG_Safety_Data.SM_ATR_COLUMN_MEMORY_TEST_1_vs_Threshold(dataFrame, groupBy, document, pltPath, showPlt, **kwargs)
    VRG_Safety_Data.SM_ATR_COLUMN_MEMORY_TEST_2_vs_Threshold(dataFrame, groupBy, document, pltPath, showPlt, **kwargs)
    VRG_Safety_Data.SM_ATR_COLUMN_MEMORY_TEST_3_vs_Threshold(dataFrame, groupBy, document, pltPath, showPlt, **kwargs)
    VRG_Safety_Data.SM_ATR_ZEBRA_AB_vs_Threshold(dataFrame, groupBy, document, pltPath, showPlt, **kwargs)
    VRG_Safety_Data.SM_ATR_ZEBRA_BA_vs_Threshold(dataFrame, groupBy, document, pltPath, showPlt, **kwargs)
    VRG_Safety_Data.SM_ATR_OVERDRIVE_1_vs_Threshold(dataFrame, groupBy, document, pltPath, showPlt, **kwargs)
    VRG_Safety_Data.SM_ATR_OVERDRIVE_2_vs_Threshold(dataFrame, groupBy, document, pltPath, showPlt, **kwargs)
    VRG_Safety_Data.SM_ATR_OVERDRIVE_3_vs_Threshold(dataFrame, groupBy, document, pltPath, showPlt, **kwargs)
    VRG_Safety_Data.SM_ATR_OVERDRIVE_4_vs_Threshold(dataFrame, groupBy, document, pltPath, showPlt, **kwargs)
    VRG_Safety_Data.SM_ATR_OVERDRIVE_5_vs_Threshold(dataFrame, groupBy, document, pltPath, showPlt, **kwargs)
    VRG_Safety_Data.SM_ATR_OVERDRIVE_6_vs_Threshold(dataFrame, groupBy, document, pltPath, showPlt, **kwargs)
    VRG_Safety_Data.SM_ATR_OVERDRIVE_7_vs_Threshold(dataFrame, groupBy, document, pltPath, showPlt, **kwargs)
    VRG_Safety_Data.SM_ATR_OVERDRIVE_8_vs_Threshold(dataFrame, groupBy, document, pltPath, showPlt, **kwargs)
    VRG_Safety_Data.SM_ATR_VERT_PIXOUT_1_vs_Threshold(dataFrame, groupBy, document, pltPath, showPlt, **kwargs)
    VRG_Safety_Data.SM_ATR_VERT_PIXOUT_2_vs_Threshold(dataFrame, groupBy, document, pltPath, showPlt, **kwargs)
    VRG_Safety_Data.SM_ATR_ECL_COMPARATOR_LOGIC_vs_Threshold(dataFrame, groupBy, document, pltPath, showPlt, **kwargs)
    VRG_Safety_Data.SM_ATR_DCDS2_vs_Threshold(dataFrame, groupBy, document, pltPath, showPlt, **kwargs)

'''
SM RRC IMAGE DATA VALIDATION
'''
def SM_Row_Rom_Address_Columns_Expanded_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'RRC_Col_0 max'
        d2 = 'RRC_Col_0 mean'
        d3 = 'RRC_Col_0 min'
        d4 = 'RRC_Col_0 std'
        d5 = 'RRC_Col_1 max'
        d6 = 'RRC_Col_1 mean'
        d7 = 'RRC_Col_1 min'
        d8 = 'RRC_Col_1 std'
        d9 = 'RRC_Col_2 max'
        d10 = 'RRC_Col_2 mean'
        d11 = 'RRC_Col_2 min'
        d12 = 'RRC_Col_2 std'
        d13 = 'RRC_Col_3 max'
        d14 = 'RRC_Col_3 mean'
        d15 = 'RRC_Col_3 min'
        d16 = 'RRC_Col_3 std'
        d17 = 'RRC_Col_4 max'
        d18 = 'RRC_Col_4 mean'
        d19 = 'RRC_Col_4 min'
        d20 = 'RRC_Col_4 std'
        d21 = 'RRC_Col_5 max'
        d22 = 'RRC_Col_5 mean'
        d23 = 'RRC_Col_5 min'
        d24 = 'RRC_Col_5 std'
        d25 = 'RRC_Col_6 max'
        d26 = 'RRC_Col_6 mean'
        d27 = 'RRC_Col_6 min'
        d28 = 'RRC_Col_6 std'
        d29 = 'RRC_Col_7 max'
        d30 = 'RRC_Col_7 mean'
        d31 = 'RRC_Col_7 min'
        d32 = 'RRC_Col_7 std'
        d33 = 'RRC_Col_8 max'
        d34 = 'RRC_Col_8 mean'
        d35 = 'RRC_Col_8 min'
        d36 = 'RRC_Col_8 std'
        d37 = 'RRC_Col_9 max'
        d38 = 'RRC_Col_9 mean'
        d39 = 'RRC_Col_9 min'
        d40 = 'RRC_Col_9 std'
        d41 = 'RRC_Col_10 max'
        d42 = 'RRC_Col_10 mean'
        d43 = 'RRC_Col_10 min'
        d44 = 'RRC_Col_10 std'
        d45 = 'RRC_Col_11 max'
        d46 = 'RRC_Col_11 mean'
        d47 = 'RRC_Col_11 min'
        d48 = 'RRC_Col_11 std'
        d49 = 'RRC_ADDR_CRC'

        figTitle = 'SM_Row_Rom_Address_Columns_Expanded'
        ylabel = 'DN'
        ylabel2 = 'CRC Val'
        numDataCols = 50  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):
                if x != 49:
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
                elif x == 49:  # CRC
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):
                if x != 49:
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
                elif x == 49:  # CRC
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_Row_Rom_Address_Columns_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:

        # Column Names in CSV
        d1 = 'RRC_Col_0 max'
        d2 = 'RRC_Col_0 mean'
        d3 = 'RRC_Col_0 min'
        d4 = 'RRC_Col_0 std'
        d5 = 'RRC_Col_1 max'
        d7 = 'RRC_Col_1 min'
        d6 = 'RRC_Col_1 mean'
        d8 = 'RRC_Col_1 std'
        d9 = 'RRC_Col_2 max'
        d10 = 'RRC_Col_2 mean'
        d11 = 'RRC_Col_2 min'
        d12 = 'RRC_Col_2 std'
        d13 = 'RRC_Col_3 max'
        d14 = 'RRC_Col_3 mean'
        d15 = 'RRC_Col_3 min'
        d16 = 'RRC_Col_3 std'
        d17 = 'RRC_Col_4 max'
        d18 = 'RRC_Col_4 mean'
        d19 = 'RRC_Col_4 min'
        d20 = 'RRC_Col_4 std'
        d21 = 'RRC_Col_5 max'
        d22 = 'RRC_Col_5 mean'
        d23 = 'RRC_Col_5 min'
        d24 = 'RRC_Col_5 std'
        d25 = 'RRC_Col_6 max'
        d26 = 'RRC_Col_6 mean'
        d27 = 'RRC_Col_6 min'
        d28 = 'RRC_Col_6 std'
        d29 = 'RRC_Col_7 max'
        d30 = 'RRC_Col_7 mean'
        d31 = 'RRC_Col_7 min'
        d32 = 'RRC_Col_7 std'
        d33 = 'RRC_Col_8 max'
        d34 = 'RRC_Col_8 mean'
        d35 = 'RRC_Col_8 min'
        d36 = 'RRC_Col_8 std'
        d37 = 'RRC_Col_9 max'
        d38 = 'RRC_Col_9 mean'
        d39 = 'RRC_Col_9 min'
        d40 = 'RRC_Col_9 std'
        d41 = 'RRC_Col_10 max'
        d42 = 'RRC_Col_10 mean'
        d43 = 'RRC_Col_10 min'
        d44 = 'RRC_Col_10 std'
        d45 = 'RRC_Col_11 max'
        d46 = 'RRC_Col_11 mean'
        d47 = 'RRC_Col_11 min'
        d48 = 'RRC_Col_11 std'
        d49 = 'RRC_ADDR_CRC'

        figTitle = 'SM_Row_Rom_Address_Columns'
        ylabel = 'DN'
        ylabel2 = 'CRC Val'
        numDataCols = 50  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None: # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols, 4):  # 1 to numcols by 4
                if x != 49:
                    n1 = eval("d" + str(x))
                    n2 = eval("d" + str(x + 1))
                    n3 = eval("d" + str(x + 2))
                    n4 = eval("d" + str(x + 3))
                    dname1 = n1.split()
                    dname2 = n2.split()
                    dname3 = n3.split()
                    dname4 = n4.split()
                    fcp.plot(df, x='Step',
                             y=[eval("d" + str(x)), eval("d" + str(x + 1)), eval("d" + str(x + 2)), eval("d" + str(x + 3))],
                             title=dname1[0] + ' ' + dname1[1] + ', ' + dname2[1] + ', ' + dname3[1] + ', ' + dname4[1],
                             show=showPlt, inline=showPlt, label_y=ylabel,
                             title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                             legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + eval(
                                 "d" + str(x + 2)) + '_' + eval("d" + str(x + 3)) + '_' + timestamp + '.png')
                    document.add_heading(dname1[0] + ' ' + dname1[1] + ', ' + dname2[1] + ', ' + dname3[1] + ', ' + dname4[1], level=3)
                    document.add_picture( pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + eval("d" + str(x + 2)) + '_' + eval(
                            "d" + str(x + 3)) + '_' + timestamp + '.png')  # Add figure to report
                elif x == 49:  # CRC
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols, 4):  # 1 to numcols by 4
                if x != 49:
                    n1 = eval("d" + str(x))
                    n2 = eval("d" + str(x + 1))
                    n3 = eval("d" + str(x + 2))
                    n4 = eval("d" + str(x + 3))
                    dname1 = n1.split()
                    dname2 = n2.split()
                    dname3 = n3.split()
                    dname4 = n4.split()
                    fcp.plot(df, x='Step',
                             y=[eval("d" + str(x)), eval("d" + str(x + 1)), eval("d" + str(x + 2)), eval("d" + str(x + 3))],
                             title=dname1[0] + ' ' + dname1[1] + ', ' + dname2[1] + ', ' + dname3[1] + ', ' + dname4[1],
                             legend=groupBy, show=showPlt, inline=showPlt, label_y=ylabel,
                             title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                             legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + eval(
                                 "d" + str(x + 2)) + '_' + eval("d" + str(x + 3)) + '_' + timestamp + '.png')
                    document.add_heading(dname1[0] + ' ' + dname1[1] + ', ' + dname2[1] + ', ' + dname3[1] + ', ' + dname4[1], level=3)
                    document.add_picture(
                        pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + eval("d" + str(x + 2)) + '_' + eval(
                            "d" + str(x + 3)) + '_' + timestamp + '.png')  # Add figure to report
                elif x == 49:  # CRC
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

'''
SM RRC SIC IMAGE DATA VALIDATION
'''
def SM_Row_Rom_SIC_Expanded_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'LDO_SIC_Col_1_max'
        d2 = 'LDO_SIC_Col_1_mean'
        d3 = 'LDO_SIC_Col_1_min'
        d4 = 'LDO_SIC_Col_1_std'
        d5 = 'LDO_SIC_Col_2_max'
        d6 = 'LDO_SIC_Col_2_mean'
        d7 = 'LDO_SIC_Col_2_min'
        d8 = 'LDO_SIC_Col_2_std'
        d9 = 'LDO_SIC_Col_3_max'
        d10 = 'LDO_SIC_Col_3_mean'
        d11 = 'LDO_SIC_Col_3_min'
        d12 = 'LDO_SIC_Col_3_std'
        d13 = 'LDO_SIC_Col_4_max'
        d14 = 'LDO_SIC_Col_4_mean'
        d15 = 'LDO_SIC_Col_4_min'
        d16 = 'LDO_SIC_Col_4_std'
        d17 = 'LDO_SIC_Col_5_max'
        d18 = 'LDO_SIC_Col_5_mean'
        d19 = 'LDO_SIC_Col_5_min'
        d20 = 'LDO_SIC_Col_5_std'
        d21 = 'LDO_SIC_Col_6_max'
        d22 = 'LDO_SIC_Col_6_mean'
        d23 = 'LDO_SIC_Col_6_min'
        d24 = 'LDO_SIC_Col_6_std'
        d25 = 'LDO_SIC_Col_7_max'
        d26 = 'LDO_SIC_Col_7_mean'
        d27 = 'LDO_SIC_Col_7_min'
        d28 = 'LDO_SIC_Col_7_std'
        d29 = 'LDO_SIC_Col_8_max'
        d30 = 'LDO_SIC_Col_8_mean'
        d31 = 'LDO_SIC_Col_8_min'
        d32 = 'LDO_SIC_Col_8_std'

        figTitle = 'SM_Row_Rom_SIC_Expanded'
        ylabel = 'DN'
        numDataCols = 33  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 32
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 32
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_Row_Rom_SIC_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'LDO_SIC_Col_1_max'
        d2 = 'LDO_SIC_Col_1_mean'
        d3 = 'LDO_SIC_Col_1_min'
        d4 = 'LDO_SIC_Col_1_std'
        d5 = 'LDO_SIC_Col_2_max'
        d6 = 'LDO_SIC_Col_2_mean'
        d7 = 'LDO_SIC_Col_2_min'
        d8 = 'LDO_SIC_Col_2_std'
        d9 = 'LDO_SIC_Col_3_max'
        d10 = 'LDO_SIC_Col_3_mean'
        d11 = 'LDO_SIC_Col_3_min'
        d12 = 'LDO_SIC_Col_3_std'
        d13 = 'LDO_SIC_Col_4_max'
        d14 = 'LDO_SIC_Col_4_mean'
        d15 = 'LDO_SIC_Col_4_min'
        d16 = 'LDO_SIC_Col_4_std'
        d17 = 'LDO_SIC_Col_5_max'
        d18 = 'LDO_SIC_Col_5_mean'
        d19 = 'LDO_SIC_Col_5_min'
        d20 = 'LDO_SIC_Col_5_std'
        d21 = 'LDO_SIC_Col_6_max'
        d22 = 'LDO_SIC_Col_6_mean'
        d23 = 'LDO_SIC_Col_6_min'
        d24 = 'LDO_SIC_Col_6_std'
        d25 = 'LDO_SIC_Col_7_max'
        d26 = 'LDO_SIC_Col_7_mean'
        d27 = 'LDO_SIC_Col_7_min'
        d28 = 'LDO_SIC_Col_7_std'
        d29 = 'LDO_SIC_Col_8_max'
        d30 = 'LDO_SIC_Col_8_mean'
        d31 = 'LDO_SIC_Col_8_min'
        d32 = 'LDO_SIC_Col_8_std'

        figTitle = 'SM_Row_Rom_SIC'
        ylabel = 'DN'
        numDataCols = 33  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols, 4):  # 1 to numcols by 4
                n1 = eval("d" + str(x))
                n2 = eval("d" + str(x + 1))
                n3 = eval("d" + str(x + 2))
                n4 = eval("d" + str(x + 3))
                dname1 = n1.split('_')
                dname2 = n2.split('_')
                dname3 = n3.split('_')
                dname4 = n4.split('_')
                fcp.plot(df, x='Step',
                         y=[eval("d" + str(x)), eval("d" + str(x + 1)), eval("d" + str(x + 2)), eval("d" + str(x + 3))],
                         title=dname1[0] + ' ' + dname1[1] + ' ' + dname1[2] + ', ' + dname2[2] + ', ' + dname3[2] + ', ' + dname4[2],
                         show=showPlt, inline=showPlt, label_y=ylabel,
                         title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                         legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + eval(
                             "d" + str(x + 2)) + '_' + eval("d" + str(x + 3)) + '_' + timestamp + '.png')
                document.add_heading(dname1[0] + ' ' + dname1[1] + ' ' + dname1[2] + ', ' + dname2[2] + ', ' + dname3[2] + ', ' + dname4[2], level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + eval("d" + str(x + 2)) + '_' + eval(
                        "d" + str(x + 3)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols, 4): # 1 to numcols by 4
                n1 = eval("d" + str(x))
                n2 = eval("d" + str(x + 1))
                n3 = eval("d" + str(x + 2))
                n4 = eval("d" + str(x + 3))
                dname1 = n1.split('_')
                dname2 = n2.split('_')
                dname3 = n3.split('_')
                dname4 = n4.split('_')
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1)), eval("d" + str(x + 2)), eval("d" + str(x + 3))],
                         title=dname1[0] + ' ' + dname1[1] + ' ' + dname1[2] + ', ' + dname2[2] + ', ' + dname3[2] + ', ' + dname4[2],
                         legend=groupBy, show=showPlt, inline=showPlt, label_y=ylabel,
                         title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                         legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + eval("d" + str(x + 2)) + '_' + eval("d" + str(x + 3)) + '_' + timestamp + '.png')
                document.add_heading(dname1[0] + ' ' + dname1[1] + ' ' + dname1[2] + ', ' + dname2[2] + ', ' + dname3[2] + ', ' + dname4[2], level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + eval("d" + str(x + 2)) + '_' + eval("d" + str(x + 3)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

'''
SM DTR IMAGE DATA VALIDATION
'''
def SM_Digital_Test_Rows_Expanded_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'DTR CRC Row# 1'
        d2 = 'DTR CRC Row# 2'
        d3 = 'DTR CRC Row# 3'
        d4 = 'DTR CRC Row# 4'
        d5 = 'DTR CRC Row# 5'
        d6 = 'DTR CRC Row# 6'
        d7 = 'DTR CRC Row# 7'
        d8 = 'DTR CRC Row# 8'
        d9 = 'DTR CRC'

        figTitle = 'SM_Digital_Test_Rows_Stats_Data_Expanded'
        ylabel = 'CRC Val'
        numDataCols = 10  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 9
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 9
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_Digital_Test_Rows_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'DTR CRC Row# 1'
        d2 = 'DTR CRC Row# 2'
        d3 = 'DTR CRC Row# 3'
        d4 = 'DTR CRC Row# 4'
        d5 = 'DTR CRC Row# 5'
        d6 = 'DTR CRC Row# 6'
        d7 = 'DTR CRC Row# 7'
        d8 = 'DTR CRC Row# 8'
        d9 = 'DTR CRC'

        figTitle = 'SM_Digital_Test_Rows_Stats_Data'
        ylabel = 'CRC Val'
        numDataCols = 10  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols, 8):  # 1 to 16
                if x != 9:
                    n1 = eval("d" + str(x))
                    n2 = eval("d" + str(x + 1))
                    n3 = eval("d" + str(x + 2))
                    n4 = eval("d" + str(x + 3))
                    n5 = eval("d" + str(x + 4))
                    n6 = eval("d" + str(x + 5))
                    n7 = eval("d" + str(x + 6))
                    n8 = eval("d" + str(x + 7))
                    dname1 = n1.split()
                    dname2 = n2.split()
                    dname3 = n3.split()
                    dname4 = n4.split()
                    dname5 = n5.split()
                    dname6 = n6.split()
                    dname7 = n7.split()
                    dname8 = n8.split()
                    fcp.plot(df, x='Step',
                             y=[eval("d" + str(x)), eval("d" + str(x + 1)), eval("d" + str(x + 2)), eval("d" + str(x + 3)),
                                eval("d" + str(x + 4)), eval("d" + str(x + 5)), eval("d" + str(x + 6)),
                                eval("d" + str(x + 7))],
                             title=dname1[0] + ' ' + dname1[1] + ' ' + dname1[2] + ' ' + dname1[3] + ', ' + dname2[3] + ', ' +
                                   dname3[3] + ', ' + dname4[3] + ', ' + dname5[3] + ', ' + dname6[3] + ', ' + dname7[3] + ', ' +
                                   dname8[3], show=showPlt, inline=showPlt, label_y=ylabel, title_font_size=titleFontSize,
                             label_x_font_size=xFontsize, label_y_font_size=yFontsize, legend_font_size=legFontSize,
                             legend_marker_size=legFontSize, **kwargs,
                             filename=pltPath + dname1[0] + '_' + dname1[1] + '_' + dname1[2] + '_' + dname1[3] + '_' + dname2[3] + '_' +
                                   dname3[3] + '_' + dname4[3] + '_' + dname5[3] + '_' + dname6[3] + '_' + dname7[3] + '_' + dname8[3] + '_' +
                                   timestamp + '.png')
                    document.add_heading(dname1[0] + ' ' + dname1[1] + ' ' + dname1[2] + ' ' + dname1[3] + ', ' + dname2[3] + ', ' +
                                   dname3[3] + ', ' + dname4[3] + ', ' + dname5[3] + ', ' + dname6[3] + ', ' + dname7[3] + ', ' +
                                   dname8[3], level=3)
                    document.add_picture(pltPath + dname1[0] + '_' + dname1[1] + '_' + dname1[2] + '_' + dname1[3] + '_' + dname2[3] + '_' +
                                   dname3[3] + '_' + dname4[3] + '_' + dname5[3] + '_' + dname6[3] + '_' + dname7[3] + '_' + dname8[3] + '_' +
                                   timestamp + '.png')  # Add figure to report
                elif x == 9:  # DTR CRC
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols, 8):  # 1 to 16
                if x != 9:
                    n1 = eval("d" + str(x))
                    n2 = eval("d" + str(x + 1))
                    n3 = eval("d" + str(x + 2))
                    n4 = eval("d" + str(x + 3))
                    n5 = eval("d" + str(x + 4))
                    n6 = eval("d" + str(x + 5))
                    n7 = eval("d" + str(x + 6))
                    n8 = eval("d" + str(x + 7))
                    dname1 = n1.split()
                    dname2 = n2.split()
                    dname3 = n3.split()
                    dname4 = n4.split()
                    dname5 = n5.split()
                    dname6 = n6.split()
                    dname7 = n7.split()
                    dname8 = n8.split()
                    fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1)), eval("d" + str(x + 2)), eval("d" + str(x + 3)),
                                eval("d" + str(x + 4)), eval("d" + str(x + 5)), eval("d" + str(x + 6)), eval("d" + str(x + 7))],
                             title=dname1[0] + ' ' + dname1[1] + ' ' + dname1[2] + ' ' + dname1[3] + ', ' + dname2[3] + ', ' +
                                   dname3[3] + ', ' + dname4[3] + ', ' + dname5[3] + ', ' + dname6[3] + ', ' + dname7[3] + ', ' +
                                   dname8[3], legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + dname1[0] + '_' + dname1[1] + '_' + dname1[2] + '_' + dname1[3] + '_' + dname2[3] + '_' +
                                   dname3[3] + '_' + dname4[3] + '_' + dname5[3] + '_' + dname6[3] + '_' + dname7[3] + '_' + dname8[3] + '_' +
                                   timestamp + '.png')
                    document.add_heading(dname1[0] + ' ' + dname1[1] + ' ' + dname1[2] + ' ' + dname1[3] + ', ' + dname2[3] + ', ' +
                                   dname3[3] + ', ' + dname4[3] + ', ' + dname5[3] + ', ' + dname6[3] + ', ' + dname7[3] + ', ' +
                                   dname8[3], level=3)
                    document.add_picture(pltPath + dname1[0] + '_' + dname1[1] + '_' + dname1[2] + '_' + dname1[3] + '_' + dname2[3] + '_' +
                                   dname3[3] + '_' + dname4[3] + '_' + dname5[3] + '_' + dname6[3] + '_' + dname7[3] + '_' + dname8[3] + '_' +
                                   timestamp + '.png')# Add figure to report
                elif x == 9:  # DTR CRC
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found


'''
ASIL SAFE STATE
'''
def SM_Safe_State(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'LOW_POWER_CONTROL'
        d2 = 'SAFE_STATE_RESET_REGISTER'

        figTitle = 'SM_Safe_State'
        ylabel = 'RegVal (Dec)'
        numDataCols = 3  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_Safe_State_Power_Consumption_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'SafeState_P_VAA(mW)'
        d2 = 'SafeState_P_VAA_PIX(mW)'
        d3 = 'SafeState_P_VDD(mW)'
        d4 = 'SafeState_P_VAA1V8(mW)'
        d5 = 'SafeState_P_VAA2V8(mW)'
        d6 = 'SafeState_P_VDD_IO(mW)'
        d7 = 'SafeState_P_VDDIO_PHY(mW)'
        d8 = 'SafeState_P_TOTAL(mW)'

        figTitle = 'SM_Safe_State_Power_Consumption'
        ylabel = 'Power (mW)'
        numDataCols = 9  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_Safe_State_Current_Consumption_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'SafeState_I_VAA(mA)'
        d2 = 'SafeState_I_VAA_PIX(mA)'
        d3 = 'SafeState_I_VDD(mA)'
        d4 = 'SafeState_I_VAA1V8(mA)'
        d5 = 'SafeState_I_VAA2V8(mA)'
        d6 = 'SafeState_I_VDD_IO(mA)'
        d7 = 'SafeState_I_VDDIO_PHY(mA)'
        d8 = 'SafeState_I_TOTAL(mA)'

        figTitle = 'SM_Safe_State_Current_Consumption'
        ylabel = 'Current (mA)'
        numDataCols = 9  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found


'''
ASIL MEMORY & ECC Test
'''
def SM_Fault_Memory_Test_1_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ODP_CRC_FAULT_CONTROL'
        d2 = 'ODP_CRC_FAULT_FRAMES'
        d3 = 'ODP_CRC_FAULTS_PER_FRAME'
        d4 = 'LFM2_CRC_FAULT_CONTROL'
        d5 = 'LFM2_CRC_FAULT_FRAMES'
        d6 = 'LFM2_CRC_FAULTS_PER_FRAME'
        d7 = 'DCDS_CRC_FAULT_CONTROL_TOP'
        d8 = 'DCDS_CRC_FAULT_FRAMES_TOP'
        d9 = 'DCDS_CRC_FAULTS_PER_FRAME_TOP'
        d10 = 'DCDS_CRC_FAULT_CONTROL_BTM'
        d11 = 'DCDS_CRC_FAULT_FRAMES_BTM'
        d12 = 'DCDS_CRC_FAULTS_PER_FRAME_BTM'
        d13 = 'CONV_CRC_FAULT_CONTROL'
        d14 = 'CONV_CRC_FAULT_FRAMES'
        d15 = 'CONV_CRC_FAULTS_PER_FRAME'
        d16 = 'MEC_CRC_FAULT_CONTROL'
        d17 = 'MEC_CRC_FAULT_FRAMES'
        d18 = 'MEC_CRC_FAULTS_PER_FRAME'
        d19 = 'FOR_CRC_FAULT_CONTROL'
        d20 = 'FOT_CRC_FAULTS_PER_FRAME'
        d21 = 'FOR_CRC_FAULT_FRAMES'
        d22 = 'T1_SM_STATUS'
        d23 = 'T4_SM_STATUS'
        d24 = 'T4_SM_PDC_FULL_CRC'
        d25 = 'T4_SM_PDC_DTR_CRC'
        d26 = 'ASIL_PIN_ENABLES_00'
        d27 = 'ASIL_CHECK_ENABLES_00'
        d28 = 'ASIL_STATUS_00'
        d29 = 'ASIL_STATUS_03'
        d30 = 'ASIL_STATUS_03__DELAY_BUFFER_CRC_FAULT'
        d31 = 'ASIL_STATUS_03__MC_MEMORY_CRC_FAULT'
        d32 = 'ASIL_STATUS_03__LFM2_MEMORY_CRC_FAULT'
        d33 = 'ASIL_STATUS_03__DCDS_TOP_MEMORY_CRC_FAULT'
        d34 = 'ASIL_STATUS_03__DCDS_BTM_MEMORY_CRC_FAULT'
        d35 = 'ASIL_STATUS_03__CONV_MEMORY_CRC_FAULT'
        d36 = 'ASIL_STATUS_03__ODP_MEMORY_CRC_FAULT'
        d37 = 'ASIL_STATUS_03__MEC_MEMORY_CRC_FAULT'
        d38 = 'ASIL_STATUS_03__DEFRAMER_FAULT'

        figTitle = 'SM_Fault_Memory_Test_1'
        ylabel = 'RegVal (Dec)'
        numDataCols = 39  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_Fault_Memory_Test_2_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'TEST_PATTERN_MODE_'
        d2 = 'DELAY_BUFFER_CRC_FAULT_CONTROL'
        d3 = 'DELAY_BUFFER_CRC_FAULT_FRAMES'
        d4 = 'DELAY_BUFFER_CRC_FAULTS_PER_FRAME'
        d5 = 'ASIL_STATUS_03'
        d6 = 'ASIL_STATUS_03__DELAY_BUFFER_CRC_FAULT'
        d7 = 'ASIL_STATUS_03__MC_MEMORY_CRC_FAULT'
        d8 = 'ASIL_STATUS_03__LFM2_MEMORY_CRC_FAULT'
        d9 = 'ASIL_STATUS_03__DCDS_TOP_MEMORY_CRC_FAULT'
        d10 = 'ASIL_STATUS_03__DCDS_BTM_MEMORY_CRC_FAULT'
        d11 = 'ASIL_STATUS_03__CONV_MEMORY_CRC_FAULT'
        d12 = 'ASIL_STATUS_03__ODP_MEMORY_CRC_FAULT'
        d13 = 'ASIL_STATUS_03__MEC_MEMORY_CRC_FAULT'
        d14 = 'ASIL_STATUS_03__DEFRAMER_FAULT'

        figTitle = 'SM_Fault_Memory_Test_2'
        ylabel = 'RegVal (Dec)'
        numDataCols = 15  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SM_Memory_CRC_Test_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ASIL_PIN_ENABLES_00'
        d2 = 'ASIL_CHECK_ENABLES_00'
        d3 = 'ASIL_PIN_ENABLES_02'
        d4 = 'ASIL_CHECK_ENABLES_02'
        d5 = 'ASIL_PIN_ENABLES_04'
        d6 = 'ASIL_CHECK_ENABLES_04'
        d7 = 'ASIL_STATUS_00'
        d8 = 'ASIL_STATUS_03'
        d9 = 'ASIL_STATUS_02'
        d10 = 'ASIL_STATUS_04'
        d11 = 'ASIL_CHECK_ENABLES_02_DBLC_RAM_ECC_DED_ENABLE'
        d12 = 'ASIL_CHECK_ENABLES_02__DBLC_RAM_ECC_SEC_ENABLE'
        d13 = 'ASIL_CHECK_ENABLES_02__DBLC_STATE_PARITY_ENABLE'
        d14 = 'ASIL_STATUS_02__DBLC_RAM_ECC_DED_STATUS'
        d15 = 'ASIL_STATUS_02__DBLC_RAM_ECC_SEC_STATUS'
        d16 = 'ASIL_STATUS_02__DBLC_STATE_PARITY_STATUS'
        d17 = 'ASIL_STATUS_02__TPG_RAM_ECC_SEC'
        d18 = 'ASIL_STATUS_02__TPG_RAM_ECC_DED'
        d19 = 'ASIL_STATUS_02__AUX_SEQUENCER_ECC_STATUS'
        d20 = 'ASIL_STATUS_04__CTX_RAM_SEC'
        d21 = 'ASIL_STATUS_04__CTX_RAM_DED'
        d22 = 'LFM2_CRC_FAULT_CONTROL'
        d23 = 'LFM2_CRC_FAULT_FRAMES'
        d24 = 'LFM2_CRC_FAULTS_PER_FRAME'
        d25 = 'ASIL_STATUS_03__LFM2_MEMORY_CRC_FAULT'
        d26 = 'DELAY_BUFFER_CRC_FAULT_CONTROL'
        d27 = 'DELAY_BUFFER_CRC_FAULT_FRAMES'
        d28 = 'DELAY_BUFFER_CRC_FAULTS_PER_FRAME'
        d29 = 'ASIL_STATUS_03__DELAY_BUFFER_CRC_FAULT'
        d30 = 'T1_SM_STATUS'
        d31 = 'T4_SM_STATUS'
        d32 = 'ASIL_STATUS_04__STATS1_RAM_SEC'
        d33 = 'ASIL_STATUS_04__STATS1_RAM_DED'
        d34 = 'ASIL_STATUS_04__STATS2_RAM_SEC'
        d35 = 'ASIL_STATUS_04__STATS2_RAM_DED'
        d36 = 'ASIL_STATUS_04__STATS3_RAM_SEC'
        d37 = 'ASIL_STATUS_04__STATS3_RAM_DED'
        d38 = 'ASIL_STATUS_04__STATS4_RAM_SEC'
        d39 = 'ASIL_STATUS_04__STATS4_RAM_DED'
        d40 = 'ASIL_STATUS_04__STATS5_RAM_SEC'
        d41 = 'ASIL_STATUS_04__STATS5_RAM_DED'
        d42 = 'ASIL_STATUS_04__STATS6_RAM_SEC'
        d43 = 'ASIL_STATUS_04__STATS6_RAM_DED'
        d44 = 'MEC_CRC_FAULT_CONTROL'
        d45 = 'MEC_CRC_FAULT_FRAMES'
        d46 = 'MEC_CRC_FAULTS_PER_FRAME'
        d47 = 'ASIL_STATUS_03__MEC_MEMORY_CRC_FAULT'
        d48 = 'ODP_CRC_FAULT_CONTROL'
        d49 = 'ODP_CRC_FAULT_FRAMES'
        d50 = 'ODP_CRC_FAULTS_PER_FRAME'
        d51 = 'ASIL_STATUS_03__ODP_MEMORY_CRC_FAULT'
        d52 = 'FOR_CRC_FAULT_CONTROL'
        d53 = 'FOT_CRC_FAULTS_PER_FRAME'
        d54 = 'FOR_CRC_FAULT_FRAMES'
        d55 = 'CONV_CRC_FAULT_CONTROL'
        d56 = 'CONV_CRC_FAULT_FRAMES'
        d57 = 'CONV_CRC_FAULTS_PER_FRAME'
        d58 = 'ASIL_STATUS_03__CONV_MEMORY_CRC_FAULT'
        d59 = 'DCDS_CRC_FAULT_CONTROL_TOP'
        d60 = 'DCDS_CRC_FAULT_FRAMES_TOP'
        d61 = 'DCDS_CRC_FAULTS_PER_FRAME_TOP'
        d62 = 'ASIL_STATUS_03__DCDS_TOP_MEMORY_CRC_FAULT'
        d63 = 'DCDS_CRC_FAULT_CONTROL_BTM'
        d64 = 'DCDS_CRC_FAULT_FRAMES_BTM'
        d65 = 'DCDS_CRC_FAULTS_PER_FRAME_BTM'
        d66 = 'ASIL_STATUS_03__DCDS_BTM_MEMORY_CRC_FAULT'
        d67 = 'ASIL_STATUS_02__ADDRESS_SM_CRC_STATUS'

        figTitle = 'SM_Memory_CRC_Test'
        ylabel = 'RegVal (Dec)'
        numDataCols = 68  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found


'''
ASIL RUNTIME
'''
def AR1212_SM_Runtime_Plot_Old(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ATR_CHECK_CONTROL'
        d2 = 'LINE_LENGTH_PCK_'
        d3 = 'SMIA_TEST'
        d4 = 'READ_MODE'
        d5 = 'TEST_ASIL_ROWS'
        d6 = 'DARK_CONTROL'
        d7 = 'DBLC_CONTROL'
        d8 = 'LFM2_T1_DBLC_TILT_ATR_CTRL'
        d9 = 'ASIL_EXT_CLK_COUNT_MSB_EXPECT'
        d10 = 'ASIL_EXT_CLK_COUNT_LSB_EXPECT'
        d11 = 'ASIL_CLK_PIX_COUNT_MSB_EXPECT'
        d12 = 'ASIL_CLK_PIX_COUNT_LSB_EXPECT'
        d13 = 'ASIL_CLK_OP_COUNT_MSB_EXPECT'
        d14 = 'ASIL_CLK_OP_COUNT_LSB_EXPECT'
        d15 = 'ASIL_CLK_REG_COUNT_MSB_EXPECT'
        d16 = 'ASIL_CLK_REG_COUNT_LSB_EXPECT'
        d17 = 'ASIL_CLK_PIX_COUNT_100_EXT_EXPECT'
        d18 = 'ASIL_CLK_OP_COUNT_100_EXT_EXPECT'
        d19 = 'ASIL_CLK_REG_COUNT_100_EXT_EXPECT'
        d20 = 'ASIL_EXT_CLK_COUNT_MSB'
        d21 = 'ASIL_EXT_CLK_COUNT_LSB'
        d22 = 'ASIL_CLK_PIX_COUNT_MSB'
        d23 = 'ASIL_CLK_PIX_COUNT_LSB'
        d24 = 'ASIL_CLK_OP_COUNT_MSB'
        d25 = 'ASIL_CLK_OP_COUNT_LSB'
        d26 = 'ASIL_CLK_REG_COUNT_MSB'
        d27 = 'ASIL_CLK_REG_COUNT_LSB'
        d28 = 'ASIL_CLK_PIX_COUNT_100_EXT'
        d29 = 'ASIL_CLK_OP_COUNT_100_EXT'
        d30 = 'ASIL_CLK_REG_COUNT_100_EXT'
        d31 = 'ASIL_ASIC_EXT_CLK_COUNT_MSB'
        d32 = 'ASIL_ASIC_EXT_CLK_COUNT_LSB'
        d33 = 'ASIL_ASIC_CLK_PIX_COUNT_MSB'
        d34 = 'ASIL_ASIC_CLK_PIX_COUNT_LSB'
        d35 = 'ASIL_ASIC_CLK_OP_COUNT_MSB'
        d36 = 'ASIL_ASIC_CLK_OP_COUNT_LSB'
        d37 = 'ASIL_ASIC_CLK_REG_COUNT_MSB'
        d38 = 'ASIL_ASIC_CLK_REG_COUNT_LSB'
        d39 = 'ASIL_ASIC_CLK_PIX_COUNT_100_EXT'
        d40 = 'ASIL_ASIC_CLK_OP_COUNT_100_EXT'
        d41 = 'ASIL_ASIC_CLK_REG_COUNT_100_EXT'
        d42 = 'TEMPSENS1_CTRL_REG'
        d43 = 'TEMPVSENS1_TMG_CTRL'
        d44 = 'TEMPVSENS1_FLAG_CTRL'
        d45 = 'TEMPVSENS1_EN_CTRL'
        d46 = 'TEMPVSENS1_TMG_CTRL_K0'
        d47 = 'TEMPVSENS1_TMG_CTRL_K1'
        d48 = 'TEMPVSENS1_STATUS'
        d49 = 'TEMPVSENS0_BOOST_MEAS_0'
        d50 = 'TEMPVSENS0_BOOST_MEAS_1'
        d51 = 'TEMPVSENS0_BOOST_MEAS_2'
        d52 = 'TEMPVSENS0_BOOST_MEAS_3'
        d53 = 'TEMPVSENS0_BOOST_MEAS_4'
        d54 = 'TEMPVSENS0_BOOST_MEAS_5'
        d55 = 'TEMPVSENS0_BOOST_MEAS_6'
        d56 = 'TEMPVSENS0_BOOST_MEAS_7'
        d57 = 'TEMPVSENS0_BOOST_MEAS_8'
        d58 = 'TEMPVSENS0_BOOST_MEAS_9'
        d59 = 'TEMPVSENS0_BOOST_MEAS_10'
        d60 = 'TEMPVSENS0_BOOST_MEAS_11'
        d61 = 'TEMPVSENS0_BOOST_MEAS_12'
        d62 = 'TEMPVSENS0_BOOST_MEAS_13'
        d63 = 'TEMPVSENS0_BOOST_MEAS_14'
        d64 = 'TEMPVSENS0_BOOST_MEAS_15'
        d65 = 'TEMPVSENS0_BOOST_MEAS_16'
        d66 = 'TEMPVSENS0_BOOST_MEAS_17'
        d67 = 'DAC_LD_34_35'
        d68 = 'ATR_CHECK_CRT_CRC_VALUE'
        d69 = 'ATR_CHECK_CRT_CRC_EXPECT'
        d70 = 'ATR_CHECK_MT_EXPECT_ADCL'
        d71 = 'ATR_CHECK_MT_EXPECT_DCDS'
        d72 = 'ATR_CHECK_MT_EXPECT1'
        d73 = 'ATR_CHECK_MT_EXPECT2'
        d74 = 'ATR_CHECK_MT_EXPECT_B'
        d75 = 'ATR_CHECK_MT_EXPECT_W'
        d76 = 'ATR_CHECK_OT1_HI_THRESH'
        d77 = 'ATR_CHECK_OT1_LO_THRESH'
        d78 = 'ATR_CHECK_OT2_HI_THRESH'
        d79 = 'ATR_CHECK_OT2_LO_THRESH'
        d80 = 'ATR_CHECK_OT3_HI_THRESH'
        d81 = 'ATR_CHECK_OT3_LO_THRESH'
        d82 = 'ATR_CHECK_OT4_HI_THRESH'
        d83 = 'ATR_CHECK_OT4_LO_THRESH'
        d84 = 'ATR_CHECK_OT5_HI_THRESH'
        d85 = 'ATR_CHECK_OT5_LO_THRESH'
        d86 = 'ATR_CHECK_OT6_HI_THRESH'
        d87 = 'ATR_CHECK_OT6_LO_THRESH'
        d88 = 'ATR_CHECK_OT7_HI_THRESH'
        d89 = 'ATR_CHECK_OT7_LO_THRESH'
        d90 = 'ATR_CHECK_OT8_HI_THRESH'
        d91 = 'ATR_CHECK_OT8_LO_THRESH'
        d92 = 'ATR_CHECK_ZT_LO_THRESH'
        d93 = 'ATR_CHECK_ZT_HI_THRESH'
        d94 = 'TEST_CTRL'
        d95 = 'ATR_CHECK_GRD_HI_THRESH'
        d96 = 'ATR_CHECK_GRD_LO_THRESH'
        d97 = 'ATR_CHECK_PT_LO_THRESH'
        d98 = 'ATR_CHECK_PT_HI_THRESH'
        d99 = 'ATR_CHECK_MT_EXPECT_PIXOUT'
        d100 = 'ATR_CHECK_MT_EXPECT_EC_COMP'
        d101 = 'ATR_CHECK_MT_EXPECT_DCDS2'
        d102 = 'RRC_CHECK_LO_THRESH'
        d103 = 'RRC_CHECK_HI_THRESH'
        d104 = 'RRC_CHECK_ADDR_CRC_EXPECT'
        d105 = 'RRC_CHECK_ADDR_CRC_VALUE'
        d106 = 'TPG_CONTROL'
        d107 = 'TPG_STDPAT_REGION1'
        d108 = 'TPG_STDPAT_REGION2'
        d109 = 'TPG_COLOR0_GR1_HI'
        d110 = 'TPG_COLOR0_GR1_LO'
        d111 = 'TPG_COLOR0_RED_HI'
        d112 = 'TPG_COLOR0_RED_LO'
        d113 = 'TPG_COLOR0_BLU_HI'
        d114 = 'TPG_COLOR0_BLU_LO'
        d115 = 'TPG_COLOR0_GR2_HI'
        d116 = 'TPG_COLOR0_GR2_LO'
        d117 = 'TPG_COLOR1_GR1_HI'
        d118 = 'TPG_COLOR1_GR1_LO'
        d119 = 'TPG_COLOR1_RED_HI'
        d120 = 'TPG_COLOR1_RED_LO'
        d121 = 'TPG_COLOR1_BLU_HI'
        d122 = 'TPG_COLOR1_BLU_LO'
        d123 = 'TPG_COLOR1_GR2_HI'
        d124 = 'TPG_COLOR1_GR2_LO'
        d125 = 'CRC_FR_DTR_WRT_CHECKSUM_HIGH'
        d126 = 'CRC_DTR_WRT_CHECKSUM_LOW'
        d127 = 'CRC_FR_WRT_CHECKSUM_LOW'
        d128 = 'CRC_FR_DTR_CALC_CHECKSUM_HIGH'
        d129 = 'CRC_DTR_CALC_CHECKSUM_LOW'
        d130 = 'CRC_FR_CALC_CHECKSUM_LOW'
        d131 = 'SM_TEST_PAT_WIDTH'
        d132 = 'SM_TEST_RATIO_21'
        d133 = 'SM_TEST_RATIO_32'
        d134 = 'SM_TEST_RATIO_43'
        d135 = 'SM_TEST_PAT_START'
        d136 = 'SM_TEST_PAT_ST_M'
        d137 = 'SM_TEST_LIN_FACTOR'
        d138 = 'SM_TEST_CHANNEL_SHIFT'
        d139 = 'MEC_SM_ERR_COUNT_LSB'
        d140 = 'MEC_SM_ERR_COUNT_MSB'
        d141 = 'MEC_SM_ERR_HIGH_LSB'
        d142 = 'MEC_SM_ERR_HIGH_MSB'
        d143 = 'MEC_SM_ERR_LOW_LSB'
        d144 = 'MEC_SM_ERR_LOW_MSB'
        d145 = 'MEC_SM_ERR_STATUS'
        d146 = 'MASTER_FSM_REQ_CODE'
        d147 = 'MASTER_FSM_STATUS'
        d148 = 'MASTER_FSM_RSP_CODE'
        d149 = 'MASTER_FSM_FULL_STATUS_HI'
        d150 = 'MASTER_FSM_FULL_STATUS_LO'
        d151 = 'AE_STATS_CONTROL'
        d152 = 'AE_STATS_CONTROL2'
        d153 = 'AE_ROI_X_START_OFFSET'
        d154 = 'AE_ROI_Y_START_OFFSET'
        d155 = 'AE_ROI_X_SIZE'
        d156 = 'AE_ROI_Y_SIZE'
        d157 = 'AE_ROI2_X_START_OFFSET'
        d158 = 'AE_ROI2_Y_START_OFFSET'
        d159 = 'AE_ROI2_X_SIZE'
        d160 = 'AE_ROI2_Y_SIZE'
        d161 = 'AE_ROI3_X_START_OFFSET'
        d162 = 'AE_ROI3_Y_START_OFFSET'
        d163 = 'AE_ROI3_X_SIZE'
        d164 = 'AE_ROI3_Y_SIZE'
        d165 = 'AE_X1_START_OFFSET'
        d166 = 'AE_X2_START_OFFSET'
        d167 = 'AE_X3_START_OFFSET'
        d168 = 'AE_Y1_START_OFFSET'
        d169 = 'AE_Y2_START_OFFSET'
        d170 = 'AE_Y3_START_OFFSET'
        d171 = 'DELAY_BUFFER_CRC_FAULT_CONTROL'
        d172 = 'DELAY_BUFFER_CRC_FAULT_FRAMES'
        d173 = 'DELAY_BUFFER_CRC_FAULTS_PER_FRAME'
        d174 = 'ODP_CRC_FAULT_CONTROL'
        d175 = 'ODP_CRC_FAULT_FRAMES'
        d176 = 'ODP_CRC_FAULTS_PER_FRAME'
        d177 = 'LFM2_CRC_FAULT_CONTROL'
        d178 = 'LFM2_CRC_FAULT_FRAMES'
        d179 = 'LFM2_CRC_FAULTS_PER_FRAME'
        d180 = 'DCDS_CRC_FAULT_CONTROL_TOP'
        d181 = 'DCDS_CRC_FAULT_FRAMES_TOP'
        d182 = 'DCDS_CRC_FAULTS_PER_FRAME_TOP'
        d183 = 'DCDS_CRC_FAULT_CONTROL_BTM'
        d184 = 'DCDS_CRC_FAULT_FRAMES_BTM'
        d185 = 'DCDS_CRC_FAULTS_PER_FRAME_BTM'
        d186 = 'CONV_CRC_FAULT_CONTROL'
        d187 = 'CONV_CRC_FAULT_FRAMES'
        d188 = 'CONV_CRC_FAULTS_PER_FRAME'
        d189 = 'MEC_CRC_FAULT_CONTROL'
        d190 = 'MEC_CRC_FAULT_FRAMES'
        d191 = 'MEC_CRC_FAULTS_PER_FRAME'
        d192 = 'FOR_CRC_FAULT_CONTROL'
        d193 = 'FOT_CRC_FAULTS_PER_FRAME'
        d194 = 'FOR_CRC_FAULT_FRAMES'
        d195 = 'T1_SM_STATUS'
        d196 = 'T4_SM_STATUS'
        d197 = 'SENSOR_HISPI_TIMING'
        d198 = 'DEFRAMER_CTRL2'
        d199 = 'DEFRAMER_FAULT_CTRL'
        d200 = 'DEFRAMER_ERROR_STATUS'
        d201 = 'CRC_EMB_WRT_CHECKSUM'
        d202 = 'CRC_EMB_CALC_CHECKSUM'
        d203 = 'STATC_ERR_EN'
        d204 = 'STATC_ERR'
        d205 = 'DTEST_26_27'
        d206 = 'FINE_INT_ERR'
        d207 = 'I2C_WRT_CHECKSUM'
        d208 = 'I2C_RD_CHECKSUM'
        d209 = 'GPI_STATUS'
        d210 = 'LOCK_CONTROL'
        d211 = 'MIPI_CONFIG_STATUS'
        d212 = 'FRAME_COUNT2_'
        d213 = 'FRAME_COUNT_'
        d214 = 'FUSE_PIXEL_DEFECT_COUNT'
        d215 = 'HISPI_CONTROL'
        d216 = 'HISPI_STATUS'
        d217 = 'HISPI_CRC_0'
        d218 = 'ASIL_PIN_ENABLES_00'
        d219 = 'ASIL_PIN_ENABLES_01'
        d220 = 'ASIL_PIN_ENABLES_02'
        d221 = 'ASIL_PIN_ENABLES_04'
        d222 = 'ASIL_PIN_ENABLES_05'
        d223 = 'ASIL_PIN_ENABLES_06'
        d224 = 'ASIL_PIN_ENABLES_09'
        d225 = 'ASIL_CHECK_ENABLES_00'
        d226 = 'ASIL_CHECK_ENABLES_01'
        d227 = 'ASIL_CHECK_ENABLES_02'
        d228 = 'ASIL_CHECK_ENABLES_04'
        d229 = 'ASIL_CHECK_ENABLES_05'
        d230 = 'ASIL_CHECK_ENABLES_06'
        d231 = 'ASIL_CHECK_ENABLES_09'
        d232 = 'ASIL_STATUS_00'
        d233 = 'ASIL_STATUS_00__ASIL_STATUS_DATA_FORMAT_ERROR'
        d234 = 'ASIL_STATUS_00__ASIL_STATUS_BO_1V2_PARAM'
        d235 = 'ASIL_STATUS_00__ASIL_STATUS_BO_1V8_PARAM'
        d236 = 'ASIL_STATUS_00__ASIL_STATUS_BO_2V8_PARAM'
        d237 = 'ASIL_STATUS_00__ASIL_STATUS_EXT_CLK_PARAM'
        d238 = 'ASIL_STATUS_00__ASIL_STATUS_CLK_PIX_PARAM'
        d239 = 'ASIL_STATUS_00__ASIL_STATUS_CLK_OP_PARAM'
        d240 = 'ASIL_STATUS_00__ASIL_STATUS_CLK_REG_PARAM'
        d241 = 'ASIL_STATUS_00__ASIL_STATUS_CLK_PIX_100_PARAM'
        d242 = 'ASIL_STATUS_00__ASIL_STATUS_CLK_OP_100_PARAM'
        d243 = 'ASIL_STATUS_00__ASIL_STATUS_CLK_REG_100_PARAM'
        d244 = 'ASIL_STATUS_01'
        d245 = 'ASIL_STATUS_01__FAIL_CRT'
        d246 = 'ASIL_STATUS_01__FAIL_OT1_PIXEL_LOW'
        d247 = 'ASIL_STATUS_01__FAIL_OT1_PIXEL_HIGH'
        d248 = 'ASIL_STATUS_01__FAIL_OT2_PIXEL_LOW'
        d249 = 'ASIL_STATUS_01__FAIL_OT2_PIXEL_HIGH'
        d250 = 'ASIL_STATUS_01__FAIL_ZEBRA_AB_PIXEL_LEGAL'
        d251 = 'ASIL_STATUS_01__FAIL_ZEBRA_AB_PIXEL_CORRECT'
        d252 = 'ASIL_STATUS_01__FAIL_ZEBRA_BA_PIXEL_LEGAL'
        d253 = 'ASIL_STATUS_01__FAIL_ZEBRA_BA_PIXEL_CORRECT'
        d254 = 'ASIL_STATUS_01__FAIL_PT1_BELOW_THRESHOLD'
        d255 = 'ASIL_STATUS_01__FAIL_PT2_ABOVE_THRESHOLD'
        d256 = 'ASIL_STATUS_01__FAIL_RRC_PIXEL_LEGAL'
        d257 = 'ASIL_STATUS_01__FAIL_RRC_ADDRESS'
        d258 = 'ASIL_STATUS_01__FAIL_RRC_DCG'
        d259 = 'ASIL_STATUS_02'
        d260 = 'ASIL_STATUS_02__AUX_SEQUENCER_ECC_STATUS'
        d261 = 'ASIL_STATUS_02__ASIL_STATUS_RRC_AB1'
        d262 = 'ASIL_STATUS_02__ASIL_STATUS_RRC_TX1'
        d263 = 'ASIL_STATUS_02__DBLC_RAM_ECC_DED_STATUS'
        d264 = 'ASIL_STATUS_02__DBLC_RAM_ECC_SEC_STATUS'
        d265 = 'ASIL_STATUS_02__DBLC_STATE_PARITY_STATUS'
        d266 = 'ASIL_STATUS_02__TPG_RAM_ECC_SEC'
        d267 = 'ASIL_STATUS_02__TPG_RAM_ECC_DED'
        d268 = 'ASIL_STATUS_02__ADDRESS_SM_CRC_STATUS'
        d269 = 'ASIL_STATUS_02__SEQUENCER_ECC_STATUS'
        d270 = 'ASIL_STATUS_02__DTR_CRC_STATUS'
        d271 = 'ASIL_STATUS_02__ROW_FRAME_CRC_STATUS'
        d272 = 'ASIL_STATUS_03'
        d273 = 'ASIL_STATUS_03__DELAY_BUFFER_CRC_FAULT'
        d274 = 'ASIL_STATUS_03__MC_MEMORY_CRC_FAULT'
        d275 = 'ASIL_STATUS_03__LFM2_MEMORY_CRC_FAULT'
        d276 = 'ASIL_STATUS_03__DCDS_TOP_MEMORY_CRC_FAULT'
        d277 = 'ASIL_STATUS_03__DCDS_BTM_MEMORY_CRC_FAULT'
        d278 = 'ASIL_STATUS_03__CONV_MEMORY_CRC_FAULT'
        d279 = 'ASIL_STATUS_03__ODP_MEMORY_CRC_FAULT'
        d280 = 'ASIL_STATUS_03__MEC_MEMORY_CRC_FAULT'
        d281 = 'ASIL_STATUS_03__DEFRAMER_FAULT'
        d282 = 'ASIL_STATUS_04'
        d283 = 'ASIL_STATUS_04__STATS1_RAM_SEC'
        d284 = 'ASIL_STATUS_04__STATS1_RAM_DED'
        d285 = 'ASIL_STATUS_04__STATS2_RAM_SEC'
        d286 = 'ASIL_STATUS_04__STATS2_RAM_DED'
        d287 = 'ASIL_STATUS_04__STATS3_RAM_SEC'
        d288 = 'ASIL_STATUS_04__STATS3_RAM_DED'
        d289 = 'ASIL_STATUS_04__STATS4_RAM_SEC'
        d290 = 'ASIL_STATUS_04__STATS4_RAM_DED'
        d291 = 'ASIL_STATUS_04__STATS5_RAM_SEC'
        d292 = 'ASIL_STATUS_04__STATS5_RAM_DED'
        d293 = 'ASIL_STATUS_04__STATS6_RAM_SEC'
        d294 = 'ASIL_STATUS_04__STATS6_RAM_DED'
        d295 = 'ASIL_STATUS_04__CTX_RAM_SEC'
        d296 = 'ASIL_STATUS_04__CTX_RAM_DED'
        d297 = 'ASIL_STATUS_05'
        d298 = 'ASIL_STATUS_05__FAIL_OT3_PIXEL_LOW'
        d299 = 'ASIL_STATUS_05__FAIL_OT3_PIXEL_HIGH'
        d300 = 'ASIL_STATUS_05__FAIL_OT4_PIXEL_LOW'
        d301 = 'ASIL_STATUS_05__FAIL_OT4_PIXEL_HIGH'
        d302 = 'ASIL_STATUS_05__FAIL_OT5_PIXEL_LOW'
        d303 = 'ASIL_STATUS_05__FAIL_OT5_PIXEL_HIGH'
        d304 = 'ASIL_STATUS_05__FAIL_GRD_PIXEL_LOW'
        d305 = 'ASIL_STATUS_05__FAIL_GRD_PIXEL_HIGH'
        d306 = 'ASIL_STATUS_06'
        d307 = 'ASIL_STATUS_06__FAIL_ADCL'
        d308 = 'ASIL_STATUS_06__FAIL_DCDS'
        d309 = 'ASIL_STATUS_06__FAIL_PIXOUT'
        d310 = 'ASIL_STATUS_06__FAIL_BW'
        d311 = 'ASIL_STATUS_06__FAIL_WB'
        d312 = 'ASIL_STATUS_06__FAIL_OT6_LOW'
        d313 = 'ASIL_STATUS_06__FAIL_OT6_HIGH'
        d314 = 'ASIL_STATUS_06__FAIL_OT7_LOW'
        d315 = 'ASIL_STATUS_06__FAIL_OT7_HIGH'
        d316 = 'ASIL_STATUS_06__FAIL_OT8_LOW'
        d317 = 'ASIL_STATUS_06__FAIL_OT8_HIGH'
        d318 = 'ASIL_STATUS_06__FAIL_EC_COMP'
        d319 = 'ASIL_STATUS_06__FAIL_DCDS2'
        d320 = 'ASIL_STATUS_09'
        d321 = 'ASIL_STATUS_09__FAIL_RRC_LEGAL_12'
        d322 = 'ASIL_STATUS_09__FAIL_RRC_LEGAL_13'
        d323 = 'ASIL_STATUS_09__FAIL_RRC_LEGAL_14'
        d324 = 'ASIL_STATUS_09__FAIL_RRC_LEGAL_15'
        d325 = 'ASIL_STATUS_09__FAIL_RRC_LEGAL_16'
        d326 = 'ASIL_STATUS_09__FAIL_RRC_LEGAL_17'
        d327 = 'ASIL_STATUS_09__FAIL_RRC_LEGAL_18'
        d328 = 'ASIL_STATUS_09__FAIL_RRC_LEGAL_19'
        d329 = 'ASIL_STATUS_09__FAIL_RRC_LEGAL_20'
        d330 = 'ASIL_STATUS_09__FAIL_RRC_LEGAL_21'
        d331 = 'ASIL_STATUS_09__FAIL_RRC_LEGAL_22'
        d332 = 'ASIL_STATUS_09__FAIL_RRC_LEGAL_23'
        d333 = 'SYS_CHECK_POST_RUNTIME'

        figTitle = 'SM_Runtime_Plot'
        ylabel = 'RegVal (Dec)'
        numDataCols = 334  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def AR1212_SM_Runtime_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ATR_CHECK_CONTROL'
        d2 = 'LINE_LENGTH_PCK_'
        d3 = 'SMIA_TEST'
        d4 = 'READ_MODE'
        d5 = 'TEST_ASIL_ROWS'
        d6 = 'DARK_CONTROL'
        d7 = 'DBLC_CONTROL'
        d8 = 'LFM2_T1_DBLC_TILT_ATR_CTRL'
        d9 = 'CRC_CONTROL_REG'
        d10 = 'PROCESS_DTR'
        d11 = 'ASIL_EXT_CLK_COUNT_MSB_EXPECT'
        d12 = 'ASIL_EXT_CLK_COUNT_LSB_EXPECT'
        d13 = 'ASIL_CLK_PIX_COUNT_MSB_EXPECT'
        d14 = 'ASIL_CLK_PIX_COUNT_LSB_EXPECT'
        d15 = 'ASIL_CLK_OP_COUNT_MSB_EXPECT'
        d16 = 'ASIL_CLK_OP_COUNT_LSB_EXPECT'
        d17 = 'ASIL_CLK_REG_COUNT_MSB_EXPECT'
        d18 = 'ASIL_CLK_REG_COUNT_LSB_EXPECT'
        d19 = 'ASIL_CLK_PIX_COUNT_100_EXT_EXPECT'
        d20 = 'ASIL_CLK_OP_COUNT_100_EXT_EXPECT'
        d21 = 'ASIL_CLK_REG_COUNT_100_EXT_EXPECT'
        d22 = 'ASIL_EXT_CLK_COUNT_MSB'
        d23 = 'ASIL_EXT_CLK_COUNT_LSB'
        d24 = 'ASIL_CLK_PIX_COUNT_MSB'
        d25 = 'ASIL_CLK_PIX_COUNT_LSB'
        d26 = 'ASIL_CLK_OP_COUNT_MSB'
        d27 = 'ASIL_CLK_OP_COUNT_LSB'
        d28 = 'ASIL_CLK_REG_COUNT_MSB'
        d29 = 'ASIL_CLK_REG_COUNT_LSB'
        d30 = 'ASIL_CLK_PIX_COUNT_100_EXT'
        d31 = 'ASIL_CLK_OP_COUNT_100_EXT'
        d32 = 'ASIL_CLK_REG_COUNT_100_EXT'
        d33 = 'ASIL_ASIC_EXT_CLK_COUNT_MSB'
        d34 = 'ASIL_ASIC_EXT_CLK_COUNT_LSB'
        d35 = 'ASIL_ASIC_CLK_PIX_COUNT_MSB'
        d36 = 'ASIL_ASIC_CLK_PIX_COUNT_LSB'
        d37 = 'ASIL_ASIC_CLK_OP_COUNT_MSB'
        d38 = 'ASIL_ASIC_CLK_OP_COUNT_LSB'
        d39 = 'ASIL_ASIC_CLK_REG_COUNT_MSB'
        d40 = 'ASIL_ASIC_CLK_REG_COUNT_LSB'
        d41 = 'ASIL_ASIC_CLK_PIX_COUNT_100_EXT'
        d42 = 'ASIL_ASIC_CLK_OP_COUNT_100_EXT'
        d43 = 'ASIL_ASIC_CLK_REG_COUNT_100_EXT'
        d44 = 'TEMPSENS1_CTRL_REG'
        d45 = 'TEMPVSENS1_TMG_CTRL'
        d46 = 'TEMPVSENS1_FLAG_CTRL'
        d47 = 'TEMPVSENS1_EN_CTRL'
        d48 = 'TEMPVSENS1_TMG_CTRL_K0'
        d49 = 'TEMPVSENS1_TMG_CTRL_K1'
        d50 = 'TEMPVSENS1_TMG_CTRL_K0__TEMPSENS1_RED_TEMP_CODE_K'
        d51 = 'TEMPVSENS1_TMG_CTRL_K1__TEMPSENS1_YELLOW_OFF_RED_K'
        d52 = 'TEMPVSENS1_TMG_CTRL_K1__TEMPSENS1_YELLOW_HYST_K'
        d53 = 'TEMPVSENS1_STATUS__TEMPVSENS1_YELLOW_FLAG'
        d54 = 'TEMPVSENS1_STATUS__TEMPVSENS1_RED_FLAG'
        d55 = 'TEMPVSENS1_STATUS__TEMPVSENS1_YELLOW_FLAG_GATED'
        d56 = 'TEMPVSENS1_STATUS__TEMPVSENS1_RED_FLAG_GATED'
        d57 = 'TEMPVSENS1_STATUS'
        d58 = 'TempFlag'
        d59 = 'TEMPVSENS0_BOOST_MEAS_0'
        d60 = 'TEMPVSENS0_BOOST_MEAS_1'
        d61 = 'TEMPVSENS0_BOOST_MEAS_2'
        d62 = 'TEMPVSENS0_BOOST_MEAS_3'
        d63 = 'TEMPVSENS0_BOOST_MEAS_4'
        d64 = 'TEMPVSENS0_BOOST_MEAS_5'
        d65 = 'TEMPVSENS0_BOOST_MEAS_6'
        d66 = 'TEMPVSENS0_BOOST_MEAS_7'
        d67 = 'TEMPVSENS0_BOOST_MEAS_8'
        d68 = 'TEMPVSENS0_BOOST_MEAS_9'
        d69 = 'TEMPVSENS0_BOOST_MEAS_10'
        d70 = 'TEMPVSENS0_BOOST_MEAS_11'
        d71 = 'TEMPVSENS0_BOOST_MEAS_12'
        d72 = 'TEMPVSENS0_BOOST_MEAS_13'
        d73 = 'TEMPVSENS0_BOOST_MEAS_14'
        d74 = 'TEMPVSENS0_BOOST_MEAS_15'
        d75 = 'TEMPVSENS0_BOOST_MEAS_16'
        d76 = 'TEMPVSENS0_BOOST_MEAS_17'
        d77 = 'TEMPVSENS0_BOOST_MEAS_18'
        d78 = 'TEMPVSENS0_BOOST_MEAS_19'
        d79 = 'TEMPVSENS0_BOOST_MEAS_20'
        d80 = 'TEMPVSENS0_BOOST_MEAS_21'
        d81 = 'TEMPVSENS0_BOOST_MEAS_22'
        d82 = 'TEMPVSENS0_BOOST_MEAS_23'
        d83 = 'TEMPVSENS0_BOOST_MEAS_24'
        d84 = 'TEMPVSENS0_BOOST_MEAS_25'
        d85 = 'TEMPVSENS0_BOOST_MEAS_26'
        d86 = 'TEMPVSENS0_BOOST_MEAS_27'
        d87 = 'TEMPVSENS0_BOOST_MEAS_28'
        d88 = 'TEMPVSENS0_BOOST_MEAS_29'
        d89 = 'TEMPVSENS0_BOOST_MEAS_30'
        d90 = 'TEMPVSENS0_BOOST_MEAS_31'
        d91 = 'TEMPVSENS0_BOOST_MEAS_32'
        d92 = 'TEMPVSENS0_BOOST_MEAS_33'
        d93 = 'TEMPVSENS0_BOOST_MEAS_34'
        d94 = 'TEMPVSENS0_BOOST_MEAS_35'
        d95 = 'TEMPVSENS0_BOOST_MEAS_36'
        d96 = 'TEMPVSENS0_BOOST_MEAS_37'
        d97 = 'TEMPVSENS0_BOOST_MEAS_38'
        d98 = 'TEMPVSENS0_BOOST_MEAS_39'
        d99 = 'TEMPVSENS0_BOOST_MEAS_40'
        d100 = 'TEMPVSENS0_BOOST_MEAS_41'
        d101 = 'TEMPVSENS0_BOOST_MEAS_42'
        d102 = 'TEMPVSENS0_BOOST_MEAS_43'
        d103 = 'TEMPVSENS0_BOOST_MEAS_44'
        d104 = 'TEMPVSENS0_BOOST_MEAS_45'
        d105 = 'TEMPVSENS0_BOOST_MEAS_46'
        d106 = 'TEMPVSENS0_BOOST_MEAS_47'
        d107 = 'TEMPVSENS0_BOOST_MEAS_48'
        d108 = 'VHI_BMON_0'
        d109 = 'VCONN_FDHI_BMON_1'
        d110 = 'VCONN_LGHI_BMON_2'
        d111 = 'VCONN_LGSTHI_BMON_3'
        d112 = 'VCONN_VDDHI_BMON_4'
        d113 = 'VROW_SELHI_BMON_5'
        d114 = 'VSGHI_BMON_6'
        d115 = 'VTX0HI_BMON_7'
        d116 = 'VTX1HI_BMON_8'
        d117 = 'VTX_LGHI_BMON_9'
        d118 = 'VDDHILOGICL_BMON_10'
        d119 = 'VLO_BMON_11'
        d120 = 'VCONN_FDLO_BMON_12'
        d121 = 'VCONN_LGLO_BMON_13'
        d122 = 'VCONN_LGSTLO_BMON_14'
        d123 = 'VCONN_VDDLO_BMON_15'
        d124 = 'VSGLO_BMON_16'
        d125 = 'VTX0LO_BMON_17'
        d126 = 'VTX1LO_BMON_18'
        d127 = 'VTX_LGLO_BMON_19'
        d128 = 'VCONN_FDLO_SEL_BMON_20'
        d129 = 'VCONN_LGLO_SEL_BMON_21'
        d130 = 'VCONN_LGSTLO_SEL_BMON_22'
        d131 = 'VCONN_VDDLO_SEL_BMON_23'
        d132 = 'VSGLO_SEL_BMON_24'
        d133 = 'VTX0LO_SEL_BMON_25'
        d134 = 'VTX1LO_SEL_BMON_26'
        d135 = 'VTX_LGLO_SEL_BMON_27'
        d136 = 'VSSLOGIC_BMON_28'
        d137 = 'VLOPWELL_BMON_29'
        d138 = 'VSSHILOGIC_BMON_30'
        d139 = 'VCONN_LGMID_BMON_31'
        d140 = 'VTX_LGMID_BMON_32'
        d141 = 'VTX1MID_BMON_33'
        d142 = 'VAA_BMON_34'
        d143 = 'VAAPIX_BMON_35'
        d144 = 'VDDIO_BMON_36'
        d145 = 'V1P8_BMON_37'
        d146 = 'V1P8LOGIC_BMON_38'
        d147 = 'V1P8_MIPI_BMON_39'
        d148 = 'DVDD1V2_BMON_40'
        d149 = 'DAC_LD_34_35'
        d150 = 'DAC_LD_34_35__SREG_AE_FAULT_INJECT_EN'
        d151 = 'DAC_LD_34_35__SREG_AE_FULLFRAME_EN'
        d152 = 'DAC_LD_34_35__SREG_AE_ATR_TEST'
        d153 = 'DAC_LD_34_35__SREG_AE_ATR_TEST_ROW_EN'
        d154 = 'ATR_CHECK_CRT_CRC_VALUE'
        d155 = 'ATR_CHECK_CRT_CRC_EXPECT'
        d156 = 'ATR_CHECK_MT_EXPECT_ADCL'
        d157 = 'ATR_CHECK_MT_EXPECT_DCDS'
        d158 = 'ATR_CHECK_MT_EXPECT1'
        d159 = 'ATR_CHECK_MT_EXPECT2'
        d160 = 'ATR_CHECK_MT_EXPECT_B'
        d161 = 'ATR_CHECK_MT_EXPECT_W'
        d162 = 'ATR_CHECK_OT1_HI_THRESH'
        d163 = 'ATR_CHECK_OT1_LO_THRESH'
        d164 = 'ATR_CHECK_OT2_HI_THRESH'
        d165 = 'ATR_CHECK_OT2_LO_THRESH'
        d166 = 'ATR_CHECK_OT3_HI_THRESH'
        d167 = 'ATR_CHECK_OT3_LO_THRESH'
        d168 = 'ATR_CHECK_OT4_HI_THRESH'
        d169 = 'ATR_CHECK_OT4_LO_THRESH'
        d170 = 'ATR_CHECK_OT5_HI_THRESH'
        d171 = 'ATR_CHECK_OT5_LO_THRESH'
        d172 = 'ATR_CHECK_OT6_HI_THRESH'
        d173 = 'ATR_CHECK_OT6_LO_THRESH'
        d174 = 'ATR_CHECK_OT7_HI_THRESH'
        d175 = 'ATR_CHECK_OT7_LO_THRESH'
        d176 = 'ATR_CHECK_OT8_HI_THRESH'
        d177 = 'ATR_CHECK_OT8_LO_THRESH'
        d178 = 'ATR_CHECK_ZT_LO_THRESH'
        d179 = 'ATR_CHECK_ZT_HI_THRESH'
        d180 = 'TEST_CTRL'
        d181 = 'ATR_CHECK_GRD_HI_THRESH'
        d182 = 'ATR_CHECK_GRD_LO_THRESH'
        d183 = 'ATR_CHECK_PT_LO_THRESH'
        d184 = 'ATR_CHECK_PT_HI_THRESH'
        d185 = 'ATR_CHECK_MT_EXPECT_PIXOUT'
        d186 = 'ATR_CHECK_MT_EXPECT_EC_COMP'
        d187 = 'ATR_CHECK_MT_EXPECT_DCDS2'
        d188 = 'RRC_CHECK_LO_THRESH'
        d189 = 'RRC_CHECK_HI_THRESH'
        d190 = 'RRC_CHECK_ADDR_CRC_EXPECT'
        d191 = 'RRC_CHECK_ADDR_CRC_VALUE'
        d192 = 'TPG_CONTROL'
        d193 = 'TPG_STDPAT_REGION1'
        d194 = 'TPG_STDPAT_REGION2'
        d195 = 'TPG_COLOR0_GR1_HI'
        d196 = 'TPG_COLOR0_GR1_LO'
        d197 = 'TPG_COLOR0_RED_HI'
        d198 = 'TPG_COLOR0_RED_LO'
        d199 = 'TPG_COLOR0_BLU_HI'
        d200 = 'TPG_COLOR0_BLU_LO'
        d201 = 'TPG_COLOR0_GR2_HI'
        d202 = 'TPG_COLOR0_GR2_LO'
        d203 = 'TPG_COLOR1_GR1_HI'
        d204 = 'TPG_COLOR1_GR1_LO'
        d205 = 'TPG_COLOR1_RED_HI'
        d206 = 'TPG_COLOR1_RED_LO'
        d207 = 'TPG_COLOR1_BLU_HI'
        d208 = 'TPG_COLOR1_BLU_LO'
        d209 = 'TPG_COLOR1_GR2_HI'
        d210 = 'TPG_COLOR1_GR2_LO'
        d211 = 'TPG_HDR_RATIOS'
        d212 = 'TPG_PD0_PD1_RATIOS'
        d213 = 'TPG_LFM2_RATIOS'
        d214 = 'DTR_BOUND_X0'
        d215 = 'DTR_BOUND_X1'
        d216 = 'DTR_BOUND_Y0'
        d217 = 'DTR_BOUND_Y1'
        d218 = 'CRC_FR_DTR_WRT_CHECKSUM_HIGH'
        d219 = 'CRC_FR_DTR_WRT_CHECKSUM_HIGH__CRC_FR_WRT_CHECKSUM_HIGH'
        d220 = 'CRC_FR_DTR_WRT_CHECKSUM_HIGH__CRC_DTR_WRT_CHECKSUM_HIGH'
        d221 = 'CRC_DTR_WRT_CHECKSUM_LOW'
        d222 = 'CRC_FR_WRT_CHECKSUM_LOW'
        d223 = 'CRC_FR_DTR_CALC_CHECKSUM_HIGH'
        d224 = 'CRC_FR_DTR_CALC_CHECKSUM_HIGH__CRC_FR_CALC_CHECKSUM_HIGH'
        d225 = 'CRC_FR_DTR_CALC_CHECKSUM_HIGH__CRC_DTR_CALC_CHECKSUM_HIGH'
        d226 = 'CRC_DTR_CALC_CHECKSUM_LOW'
        d227 = 'CRC_FR_CALC_CHECKSUM_LOW'
        d228 = 'LFM2_T1_E2_GAIN_CTRL_GS'
        d229 = 'LFM2_T1_E2_GAIN_CTRL_GS__LFM2_T1_E2_GAIN_M_GS'
        d230 = 'LFM2_T1_E2_GAIN_CTRL_GS__LFM2_T1_E2_GAIN_E_GS'
        d231 = 'SM_TEST_PAT_WIDTH'
        d232 = 'SM_TEST_RATIO_21'
        d233 = 'SM_TEST_RATIO_32'
        d234 = 'SM_TEST_RATIO_43'
        d235 = 'SM_TEST_PAT_START'
        d236 = 'SM_TEST_PAT_ST_M'
        d237 = 'SM_TEST_LIN_FACTOR'
        d238 = 'SM_TEST_CHANNEL_SHIFT'
        d239 = 'MEC_SM_ERR_COUNT_LSB'
        d240 = 'MEC_SM_ERR_COUNT_MSB'
        d241 = 'MEC_SM_ERR_HIGH_LSB'
        d242 = 'MEC_SM_ERR_HIGH_MSB'
        d243 = 'MEC_SM_ERR_LOW_LSB'
        d244 = 'MEC_SM_ERR_LOW_MSB'
        d245 = 'MEC_SM_ERR_STATUS'
        d246 = 'MASTER_FSM_REQ_CODE'
        d247 = 'MASTER_FSM_STATUS'
        d248 = 'MASTER_FSM_RSP_CODE'
        d249 = 'MASTER_FSM_FULL_STATUS_HI'
        d250 = 'MASTER_FSM_FULL_STATUS_LO'
        d251 = 'CRC_EMB_WRT_CHECKSUM'
        d252 = 'CRC_EMB_CALC_CHECKSUM'
        d253 = 'AE_STATS_CONTROL'
        d254 = 'AE_STATS_CONTROL2'
        d255 = 'AE_ROI_X_START_OFFSET'
        d256 = 'AE_ROI_Y_START_OFFSET'
        d257 = 'AE_ROI_X_SIZE'
        d258 = 'AE_ROI_Y_SIZE'
        d259 = 'AE_ROI2_X_START_OFFSET'
        d260 = 'AE_ROI2_Y_START_OFFSET'
        d261 = 'AE_ROI2_X_SIZE'
        d262 = 'AE_ROI2_Y_SIZE'
        d263 = 'AE_ROI3_X_START_OFFSET'
        d264 = 'AE_ROI3_Y_START_OFFSET'
        d265 = 'AE_ROI3_X_SIZE'
        d266 = 'AE_ROI3_Y_SIZE'
        d267 = 'AE_X1_START_OFFSET'
        d268 = 'AE_X2_START_OFFSET'
        d269 = 'AE_X3_START_OFFSET'
        d270 = 'AE_Y1_START_OFFSET'
        d271 = 'AE_Y2_START_OFFSET'
        d272 = 'AE_Y3_START_OFFSET'
        d273 = 'DELAY_BUFFER_CRC_FAULT_CONTROL'
        d274 = 'DELAY_BUFFER_CRC_FAULT_FRAMES'
        d275 = 'DELAY_BUFFER_CRC_FAULTS_PER_FRAME'
        d276 = 'ODP_CRC_FAULT_CONTROL'
        d277 = 'ODP_CRC_FAULT_FRAMES'
        d278 = 'ODP_CRC_FAULTS_PER_FRAME'
        d279 = 'LFM2_CRC_FAULT_CONTROL'
        d280 = 'LFM2_CRC_FAULT_FRAMES'
        d281 = 'LFM2_CRC_FAULTS_PER_FRAME'
        d282 = 'DCDS_CRC_FAULT_CONTROL_TOP'
        d283 = 'DCDS_CRC_FAULT_FRAMES_TOP'
        d284 = 'DCDS_CRC_FAULTS_PER_FRAME_TOP'
        d285 = 'DCDS_CRC_FAULT_CONTROL_BTM'
        d286 = 'DCDS_CRC_FAULT_FRAMES_BTM'
        d287 = 'DCDS_CRC_FAULTS_PER_FRAME_BTM'
        d288 = 'CONV_CRC_FAULT_CONTROL'
        d289 = 'CONV_CRC_FAULT_FRAMES'
        d290 = 'CONV_CRC_FAULTS_PER_FRAME'
        d291 = 'MEC_CRC_FAULT_CONTROL'
        d292 = 'MEC_CRC_FAULT_FRAMES'
        d293 = 'MEC_CRC_FAULTS_PER_FRAME'
        d294 = 'FOR_CRC_FAULT_CONTROL'
        d295 = 'FOT_CRC_FAULTS_PER_FRAME'
        d296 = 'FOR_CRC_FAULT_FRAMES'
        d297 = 'PIX_DEF_ID_BASE_RAM'
        d298 = 'SENSOR_RAM_D_COUNT'
        d299 = 'PIX_DEF_ID_BASE_RAM_ASIC'
        d300 = 'FUSE_PIXEL_DEFECT_COUNT'
        d301 = 'T1_SM_STATUS'
        d302 = 'T4_SM_STATUS'
        d303 = 'T1_SM_PDC_FULL_CRC'
        d304 = 'T1_SM_PDC_DTR_CRC'
        d305 = 'T2_SM_PDC_FULL_CRC'
        d306 = 'T2_SM_PDC_DTR_CRC'
        d307 = 'T3_SM_PDC_FULL_CRC'
        d308 = 'T3_SM_PDC_DTR_CRC'
        d309 = 'T4_SM_PDC_FULL_CRC'
        d310 = 'T4_SM_PDC_DTR_CRC'
        d311 = 'DEFRAMER_CTRL2'
        d312 = 'DEFRAMER_FAULT_CTRL'
        d313 = 'DEFRAMER_ERROR_STATUS'
        d314 = 'DEFRAMER_ERROR_STATUS__CRC_ERROR'
        d315 = 'STATC_ERR_EN'
        d316 = 'STATC_ERR'
        d317 = 'DTEST_26_27'
        d318 = 'I2C_WRT_CHECKSUM'
        d319 = 'I2C_RD_CHECKSUM'
        d320 = 'I2C_WRT_COUNT'
        d321 = 'GPI_STATUS'
        d322 = 'LOCK_CONTROL'
        d323 = 'MIPI_CONFIG_STATUS'
        d324 = 'FRAME_COUNT2_'
        d325 = 'FRAME_COUNT_'
        d326 = 'HISPI_CONTROL'
        d327 = 'HISPI_STATUS'
        d328 = 'HISPI_STATUS__HISPI_CHECKSUM_VALID'
        d329 = 'HISPI_CRC_0'
        d330 = 'HISPI_CRC_1'
        d331 = 'HISPI_CRC_2'
        d332 = 'HISPI_CRC_3'
        d333 = 'SENSOR_HISPI_CONTROL'
        d334 = 'SENSOR_HISPI_STATUS'
        d335 = 'SENSOR_HISPI_STATUS__SENSOR_HISPI_CHECKSUM_VALID'
        d336 = 'SENSOR_HISPI_CRC_0'
        d337 = 'SENSOR_HISPI_CRC_1'
        d338 = 'SENSOR_HISPI_CRC_2'
        d339 = 'SENSOR_HISPI_CRC_3'
        d340 = 'DATA_FORMAT_BITS'
        d341 = 'DATA_FORMAT_ACTUAL'
        d342 = 'ASIL_PIN_ENABLES_00'
        d343 = 'ASIL_PIN_ENABLES_01'
        d344 = 'ASIL_PIN_ENABLES_02'
        d345 = 'ASIL_PIN_ENABLES_04'
        d346 = 'ASIL_PIN_ENABLES_05'
        d347 = 'ASIL_PIN_ENABLES_06'
        d348 = 'ASIL_PIN_ENABLES_09'
        d349 = 'ASIL_CHECK_ENABLES_00'
        d350 = 'ASIL_CHECK_ENABLES_01'
        d351 = 'ASIL_CHECK_ENABLES_02'
        d352 = 'ASIL_CHECK_ENABLES_04'
        d353 = 'ASIL_CHECK_ENABLES_05'
        d354 = 'ASIL_CHECK_ENABLES_06'
        d355 = 'ASIL_CHECK_ENABLES_09'
        d356 = 'ASIL_STATUS_00'
        d357 = 'ASIL_STATUS_00__ASIL_STATUS_DATA_FORMAT_ERROR'
        d358 = 'ASIL_STATUS_00__ASIL_STATUS_BO_1V2_PARAM'
        d359 = 'ASIL_STATUS_00__ASIL_STATUS_BO_1V8_PARAM'
        d360 = 'ASIL_STATUS_00__ASIL_STATUS_BO_2V8_PARAM'
        d361 = 'ASIL_STATUS_00__ASIL_STATUS_EXT_CLK_PARAM'
        d362 = 'ASIL_STATUS_00__ASIL_STATUS_CLK_PIX_PARAM'
        d363 = 'ASIL_STATUS_00__ASIL_STATUS_CLK_OP_PARAM'
        d364 = 'ASIL_STATUS_00__ASIL_STATUS_CLK_REG_PARAM'
        d365 = 'ASIL_STATUS_00__ASIL_STATUS_CLK_PIX_100_PARAM'
        d366 = 'ASIL_STATUS_00__ASIL_STATUS_CLK_OP_100_PARAM'
        d367 = 'ASIL_STATUS_00__ASIL_STATUS_CLK_REG_100_PARAM'
        d368 = 'ASIL_STATUS_01'
        d369 = 'ASIL_STATUS_01__FAIL_CRT'
        d370 = 'ASIL_STATUS_01__FAIL_OT1_PIXEL_LOW'
        d371 = 'ASIL_STATUS_01__FAIL_OT1_PIXEL_HIGH'
        d372 = 'ASIL_STATUS_01__FAIL_OT2_PIXEL_LOW'
        d373 = 'ASIL_STATUS_01__FAIL_OT2_PIXEL_HIGH'
        d374 = 'ASIL_STATUS_01__FAIL_ZEBRA_AB_PIXEL_LEGAL'
        d375 = 'ASIL_STATUS_01__FAIL_ZEBRA_AB_PIXEL_CORRECT'
        d376 = 'ASIL_STATUS_01__FAIL_ZEBRA_BA_PIXEL_LEGAL'
        d377 = 'ASIL_STATUS_01__FAIL_ZEBRA_BA_PIXEL_CORRECT'
        d378 = 'ASIL_STATUS_01__FAIL_PT1_BELOW_THRESHOLD'
        d379 = 'ASIL_STATUS_01__FAIL_PT2_ABOVE_THRESHOLD'
        d380 = 'ASIL_STATUS_01__FAIL_RRC_PIXEL_LEGAL'
        d381 = 'ASIL_STATUS_01__FAIL_RRC_ADDRESS'
        d382 = 'ASIL_STATUS_01__FAIL_RRC_DCG'
        d383 = 'ASIL_STATUS_02'
        d384 = 'ASIL_STATUS_02__AUX_SEQUENCER_ECC_STATUS'
        d385 = 'ASIL_STATUS_02__ASIL_STATUS_RRC_AB1'
        d386 = 'ASIL_STATUS_02__ASIL_STATUS_RRC_TX1'
        d387 = 'ASIL_STATUS_02__DBLC_RAM_ECC_DED_STATUS'
        d388 = 'ASIL_STATUS_02__DBLC_RAM_ECC_SEC_STATUS'
        d389 = 'ASIL_STATUS_02__DBLC_STATE_PARITY_STATUS'
        d390 = 'ASIL_STATUS_02__TPG_RAM_ECC_SEC'
        d391 = 'ASIL_STATUS_02__TPG_RAM_ECC_DED'
        d392 = 'ASIL_STATUS_02__ADDRESS_SM_CRC_STATUS'
        d393 = 'ASIL_STATUS_02__SEQUENCER_ECC_STATUS'
        d394 = 'ASIL_STATUS_02__DTR_CRC_STATUS'
        d395 = 'ASIL_STATUS_02__ROW_FRAME_CRC_STATUS'
        d396 = 'ASIL_STATUS_03'
        d397 = 'ASIL_STATUS_03__DELAY_BUFFER_CRC_FAULT'
        d398 = 'ASIL_STATUS_03__MC_MEMORY_CRC_FAULT'
        d399 = 'ASIL_STATUS_03__LFM2_MEMORY_CRC_FAULT'
        d400 = 'ASIL_STATUS_03__DCDS_TOP_MEMORY_CRC_FAULT'
        d401 = 'ASIL_STATUS_03__DCDS_BTM_MEMORY_CRC_FAULT'
        d402 = 'ASIL_STATUS_03__CONV_MEMORY_CRC_FAULT'
        d403 = 'ASIL_STATUS_03__ODP_MEMORY_CRC_FAULT'
        d404 = 'ASIL_STATUS_03__MEC_MEMORY_CRC_FAULT'
        d405 = 'ASIL_STATUS_03__DEFRAMER_FAULT'
        d406 = 'ASIL_STATUS_04'
        d407 = 'ASIL_STATUS_04__STATS1_RAM_SEC'
        d408 = 'ASIL_STATUS_04__STATS1_RAM_DED'
        d409 = 'ASIL_STATUS_04__STATS2_RAM_SEC'
        d410 = 'ASIL_STATUS_04__STATS2_RAM_DED'
        d411 = 'ASIL_STATUS_04__STATS3_RAM_SEC'
        d412 = 'ASIL_STATUS_04__STATS3_RAM_DED'
        d413 = 'ASIL_STATUS_04__STATS4_RAM_SEC'
        d414 = 'ASIL_STATUS_04__STATS4_RAM_DED'
        d415 = 'ASIL_STATUS_04__STATS5_RAM_SEC'
        d416 = 'ASIL_STATUS_04__STATS5_RAM_DED'
        d417 = 'ASIL_STATUS_04__STATS6_RAM_SEC'
        d418 = 'ASIL_STATUS_04__STATS6_RAM_DED'
        d419 = 'ASIL_STATUS_04__CTX_RAM_SEC'
        d420 = 'ASIL_STATUS_04__CTX_RAM_DED'
        d421 = 'ASIL_STATUS_05'
        d422 = 'ASIL_STATUS_05__FAIL_OT3_PIXEL_LOW'
        d423 = 'ASIL_STATUS_05__FAIL_OT3_PIXEL_HIGH'
        d424 = 'ASIL_STATUS_05__FAIL_OT4_PIXEL_LOW'
        d425 = 'ASIL_STATUS_05__FAIL_OT4_PIXEL_HIGH'
        d426 = 'ASIL_STATUS_05__FAIL_OT5_PIXEL_LOW'
        d427 = 'ASIL_STATUS_05__FAIL_OT5_PIXEL_HIGH'
        d428 = 'ASIL_STATUS_05__FAIL_GRD_PIXEL_LOW'
        d429 = 'ASIL_STATUS_05__FAIL_GRD_PIXEL_HIGH'
        d430 = 'ASIL_STATUS_06'
        d431 = 'ASIL_STATUS_06__FAIL_ADCL'
        d432 = 'ASIL_STATUS_06__FAIL_DCDS'
        d433 = 'ASIL_STATUS_06__FAIL_PIXOUT'
        d434 = 'ASIL_STATUS_06__FAIL_BW'
        d435 = 'ASIL_STATUS_06__FAIL_WB'
        d436 = 'ASIL_STATUS_06__FAIL_OT6_LOW'
        d437 = 'ASIL_STATUS_06__FAIL_OT6_HIGH'
        d438 = 'ASIL_STATUS_06__FAIL_OT7_LOW'
        d439 = 'ASIL_STATUS_06__FAIL_OT7_HIGH'
        d440 = 'ASIL_STATUS_06__FAIL_OT8_LOW'
        d441 = 'ASIL_STATUS_06__FAIL_OT8_HIGH'
        d442 = 'ASIL_STATUS_06__FAIL_EC_COMP'
        d443 = 'ASIL_STATUS_06__FAIL_DCDS2'
        d444 = 'ASIL_STATUS_09'
        d445 = 'ASIL_STATUS_09__FAIL_RRC_LEGAL_12'
        d446 = 'ASIL_STATUS_09__FAIL_RRC_LEGAL_13'
        d447 = 'ASIL_STATUS_09__FAIL_RRC_LEGAL_14'
        d448 = 'ASIL_STATUS_09__FAIL_RRC_LEGAL_15'
        d449 = 'ASIL_STATUS_09__FAIL_RRC_LEGAL_16'
        d450 = 'ASIL_STATUS_09__FAIL_RRC_LEGAL_17'
        d451 = 'ASIL_STATUS_09__FAIL_RRC_LEGAL_18'
        d452 = 'ASIL_STATUS_09__FAIL_RRC_LEGAL_19'
        d453 = 'ASIL_STATUS_09__FAIL_RRC_LEGAL_20'
        d454 = 'ASIL_STATUS_09__FAIL_RRC_LEGAL_21'
        d455 = 'ASIL_STATUS_09__FAIL_RRC_LEGAL_22'
        d456 = 'ASIL_STATUS_09__FAIL_RRC_LEGAL_23'
        d457 = 'SYS_CHECK_POST_RUNTIME'

        figTitle = 'SM_Runtime_Plot'
        ylabel = 'RegVal (Dec)'
        ylabel2 = 'Level (1 = Pass, 0 = Fail)'
        numDataCols = 458  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                if x != 457:
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
                if x == 457:
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                if x != 457:
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
                if x == 457:
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def AR1212_SM_Runtime_Fault_Injection_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ATR_CHECK_CONTROL'
        d2 = 'LINE_LENGTH_PCK_'
        d3 = 'SMIA_TEST'
        d4 = 'READ_MODE'
        d5 = 'TEST_ASIL_ROWS'
        d6 = 'DARK_CONTROL'
        d7 = 'DBLC_CONTROL'
        d8 = 'LFM2_T1_DBLC_TILT_ATR_CTRL'
        d9 = 'ASIL_EXT_CLK_COUNT_MSB_EXPECT'
        d10 = 'ASIL_EXT_CLK_COUNT_LSB_EXPECT'
        d11 = 'ASIL_CLK_PIX_COUNT_MSB_EXPECT'
        d12 = 'ASIL_CLK_PIX_COUNT_LSB_EXPECT'
        d13 = 'ASIL_CLK_OP_COUNT_MSB_EXPECT'
        d14 = 'ASIL_CLK_OP_COUNT_LSB_EXPECT'
        d15 = 'ASIL_CLK_REG_COUNT_MSB_EXPECT'
        d16 = 'ASIL_CLK_REG_COUNT_LSB_EXPECT'
        d17 = 'ASIL_CLK_PIX_COUNT_100_EXT_EXPECT'
        d18 = 'ASIL_CLK_OP_COUNT_100_EXT_EXPECT'
        d19 = 'ASIL_CLK_REG_COUNT_100_EXT_EXPECT'
        d20 = 'ASIL_EXT_CLK_COUNT_MSB'
        d21 = 'ASIL_EXT_CLK_COUNT_LSB'
        d22 = 'ASIL_CLK_PIX_COUNT_MSB'
        d23 = 'ASIL_CLK_PIX_COUNT_LSB'
        d24 = 'ASIL_CLK_OP_COUNT_MSB'
        d25 = 'ASIL_CLK_OP_COUNT_LSB'
        d26 = 'ASIL_CLK_REG_COUNT_MSB'
        d27 = 'ASIL_CLK_REG_COUNT_LSB'
        d28 = 'ASIL_ASIC_EXT_CLK_COUNT_MSB'
        d29 = 'ASIL_ASIC_EXT_CLK_COUNT_LSB'
        d30 = 'ASIL_ASIC_CLK_PIX_COUNT_MSB'
        d31 = 'ASIL_ASIC_CLK_PIX_COUNT_LSB'
        d32 = 'ASIL_ASIC_CLK_OP_COUNT_MSB'
        d33 = 'ASIL_ASIC_CLK_OP_COUNT_LSB'
        d34 = 'ASIL_ASIC_CLK_REG_COUNT_MSB'
        d35 = 'ASIL_ASIC_CLK_REG_COUNT_LSB'
        d36 = 'TEMPVSENS1_STATUS'
        d37 = 'TEMPVSENS0_BOOST_MEAS_0'
        d38 = 'TEMPVSENS0_BOOST_MEAS_1'
        d39 = 'TEMPVSENS0_BOOST_MEAS_2'
        d40 = 'TEMPVSENS0_BOOST_MEAS_3'
        d41 = 'TEMPVSENS0_BOOST_MEAS_4'
        d42 = 'TEMPVSENS0_BOOST_MEAS_5'
        d43 = 'TEMPVSENS0_BOOST_MEAS_6'
        d44 = 'TEMPVSENS0_BOOST_MEAS_7'
        d45 = 'TEMPVSENS0_BOOST_MEAS_8'
        d46 = 'TEMPVSENS0_BOOST_MEAS_9'
        d47 = 'TEMPVSENS0_BOOST_MEAS_10'
        d48 = 'TEMPVSENS0_BOOST_MEAS_11'
        d49 = 'TEMPVSENS0_BOOST_MEAS_12'
        d50 = 'TEMPVSENS0_BOOST_MEAS_13'
        d51 = 'TEMPVSENS0_BOOST_MEAS_14'
        d52 = 'TEMPVSENS0_BOOST_MEAS_15'
        d53 = 'TEMPVSENS0_BOOST_MEAS_16'
        d54 = 'TEMPVSENS0_BOOST_MEAS_17'
        d55 = 'DAC_LD_34_35'
        d56 = 'ATR_CHECK_CRT_CRC_VALUE'
        d57 = 'ATR_CHECK_CRT_CRC_EXPECT'
        d58 = 'ATR_CHECK_MT_EXPECT_ADCL'
        d59 = 'ATR_CHECK_MT_EXPECT_DCDS'
        d60 = 'ATR_CHECK_MT_EXPECT1'
        d61 = 'ATR_CHECK_MT_EXPECT2'
        d62 = 'ATR_CHECK_MT_EXPECT_B'
        d63 = 'ATR_CHECK_MT_EXPECT_W'
        d64 = 'ATR_CHECK_OT1_HI_THRESH'
        d65 = 'ATR_CHECK_OT1_LO_THRESH'
        d66 = 'ATR_CHECK_OT2_HI_THRESH'
        d67 = 'ATR_CHECK_OT2_LO_THRESH'
        d68 = 'ATR_CHECK_OT3_HI_THRESH'
        d69 = 'ATR_CHECK_OT3_LO_THRESH'
        d70 = 'ATR_CHECK_OT4_HI_THRESH'
        d71 = 'ATR_CHECK_OT4_LO_THRESH'
        d72 = 'ATR_CHECK_OT5_HI_THRESH'
        d73 = 'ATR_CHECK_OT5_LO_THRESH'
        d74 = 'ATR_CHECK_OT6_HI_THRESH'
        d75 = 'ATR_CHECK_OT6_LO_THRESH'
        d76 = 'ATR_CHECK_OT7_HI_THRESH'
        d77 = 'ATR_CHECK_OT7_LO_THRESH'
        d78 = 'ATR_CHECK_OT8_HI_THRESH'
        d79 = 'ATR_CHECK_OT8_LO_THRESH'
        d80 = 'ATR_CHECK_ZT_LO_THRESH'
        d81 = 'ATR_CHECK_ZT_HI_THRESH'
        d82 = 'TEST_CTRL'
        d83 = 'ATR_CHECK_GRD_HI_THRESH'
        d84 = 'ATR_CHECK_GRD_LO_THRESH'
        d85 = 'ATR_CHECK_PT_LO_THRESH'
        d86 = 'ATR_CHECK_PT_HI_THRESH'
        d87 = 'ATR_CHECK_MT_EXPECT_PIXOUT'
        d88 = 'ATR_CHECK_MT_EXPECT_EC_COMP'
        d89 = 'ATR_CHECK_MT_EXPECT_DCDS2'
        d90 = 'RRC_CHECK_LO_THRESH'
        d91 = 'RRC_CHECK_HI_THRESH'
        d92 = 'RRC_CHECK_ADDR_CRC_EXPECT'
        d93 = 'RRC_CHECK_ADDR_CRC_VALUE'
        d94 = 'TPG_CONTROL'
        d95 = 'TPG_STDPAT_REGION1'
        d96 = 'TPG_STDPAT_REGION2'
        d97 = 'TPG_COLOR0_GR1_HI'
        d98 = 'TPG_COLOR0_GR1_LO'
        d99 = 'TPG_COLOR0_RED_HI'
        d100 = 'TPG_COLOR0_RED_LO'
        d101 = 'TPG_COLOR0_BLU_HI'
        d102 = 'TPG_COLOR0_BLU_LO'
        d103 = 'TPG_COLOR0_GR2_HI'
        d104 = 'TPG_COLOR0_GR2_LO'
        d105 = 'TPG_COLOR1_GR1_HI'
        d106 = 'TPG_COLOR1_GR1_LO'
        d107 = 'TPG_COLOR1_RED_HI'
        d108 = 'TPG_COLOR1_RED_LO'
        d109 = 'TPG_COLOR1_BLU_HI'
        d110 = 'TPG_COLOR1_BLU_LO'
        d111 = 'TPG_COLOR1_GR2_HI'
        d112 = 'TPG_COLOR1_GR2_LO'
        d113 = 'CRC_FR_DTR_WRT_CHECKSUM_HIGH'
        d114 = 'CRC_DTR_WRT_CHECKSUM_LOW'
        d115 = 'CRC_FR_WRT_CHECKSUM_LOW'
        d116 = 'CRC_FR_DTR_CALC_CHECKSUM_HIGH'
        d117 = 'CRC_DTR_CALC_CHECKSUM_LOW'
        d118 = 'CRC_FR_CALC_CHECKSUM_LOW'
        d119 = 'SM_TEST_PAT_WIDTH'
        d120 = 'SM_TEST_RATIO_21'
        d121 = 'SM_TEST_RATIO_32'
        d122 = 'SM_TEST_RATIO_43'
        d123 = 'SM_TEST_PAT_START'
        d124 = 'SM_TEST_PAT_ST_M'
        d125 = 'SM_TEST_LIN_FACTOR'
        d126 = 'MEC_SM_ERR_COUNT_LSB'
        d127 = 'MEC_SM_ERR_COUNT_MSB'
        d128 = 'MEC_SM_ERR_HIGH_LSB'
        d129 = 'MEC_SM_ERR_HIGH_MSB'
        d130 = 'MEC_SM_ERR_LOW_LSB'
        d131 = 'MEC_SM_ERR_LOW_MSB'
        d132 = 'MEC_SM_ERR_STATUS'
        d133 = 'MASTER_FSM_REQ_CODE'
        d134 = 'MASTER_FSM_STATUS'
        d135 = 'MASTER_FSM_RSP_CODE'
        d136 = 'MASTER_FSM_FULL_STATUS_HI'
        d137 = 'MASTER_FSM_FULL_STATUS_LO'
        d138 = 'AE_STATS_CONTROL'
        d139 = 'AE_STATS_CONTROL2'
        d140 = 'AE_ROI_X_START_OFFSET'
        d141 = 'AE_ROI_Y_START_OFFSET'
        d142 = 'AE_ROI_X_SIZE'
        d143 = 'AE_ROI_Y_SIZE'
        d144 = 'AE_ROI2_X_START_OFFSET'
        d145 = 'AE_ROI2_Y_START_OFFSET'
        d146 = 'AE_ROI2_X_SIZE'
        d147 = 'AE_ROI2_Y_SIZE'
        d148 = 'AE_ROI3_X_START_OFFSET'
        d149 = 'AE_ROI3_Y_START_OFFSET'
        d150 = 'AE_ROI3_X_SIZE'
        d151 = 'AE_ROI3_Y_SIZE'
        d152 = 'AE_X1_START_OFFSET'
        d153 = 'AE_X2_START_OFFSET'
        d154 = 'AE_X3_START_OFFSET'
        d155 = 'AE_Y1_START_OFFSET'
        d156 = 'AE_Y2_START_OFFSET'
        d157 = 'AE_Y3_START_OFFSET'
        d158 = 'DELAY_BUFFER_CRC_FAULT_CONTROL'
        d159 = 'DELAY_BUFFER_CRC_FAULT_FRAMES'
        d160 = 'DELAY_BUFFER_CRC_FAULTS_PER_FRAME'
        d161 = 'ODP_CRC_FAULT_CONTROL'
        d162 = 'ODP_CRC_FAULT_FRAMES'
        d163 = 'ODP_CRC_FAULTS_PER_FRAME'
        d164 = 'LFM2_CRC_FAULT_CONTROL'
        d165 = 'LFM2_CRC_FAULT_FRAMES'
        d166 = 'LFM2_CRC_FAULTS_PER_FRAME'
        d167 = 'DCDS_CRC_FAULT_CONTROL_TOP'
        d168 = 'DCDS_CRC_FAULT_FRAMES_TOP'
        d169 = 'DCDS_CRC_FAULTS_PER_FRAME_TOP'
        d170 = 'DCDS_CRC_FAULT_CONTROL_BTM'
        d171 = 'DCDS_CRC_FAULT_FRAMES_BTM'
        d172 = 'DCDS_CRC_FAULTS_PER_FRAME_BTM'
        d173 = 'CONV_CRC_FAULT_CONTROL'
        d174 = 'CONV_CRC_FAULT_FRAMES'
        d175 = 'CONV_CRC_FAULTS_PER_FRAME'
        d176 = 'MEC_CRC_FAULT_CONTROL'
        d177 = 'MEC_CRC_FAULT_FRAMES'
        d178 = 'MEC_CRC_FAULTS_PER_FRAME'
        d179 = 'FOR_CRC_FAULT_CONTROL'
        d180 = 'FOT_CRC_FAULTS_PER_FRAME'
        d181 = 'FOR_CRC_FAULT_FRAMES'
        d182 = 'T1_SM_STATUS'
        d183 = 'T4_SM_STATUS'
        d184 = 'DEFRAMER_FAULT_CTRL'
        d185 = 'DEFRAMER_ERROR_STATUS'
        d186 = 'CRC_EMB_WRT_CHECKSUM'
        d187 = 'CRC_EMB_CALC_CHECKSUM'
        d188 = 'STATC_ERR_EN'
        d189 = 'STATC_ERR'
        d190 = 'DTEST_26_27'
        d191 = 'GPI_STATUS'
        d192 = 'FINE_INT_ERR'
        d193 = 'I2C_WRT_CHECKSUM'
        d194 = 'I2C_RD_CHECKSUM'
        d195 = 'MIPI_CONFIG_STATUS'
        d196 = 'FRAME_COUNT2_'
        d197 = 'FRAME_COUNT_'
        d198 = 'FUSE_PIXEL_DEFECT_COUNT'
        d199 = 'HISPI_CONTROL'
        d200 = 'HISPI_STATUS'
        d201 = 'HISPI_CRC_0'
        d202 = 'ASIL_PIN_ENABLES_00'
        d203 = 'ASIL_PIN_ENABLES_01'
        d204 = 'ASIL_PIN_ENABLES_02'
        d205 = 'ASIL_PIN_ENABLES_04'
        d206 = 'ASIL_PIN_ENABLES_05'
        d207 = 'ASIL_PIN_ENABLES_06'
        d208 = 'ASIL_PIN_ENABLES_09'
        d209 = 'ASIL_CHECK_ENABLES_00'
        d210 = 'ASIL_CHECK_ENABLES_01'
        d211 = 'ASIL_CHECK_ENABLES_02'
        d212 = 'ASIL_CHECK_ENABLES_04'
        d213 = 'ASIL_CHECK_ENABLES_05'
        d214 = 'ASIL_CHECK_ENABLES_06'
        d215 = 'ASIL_CHECK_ENABLES_09'
        d216 = 'ASIL_STATUS_00'
        d217 = 'ASIL_STATUS_00__ASIL_STATUS_DATA_FORMAT_ERROR'
        d218 = 'ASIL_STATUS_00__ASIL_STATUS_BO_1V2_PARAM'
        d219 = 'ASIL_STATUS_00__ASIL_STATUS_BO_1V8_PARAM'
        d220 = 'ASIL_STATUS_00__ASIL_STATUS_BO_2V8_PARAM'
        d221 = 'ASIL_STATUS_00__ASIL_STATUS_EXT_CLK_PARAM'
        d222 = 'ASIL_STATUS_00__ASIL_STATUS_CLK_PIX_PARAM'
        d223 = 'ASIL_STATUS_00__ASIL_STATUS_CLK_OP_PARAM'
        d224 = 'ASIL_STATUS_00__ASIL_STATUS_CLK_REG_PARAM'
        d225 = 'ASIL_STATUS_00__ASIL_STATUS_CLK_PIX_100_PARAM'
        d226 = 'ASIL_STATUS_00__ASIL_STATUS_CLK_OP_100_PARAM'
        d227 = 'ASIL_STATUS_00__ASIL_STATUS_CLK_REG_100_PARAM'
        d228 = 'ASIL_STATUS_01'
        d229 = 'ASIL_STATUS_01__FAIL_CRT'
        d230 = 'ASIL_STATUS_01__FAIL_OT1_PIXEL_LOW'
        d231 = 'ASIL_STATUS_01__FAIL_OT1_PIXEL_HIGH'
        d232 = 'ASIL_STATUS_01__FAIL_OT2_PIXEL_LOW'
        d233 = 'ASIL_STATUS_01__FAIL_OT2_PIXEL_HIGH'
        d234 = 'ASIL_STATUS_01__FAIL_ZEBRA_AB_PIXEL_LEGAL'
        d235 = 'ASIL_STATUS_01__FAIL_ZEBRA_AB_PIXEL_CORRECT'
        d236 = 'ASIL_STATUS_01__FAIL_ZEBRA_BA_PIXEL_LEGAL'
        d237 = 'ASIL_STATUS_01__FAIL_ZEBRA_BA_PIXEL_CORRECT'
        d238 = 'ASIL_STATUS_01__FAIL_PT1_BELOW_THRESHOLD'
        d239 = 'ASIL_STATUS_01__FAIL_PT2_ABOVE_THRESHOLD'
        d240 = 'ASIL_STATUS_01__FAIL_RRC_PIXEL_LEGAL'
        d241 = 'ASIL_STATUS_01__FAIL_RRC_ADDRESS'
        d242 = 'ASIL_STATUS_01__FAIL_RRC_DCG'
        d243 = 'ASIL_STATUS_02'
        d244 = 'ASIL_STATUS_02__AUX_SEQUENCER_ECC_STATUS'
        d245 = 'ASIL_STATUS_02__ASIL_STATUS_RRC_TX1'
        d246 = 'ASIL_STATUS_02__DBLC_RAM_ECC_DED_STATUS'
        d247 = 'ASIL_STATUS_02__DBLC_RAM_ECC_SEC_STATUS'
        d248 = 'ASIL_STATUS_02__DBLC_STATE_PARITY_STATUS'
        d249 = 'ASIL_STATUS_02__TPG_RAM_ECC_SEC'
        d250 = 'ASIL_STATUS_02__TPG_RAM_ECC_DED'
        d251 = 'ASIL_STATUS_02__ADDRESS_SM_CRC_STATUS'
        d252 = 'ASIL_STATUS_02__SEQUENCER_ECC_STATUS'
        d253 = 'ASIL_STATUS_02__DTR_CRC_STATUS'
        d254 = 'ASIL_STATUS_02__ROW_FRAME_CRC_STATUS'
        d255 = 'ASIL_STATUS_03'
        d256 = 'ASIL_STATUS_03__DELAY_BUFFER_CRC_FAULT'
        d257 = 'ASIL_STATUS_03__MC_MEMORY_CRC_FAULT'
        d258 = 'ASIL_STATUS_03__LFM2_MEMORY_CRC_FAULT'
        d259 = 'ASIL_STATUS_03__DCDS_TOP_MEMORY_CRC_FAULT'
        d260 = 'ASIL_STATUS_03__DCDS_BTM_MEMORY_CRC_FAULT'
        d261 = 'ASIL_STATUS_03__CONV_MEMORY_CRC_FAULT'
        d262 = 'ASIL_STATUS_03__ODP_MEMORY_CRC_FAULT'
        d263 = 'ASIL_STATUS_03__MEC_MEMORY_CRC_FAULT'
        d264 = 'ASIL_STATUS_03__DEFRAMER_FAULT'
        d265 = 'ASIL_STATUS_04'
        d266 = 'ASIL_STATUS_04__STATS1_RAM_SEC'
        d267 = 'ASIL_STATUS_04__STATS1_RAM_DED'
        d268 = 'ASIL_STATUS_04__STATS2_RAM_SEC'
        d269 = 'ASIL_STATUS_04__STATS2_RAM_DED'
        d270 = 'ASIL_STATUS_04__STATS3_RAM_SEC'
        d271 = 'ASIL_STATUS_04__STATS3_RAM_DED'
        d272 = 'ASIL_STATUS_04__STATS4_RAM_SEC'
        d273 = 'ASIL_STATUS_04__STATS4_RAM_DED'
        d274 = 'ASIL_STATUS_04__STATS5_RAM_SEC'
        d275 = 'ASIL_STATUS_04__STATS5_RAM_DED'
        d276 = 'ASIL_STATUS_04__STATS6_RAM_SEC'
        d277 = 'ASIL_STATUS_04__STATS6_RAM_DED'
        d278 = 'ASIL_STATUS_04__CTX_RAM_SEC'
        d279 = 'ASIL_STATUS_04__CTX_RAM_DED'
        d280 = 'ASIL_STATUS_05'
        d281 = 'ASIL_STATUS_05__FAIL_OT3_PIXEL_LOW'
        d282 = 'ASIL_STATUS_05__FAIL_OT3_PIXEL_HIGH'
        d283 = 'ASIL_STATUS_05__FAIL_OT4_PIXEL_LOW'
        d284 = 'ASIL_STATUS_05__FAIL_OT4_PIXEL_HIGH'
        d285 = 'ASIL_STATUS_05__FAIL_OT5_PIXEL_LOW'
        d286 = 'ASIL_STATUS_05__FAIL_OT5_PIXEL_HIGH'
        d287 = 'ASIL_STATUS_05__FAIL_GRD_PIXEL_LOW'
        d288 = 'ASIL_STATUS_05__FAIL_GRD_PIXEL_HIGH'
        d289 = 'ASIL_STATUS_06'
        d290 = 'ASIL_STATUS_06__FAIL_ADCL'
        d291 = 'ASIL_STATUS_06__FAIL_DCDS'
        d292 = 'ASIL_STATUS_06__FAIL_PIXOUT'
        d293 = 'ASIL_STATUS_06__FAIL_BW'
        d294 = 'ASIL_STATUS_06__FAIL_WB'
        d295 = 'ASIL_STATUS_06__FAIL_OT6_LOW'
        d296 = 'ASIL_STATUS_06__FAIL_OT6_HIGH'
        d297 = 'ASIL_STATUS_06__FAIL_OT7_LOW'
        d298 = 'ASIL_STATUS_06__FAIL_OT7_HIGH'
        d299 = 'ASIL_STATUS_06__FAIL_OT8_LOW'
        d300 = 'ASIL_STATUS_06__FAIL_OT8_HIGH'
        d301 = 'ASIL_STATUS_06__FAIL_EC_COMP'
        d302 = 'ASIL_STATUS_06__FAIL_DCDS2'
        d303 = 'ASIL_STATUS_09'
        d304 = 'ASIL_STATUS_09__FAIL_RRC_LEGAL_12'
        d305 = 'ASIL_STATUS_09__FAIL_RRC_LEGAL_13'
        d306 = 'ASIL_STATUS_09__FAIL_RRC_LEGAL_14'
        d307 = 'ASIL_STATUS_09__FAIL_RRC_LEGAL_15'
        d308 = 'ASIL_STATUS_09__FAIL_RRC_LEGAL_16'
        d309 = 'ASIL_STATUS_09__FAIL_RRC_LEGAL_17'
        d310 = 'ASIL_STATUS_09__FAIL_RRC_LEGAL_18'
        d311 = 'ASIL_STATUS_09__FAIL_RRC_LEGAL_19'
        d312 = 'ASIL_STATUS_09__FAIL_RRC_LEGAL_20'
        d313 = 'ASIL_STATUS_09__FAIL_RRC_LEGAL_21'
        d314 = 'ASIL_STATUS_09__FAIL_RRC_LEGAL_22'
        d315 = 'ASIL_STATUS_09__FAIL_RRC_LEGAL_23'
        d316 = 'SYS_CHECK_POST_RUNTIME'
    
        figTitle = 'SM_Runtime_Fault_Injection_Plot'
        ylabel = 'RegVal (Dec)'
        numDataCols = 317  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame
    
        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)
    
        document.add_heading(figTitle, level=2)  # Add section title to docx report
    
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found


'''
ASIL REGISTERS
'''

def SM_Runtime_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
        figTitle = 'SM_Runtime_Plot'

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        VRG_Safety_Data.ASIL_REGISTERS(dataFrame, groupBy, document, pltPath, showPlt)
        VRG_Safety_Data.ASIL_PIN_ENABLES(dataFrame, groupBy, document, pltPath, showPlt)
        VRG_Safety_Data.ASIL_CHECK_ENABLES(dataFrame, groupBy, document, pltPath, showPlt)
        VRG_Safety_Data.ASIL_STATUS(dataFrame, groupBy, document, pltPath, showPlt)

def ASIL_REGISTERS(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ASIL_EXT_CLK_COUNT_MSB_EXPECT'
        d2 = 'ASIL_EXT_CLK_COUNT_LSB_EXPECT'
        d3 = 'ASIL_CLK_PIX_COUNT_MSB_EXPECT'
        d4 = 'ASIL_CLK_PIX_COUNT_LSB_EXPECT'
        d5 = 'ASIL_CLK_OP_COUNT_MSB_EXPECT'
        d6 = 'ASIL_CLK_OP_COUNT_LSB_EXPECT'
        d7 = 'ASIL_CLK_REG_COUNT_MSB_EXPECT'
        d8 = 'ASIL_CLK_REG_COUNT_LSB_EXPECT'
        d9 = 'ASIL_CLK_PIX_COUNT_100_EXT_EXPECT'
        d10 = 'ASIL_CLK_OP_COUNT_100_EXT_EXPECT'
        d11 = 'ASIL_CLK_REG_COUNT_100_EXT_EXPECT'
        d12 = 'ASIL_EXT_CLK_COUNT_MSB'
        d13 = 'ASIL_EXT_CLK_COUNT_LSB'
        d14 = 'ASIL_CLK_PIX_COUNT_MSB'
        d15 = 'ASIL_CLK_PIX_COUNT_LSB'
        d16 = 'ASIL_CLK_OP_COUNT_MSB'
        d17 = 'ASIL_CLK_OP_COUNT_LSB'
        d18 = 'ASIL_CLK_REG_COUNT_MSB'
        d19 = 'ASIL_CLK_REG_COUNT_LSB'
        d20 = 'ASIL_CLK_PIX_COUNT_100_EXT'
        d21 = 'ASIL_CLK_OP_COUNT_100_EXT'
        d22 = 'ASIL_CLK_REG_COUNT_100_EXT'
        d23 = 'TEMPSENS1_CTRL_REG'
        d24 = 'TEMPVSENS1_TMG_CTRL'
        d25 = 'TEMPVSENS1_FLAG_CTRL'
        d26 = 'TEMPVSENS1_EN_CTRL'
        d27 = 'TEMPVSENS1_TMG_CTRL_K0'
        d28 = 'TEMPVSENS1_TMG_CTRL_K1'
        d29 = 'TEMPVSENS1_STATUS'
        d30 = 'DAC_LD_112_113'
        d31 = 'DAC_LD_112_113__SREG_FAULT_INJECT_EN'
        d32 = 'CHECK_BW_ADC21_CRT'
        d33 = 'CHECK_OT321_WB'
        d34 = 'CHECK_ZAB_OT654'
        d35 = 'CHECK_PT21_AFC_ZBA'
        d36 = 'CHECK_EC_GRD'
        d37 = 'CHECK_ZEB_WB'
        d38 = 'DAC_LD_112_113__SREG_ATR_TEST_ROW_EN'
        d39 = 'DAC_LD_112_113__SREG_FULLFRAME_EN'
        d40 = 'ATR_CHECK_CRT_CRC_VALUE'
        d41 = 'ATR_CHECK_CRT_CRC_EXPECT'
        d42 = 'ATR_CHECK_MT_EXPECT_ADCL1'
        d43 = 'ATR_CHECK_MT_EXPECT_ADCL2'
        d44 = 'ATR_CHECK_MT_EXPECT_B'
        d45 = 'ATR_CHECK_MT_EXPECT_W'
        d46 = 'ATR_CHECK_MT_EXPECT_ID_BITS__MT_ID_B_EXPECT'
        d47 = 'ATR_CHECK_MT_EXPECT_ID_BITS__MT_ID_W_EXPECT'
        d48 = 'ATR_CHECK_OT1_HI_THRESH'
        d49 = 'ATR_CHECK_OT1_LO_THRESH'
        d50 = 'ATR_CHECK_OT2_HI_THRESH'
        d51 = 'ATR_CHECK_OT2_LO_THRESH'
        d52 = 'ATR_CHECK_OT3_HI_THRESH'
        d53 = 'ATR_CHECK_OT3_LO_THRESH'
        d54 = 'ATR_CHECK_OT4_HI_THRESH'
        d55 = 'ATR_CHECK_OT4_LO_THRESH'
        d56 = 'ATR_CHECK_MT_EXPECT_ID_BITS__MT_ID_OT4_EXPECT'
        d57 = 'ATR_CHECK_OT5_HI_THRESH'
        d58 = 'ATR_CHECK_OT5_LO_THRESH'
        d59 = 'ATR_CHECK_MT_EXPECT_ID_BITS__MT_ID_OT5_EXPECT'
        d60 = 'ATR_CHECK_OT6_HI_THRESH'
        d61 = 'ATR_CHECK_OT6_LO_THRESH'
        d62 = 'ATR_CHECK_MT_EXPECT_ID_BITS__MT_ID_OT6_EXPECT'
        d63 = 'ATR_CHECK_ZT_LO_THRESH'
        d64 = 'ATR_CHECK_ZT_HI_THRESH'
        d65 = 'ATR_CHECK_PT_LO_THRESH'
        d66 = 'ATR_CHECK_PT_HI_THRESH'
        d67 = 'ATR_CHECK_MT_EXPECT_ID_BITS__MT_ID_ECL_EXPECT'
        d68 = 'CHECK_RRC_ADDR'
        d69 = 'RRC_CHECK_LO_THRESH'
        d70 = 'RRC_CHECK_HI_THRESH'
        d71 = 'RRC_CHECK_ADDR_CRC_EXPECT'
        d72 = 'RRC_CHECK_ADDR_CRC_VALUE'
        d73 = 'CHECK_RRC_SIC'
        d74 = 'GAINCTRL_LO_THRESH'
        d75 = 'GAINCTRL_HI_THRESH'
        d76 = 'DCG_LO_THRESH'
        d77 = 'DCG_HI_THRESH'
        d78 = 'DCG1_LO_THRESH'
        d79 = 'DCG1_HI_THRESH'
        d80 = 'CLGREF_LO_THRESH'
        d81 = 'CLGREF_HI_THRESH'
        d82 = 'FAULT_INJ__DAC_LD_112_113__SREG_FAULT_INJECT_EN'
        d83 = 'FAULT_REG__DAC_LD_110_111__SREG111_NC_7_0'
        d84 = 'FAULT_REG__DAC_LD_146_147'
        d85 = 'TPG_CONTROL'
        d86 = 'TPG_STDPAT_REGION1'
        d87 = 'TPG_STDPAT_REGION2'
        d88 = 'TPG_COLOR0_GR1_HI'
        d89 = 'TPG_COLOR0_GR1_LO'
        d90 = 'TPG_COLOR0_RED_HI'
        d91 = 'TPG_COLOR0_RED_LO'
        d92 = 'TPG_COLOR0_BLU_HI'
        d93 = 'TPG_COLOR0_BLU_LO'
        d94 = 'TPG_COLOR0_GR2_HI'
        d95 = 'TPG_COLOR0_GR2_LO'
        d96 = 'TPG_COLOR1_GR1_HI'
        d97 = 'TPG_COLOR1_GR1_LO'
        d98 = 'TPG_COLOR1_RED_HI'
        d99 = 'TPG_COLOR1_RED_LO'
        d100 = 'TPG_COLOR1_BLU_HI'
        d101 = 'TPG_COLOR1_BLU_LO'
        d102 = 'TPG_COLOR1_GR2_HI'
        d103 = 'TPG_COLOR1_GR2_LO'
        d104 = 'TPG_HDR_RATIOS'
        d105 = 'TPG_PD0_PD1_RATIOS'
        d106 = 'DTR_BOUND_X0'
        d107 = 'DTR_BOUND_X1'
        d108 = 'DTR_BOUND_Y0'
        d109 = 'DTR_BOUND_Y1'
        d110 = 'CRC_FR_DTR_WRT_CHECKSUM_HIGH'
        d111 = 'CRC_FR_DTR_WRT_CHECKSUM_HIGH__FR_CHECKSUM_REG_HIGH'
        d112 = 'CRC_FR_DTR_WRT_CHECKSUM_HIGH__DTR_CHECKSUM_REG_HIGH'
        d113 = 'CRC_FR_DTR_CALC_CHECKSUM_HIGH'
        d114 = 'CRC_FR_DTR_CALC_CHECKSUM_HIGH__CRC_FR_CALC_CHECKSUM_HIGH'
        d115 = 'CRC_FR_DTR_CALC_CHECKSUM_HIGH__CRC_DTR_CALC_CHECKSUM_HIGH'
        d116 = 'CRC_FR_WRT_CHECKSUM_LOW'
        d117 = 'CRC_FR_CALC_CHECKSUM_LOW'
        d118 = 'CRC_DTR_WRT_CHECKSUM_LOW'
        d119 = 'CRC_DTR_CALC_CHECKSUM_LOW'
        d120 = 'MASTER_FSM_REQ_CODE'
        d121 = 'MASTER_FSM_RSP_CODE'
        d122 = 'MASTER_FSM2_REQ_CODE'
        d123 = 'MASTER_FSM2_RSP_CODE'
        d124 = 'CRC_EMB_WRT_CHECKSUM'
        d125 = 'CRC_EMB_CALC_CHECKSUM'
        d126 = 'DELAY_BUFFER_CRC_FAULT_CONTROL'
        d127 = 'DELAY_BUFFER_CRC_FAULT_CONTROL__DELAY_BUFFER_CRC_FAULT_CONTROL_CRC_FAULT_RESET'
        d128 = 'DELAY_BUFFER_CRC_FAULT_CONTROL__DELAY_BUFFER_CRC_FAULT_CONTROL_DTR_CRC_EN'
        d129 = 'DELAY_BUFFER_CRC_FAULT_CONTROL__DLY_BUF_FAULT_INS'
        d130 = 'DELAY_BUFFER_CRC_FAULT_CONTROL__DLY_BUF_FAULT_PIXEL'
        d131 = 'DELAY_BUFFER_CRC_FAULT_FRAMES'
        d132 = 'DELAY_BUFFER_CRC_FAULTS_PER_FRAME'
        d133 = 'ODP_CRC_FAULT_CONTROL'
        d134 = 'ODP_CRC_FAULT_CONTROL__ODP_CRC_FAULT_CONTROL_CRC_FAULT_RESET'
        d135 = 'ODP_CRC_FAULT_CONTROL__ODP_CRC_FAULT_CONTROL_CRC_ERROR_INJECT'
        d136 = 'ODP_CRC_FAULT_FRAMES'
        d137 = 'ODP_CRC_FAULTS_PER_FRAME'
        d138 = 'DCDS_CRC_FAULT_CONTROL_BTM'
        d139 = 'DCDS_CRC_FAULT_CONTROL_BTM__DCDS_CRC_FAULT_RESET_LB1'
        d140 = 'DCDS_CRC_FAULT_CONTROL_BTM__DCDS_CRC_FAULT_INSERT_LB1'
        d141 = 'DCDS_CRC_FAULT_CONTROL_BTM__DCDS_CRC_FAULT_RESET_LB2'
        d142 = 'DCDS_CRC_FAULT_CONTROL_BTM__DCDS_CRC_FAULT_INSERT_LB2'
        d143 = 'DCDS_CRC_FAULT_CONTROL_BTM__DCDS_CRC_FAULT_RESET_LB3'
        d144 = 'DCDS_CRC_FAULT_CONTROL_BTM__DCDS_CRC_FAULT_INSERT_LB3'
        d145 = 'DCDS_CRC_FAULT_CONTROL_BTM__CH_CONV_CRC_FAULT_RESET'
        d146 = 'DCDS_CRC_FAULT_CONTROL_BTM__CH_CONV_CRC_FAULT_INSERT'
        d147 = 'DCDS_CRC_FAULT_FRAMES_BTM'
        d148 = 'DCDS_CRC_FAULTS_PER_FRAME_BTM'
        d149 = 'OVF_CRC_FAULT_CONTROL'
        d150 = 'OVF_CRC_FAULT_CONTROL__OVF_CRC_FAULT_CONTROL_CRC_FAULT_RESET'
        d151 = 'OVF_CRC_FAULT_CONTROL__OVF_CRC_FAULT_CONTROL_DTC_FAULT_RESET'
        d152 = 'OVF_CRC_FAULT_CONTROL__OVF_CRC_FAULT_CONTROL_DTC_BYPASS'
        d153 = 'OVF_CRC_FAULT_CONTROL__OVF_CRC_FAULT_CONTROL_DTR_CRC_EN'
        d154 = 'OVF_CRC_FAULT_CONTROL__CRC_FAULT_INJ'
        d155 = 'OVF_CRC_FAULT_CONTROL__DTC_FAULT_INJ'
        d156 = 'ASIL_CRC_ENABLES'
        d157 = 'ASIL_CRC_ENABLES__BUF824_CRC_FAULT_EN'
        d158 = 'ASIL_CRC_ENABLES__BUF824_CRC_FAULT_RESET'
        d159 = 'ASIL_CRC_ENABLES__BUF824_CRC_FAULT_INSERT'
        d160 = 'SM_FIFO_CRC__DCDS_CRC_FAULT_CONTROL_BTM__CH_CONV_CRC_FAULT_RESET'
        d161 = 'CONV_CRC_FAULT_FRAMES'
        d162 = 'CONV_CRC_FAULTS_PER_FRAME'
        d163 = 'T1_DDC_FAULT_CONTROL'
        d164 = 'T1_DDC_FAULT_CONTROL__T1_DDC_FAULT_CONTROL_DP2_DP4_DTC_FAULT_INJ'
        d165 = 'T1_DDC_FAULT_CONTROL__T1_DDC_FAULT_CONTROL_LINE0_CRC_FAULT_INJ'
        d166 = 'T1_DDC_FAULT_CONTROL__T1_DDC_FAULT_CONTROL_LINE1_CRC_FAULT_INJ'
        d167 = 'T1_DDC_FAULT_CONTROL__T1_DDC_FAULT_CONTROL_LINE2_CRC_FAULT_INJ'
        d168 = 'T1_DDC_FAULT_CONTROL__T1_DDC_FAULT_CONTROL_LINE3_CRC_FAULT_INJ'
        d169 = 'T1_DDC_FAULT_CONTROL__T1_DDC_FAULT_CONTROL_LINE4_CRC_FAULT_INJ'
        d170 = 'T1_SM_STATUS'
        d171 = 'ECC_FAULT_INJECTION'
        d172 = 'ECC_FAULT_INJECTION__CTX'
        d173 = 'ECC_FAULT_INJECTION__TBRS'
        d174 = 'ECC_FAULT_INJECTION__OTPM'
        d175 = 'ECC_FAULT_INJECTION__SEQ1'
        d176 = 'ECC_FAULT_INJECTION__SEQ2'
        d177 = 'ECC_FAULT_INJECTION__PDI_BRAM'
        d178 = 'ECC_FAULT_INJECTION__PDI_SRAM'
        d179 = 'I2C_WRT_CHECKSUM'
        d180 = 'I2C_RD_CHECKSUM'
        d181 = 'I2C_WRT_COUNT'
        d182 = 'GPI_STATUS'
        d183 = 'GPI_STATUS_GPI0'
        d184 = 'GPI_STATUS_GPI1'
        d185 = 'GPI_STATUS_GPI2'
        d186 = 'GPI_STATUS_GPI3'
        d187 = 'GPI_STATUS_SADDR_PIN_SELECT'
        d188 = 'GPI_STATUS_OE_N_PIN_SELECT'
        d189 = 'GPI_STATUS_TRIGGER_PIN_SELECT'
        d190 = 'GPI_STATUS_STANDBY_PIN_SELECT'
        d191 = 'LOCK_CONTROL'
        d192 = 'MIPI_CONFIG_STATUS'
        d193 = 'FRAME_COUNT2_'
        d194 = 'FRAME_COUNT_'
        d195 = 'PLC_CTRL'
        d196 = 'DTC_COL_CTRL'
        d197 = 'DTC_COL_LFSR_SEED1'
        d198 = 'DTC_COL_LFSR_SEED2'
        d199 = 'SM_DTC__OVF_CRC_FAULT_CONTROL__'
        d200 = 'SM_DTC__OVF_CRC_FAULT_CONTROL__OVF_CRC_FAULT_CONTROL_CRC_FAULT_RESET'
        d201 = 'SM_DTC__OVF_CRC_FAULT_CONTROL__OVF_CRC_FAULT_CONTROL_DTC_FAULT_RESET'
        d202 = 'SM_DTC__OVF_CRC_FAULT_CONTROL__OVF_CRC_FAULT_CONTROL_DTC_BYPASS'
        d203 = 'SM_DTC__OVF_CRC_FAULT_CONTROL__OVF_CRC_FAULT_CONTROL_DTR_CRC_EN'
        d204 = 'SM_DTC__OVF_CRC_FAULT_CONTROL__CRC_FAULT_INJ'
        d205 = 'SM_DTC__OVF_CRC_FAULT_CONTROL__DTC_FAULT_INJ'
        d206 = 'SM_DTC__T1_DDC_FAULT_CONTROL'
        d207 = 'SM_DTC__T1_DDC_FAULT_CONTROL__T1_DDC_FAULT_CONTROL_DP2_DP4_DTC_FAULT_INJ'
        d208 = 'SM_DTC__T1_DDC_FAULT_CONTROL__T1_DDC_FAULT_CONTROL_LINE0_CRC_FAULT_INJ'
        d209 = 'SM_DTC__T1_DDC_FAULT_CONTROL__T1_DDC_FAULT_CONTROL_LINE1_CRC_FAULT_INJ'
        d210 = 'SM_DTC__T1_DDC_FAULT_CONTROL__T1_DDC_FAULT_CONTROL_LINE2_CRC_FAULT_INJ'
        d211 = 'SM_DTC__T1_DDC_FAULT_CONTROL__T1_DDC_FAULT_CONTROL_LINE3_CRC_FAULT_INJ'
        d212 = 'SM_DTC__T1_DDC_FAULT_CONTROL__T1_DDC_FAULT_CONTROL_LINE4_CRC_FAULT_INJ'
        d213 = 'SM_DTC__T1_SM_STATUS'
        d214 = 'MipiControls'
        d215 = 'MipiControls__CheckSumError'
        d216 = 'MipiControls__SpEccError'
        d217 = 'MipiControls__LpEccError'
        d218 = 'DATA_FORMAT_BITS'
        d219 = 'DATA_FORMAT_ACTUAL'
        d220 = 'TBRS_CONTROL'
        d221 = 'TBRS_CONTROL__GO_BSY'
        d222 = 'TBRS_CONTROL__FRM_SYNC_GO'
        d223 = 'TBRS_CONTROL__TBRS_CONTROL_I2C_AUTO_INC_DISABLE'
        d224 = 'TBRS_CONTROL__TBRS_CONTROL_AUTO_INC_ON_READ'
        d225 = 'TBRS_CONTROL__MEM_ECC_DIS'
        d226 = 'TBRS_CONTROL__ECC_SEC_FAULT_INJECT'
        d227 = 'TBRS_CONTROL__ECC_DED_FAULT_INJECT'
        d228 = 'TBRS_CONTROL__RAM_CRC_FAULT_INJECT'
        d229 = 'TBRS_CONTROL__TBL_CRC_FAULT_INJECT'
        d230 = 'TBRS_CONTROL__TBL_FIXED_REG_INJECT'
        d231 = 'TBRS_CONTROL__RUN_RAM_CRC'
        d232 = 'TBRS_RAM_LOCK_START'
        d233 = 'TBRS_RAM_LOCK_START__RAM_LOCK_START'
        d234 = 'TBRS_RAM_LOCK_START__TBRS_RAM_LOCK_START_UNUSED'
        d235 = 'TBRS_RAM_LOCK_START__LOCK_STATIC_RAM'
        d236 = 'TBRS_RAM_LOCK_END'
        d237 = 'TBRS_RAM_CALCULATED_CRC'
        d238 = 'TBRS_TBL_CALCULATED_CRC'
        d239 = 'TBRS_FIXED_TBL_REG0'
        d240 = 'TBRS_FIXED_TBL_REG1'
        d241 = 'TBRS_FIXED_TBL_RES_START'
        d242 = 'TBRS_FIXED_TBL_RES_END'

        figTitle = 'ASIL_Registers'
        ylabel = 'RegVal (Dec)'
        numDataCols = 243  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Found: " + groupBy, level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def ASIL_PIN_ENABLES(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ASIL_PIN_ENABLES_' # Columns to find

        df = dataFrame

        # get data columns
        t1_cols = [x for x in df.columns[df.columns.str.contains(d1)]]

        figTitle = 'ASIL_PIN_ENABLES Registers'
        ylabel = 'RegVal (Dec)'
        numDataCols = len(t1_cols) + 1 # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        for dc in t1_cols: # loop through all column names
            if groupBy == None:  # Remove Legend= keyword
                # Plot each data frame column
                fcp.plot(df, x='Step', y=dc, title=dc, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + dc + '_' + timestamp + '.png')
                document.add_heading(dc, level=3)
                document.add_picture(pltPath + dc + '_' + timestamp + '.png')  # Add figure to report
            elif groupBy != None:
                # Plot each data frame column
                fcp.plot(df, x='Step', y=dc, title=dc, legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + dc + '_' + timestamp + '.png')
                document.add_heading(dc, level=3)
                document.add_picture(pltPath + dc + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for dc in t1_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def ASIL_CHECK_ENABLES(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ASIL_CHECK_ENABLES_' # Columns to find

        df = dataFrame

        # get data columns
        t1_cols = [x for x in df.columns[df.columns.str.contains(d1)]]

        figTitle = 'ASIL_CHECK_ENABLES Registers'
        ylabel = 'RegVal (Dec)'
        numDataCols = len(t1_cols) + 1 # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        for dc in t1_cols: # loop through all column names
            if groupBy == None:  # Remove Legend= keyword
                # Plot each data frame column
                fcp.plot(df, x='Step', y=dc, title=dc, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + dc + '_' + timestamp + '.png')
                document.add_heading(dc, level=3)
                document.add_picture(pltPath + dc + '_' + timestamp + '.png')  # Add figure to report
            elif groupBy != None:
                # Plot each data frame column
                fcp.plot(df, x='Step', y=dc, title=dc, legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + dc + '_' + timestamp + '.png')
                document.add_heading(dc, level=3)
                document.add_picture(pltPath + dc + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for dc in t1_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def ASIL_STATUS(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ASIL_STATUS_' # Columns to find

        df = dataFrame

        # get data columns
        t1_cols = [x for x in df.columns[df.columns.str.contains(d1)]]

        figTitle = 'ASIL_STATUS Registers'
        ylabel = 'RegVal (Dec)'
        numDataCols = len(t1_cols) + 1 # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        for dc in t1_cols: # loop through all column names
            if groupBy == None:  # Remove Legend= keyword
                # Plot each data frame column
                fcp.plot(df, x='Step', y=dc, title=dc, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + dc + '_' + timestamp + '.png')
                document.add_heading(dc, level=3)
                document.add_picture(pltPath + dc + '_' + timestamp + '.png')  # Add figure to report
            elif groupBy != None:
                # Plot each data frame column
                fcp.plot(df, x='Step', y=dc, title=dc, legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + dc + '_' + timestamp + '.png')
                document.add_heading(dc, level=3)
                document.add_picture(pltPath + dc + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for dc in t1_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found


