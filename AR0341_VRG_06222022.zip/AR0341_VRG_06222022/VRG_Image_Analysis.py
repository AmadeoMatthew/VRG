__author__ = 'fg66yw'

from matplotlib import pyplot
from matplotlib import cm
import png
from docx import Document
from docx.shared import Inches
from numpy import genfromtxt
from numpy import asarray
from numpy import amin
from numpy import amax
from numpy import percentile
from numpy import mean
from numpy import float64
from numpy import uint32
from numpy import arange
from numpy import histogram
from numpy import extract
from numpy import where
from numpy import fromfile
from numpy import nditer
from numpy import delete
from tabulate import tabulate
import os
from math import log10
from matplotlib.ticker import StrMethodFormatter
import matplotlib.image as mpimg
from PIL import Image
from PIL import ImageFont
from PIL import ImageDraw

'''
Supporting definitions for Image Analysis
'''
def load_raw_to_numpy_array(pathname):
    # print(pathname)
    return_array = fromfile(pathname,dtype=uint32,count=-1)
    return_array = return_array.reshape(948,1828)
    return return_array

def load_png_to_numpy_array(pathname):
    png_data = png.Reader(pathname).asDirect()
    bit_depth = png_data[3]['bitdepth']
    my_array = []
    for row in png_data[2]:
        my_row = []
        iter_row = iter(row)
        for pixel in iter_row:
            my_row.append(pixel)
        my_array.append(my_row)
    return (asarray(my_array), bit_depth)

def png_text(pathname):
    for chunk_type, chunk in png.Reader(pathname).chunks():
        if chunk_type == 'tEXt':
            print(chunk)

def histogram_stretch(numpy_array,bit_depth):
    min = percentile(numpy_array, 0.1)
    max = percentile(numpy_array, 99.9)
    numpy_array[numpy_array>max] = max
    numpy_array[numpy_array < min] = min
    # print(min)
    # print(max)
    # print(amin(numpy_array))
    # print(amax(numpy_array))
    histogram_stretch = ((numpy_array - min)/(max - min))*2**bit_depth
    return histogram_stretch

def normalize_array_to_one(numpy_array,bit_depth):
    numpy_array = numpy_array/float(amax(numpy_array))
    return numpy_array

def get_color_planes(numpy_array):
    color_planes = list()
    color_planes.append(numpy_array[0::2, 0::2])    # upper left, every 2nd column starting from 0, row 0 every 2
    color_planes.append(numpy_array[1::2, 0::2])    # upper right, every 2nd column starting from 1 row 0 every 2
    color_planes.append(numpy_array[0::2, 1::2])    # lower left, every 2nd column starting from 0, row 1 every 2
    color_planes.append(numpy_array[1::2, 1::2])    # lower right, every 2nd column starting from 1, row 1 every 2
    return color_planes

def find_row(data, column, value):
    step = where(data[column] == value)
    row = data[step]
    return row

def decompand(numpy_array, bit_depth):
    decompanded_array = numpy_array
    if bit_depth is 12:
        for out in nditer(decompanded_array, op_flags=['readwrite']):
            if 3040 >= out >= 2048:
                out[...] = (out - 2048)*64 + 2048
            elif 4000 >= out > 3040:
                out[...] = (out - 3040)*1024 + 65536
    elif bit_depth is 14:
        for out in nditer(decompanded_array, op_flags=['readwrite']):
            if 7946 >= out >= 4096:
                out[...] = (out - 4096)*16 + 4096
            elif 11787 >= out > 7946:
                out[...] = (out - 7946)*256 + 65536
    elif bit_depth is 16:
        for out in nditer(decompanded_array, op_flags=['readwrite']):
            if 40960 >= out >= 16384:
                out[...] = (out - 16384)*2 + 16384
            elif 55296 >= out > 40960:
                out[...] = (out - 40960)*32 + 65536
            elif 63487 >= out > 55296:
                out[...] = (out - 55296)*64 + 524288
    return decompanded_array



'''
Image Analysis
'''
def Add_External_Image(imgDir, imgFileName, document, showPlt):
    try:
    
        imgWidth = 7.25  # size of img (inches)
    
        for file in os.scandir(imgDir):
            if file.name.endswith(".png") or file.name.endswith(".PNG"):
                if file.name == imgFileName:
                    imgFilePath = str(os.path.join(imgDir, imgFileName))
                    if showPlt == True:
                        image = Image.open(imgFilePath)
                        image.show()
                    document.add_heading('External Image', level=2)
                    document.add_heading(imgFileName, level=3)
                    document.add_picture(imgFilePath, width=Inches(imgWidth))  # Add Image to report
    except:
        document.add_heading("Failed To Add_External_Image: ", level=2)
        document.add_heading("imgDir Used: " + imgDir, level=3)
        document.add_heading("imgFileName Used: " + imgFileName, level=3)

def Add_External_Image_Analysis(imgDir, imgFileName, document, showPlt):
    try:
        # Get the image stats from the CSV file
        labelFontSize = 20 # Plot lable Fontsize
        titleFontSize = 26 # Title Fontsize
        lineWidthSize = 5 # Thickness of the plot lines
        fontWeight = 'bold' # Fontweight
        imgWidth = 7.25 # size of img (inches)
    
        for file in os.scandir(imgDir):
            if file.name.endswith(".png") or file.name.endswith(".PNG"):
                if file.name == imgFileName:
                    imgFilePath = str(os.path.join(imgDir, imgFileName))
    
                    color_map = dict(All='k', Red='r', GreenRed='g', GreenBlue='g--', Blue='b--')
                    Bayer = list()
                    Bayer.append(color_map['GreenRed'])
                    Bayer.append(color_map['Red'])
                    Bayer.append(color_map['Blue'])
                    Bayer.append(color_map['GreenBlue'])
                    numpy_array, bit_depth = load_png_to_numpy_array(imgFilePath)
                    analysis_array = numpy_array[32:-32:1, 256::1]
                    display_array = histogram_stretch(analysis_array, bit_depth)
                    normalized_array = normalize_array_to_one(display_array, bit_depth)
                    color_planes = get_color_planes(analysis_array)
                    header_name = imgFileName
                    fig = pyplot.figure(1)
                    fig.set_size_inches(40.96, 30.98, forward=True)
    
                    # NEW CODE
                    # Add the Image to the Plot
                    ax = pyplot.subplot2grid((4, 4), (0, 0), colspan=3, rowspan=3)
                    imgplot = ax.imshow(display_array, cmap=cm.Greys_r, vmin=amin(display_array), vmax=amax(display_array))
                    imgplot.set_interpolation('bilinear')
                    ax.autoscale(True, 'both', True)
                    ax.xaxis.set_visible(False)
                    ax.yaxis.set_visible(False)
    
                    # Add the Row Means to the Plot
                    ax = pyplot.subplot2grid((4, 4), (0, 3), rowspan=3)
                    for index, color_plane in enumerate(color_planes):
                        row_means = mean(color_plane, axis=1)
                        x = arange(0, row_means.size * 2, 2)
                        y = row_means
                        pyplot.plot(y, x, Bayer[index], linewidth=lineWidthSize)
                        col_means = mean(color_plane, axis=0)
                    ax.invert_yaxis()
                    ax.autoscale(True, 'both', True)
                    ax.set_title("Row Means", fontsize=titleFontSize, fontweight=fontWeight)
                    ax.tick_params(axis='x', labelsize=labelFontSize, grid_alpha=1)
                    ax.tick_params(axis='y', labelsize=labelFontSize, grid_alpha=1)
                    ax.set_yticklabels(y, fontsize=labelFontSize, fontweight=fontWeight)
                    ax.set_xticklabels(x, fontsize=labelFontSize, fontweight=fontWeight)
                    pyplot.gca().xaxis.set_major_formatter(StrMethodFormatter('{x:,.0f}'))
                    pyplot.gca().yaxis.set_major_formatter(StrMethodFormatter('{x:,.0f}'))
                    ax.grid(which='major', linestyle=':', color='gray')
    
                    # Add Column Means to the Plot
                    ax = pyplot.subplot2grid((4, 4), (3, 0), colspan=3)
                    for index, color_plane in enumerate(color_planes):
                        col_means = mean(color_plane, axis=0)
                        x = arange(0, col_means.size * 2, 2)
                        y = col_means
                        pyplot.plot(x, y, Bayer[index], linewidth=lineWidthSize)
                    ax.autoscale(True, 'both', True)
                    ax.set_title("Column Means", fontsize=titleFontSize, fontweight=fontWeight)
                    ax.tick_params(axis='x', labelsize=labelFontSize, grid_alpha=1)
                    ax.tick_params(axis='y', labelsize=labelFontSize, grid_alpha=1)
                    ax.set_yticklabels(y, fontsize=labelFontSize, fontweight=fontWeight)
                    ax.set_xticklabels(x, fontsize=labelFontSize, fontweight=fontWeight)
                    pyplot.gca().xaxis.set_major_formatter(StrMethodFormatter('{x:,.0f}'))
                    pyplot.gca().yaxis.set_major_formatter(StrMethodFormatter('{x:,.0f}'))
                    ax.grid(which='major', linestyle=':', color='gray')
    
                    # Add Histogram to Plot
                    ax = pyplot.subplot2grid((4, 4), (3, 3))
                    for index, color_plane in enumerate(color_planes):
                        if amax(color_plane) == amin(color_plane): # Test Patterns
                            maxHbin = amax(color_plane) * 2
                            if maxHbin == 0:
                                maxHbin = 1
                            minHbin = 0
                        else:
                            maxHbin = amax(color_plane)
                            minHbin = amin(color_plane)
                        histo = histogram(color_plane, (maxHbin - minHbin))
                        x = histo[1][1:]
                        y = histo[0]
                        pyplot.plot(x, y, Bayer[index], linewidth=lineWidthSize)
                    ax.autoscale(True, 'both', True)
                    ax.set_title("Histogram", fontsize=titleFontSize, fontweight=fontWeight)
                    ax.tick_params(axis='x', labelsize=labelFontSize, grid_alpha=1)
                    ax.tick_params(axis='y', labelsize=labelFontSize, grid_alpha=1)
                    ax.set_yticklabels(y, fontsize=labelFontSize, fontweight=fontWeight)
                    ax.set_xticklabels(x, fontsize=labelFontSize, fontweight=fontWeight)
                    pyplot.gca().xaxis.set_major_formatter(StrMethodFormatter('{x:,.0f}'))
                    pyplot.gca().yaxis.set_major_formatter(StrMethodFormatter('{x:,.0f}'))
                    ax.grid(which='major', linestyle=':', color='gray')
    
                    # Save plot & png
                    pyplot.suptitle('Image = ' + header_name, fontsize=titleFontSize, fontweight=fontWeight)
                    pyplot.subplots_adjust(top=0.92)
                    new_root = imgDir + r"\movie"
                    new_filename = str(os.path.join(new_root, imgFileName))
                    vrg_filename = new_filename[:-4] + "_ext_analysis.png"
                    if not os.path.exists(new_root):
                        os.makedirs(new_root)
                    pyplot.savefig(vrg_filename)
                    pyplot.clf()
                    if showPlt == True:
                        image = Image.open(vrg_filename)
                        image.show()
                    document.add_heading('External Image Analysis', level=2)
                    document.add_heading(imgFileName, level=3)
                    document.add_picture(vrg_filename, width=Inches(imgWidth))  # Add Image to report

    except:
        document.add_heading("Failed To Add_External_Image_Analysis: ", level=2)
        document.add_heading("imgDir Used: " + imgDir, level=3)
        document.add_heading("imgFileName Used: " + imgFileName, level=3)

def Add_Image_Analysis(dataframe, imgNum, document, showPlt):
    try:
        i0 = 'ImageLinkDir1'
        i1 = 'ImageLink1'
    
        # Get the image stats from the CSV file
        numDataCols = 3
        labelFontSize = 20 # Plot lable Fontsize
        titleFontSize = 26 # Title Fontsize
        lineWidthSize = 5 # Thickness of the plot lines
        fontWeight = 'bold' # Fontweight
        imgWidth = 7.25 # size of img (inches)
        df = dataframe
    
        imgNum = imgNum - 1 # Convert to dataframe step
        imgDir = df[i0].loc[imgNum]
        imgFileName = df[i1].loc[imgNum]
        imgLinkLen = len(df[i0])
    
        if imgNum >= 0 and imgNum <= imgLinkLen:
            for file in os.scandir(imgDir):
                if file.name.endswith(".png") or file.name.endswith(".PNG"):
                    if file.name == imgFileName:
                        imgFilePath = str(os.path.join(imgDir, imgFileName))
                        print(imgFilePath)
                        color_map = dict(All='k', Red='r', GreenRed='g', GreenBlue='g--', Blue='b--')
                        Bayer = list()
                        Bayer.append(color_map['GreenRed'])
                        Bayer.append(color_map['Red'])
                        Bayer.append(color_map['Blue'])
                        Bayer.append(color_map['GreenBlue'])
                        numpy_array, bit_depth = load_png_to_numpy_array(imgFilePath)
                        analysis_array = numpy_array[0::1, 0::1] #[32:-32:1, 256::1] # row start, row end, column start, column end
                        display_array = histogram_stretch(analysis_array, bit_depth)
                        normalized_array = normalize_array_to_one(display_array, bit_depth)
                        color_planes = get_color_planes(analysis_array)
                        header_name = imgFileName
                        fig = pyplot.figure(1)
                        fig.set_size_inches(40.96, 30.98, forward=True)
    
                        # NEW CODE
                        # Add the Image to the Plot
                        ax = pyplot.subplot2grid((4, 4), (0, 0), colspan=3, rowspan=3)
                        imgplot = ax.imshow(display_array, cmap=cm.Greys_r, vmin=amin(display_array), vmax=amax(display_array))
                        imgplot.set_interpolation('bilinear')
                        ax.autoscale(True, 'both', True)
                        ax.xaxis.set_visible(False)
                        ax.yaxis.set_visible(False)
    
                        # Add the Row Means to the Plot
                        ax = pyplot.subplot2grid((4, 4), (0, 3), rowspan=3)
                        for index, color_plane in enumerate(color_planes):
                            row_means = mean(color_plane, axis=1)
                            x = arange(0, row_means.size * 2, 2)
                            y = row_means
                            pyplot.plot(y, x, Bayer[index], linewidth=lineWidthSize)
                            col_means = mean(color_plane, axis=0)
                        ax.invert_yaxis()
                        ax.autoscale(True, 'both', True)
                        ax.set_title("Row Means", fontsize=titleFontSize, fontweight=fontWeight)
                        ax.tick_params(axis='x', labelsize=labelFontSize, grid_alpha=1)
                        ax.tick_params(axis='y', labelsize=labelFontSize, grid_alpha=1)
                        ax.set_yticklabels(y, fontsize=labelFontSize, fontweight=fontWeight)
                        ax.set_xticklabels(x, fontsize=labelFontSize, fontweight=fontWeight)
                        pyplot.gca().xaxis.set_major_formatter(StrMethodFormatter('{x:,.0f}'))
                        pyplot.gca().yaxis.set_major_formatter(StrMethodFormatter('{x:,.0f}'))
                        ax.grid(which='major', linestyle=':', color='gray')
    
                        # Add Column Means to the Plot
                        ax = pyplot.subplot2grid((4, 4), (3, 0), colspan=3)
                        for index, color_plane in enumerate(color_planes):
                            col_means = mean(color_plane, axis=0)
                            x = arange(0, col_means.size * 2, 2)
                            y = col_means
                            pyplot.plot(x, y, Bayer[index], linewidth=lineWidthSize)
                        ax.autoscale(True, 'both', True)
                        ax.set_title("Column Means", fontsize=titleFontSize, fontweight=fontWeight)
                        ax.tick_params(axis='x', labelsize=labelFontSize, grid_alpha=1)
                        ax.tick_params(axis='y', labelsize=labelFontSize, grid_alpha=1)
                        ax.set_yticklabels(y, fontsize=labelFontSize, fontweight=fontWeight)
                        ax.set_xticklabels(x, fontsize=labelFontSize, fontweight=fontWeight)
                        pyplot.gca().xaxis.set_major_formatter(StrMethodFormatter('{x:,.0f}'))
                        pyplot.gca().yaxis.set_major_formatter(StrMethodFormatter('{x:,.0f}'))
                        ax.grid(which='major', linestyle=':', color='gray')
    
                        # Add Histogram to Plot
                        ax = pyplot.subplot2grid((4, 4), (3, 3))
                        for index, color_plane in enumerate(color_planes):
                            if amax(color_plane) == amin(color_plane): # Test Patterns
                                maxHbin = amax(color_plane) * 2
                                if maxHbin == 0:
                                    maxHbin = 1
                                minHbin = 0
                            else:
                                maxHbin = amax(color_plane)
                                minHbin = amin(color_plane)
                            histo = histogram(color_plane, (maxHbin - minHbin))
                            x = histo[1][1:]
                            y = histo[0]
                            pyplot.plot(x, y, Bayer[index], linewidth=lineWidthSize)
                        ax.autoscale(True, 'both', True)
                        ax.set_title("Histogram", fontsize=titleFontSize, fontweight=fontWeight)
                        ax.tick_params(axis='x', labelsize=labelFontSize, grid_alpha=1)
                        ax.tick_params(axis='y', labelsize=labelFontSize, grid_alpha=1)
                        ax.set_yticklabels(y, fontsize=labelFontSize, fontweight=fontWeight)
                        ax.set_xticklabels(x, fontsize=labelFontSize, fontweight=fontWeight)
                        pyplot.gca().xaxis.set_major_formatter(StrMethodFormatter('{x:,.0f}'))
                        pyplot.gca().yaxis.set_major_formatter(StrMethodFormatter('{x:,.0f}'))
                        ax.grid(which='major', linestyle=':', color='gray')
    
                        # Save plot & png
                        pyplot.suptitle('Image = ' + header_name, fontsize=titleFontSize, fontweight=fontWeight)
                        pyplot.subplots_adjust(top=0.92)
                        new_root = imgDir + r"\movie"
                        new_filename = str(os.path.join(new_root, imgFileName))
                        vrg_filename = new_filename[:-4] + "_analysis.png"
                        if not os.path.exists(new_root):
                            os.makedirs(new_root)
                        pyplot.savefig(vrg_filename)
                        pyplot.clf()
                        if showPlt == True:
                            image = Image.open(vrg_filename)
                            image.show()
                        document.add_heading('Image Analysis', level=2)
                        document.add_heading(imgFileName, level=3)
                        document.add_picture(vrg_filename, width=Inches(imgWidth))  # Add Image to report
    except:
        document.add_heading("Failed To Add_Image_Analysis: ", level=2)
        document.add_heading("imgNum Used: " + imgNum, level=3)
        for x in range(1, numDataCols):  # 1 to 4
            if eval("i" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("i" + str(x)), level=3)  # Add columns found
                if imgNum in df[eval("i" + str(x))].unique():
                    document.add_heading("imgNum Found: " + imgNum + " in " + eval("i" + str(x)),  level=3)  # Add Groupby found
                else:
                    document.add_heading("imgNum Not Found: " + imgNum + " in " + eval("i" + str(x)), level=3)  # Add Groupby not found
            else:
                document.add_heading("Column Not Found: " + eval("i" + str(x)), level=3)  # Add columns not found

def Add_Image_Analysis_Info(dataframe, imgNum, document, showPlt):
    try:
        i0 = 'ImageLinkDir1'
        i1 = 'ImageLink1'
        d1 = 'Mean_GreenR'
        d2 = 'Mean_Red'
        d3 = 'Mean_GreenB'
        d4 = 'Mean_Blue'
        d5 = 'StdDev_GreenR'
        d6 = 'StdDev_Red'
        d7 = 'StdDev_GreenB'
        d8 = 'StdDev_Blue'
    
        # Get the image stats from the CSV file
        numDataCols = 3
        numDataCols2 = 9
        labelFontSize = 20 # Plot lable Fontsize
        titleFontSize = 26 # Title Fontsize
        txtFontSize = 20 # Text Fontsize
        lineWidthSize = 5 # Thickness of the plot lines
        fontWeight = 'bold' # Fontweight
        imgWidth = 7.25 # size of img (inches)
        fntColor = (0, 102, 204)
        fnt = ImageFont.truetype('C:\Windows\Fonts\\ariblk.ttf', size=80)
    
        df = dataframe
    
        imgNum = imgNum - 1 # Convert to dataframe step
        imgDir = df[i0].loc[imgNum]
        imgFileName = df[i1].loc[imgNum]
        imgLinkLen = len(df[i0])
    
        if imgNum > 0 and imgNum <= imgLinkLen:
            for file in os.scandir(imgDir):
                if file.name.endswith(".png") or file.name.endswith(".PNG"):
                    if file.name == imgFileName:
                        imgFilePath = str(os.path.join(imgDir, imgFileName))
                        color_map = dict(All='k', Red='r', GreenRed='g', GreenBlue='g--', Blue='b--')
                        Bayer = list()
                        Bayer.append(color_map['GreenRed'])
                        Bayer.append(color_map['Red'])
                        Bayer.append(color_map['Blue'])
                        Bayer.append(color_map['GreenBlue'])
                        numpy_array, bit_depth = load_png_to_numpy_array(imgFilePath)
                        analysis_array = numpy_array[32:-32:1, 256::1]
                        display_array = histogram_stretch(analysis_array, bit_depth)
                        normalized_array = normalize_array_to_one(display_array, bit_depth)
                        color_planes = get_color_planes(analysis_array)
                        header_name = imgFileName
                        fig = pyplot.figure(1)
                        fig.set_size_inches(40.96, 30.98, forward=True)
    
                        # NEW CODE
                        # Add the Image to the Plot
                        ax = pyplot.subplot2grid((4, 4), (0, 0), colspan=3, rowspan=3)
                        imgplot = ax.imshow(display_array, cmap=cm.Greys_r, vmin=amin(display_array), vmax=amax(display_array))
                        imgplot.set_interpolation('bilinear')
                        ax.autoscale(True, 'both', True)
                        ax.xaxis.set_visible(False)
                        ax.yaxis.set_visible(False)
                        ax.text(10, 100, d1 + ' = ' + df[d1].loc[imgNum].astype(str), fontsize=txtFontSize)
                        ax.text(10, 200, d2 + ' = ' + df[d2].loc[imgNum].astype(str), fontsize=txtFontSize)
                        ax.text(10, 300, d3 + ' = ' + df[d3].loc[imgNum].astype(str), fontsize=txtFontSize)
                        ax.text(10, 400, d4 + ' = ' + df[d4].loc[imgNum].astype(str), fontsize=txtFontSize)
                        ax.text(10, 500, d5 + ' = ' + df[d5].loc[imgNum].astype(str), fontsize=txtFontSize)
                        ax.text(10, 600, d6 + ' = ' + df[d6].loc[imgNum].astype(str), fontsize=txtFontSize)
                        ax.text(10, 700, d7 + ' = ' + df[d7].loc[imgNum].astype(str), fontsize=txtFontSize)
                        ax.text(10, 800, d8 + ' = ' + df[d8].loc[imgNum].astype(str), fontsize=txtFontSize)
    
                        # Add the Row Means to the Plot
                        ax = pyplot.subplot2grid((4, 4), (0, 3), rowspan=3)
                        for index, color_plane in enumerate(color_planes):
                            row_means = mean(color_plane, axis=1)
                            x = arange(0, row_means.size * 2, 2)
                            y = row_means
                            pyplot.plot(y, x, Bayer[index], linewidth=lineWidthSize)
                            col_means = mean(color_plane, axis=0)
                        ax.invert_yaxis()
                        ax.autoscale(True, 'both', True)
                        ax.set_title("Row Means", fontsize=titleFontSize, fontweight=fontWeight)
                        ax.tick_params(axis='x', labelsize=labelFontSize, grid_alpha=1)
                        ax.tick_params(axis='y', labelsize=labelFontSize, grid_alpha=1)
                        ax.set_yticklabels(y, fontsize=labelFontSize, fontweight=fontWeight)
                        ax.set_xticklabels(x, fontsize=labelFontSize, fontweight=fontWeight)
                        pyplot.gca().xaxis.set_major_formatter(StrMethodFormatter('{x:,.0f}'))
                        pyplot.gca().yaxis.set_major_formatter(StrMethodFormatter('{x:,.0f}'))
                        ax.grid(which='major', linestyle=':', color='gray')
    
                        # Add Column Means to the Plot
                        ax = pyplot.subplot2grid((4, 4), (3, 0), colspan=3)
                        for index, color_plane in enumerate(color_planes):
                            col_means = mean(color_plane, axis=0)
                            x = arange(0, col_means.size * 2, 2)
                            y = col_means
                            pyplot.plot(x, y, Bayer[index], linewidth=lineWidthSize)
                        ax.autoscale(True, 'both', True)
                        ax.set_title("Column Means", fontsize=titleFontSize, fontweight=fontWeight)
                        ax.tick_params(axis='x', labelsize=labelFontSize, grid_alpha=1)
                        ax.tick_params(axis='y', labelsize=labelFontSize, grid_alpha=1)
                        ax.set_yticklabels(y, fontsize=labelFontSize, fontweight=fontWeight)
                        ax.set_xticklabels(x, fontsize=labelFontSize, fontweight=fontWeight)
                        pyplot.gca().xaxis.set_major_formatter(StrMethodFormatter('{x:,.0f}'))
                        pyplot.gca().yaxis.set_major_formatter(StrMethodFormatter('{x:,.0f}'))
                        ax.grid(which='major', linestyle=':', color='gray')
    
                        # Add Histogram to Plot
                        ax = pyplot.subplot2grid((4, 4), (3, 3))
                        for index, color_plane in enumerate(color_planes):
                            if amax(color_plane) == amin(color_plane): # Test Patterns
                                maxHbin = amax(color_plane) * 2
                                if maxHbin == 0:
                                    maxHbin = 1
                                minHbin = 0
                            else:
                                maxHbin = amax(color_plane)
                                minHbin = amin(color_plane)
                            histo = histogram(color_plane, (maxHbin - minHbin))
                            x = histo[1][1:]
                            y = histo[0]
                            pyplot.plot(x, y, Bayer[index], linewidth=lineWidthSize)
                        ax.autoscale(True, 'both', True)
                        ax.set_title("Histogram", fontsize=titleFontSize, fontweight=fontWeight)
                        ax.tick_params(axis='x', labelsize=labelFontSize, grid_alpha=1)
                        ax.tick_params(axis='y', labelsize=labelFontSize, grid_alpha=1)
                        ax.set_yticklabels(y, fontsize=labelFontSize, fontweight=fontWeight)
                        ax.set_xticklabels(x, fontsize=labelFontSize, fontweight=fontWeight)
                        pyplot.gca().xaxis.set_major_formatter(StrMethodFormatter('{x:,.0f}'))
                        pyplot.gca().yaxis.set_major_formatter(StrMethodFormatter('{x:,.0f}'))
                        ax.grid(which='major', linestyle=':', color='gray')
    
                        # Save plot & png
                        pyplot.suptitle('Image = ' + header_name, fontsize=titleFontSize, fontweight=fontWeight)
                        pyplot.subplots_adjust(top=0.92)
                        new_root = imgDir + r"\movie"
                        new_filename = str(os.path.join(new_root, imgFileName))
                        vrg_filename = new_filename[:-4] + "_analysis.png"
                        if not os.path.exists(new_root):
                            os.makedirs(new_root)
                        pyplot.savefig(vrg_filename)
                        pyplot.clf()
                        if showPlt == True:
                            image = Image.open(vrg_filename)
                            image.show()
                        document.add_heading('Image Analysis', level=2)
                        document.add_heading(imgFileName, level=3)
                        document.add_picture(vrg_filename, width=Inches(imgWidth))  # Add Image to report
    except:
        document.add_heading("Failed To Add_Image_Analysis: ", level=2)
        document.add_heading("imgNum Used: " + imgNum, level=3)
        for x in range(1, numDataCols):  # 1 to 4
            if eval("i" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("i" + str(x)), level=3)  # Add columns found
                if imgNum in df[eval("i" + str(x))].unique():
                    document.add_heading("imgNum Found: " + imgNum + " in " + eval("i" + str(x)),  level=3)  # Add Groupby found
                else:
                    document.add_heading("imgNum Not Found: " + imgNum + " in " + eval("i" + str(x)), level=3)  # Add Groupby not found
            else:
                document.add_heading("Column Not Found: " + eval("i" + str(x)), level=3)  # Add columns not found
        for x in range(1, numDataCols2):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found

def Add_Image(dataframe, imgNum, document, showPlt):
    try:
        i0 = 'ImageLinkDir1'
        i1 = 'ImageLink1'

        imgWidth = 7.25  # size of img (inches)
        numDataCols = 3
        df = dataframe
    
        imgNum = imgNum - 1 # Convert to dataframe step
        imgDir = df[i0].loc[imgNum]
        imgFileName = df[i1].loc[imgNum]
        imgLinkLen = len(df[i0])
    
        if imgNum > 0 and imgNum <= imgLinkLen:
            for file in os.scandir(imgDir):
                if file.name.endswith(".png") or file.name.endswith(".PNG"):
                    if file.name == imgFileName:
                        imgFilePath = str(os.path.join(imgDir, imgFileName))
                        if showPlt == True:
                            image = Image.open(imgFilePath)
                            image.show()
                        document.add_heading('Image', level=2)
                        document.add_heading(imgFileName, level=3)
                        document.add_picture(imgFilePath, width=Inches(imgWidth))  # Add Image to report

    except:
        document.add_heading("Failed To Add_Image_Analysis: ", level=2)
        document.add_heading("imgNum Used: " + imgNum, level=3)
        for x in range(1, numDataCols):  # 1 to 4
            if eval("i" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("i" + str(x)), level=3)  # Add columns found
                if imgNum in df[eval("i" + str(x))].unique():
                    document.add_heading("imgNum Found: " + imgNum + " in " + eval("i" + str(x)), level=3)  # Add Groupby found
                else:
                    document.add_heading("imgNum Not Found: " + imgNum + " in " + eval("i" + str(x)), level=3)  # Add Groupby not found
            else:
                document.add_heading("Column Not Found: " + eval("i" + str(x)), level=3)  # Add columns not found

def Add_Image_Info(dataframe, imgNum, document, showPlt):
    try:
        i0 = 'ImageLinkDir1'
        i1 = 'ImageLink1'
    
        d1 = 'Mean_GreenR'
        d2 = 'Mean_Red'
        d3 = 'Mean_GreenB'
        d4 = 'Mean_Blue'
        d5 = 'StdDev_GreenR'
        d6 = 'StdDev_Red'
        d7 = 'StdDev_GreenB'
        d8 = 'StdDev_Blue'

        numDataCols = 3
        numDataCols2 = 9
        imgWidth = 7.25  # size of img (inches)
        fntColor = (0, 102, 204)
        fnt = ImageFont.truetype('C:\Windows\Fonts\\ariblk.ttf', size=80)
    
        df = dataframe
        imgNum = imgNum - 1 # Convert to dataframe step
        imgDir = df[i0].loc[imgNum]
        imgFileName = df[i1].loc[imgNum]
        imgLinkLen = len(df[i0])
    
        if imgNum > 0 and imgNum <= imgLinkLen:
            for file in os.scandir(imgDir):
                if file.name.endswith(".png") or file.name.endswith(".PNG"):
                    if file.name == imgFileName:
                        imgFilePath = str(os.path.join(imgDir, imgFileName))
                        img = Image.open(imgFilePath)
                        if img.mode != "RGB":
                            img = img.convert("RGB")
                        draw = ImageDraw.Draw(img)
                        draw.text((10, 100), 'Image = ' + imgFileName, fill=fntColor, font=fnt)
                        draw.text((10, 200), d1 + ' = ' + df[d1].loc[imgNum].astype(str), fill=fntColor, font=fnt)
                        draw.text((10, 300), d2 + ' = ' + df[d2].loc[imgNum].astype(str), fill=fntColor, font=fnt)
                        draw.text((10, 400), d3 + ' = ' + df[d3].loc[imgNum].astype(str), fill=fntColor, font=fnt)
                        draw.text((10, 500), d4 + ' = ' + df[d4].loc[imgNum].astype(str), fill=fntColor, font=fnt)
                        draw.text((10, 600), d5 + ' = ' + df[d5].loc[imgNum].astype(str), fill=fntColor, font=fnt)
                        draw.text((10, 700), d6 + ' = ' + df[d6].loc[imgNum].astype(str), fill=fntColor, font=fnt)
                        draw.text((10, 800), d7 + ' = ' + df[d7].loc[imgNum].astype(str), fill=fntColor, font=fnt)
                        draw.text((10, 900), d8 + ' = ' + df[d8].loc[imgNum].astype(str), fill=fntColor, font=fnt)
                        vrg_filename = imgFilePath[:-4] + "_info.png"
                        img = img.convert("L") # convert back to grayscale
                        img.save(vrg_filename)
                        img.close()
    
                        if showPlt == True:
                            newImg = Image.open(vrg_filename)
                            newImg.show()
                        document.add_heading('Image Info', level=2)
                        document.add_heading(imgFileName, level=3)
                        document.add_picture(vrg_filename, width=Inches(imgWidth))  # Add Image to report
    except:
        document.add_heading("Failed To Add_Image_Analysis: ", level=2)
        document.add_heading("imgNum Used: " + imgNum, level=3)
        for x in range(1, numDataCols):  # 1 to 4
            if eval("i" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("i" + str(x)), level=3)  # Add columns found
                if imgNum in df[eval("i" + str(x))].unique():
                    document.add_heading("imgNum Found: " + imgNum + " in " + eval("i" + str(x)),  level=3)  # Add Groupby found
                else:
                    document.add_heading("imgNum Not Found: " + imgNum + " in " + eval("i" + str(x)), level=3)  # Add Groupby not found
            else:
                document.add_heading("Column Not Found: " + eval("i" + str(x)), level=3)  # Add columns not found
        for x in range(1, numDataCols2):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found