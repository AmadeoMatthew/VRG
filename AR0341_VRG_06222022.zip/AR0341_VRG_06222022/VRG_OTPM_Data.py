import matplotlib
import matplotlib.pyplot as plt
from matplotlib import pyplot
from docx import Document
from docx.shared import Inches
from docx.shared import Pt
from tkinter import *
from tkinter import filedialog
from tkinter import messagebox
import numpy as np
import csv
import argparse
import os
import pandas as pd
import pixelcrunch as pc
import fivecentplots as fcp
import bokeh
import sys
import io
import multiprocessing
import VRG_Safety_Data
import VRG_Calculate
import VRG_Data_Frame
import VRG_Doc
import VRG_General_Data
import VRG_Image_Analysis
import VRG_Image_Utils
import VRG_Macro_Data
import VRG_OTPM_Data
import VRG_Pins_Data
import VRG_Power_Data
import VRG_Register_Data
import VRG_Stats_Arr
import VRG_Stats_ArrCenter
import VRG_Stats_ArrQuad1
import VRG_Stats_ArrQuad2
import VRG_Stats_ArrQuad3
import VRG_Stats_ArrQuad4
import VRG_Stats_ArrRoi1
import VRG_Stats_ArrRoi2
import VRG_Stats_ArrRoi3
import VRG_Stats_ArrRoi4
import VRG_Stats_ArrRoi5
import VRG_Stats_ArrRoi6
import VRG_Stats_ArrRoi7
import VRG_Stats_ArrRoi8
import VRG_Stats_ArrRoi9
import VRG_Stats_DBLC
import VRG_Stats_Frame
import VRG_Stats_Lag
import VRG_Stats_RNC
import VRG_Stats_Tilt
import VRG_Tempsensor_Data
import VRG_Reports
import time

'''
OTPM Data
'''
def OTPM_Initial_Check_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'Initial_Check OTPM_MANUAL_ADDR'
        d2 = 'Initial_Check OTPM_DATA_MANUAL_H'
        d3 = 'Initial_Check OTPM_DATA_MANUAL_L'
        d4 = 'Initial_Check OTPM_DATA_MANUAL_EX'

        figTitle = 'OTPM_Initial_Check_'
        ylabel = 'RegVal (Dec)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def OTPM_Manual_Read_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        df = dataFrame
        d1 = 'Manual_Read OTPM_DATA_MANUAL'
        d_cols = [x for x in df.columns[df.columns.str.contains(d1)]]

        figTitle = 'OTPM Manual Read Data'
        ylabel = 'RegVal (Dec)'
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in d_cols:
                fcp.plot(df, x='Step', y=x, title=x, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + x + '_' + timestamp + '.png')
                document.add_heading(x, level=3)
                document.add_picture(pltPath + x + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in d_cols:  # 1 to 4
                fcp.plot(df, x='Step', y=x, title=x, legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + x + '_' + timestamp + '.png')
                document.add_heading(x, level=3)
                document.add_picture(pltPath + x + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in d_cols:  # 1 to 4
            if x in df.columns:
                document.add_heading("Column Found: " + x, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + x, level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def OTPM_Manual_Read_Status_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        df = dataFrame
        d1 = 'Manual_Read OTPM_STATUS'
        d_cols = [x for x in df.columns[df.columns.str.contains(d1)]]

        figTitle = 'Manual Read OTPM_STATUS Data'
        ylabel = 'RegVal (Dec)'
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in d_cols:
                fcp.plot(df, x='Step', y=x, title=x, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + x + '_' + timestamp + '.png')
                document.add_heading(x, level=3)
                document.add_picture(pltPath + x + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in d_cols:  # 1 to 4
                fcp.plot(df, x='Step', y=x, title=x, legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + x + '_' + timestamp + '.png')
                document.add_heading(x, level=3)
                document.add_picture(pltPath + x + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in d_cols:  # 1 to 4
            if x in df.columns:
                document.add_heading("Column Found: " + x, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + x, level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def OTPM_Auto_Read_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        df = dataFrame
        d1 = 'OTPM_DATA_'
        d_cols = [x for x in df.columns[df.columns.str.contains(d1)]]
        autoRead = []
        for d in d_cols:
            if 'Manual_Read' in d: # remove all manual read columns
                pass
            elif 'Initial_Check' in d:
                pass
            else:
                autoRead.append(d)

        figTitle = 'OTPM Auto Read Data'
        ylabel = 'RegVal (Dec)'
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in autoRead:
                fcp.plot(df, x='Step', y=x, title=x, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + x + '_' + timestamp + '.png')
                document.add_heading(x, level=3)
                document.add_picture(pltPath + x + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in autoRead:  # 1 to 4
                fcp.plot(df, x='Step', y=x, title=x, legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + x + '_' + timestamp + '.png')
                document.add_heading(x, level=3)
                document.add_picture(pltPath + x + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in autoRead:
            if x in df.columns:
                document.add_heading("Column Found: " + x, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + x, level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def OTPM_Auto_Read_Status_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        df = dataFrame
        d1 = 'Auto_Read OTPM_STATUS'
        d_cols = [x for x in df.columns[df.columns.str.contains(d1)]]
        autoRead = []
        for d in d_cols:
            if 'Manual_Read' in d: # remove all manual read columns
                pass
            elif 'Initial_Check' in d:
                pass
            else:
                autoRead.append(d)

        figTitle = 'Auto Read OTPM_STATUS Data'
        ylabel = 'RegVal (Dec)'
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in autoRead:
                fcp.plot(df, x='Step', y=x, title=x, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + x + '_' + timestamp + '.png')
                document.add_heading(x, level=3)
                document.add_picture(pltPath + x + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in autoRead:  # 1 to 4
                fcp.plot(df, x='Step', y=x, title=x, legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + x + '_' + timestamp + '.png')
                document.add_heading(x, level=3)
                document.add_picture(pltPath + x + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in autoRead:
            if x in df.columns:
                document.add_heading("Column Found: " + x, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + x, level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def OTPM_Auto_Write_Status_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        df = dataFrame
        d1 = 'Auto_Write OTPM_STATUS'
        d_cols = [x for x in df.columns[df.columns.str.contains(d1)]]
        autoRead = []
        for d in d_cols:
            if 'Manual_Read' in d: # remove all manual read columns
                pass
            elif 'Initial_Check' in d:
                pass
            else:
                autoRead.append(d)

        figTitle = 'Auto Write OTPM_STATUS Data'
        ylabel = 'RegVal (Dec)'
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in autoRead:
                fcp.plot(df, x='Step', y=x, title=x, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + x + '_' + timestamp + '.png')
                document.add_heading(x, level=3)
                document.add_picture(pltPath + x + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in autoRead:  # 1 to 4
                fcp.plot(df, x='Step', y=x, title=x, legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + x + '_' + timestamp + '.png')
                document.add_heading(x, level=3)
                document.add_picture(pltPath + x + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in autoRead:
            if x in df.columns:
                document.add_heading("Column Found: " + x, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + x, level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

'''
EID Data
'''
def EID_Attribute_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        df = dataFrame
        FID = 'FID'

        EID = df[FID].str.split('_', n=6, expand=True)
        df['EID_Lot'] = EID[0]
        df['EID_Wafer'] = EID[1]
        df['EID_X_Position'] = EID[2]
        df['EID_Y_Position'] = EID[3]
        df['EID_C_Feature'] = EID[4]
        df['EID_Design_Rev'] = EID[5]
        df['EID_Fab_ID'] = EID[6]

        df['EID_X_Position'] = df['EID_X_Position'].str.replace('P', '')
        df['EID_X_Position']= df['EID_X_Position'].str.replace('N', '-')
        d1 = 'EID_Lot'
        d2 = 'EID_Wafer'
        d3 = 'EID_X_Position'
        d4 = 'EID_Y_Position'
        d5 = 'EID_C_Feature'
        d6 = 'EID_Design_Rev'
        d7 = 'EID_Fab_ID'


        figTitle = 'EID_Attribute'
        ylabel = 'Value'
        numDataCols = 8  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
