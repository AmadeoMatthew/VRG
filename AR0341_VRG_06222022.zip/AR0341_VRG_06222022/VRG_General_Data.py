import matplotlib
import matplotlib.pyplot as plt
from matplotlib import pyplot
from docx import Document
from docx.shared import Inches
from docx.shared import Pt
from tkinter import *
from tkinter import filedialog
from tkinter import messagebox
import numpy as np
import csv
import argparse
import os
import pandas as pd
import pixelcrunch as pc
import fivecentplots as fcp
import bokeh
import sys
import io
import multiprocessing
import VRG_Safety_Data
import VRG_Calculate
import VRG_Data_Frame
import VRG_Doc
import VRG_General_Data
import VRG_Image_Analysis
import VRG_Image_Utils
import VRG_Macro_Data
import VRG_OTPM_Data
import VRG_Pins_Data
import VRG_Power_Data
import VRG_Register_Data
import VRG_Stats_Arr
import VRG_Stats_ArrCenter
import VRG_Stats_ArrQuad1
import VRG_Stats_ArrQuad2
import VRG_Stats_ArrQuad3
import VRG_Stats_ArrQuad4
import VRG_Stats_ArrRoi1
import VRG_Stats_ArrRoi2
import VRG_Stats_ArrRoi3
import VRG_Stats_ArrRoi4
import VRG_Stats_ArrRoi5
import VRG_Stats_ArrRoi6
import VRG_Stats_ArrRoi7
import VRG_Stats_ArrRoi8
import VRG_Stats_ArrRoi9
import VRG_Stats_DBLC
import VRG_Stats_Frame
import VRG_Stats_Lag
import VRG_Stats_RNC
import VRG_Stats_Tilt
import VRG_Tempsensor_Data
import VRG_Reports
import time

'''
Data Plots
'''
def Data_vs_Data_vs_Data_Contour_Plot(dataFrame, groupBy, document, pltPath, xColumn1, yColumn2, zColumn3, showPlt, **kwargs):
    try:
        d1 = xColumn1
        d2 = yColumn2
        d3 = zColumn3

        figTitle = 'Data_vs_Data_vs_Data_Contour_Plot'
        numDataCols = 4
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each color plane separately & then together
            fcp.contour(df, x=d1, y=d2, z=d3, title=d1 + " vs. " + d2 + " vs. " + d3, show=showPlt, inline=showPlt,
                        cbar=True, filled=True,
                        title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                        legend_font_size=legFontSize, legend_marker_size=legFontSize,
                        **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + " vs. " + d2, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each color plane separately & then together
            fcp.contour(df, x=d1, y=d2, z=d3, title=d1 + " vs. " + d2 + " vs. " + d3, show=showPlt, cbar=True,
                        filled=True,
                        inline=showPlt,
                        row=groupBy, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                        label_y_font_size=yFontsize,
                        legend_font_size=legFontSize, legend_marker_size=legFontSize, **kwargs,
                        filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + " vs. " + d2, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Data_vs_Data_Plot(dataFrame, groupBy, document, pltPath, xColumn1, yColumn2, showPlt, **kwargs):
    try:
        d1 = xColumn1
        d2 = yColumn2

        figTitle = 'Data_Vs_Data'
        ylabel1 = xColumn1
        ylabel2 = yColumn2
        numDataCols = 3
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each color plane separately & then together
            fcp.plot(df, x=d1, y=d2, title=d1 + " vs. " + d2, show=showPlt, inline=showPlt,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + " vs. " + d2, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each color plane separately & then together
            fcp.plot(df, x=d1, y=d2, title=d1 + " vs. " + d2, show=showPlt, inline=showPlt, legend=groupBy,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + " vs. " + d2, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Data_vs_Data_vs_Step_Plot(dataFrame, groupBy, document, pltPath, column1, column2, showPlt, **kwargs):
    try:
        d1 = column1
        d2 = column2

        figTitle = 'Data_vs_Data_vs_Step'
        numDataCols = 3
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=[d1, d2], title=figTitle, show=showPlt, inline=showPlt, twin_x=True,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + d2 + '_' + timestamp + '.png')
            document.add_heading(d1 + ' vs. ' + d2, level=3)
            document.add_picture(pltPath + d1 + '_' + d2 + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=[d1, d2], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     twin_x=True,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + d2 + '_' + timestamp + '.png')
            document.add_heading(d1 + ' vs. ' + d2, level=3)
            document.add_picture(pltPath + d1 + '_' + d2 + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Data_vs_Step_Plot(dataFrame, groupBy, document, pltPath, column, showPlt, **kwargs):
    try:
        d1 = column

        figTitle = 'Data_Vs_Step'
        ylabel = column
        numDataCols = 2
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_heading(d1 + ' vs. Step', level=3)
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, legend=groupBy, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_heading(d1 + ' vs. Step', level=3)
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found


'''
Registers vs Timing Data
'''
def Reg_vs_Sensor_FPS_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'Sensor_FPS'

        figTitle = 'Reg_vs_Sensor_FPS'
        xlabel = register
        ylabel = 'Frames/Sec'
        numDataCols = 2
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each color plane separately & then together
            fcp.plot(df, x=register, y=d1, title=d1, show=showPlt, inline=showPlt, label_x=xlabel, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1, level=3)
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each color plane separately & then together
            fcp.plot(df, x=register, y=d1, title=d1, legend=groupBy, show=showPlt, inline=showPlt, label_x=xlabel,
                     label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1, level=3)
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_FrameTime_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'FrameTime(s)'

        figTitle = 'Reg_vs_FrameTime'
        xlabel = register
        ylabel = 'FrameTime(s)'
        numDataCols = 2
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each color plane separately & then together
            fcp.plot(df, x=register, y=d1, title=d1, show=showPlt, inline=showPlt, label_x=xlabel, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1, level=3)
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each color plane separately & then together
            fcp.plot(df, x=register, y=d1, title=d1, legend=groupBy, show=showPlt, inline=showPlt, label_x=xlabel,
                     label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1, level=3)
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_PLL_Clock_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'Ext Clk (MHz)'
        d2 = 'PFD (MHz)'
        d3 = 'VCO (MHz)'
        d4 = 'VtPixClk (MHz)'
        d5 = 'OpPixClk (MHz)'

        figTitle = 'Reg_vs_PLL_Clock_Frequencies'
        xlabel = register
        ylabel = 'MHz'
        numDataCols = 6  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        # df[d2] = df[d2].astype(str).str.extract('(\d+)', expand=False).astype(float)  # Remove MHz off the float value
        # df[d3] = df[d3].astype(str).str.extract('(\d+)', expand=False).astype(float)  # Remove MHz off the float value
        # df[d4] = df[d4].astype(str).str.extract('(\d+)', expand=False).astype(float)  # Remove MHz off the float value
        # df[d5] = df[d5].astype(str).str.extract('(\d+)', expand=False).astype(float)  # Remove MHz off the float value

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 8
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 8
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_I2C_Status_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'I2C Status'

        figTitle = 'Reg_vs_I2C_Status'
        xlabel = register
        ylabel = 'Status (OK=1, Fail=0)'
        numDataCols = 2
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        df[d1] = df[d1].eq('OK').mul(1)  # Replace OK with 1, Fail with 0

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each color plane separately & then together
            fcp.plot(df, x=register, y=d1, title=d1, show=showPlt, inline=showPlt, label_x=xlabel, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1, level=3)
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each color plane separately & then together
            fcp.plot(df, x=register, y=d1, title=d1, legend=groupBy, show=showPlt, inline=showPlt, label_x=xlabel,
                     label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1, level=3)
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

'''
DVM General Data
'''

def General_Data_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'FRAME_LENGTH_LINES_'
        d2 = 'LINE_LENGTH_PCK_'
        d3 = 'SMIA_TEST'
        d4 = 'SMIA_TEST__EMB_STATS_EN'
        d5 = 'SMIA_TEST__EMB_DATA_EN'
        d6 = 'SMIA_TEST__EMB_DATA_BTM_EN'
        d7 = 'READ_MODE'
        d8 = 'READ_MODE__STATS_ROWS_NR'
        d9 = 'READ_MODE__EMBED_ROWS_NR'
        d10 = 'DARK_CONTROL'
        d11 = 'DARK_CONTROL__SHOW_DARK_COLS'
        d12 = 'DARK_CONTROL__SHOW_DARK_BORDER_ROWS'
        d13 = 'DARK_CONTROL__SHOW_ATR'
        d14 = 'DARK_CONTRO__SHOW_DTR'
        d15 = 'TEST_ASIL_ROWS'
        d16 = 'TEST_ASIL_ROWS__DTR_TOP_NR'
        d17 = 'PROCESS_DTR'
        d18 = 'PROCESS_DTR__RNC_DTR'
        d19 = 'PROCESS_DTR__RNC_DITHER_DTR'
        d20 = 'PROCESS_DTR__DBLC_DTR'
        d21 = 'PROCESS_DTR__DEF_CORR_DTR'
        d22 = 'PROCESS_DTR__PRE_HDR_GAIN_DTR'
        d23 = 'PROCESS_DTR__PRE_HDR_GAIN_DITHER_DTR'
        d24 = 'PROCESS_DTR__POST_HDR_GAIN_DTR'
        d25 = 'PROCESS_DTR__POST_HDR_GAIN_DITHER_DTR'
        d26 = 'PROCESS_DTR__PEDESTAL_DTR'
        d27 = 'PROCESS_DTR__NOISE_PEDESTAL_DTR'
        d28 = 'PROCESS_DTR__DTR_BARRIER_DITHER'
        d29 = 'ANALOG_TEST_ASIL_ROWS'
        d30 = 'ANALOG_TEST_ASIL_ROWS::ATR_BTM_NR'
        d31 = 'ATR_CHECK_CONTROL'
        d32 = 'CFG_LAG_ROWS__SHOW_LAG_ROWS'
        d33 = 'CFG_LAG_ROWS__LAG_REF_ROWS_NR'
        d34 = 'CFG_LAG_ROWS__LAG_INTG_ROWS_NR'
        d35 = 'TILT_CTRL__TILT_ROWS_NR'
        d36 = 'DELTA_DK_CONTROL__DELTA_DARK_ROWS_NR'
        d37 = 'DARK_CONTROL__ROW_NOISE_CORRECTION_EN'
        d38 = 'DBLC_CONTROL'
        d39 = 'ROW_NOISE_CONTROL'
        d40 = 'CRC_CONTROL_REG'
        d41 = 'CRC_CONTROL_REG__CRC_PER_ROW_FRAME'
        d42 = 'CRC_CONTROL_REG__FR_CRC_EXP'
        d43 = 'CRC_CONTROL_REG__FR_CRC_REGION'
        d44 = 'CRC_CONTROL_REG__CRC_INV_EMB'
        d45 = 'CRC_CONTROL_REG__CRC_INV_DTR'
        d46 = 'CRC_CONTROL_REG__CRC_INV_FRAME'
        d47 = 'CRC_CONTROL_REG__CRC_INV_LINE'
        d48 = 'CRC_CONTROL_REG__EN_CRC_ADDR_MAP'
        d49 = 'DATA_PEDESTAL___DATA_PEDESTAL'
        d50 = 'COARSE_INTEGRATION_TIME_'
        d51 = 'COARSE_INTEGRATION_TIME2'
        d52 = 'EXPOSURE_RATIO__EXPOSURE_RATIO_RATIO_T1_T2'
        d53 = 'EXPOSURE_RATIO__USE_REG'
        d54 = 'EXPOSURE_T1_CLK_U'
        d55 = 'EXPOSURE_T1_CLK_L'
        d56 = 'EXPOSURE_T2_CLK_U'
        d57 = 'EXPOSURE_T2_CLK_L'
        d58 = 'EXPOSURE_T3_CLK_U'
        d59 = 'EXPOSURE_T3_CLK_L'
        d60 = 'EXPOSURE_T4_CLK_U'
        d61 = 'EXPOSURE_T4_CLK_L'

        figTitle = 'General_Data_Plot'
        ylabel = 'RegVal (Dec)'
        numDataCols = 62  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        VRG_Register_Data.Streaming_Register_Plot(df, groupBy, document, pltPath, showPlt)
        VRG_Register_Data.Flip_Mirror_Register_Plot(df, groupBy, document, pltPath, showPlt)
        VRG_Register_Data.Image_Size_Register_Plot(df, groupBy, document, pltPath, showPlt)
        VRG_General_Data.Integration_Time_Plot(df, groupBy, document, pltPath, showPlt)
        VRG_Register_Data.PLL_Register_Plot(df, groupBy, document, pltPath, showPlt)
        VRG_General_Data.PLL_Clock_Plot(df, groupBy, document, pltPath, showPlt)
        VRG_General_Data.FrameTime_Plot(df, groupBy, document, pltPath, showPlt)
        VRG_General_Data.I2C_Status_Plot(df, groupBy, document, pltPath, showPlt)

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found


'''
General PLL, I2C, & Frame Timing Data
'''
def Sensor_FPS_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'Sensor_FPS'

        figTitle = 'Sensor_FPS'
        ylabel = 'Frames/Sec'
        numDataCols = 2
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, legend=groupBy, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def FrameGrabber_FPS_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'FrameGrabber_FPS'

        figTitle = 'FrameGrabber_FPS'
        ylabel = 'Frames/Sec'
        numDataCols = 2
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, legend=groupBy, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def FrameTime_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'FrameTime(s)'

        figTitle = 'FrameTime'
        ylabel = 'FrameTime(s)'
        numDataCols = 2
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, legend=groupBy, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Calc_FPS_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'CalcFramesPerSecond'

        figTitle = 'Calculated_FPS'
        ylabel = 'Frames/Second'
        numDataCols = 2
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, legend=groupBy, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Calc_Sensor_Data_Rate_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'CalcSensorDataRate'

        figTitle = 'Calculated_Sensor_Data_Rate'
        ylabel = 'Mbps'
        numDataCols = 2
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, legend=groupBy, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Calc_ASIC_Data_Rate_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'CalcASICDataRate'

        figTitle = 'Calculated_ASIC_Data_Rate'
        ylabel = 'Mbps'
        numDataCols = 2
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, legend=groupBy, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def PLL_Clock_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'Ext Clk (MHz)'
        d2 = 'PFD (MHz)'
        d3 = 'VCO (MHz)'
        d4 = 'VtPixClk (MHz)'
        d5 = 'OpPixClk (MHz)'

        figTitle = 'PLL Clock Frequencies'
        ylabel = 'MHz'
        numDataCols = 6  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def PLL_GetStatus_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'Ext Clk (MHz)'
        d2 = 'PFD (MHz)'
        d3 = 'VCO (MHz)'
        d4 = 'VtPixClk (MHz)'
        d5 = 'OpPixClk (MHz)'

        figTitle = 'PLL Clock Frequencies'
        ylabel = 'MHz'
        numDataCols = 6  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        df[d2] = df[d2].astype(str).str.extract('(\d+)', expand=False).astype(float)  # Remove MHz off the float value
        df[d3] = df[d3].astype(str).str.extract('(\d+)', expand=False).astype(float)  # Remove MHz off the float value
        df[d4] = df[d4].astype(str).str.extract('(\d+)', expand=False).astype(float)  # Remove MHz off the float value
        df[d5] = df[d5].astype(str).str.extract('(\d+)', expand=False).astype(float)  # Remove MHz off the float value

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def I2C_Status_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'I2C Status'

        figTitle = 'I2C Status'
        ylabel = 'Status (OK=1, Fail=0)'
        numDataCols = 2
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        # Convert objects to int32
        if df[d1].dtype == object:
            if ((df[d1] == 'OK') | (df[d1] == 'Fail')).any():
                df[d1] = df[d1].eq('OK').mul(1)  # Replace OK with 1, Fail with 0

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, legend=groupBy, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def I2C_Speed_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'DVM_5_12_I2C_Speed'

        figTitle = 'I2C_Speed'
        ylabel = 'Freq (kHz)'
        numDataCols = 2
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, legend=groupBy, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

'''
ADC Data
'''

def VoltRampStart_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'VoltRampStart'

        figTitle = 'VoltRampStart'
        ylabel = 'VoltRampStart (V)'
        numDataCols = 2  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, legend=groupBy, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def VoltRampStop_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'VoltRampStop'

        figTitle = 'VoltRampStop'
        ylabel = 'VoltRampStop (V)'
        numDataCols = 2  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, legend=groupBy, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def VoltRampStep_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'VoltRampStep'

        figTitle = 'VoltRampStep'
        ylabel = 'VoltRampStep (V)'
        numDataCols = 2  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, legend=groupBy, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def VoltRampLinesPerStep_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'VoltRampLinesPerStep'

        figTitle = 'VoltRampLinesPerStep'
        ylabel = 'VoltRampLinesPerStep'
        numDataCols = 2  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, legend=groupBy, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def AdcName_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        df = dataFrame

        dc1 = 'AdcName'
        d1 = 'AdcName(col)'
        df[d1] = df[dc1].str.split('=')[1]

        figTitle = 'AdcName'
        ylabel = 'AdcName (Column #)'
        numDataCols = 2  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, legend=groupBy, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

'''
Integration Time Data
'''
def Integration_Time_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'Integration_Time (ms)'

        figTitle = 'Integration_Time'
        ylabel = 'Integration_Time (ms)'
        numDataCols = 2
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, legend=groupBy, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
    for x in range(1, numDataCols):  # 1 to 4
        if eval("d" + str(x)) in df.columns:
            document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
        else:
            document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
    if groupBy == None:
        document.add_heading("Groupby Not Used", level=3)
    elif groupBy != None:
        if groupBy in df.columns:
            document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
        else:
            document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

'''
Light Level Data
'''
def LightLevel_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'Light'

        figTitle = 'Light'
        ylabel = 'Light Level (dec)'
        numDataCols = 2
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, legend=groupBy, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

'''
EID Data
'''
def EID_vs_Die_Table(dataFrame, document):
    try:
        df = dataFrame
        # Column Names in CSV
        d1 = 'Die'
        d2 = 'FID'

        figTitle = 'Die Number vs. FID'
        rowLabel1 = 'DIE #'
        rowLabel2 = 'FID'
        numDataCols = 3  # Number of columns + 1 to loop through (last col + 1)
        tableStyle = 'Table Grid'

        FIDarr = np.asarray(df[d2].unique())  # Obtain array of unique FIDS from CSV files
        document.add_heading(figTitle, level=2)
        table_count = len(document.tables)
        table = document.add_table(rows=len(FIDarr) + 1, cols=2)
        table.style = tableStyle

        for i in range(len(FIDarr)):
            FID_indexer = df[df[d2] == FIDarr[i]].index
            die = np.mean(df.loc[FID_indexer, d1])
            document.tables[table_count].cell(0, 0).text = rowLabel1
            document.tables[table_count].cell(0, 1).text = rowLabel2
            document.tables[table_count].cell(i + 1, 0).text = str(die)
            document.tables[table_count].cell(i + 1, 1).text = str(FIDarr[i])
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found


'''
ODS Data
'''
def ODS_Data_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'Very Bright Pixels'
        d2 = 'Bright Pixels'
        d3 = 'Dark Pixels'
        d4 = 'Very Dark Pixels'
        d5 = 'Very hot Pixels'
        d6 = 'Hot Pixels'

        figTitle = 'ODS_Data'
        ylabel = 'Count (# Pixels)'
        numDataCols = 7  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4, d5, d6], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4, d5, d6], title=figTitle, legend=groupBy, show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def ODS_Threshold_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'frm_mean'
        d2 = 'veryhotthresh'
        d3 = 'hotthresh'
        d4 = 'verybrightthresh'
        d5 = 'brightthresh'
        d6 = 'darkthresh'
        d7 = 'verydarkthresh'

        figTitle = 'ODS Threshold'
        ylabel = 'Threshold (DN)'
        numDataCols = 8  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4, d5, d6, d7], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4, d5, d6, d7], title=figTitle, legend=groupBy, show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found


'''
General Validation Suite Data
'''
def TemperatureSetPoint_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'TemperatureSetPoint'

        figTitle = 'TemperatureSetPoint'
        ylabel = 'TemperatureSetPoint (C)'
        numDataCols = 2  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, legend=groupBy, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def FrameCount_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'FrameCount'

        figTitle = 'FrameCount'
        ylabel = 'FrameCount'
        numDataCols = 2  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, legend=groupBy, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def TestTime_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'TestTime(s)'

        figTitle = 'TestTime'
        ylabel = 'TestTime(s)'
        numDataCols = 2  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, legend=groupBy, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Total_TestTime_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        df = dataFrame
        t1 = 'TestTime(s)'
        df['Total_TestTime(s)'] = df[t1].sum()
        df['Total_TestTime(min)'] = df['Total_TestTime(s)'] / 60
        df['Total_TestTime(hr)'] = df['Total_TestTime(min)'] / 60

        d1 = 'Total_TestTime(s)'
        d2 = 'Total_TestTime(min)'
        d3 = 'Total_TestTime(hr)'

        figTitle = 'Total_TestTime'
        ylabel = 'TestTime(s)'
        ylabel2 = 'TestTime(min)'
        ylabel3 = 'TestTime(hr)'
        numDataCols = 4
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report


        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                if x == 1:
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
                elif x == 2:
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
                elif x == 3:
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel3, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(
                        pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                if x == 1:
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
                elif x == 2:
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
                elif x == 3:
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel3, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Clk_Frequency_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'Clk'

        figTitle = 'Clk'
        ylabel = 'Freq (MHz)'
        numDataCols = 2  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, legend=groupBy, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Frequency_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'Freq'

        figTitle = 'Freq'
        ylabel = 'Freq (MHz)'
        numDataCols = 2  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, legend=groupBy, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def RunNumber_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'RunNo'

        figTitle = 'RunNumber'
        ylabel = 'RunNo (#)'
        numDataCols = 2  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, legend=groupBy, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def FrameWidth_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'FrameWidth'

        figTitle = 'FrameWidth'
        ylabel = 'FrameWidth (cols)'
        numDataCols = 2  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, legend=groupBy, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def FrameHeight_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'FrameHeight'

        figTitle = 'FrameHeight'
        ylabel = 'FrameHeight (rows)'
        numDataCols = 2  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, legend=groupBy, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def FrameBitDepth_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'FrameBitDepth'

        figTitle = 'FrameBitDepth'
        ylabel = 'FrameBitDepth (bits)'
        numDataCols = 2  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, legend=groupBy, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def DroppedFrames_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'DroppedFrames'

        figTitle = 'DroppedFrames'
        ylabel = 'DroppedFrames (#frms)'
        numDataCols = 2  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2) # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, legend=groupBy, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def DefaultRegCheck_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'DefaultRegCheck'

        figTitle = 'DefaultRegCheck'
        ylabel = 'DefaultRegCheck (Pass=1, Fail=0)'
        numDataCols = 2  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        # Convert objects to int32
        if df[d1].dtype == object:
            if ((df[d1] == 'Pass') | (df[d1] == 'Fail')).any():
                df[d1] = df[d1].eq('Pass').mul(1)  # Replace Pass with 1, Fail with 0

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, legend=groupBy, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def FrameCapture_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'FrameCapture'

        figTitle = 'FrameCapture'
        ylabel = 'FrameCapture (Success=1, Fail=0)'
        numDataCols = 2  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        # Convert objects to int32
        if df[d1].dtype == object:
            if ((df[d1] == 'Success') | (df[d1] == 'Frame acquisition timed out')).any():
                df[d1] = df[d1].eq('Success').mul(1)  # Replace Success with 1, Fail with 0

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, legend=groupBy, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def GrabAttempts_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'GrabAttempts'

        figTitle = 'GrabAttempts'
        ylabel = 'GrabAttempts (#frms)'
        numDataCols = 2  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2) # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, legend=groupBy, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

'''
Limits Data
'''
def Limits_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'LIMIT__' # Columns to find

        df = dataFrame

        # get data columns
        t1_cols = [x for x in df.columns[df.columns.str.contains(d1)]]

        figTitle = 'Limits'
        ylabel = 'Val'
        numDataCols = len(t1_cols) + 1 # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        for dc in t1_cols: # loop through all column names
            if groupBy == None:  # Remove Legend= keyword
                # Plot each data frame column
                fcp.plot(df, x='Step', y=dc, title=dc, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + dc + '_' + timestamp + '.png')
                document.add_heading(dc, level=3)
                document.add_picture(pltPath + dc + '_' + timestamp + '.png')  # Add figure to report
            elif groupBy != None:
                # Plot each data frame column
                fcp.plot(df, x='Step', y=dc, title=dc, legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + dc + '_' + timestamp + '.png')
                document.add_heading(dc, level=3)
                document.add_picture(pltPath + dc + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for dc in t1_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

