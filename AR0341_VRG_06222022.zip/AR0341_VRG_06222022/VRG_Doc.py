import matplotlib
import matplotlib.pyplot as plt
from matplotlib import pyplot
from docx import Document
from docx.shared import Inches
from docx.shared import Pt
from tkinter import *
from tkinter import filedialog
from tkinter import messagebox
import numpy as np
import csv
import argparse
import os
import pandas as pd
import pixelcrunch as pc
import fivecentplots as fcp
import bokeh
import sys
import io
import multiprocessing
import VRG_Safety_Data
import VRG_Calculate
import VRG_Data_Frame
import VRG_Doc
import VRG_General_Data
import VRG_Image_Analysis
import VRG_Image_Utils
import VRG_Macro_Data
import VRG_OTPM_Data
import VRG_Pins_Data
import VRG_Power_Data
import VRG_Register_Data
import VRG_Stats_Arr
import VRG_Stats_ArrCenter
import VRG_Stats_ArrQuad1
import VRG_Stats_ArrQuad2
import VRG_Stats_ArrQuad3
import VRG_Stats_ArrQuad4
import VRG_Stats_ArrRoi1
import VRG_Stats_ArrRoi2
import VRG_Stats_ArrRoi3
import VRG_Stats_ArrRoi4
import VRG_Stats_ArrRoi5
import VRG_Stats_ArrRoi6
import VRG_Stats_ArrRoi7
import VRG_Stats_ArrRoi8
import VRG_Stats_ArrRoi9
import VRG_Stats_DBLC
import VRG_Stats_Frame
import VRG_Stats_Lag
import VRG_Stats_RNC
import VRG_Stats_Tilt
import VRG_Tempsensor_Data
import VRG_Reports
import time


def CSV_Header(filePath):
    # Open CSV file to get header information
    with open(filePath) as csvDataFile:
        csvdata = [row for row in csv.reader(csvDataFile)]
        # print(csvdata[0][0])
        skipVal = re.findall(r'\b\d+\b', csvdata[0][0])  # gets a list of integers from header length
        skipRows = int(skipVal[0])  # convert skiprows to int

        print(skipRows)

        if skipRows == 23:
            fileCreated = csvdata[1][0]
            svnPath = csvdata[2][0]
            svnRev = csvdata[3][0]
            svnModFiles = csvdata[4][0]
            svnDirStatus = csvdata[5][0]
            tparamSrc = csvdata[6][0]
            standTest = csvdata[7][0]
            projName = csvdata[8][0]
            softVers = csvdata[9][0]
            sysType = csvdata[10][0]
            pcName = csvdata[11][0]
            testerHardware = csvdata[12][0]
            testerType = csvdata[13][0]
            frameGrabber = csvdata[14][0]
            personalityCard = csvdata[15][0]
            sysFPGAVers = csvdata[16][0]
            sysFPGATimeStamp = csvdata[17][0]
            dutFPGAVers = csvdata[18][0]
            dutFPGATimeStamp = csvdata[19][0]
            pwrFPGAVers = csvdata[20][0]
            pwrFPGATimeStamp = csvdata[21][0]
            return [skipRows, fileCreated, svnPath, svnRev, svnModFiles, svnDirStatus, tparamSrc, standTest, projName,
                    softVers, sysType, pcName, testerHardware, testerType, frameGrabber, personalityCard, sysFPGAVers,
                    sysFPGATimeStamp, dutFPGAVers, dutFPGATimeStamp, pwrFPGAVers, pwrFPGATimeStamp];

        elif skipRows == 19:
            fileCreated = csvdata[1][0]
            tparamSrc = csvdata[2][0]
            standTest = csvdata[3][0]
            projName = csvdata[4][0]
            softVers = csvdata[5][0]
            sysType = csvdata[6][0]
            pcName = csvdata[7][0]
            testerHardware = csvdata[8][0]
            testerType = csvdata[9][0]
            frameGrabber = csvdata[10][0]
            personalityCard = csvdata[11][0]
            sysFPGAVers = csvdata[12][0]
            sysFPGATimeStamp = csvdata[13][0]
            dutFPGAVers = csvdata[14][0]
            dutFPGATimeStamp = csvdata[15][0]
            pwrFPGAVers = csvdata[16][0]
            pwrFPGATimeStamp = csvdata[17][0]
            return [skipRows, fileCreated, tparamSrc, standTest, projName,
                    softVers, sysType, pcName, testerHardware, testerType, frameGrabber, personalityCard, sysFPGAVers,
                    sysFPGATimeStamp, dutFPGAVers, dutFPGATimeStamp, pwrFPGAVers, pwrFPGATimeStamp];

def UpdateTestProcedure(df, document, engrName, filePaths):

    document.tables[0].cell(1, 1).text = engrName  # write engineer name to table

    dataLocation = ", ".join(filePaths)
    document.tables[0].cell(13, 1).text = 'FilePaths = ' + dataLocation

    if 'FID' in df.columns:
        EID = np.array2string(np.asarray(df['FID'].unique()), separator=',')
        document.tables[0].cell(0, 1).text = EID
    if 'Clk' in df.columns:
        ClockFrequeny = np.array2string(np.asarray(df['Clk'].unique()), separator=',')
        document.tables[0].cell(3, 1).text = ClockFrequeny + ' MHz'
    if 'TemperatureSetPoint' in df.columns:
        Temperature = np.array2string(np.asarray(df['TemperatureSetPoint'].unique()), separator=',')
        document.tables[0].cell(4, 1).text = Temperature + ' C'
    if 'Power' in df.columns: # check if power exists
        SupplyVoltage = np.array2string(np.asarray(df['Power'].unique()), separator=',')
        document.tables[0].cell(2, 1).text = SupplyVoltage
    if 'DVM_Min_PowerUp_Test' in df.columns: # check if power up exists
        SupplyVoltage = np.array2string(np.asarray(df['DVM_Min_PowerUp_Test'].unique()), separator=',')
        document.tables[0].cell(2, 1).text = SupplyVoltage
    if 'DVM_Nom_PowerUp_Test' in df.columns: # check if power up exists
        SupplyVoltage = np.array2string(np.asarray(df['DVM_Nom_PowerUp_Test'].unique()), separator=',')
        document.tables[0].cell(2, 1).text = SupplyVoltage
    if 'DVM_Max_PowerUp_Test' in df.columns: # check if power up exists
        SupplyVoltage = np.array2string(np.asarray(df['DVM_Max_PowerUp_Test'].unique()), separator=',')
        document.tables[0].cell(2, 1).text = SupplyVoltage
    if 'DVM_Power_Down_Test' in df.columns:  # check if power up exists
        SupplyVoltage = np.array2string(np.asarray(df['DVM_Power_Down_Test'].unique()), separator=',')
        document.tables[0].cell(2, 1).text = SupplyVoltage
    if 'MM_GDI_ID' in df.columns: # check if power exists
        mm_gdi = np.array2string(np.asarray(df['MM_GDI_ID'].unique()), separator=',')
        document.tables[0].cell(8, 1).text = 'MM_GDI_ID = ' +  mm_gdi
    if 'MM_PROBE_DUT_ID' in df.columns: # check if power exists
        mm_dut = np.array2string(np.asarray(df['MM_PROBE_DUT_ID'].unique()), separator=',')
        document.tables[0].cell(9, 1).text = 'MM_PROBE_DUT_ID = ' +  mm_dut
    if 'MM_POWER_SUPPLY_ID' in df.columns: # check if power exists
        mm_supply = np.array2string(np.asarray(df['MM_POWER_SUPPLY_ID'].unique()), separator=',')
        document.tables[0].cell(10, 1).text = 'MM_POWER_SUPPLY_ID = ' +  mm_supply
    if 'MM_PERSONALITY_CARD_ID' in df.columns: # check if power exists
        mm_personality = np.array2string(np.asarray(df['MM_PERSONALITY_CARD_ID'].unique()), separator=',')
        document.tables[0].cell(11, 1).text = 'MM_PERSONALITY_CARD_ID = ' +  mm_personality

def ClearPlotDirectory(pltPath):
    # Clear the plots from the folder to save disk space
    for file in os.listdir(pltPath):
        if file.endswith('.png'):
            fullPltPath = os.path.join(pltPath, file)
            os.remove(fullPltPath)

def UpdateDoc(document, docTitle, designID, designRev):
    document.add_heading(docTitle)
    for paragraph in document.paragraphs:
        if paragraph.text == '[Insert Validation Plan Test Name]':
            paragraph.text = docTitle
        if paragraph.text == 'ARXXXX RevX Validation Report':
            paragraph.text = designID + ' Rev' + designRev + ' Validation Report'
    for section in document.sections:
        header = section.header
        if header.paragraphs[1].text == 'Validation Report ARXXXX RevX ':
            header.paragraphs[1].name = "Calibri"
            header.paragraphs[1].text = 'Validation Report ' + designID + ' Rev' + designRev

def df_to_table(df, document):

    t = document.add_table(df.shape[0] + 1, df.shape[1])
    # add the header rows.
    for j in range(df.shape[-1]):
        t.cell(0, j).text = df.columns[j]
        t.cell(0, j).paragraphs[0].runs[0].font.bold = True
        t.cell(0, j).paragraphs[0].runs[0].font.size = Pt(6)
        t.cell(0, j).paragraphs[0].runs[0].font.name = 'Calibri'
    # add the rest of the data frame
    for i in range(df.shape[0]):
        for j in range(df.shape[-1]):
            t.cell(i + 1, j).text = str(df.values[i, j])
            t.cell(i + 1, j).paragraphs[0].runs[0].font.size = Pt(6)
            t.cell(i + 1, j).paragraphs[0].runs[0].font.name = 'Calibri'

def SaveDoc(document, reportFilePath):
    document.save(reportFilePath)
    os.rename(reportFilePath, reportFilePath)
    # convert(reportFilePath, reportFilePath[:-4] + "PDF.pdf")
    print("Report Complete and Saved")
    # messagebox.showinfo("Report Complete", reportFilePath + " Saved Successfully")
