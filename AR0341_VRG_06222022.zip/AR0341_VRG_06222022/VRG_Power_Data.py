import matplotlib
import matplotlib.pyplot as plt
from matplotlib import pyplot
from docx import Document
from docx.shared import Inches
from docx.shared import Pt
from tkinter import *
from tkinter import filedialog
from tkinter import messagebox
import numpy as np
import csv
import argparse
import os
import pandas as pd
import pixelcrunch as pc
import fivecentplots as fcp
import bokeh
import sys
import io
import multiprocessing
import VRG_Safety_Data
import VRG_Calculate
import VRG_Data_Frame
import VRG_Doc
import VRG_General_Data
import VRG_Image_Analysis
import VRG_Image_Utils
import VRG_Macro_Data
import VRG_OTPM_Data
import VRG_Pins_Data
import VRG_Power_Data
import VRG_Register_Data
import VRG_Stats_Arr
import VRG_Stats_ArrCenter
import VRG_Stats_ArrQuad1
import VRG_Stats_ArrQuad2
import VRG_Stats_ArrQuad3
import VRG_Stats_ArrQuad4
import VRG_Stats_ArrRoi1
import VRG_Stats_ArrRoi2
import VRG_Stats_ArrRoi3
import VRG_Stats_ArrRoi4
import VRG_Stats_ArrRoi5
import VRG_Stats_ArrRoi6
import VRG_Stats_ArrRoi7
import VRG_Stats_ArrRoi8
import VRG_Stats_ArrRoi9
import VRG_Stats_DBLC
import VRG_Stats_Frame
import VRG_Stats_Lag
import VRG_Stats_RNC
import VRG_Stats_Tilt
import VRG_Tempsensor_Data
import VRG_Reports
import time

'''
Registers vs Power & Current Data
'''
def Reg_vs_Power_and_Current_Consumption_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'P_VAA2V8(mW)'
        d2 = 'I_VAA2V8(mA)'
        d3 = 'P_VAA1V8(mW)'
        d4 = 'I_VAA1V8(mA)'
        d5 = 'P_VDD(mW)'
        d6 = 'I_VDD(mA)'
        d7 = 'P_VDD_PHY(mW)'
        d8 = 'I_VDD_PHY(mA)'
        d9 = 'P_VDD_IO(mW)'
        d10 = 'I_VDD_IO(mA)'
        d11 = 'P_VAA_PIX(mW)'
        d12 = 'I_VAA_PIX(mA)'
        d13 = 'P_VDD_SLVS(mW)'
        d14 = 'I_VDD_SLVS(mA)'
        d15 = 'P_TOTAL(mW)'
        d16 = 'I_TOTAL(mA)'

        figTitle = 'Power_and_Current_Consumption'
        xlabel = register
        numDataCols = 17  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols, 2):  # 1 to 8
                fcp.plot(df, x=register, y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         show=showPlt, label_x=xlabel, inline=showPlt, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval(
                        "d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval(
                    "d" + str(x + 1)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols, 2):  # 1 to 8
                fcp.plot(df, x=register, y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         legend=groupBy, show=showPlt, label_x=xlabel,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval(
                        "d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval(
                    "d" + str(x + 1)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_Power_Consumption_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'P_VAA2V8(mW)'
        d2 = 'P_VAA1V8(mW)'
        d3 = 'P_VDD(mW)'
        d4 = 'P_VDD_PHY(mW)'
        d5 = 'P_VDD_IO(mW)'
        d6 = 'P_VAA_PIX(mW)'
        d7 = 'P_VDD_SLVS(mW)'
        d8 = 'P_TOTAL(mW)'

        figTitle = 'Register_vs_Power_Consumption'
        xlabel = register
        ylabel = 'Power (mW)'
        numDataCols = 9  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 8
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 8
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_Current_Consumption_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'I_VAA2V8(mA)'
        d2 = 'I_VAA1V8(mA)'
        d3 = 'I_VDD(mA)'
        d4 = 'I_VDD_PHY(mA)'
        d5 = 'I_VDD_IO(mA)'
        d6 = 'I_VAA_PIX(mA)'
        d7 = 'I_VDD_SLVS(mA)'
        d8 = 'I_TOTAL(mA)'

        figTitle = 'Register_vs_Current_Consumption'
        xlabel = register
        ylabel = 'Current (mA)'
        numDataCols = 9  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 8
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 8
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_Reg_vs_Power_and_Current_Consumption_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'P_VAA2V8(mW)'
        d2 = 'I_VAA2V8(mA)'
        d3 = 'P_VAA1V8(mW)'
        d4 = 'I_VAA1V8(mA)'
        d5 = 'P_VDD(mW)'
        d6 = 'I_VDD(mA)'
        d7 = 'P_VDD_PHY(mW)'
        d8 = 'I_VDD_PHY(mA)'
        d9 = 'P_VDD_IO(mW)'
        d10 = 'I_VDD_IO(mA)'
        d11 = 'P_VAA_PIX(mW)'
        d12 = 'I_VAA_PIX(mA)'
        d13 = 'P_VDD_SLVS(mW)'
        d14 = 'I_VDD_SLVS(mA)'
        d15 = 'P_TOTAL(mW)'
        d16 = 'I_TOTAL(mA)'

        figTitle = 'Power_and_Current_Consumption'
        numDataCols = 17  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols, 2):  # 1 to 8
                fcp.plot(df, x=register, y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         legend=register2, show=showPlt, inline=showPlt, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval(
                        "d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(
                    register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                    level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval(
                    "d" + str(x + 1)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols, 2):  # 1 to 8
                fcp.plot(df, x=register, y=[eval("d" + str(x)), eval("d" + str(x + 1))],
                         title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         legend=[register2, groupBy], show=showPlt, inline=showPlt, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval(
                        "d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(
                    register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                    level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval(
                    "d" + str(x + 1)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_Power_Consumption_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'P_VAA2V8(mW)'
        d2 = 'P_VAA1V8(mW)'
        d3 = 'P_VDD(mW)'
        d4 = 'P_VDD_PHY(mW)'
        d5 = 'P_VDD_IO(mW)'
        d6 = 'P_VAA_PIX(mW)'
        d7 = 'P_VDD_SLVS(mW)'
        d8 = 'P_TOTAL(mW)'

        figTitle = 'Reg_vs_Reg_vs_Power_Consumption'
        ylabel = 'Power (mW)'
        numDataCols = 9  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_Current_Consumption_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'I_VAA2V8(mA)'
        d2 = 'I_VAA1V8(mA)'
        d3 = 'I_VDD(mA)'
        d4 = 'I_VDD_PHY(mA)'
        d5 = 'I_VDD_IO(mA)'
        d6 = 'I_VAA_PIX(mA)'
        d7 = 'I_VDD_SLVS(mA)'
        d8 = 'I_TOTAL(mA)'

        figTitle = 'Reg_vs_Reg_vs_Current_Consumption'
        xlabel = register
        ylabel = 'Current (mA)'
        numDataCols = 9  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found


'''
Power & Current Data
'''

def Standby_Power_and_Current_Consumption_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'STBY_P_VAA2V8(mW)'
        d2 = 'STBY_I_VAA2V8(mA)'
        d3 = 'STBY_P_VAA1V8(mW)'
        d4 = 'STBY_I_VAA1V8(mA)'
        d5 = 'STBY_P_VDD(mW)'
        d6 = 'STBY_I_VDD(mA)'
        d7 = 'STBY_P_VDD_PHY(mW)'
        d8 = 'STBY_I_VDD_PHY(mA)'
        d9 = 'STBY_P_VDD_IO(mW)'
        d10 = 'STBY_I_VDD_IO(mA)'
        d11 = 'STBY_P_VAA_PIX(mW)'
        d12 = 'STBY_I_VAA_PIX(mA)'
        d13 = 'STBY_P_VDD_SLVS(mW)'
        d14 = 'STBY_I_VDD_SLVS(mA)'
        d15 = 'STBY_P_TOTAL(mW)'
        d16 = 'STBY_I_TOTAL(mA)'
    
        figTitle = 'STBY_Power_and_Current_Consumption'
        numDataCols = 17  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame
    
        currTime = time.strftime("%m%d%Y_%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)
    
        document.add_heading(figTitle, level=2)  # Add section title to docx report
    
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols, 2):  # 1 to 8
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))], title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols, 2):  # 1 to 8
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))], title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         legend=groupBy, show=showPlt,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Standby_Power_Consumption_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'STBY_P_VAA2V8(mW)'
        d2 = 'STBY_P_VAA1V8(mW)' 
        d3 = 'STBY_P_VDD(mW)' 
        d4 = 'STBY_P_VDD_PHY(mW)'
        d5 = 'STBY_P_VDD_IO(mW)'
        d6 = 'STBY_P_VAA_PIX(mW)' 
        d7 = 'STBY_P_VDD_SLVS(mW)'
        d8 = 'STBY_P_TOTAL(mW)'
    
        figTitle = 'Standby_Power_Consumption'
        ylabel = 'Standby_Power (mW)'
        numDataCols = 9  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame
    
        currTime = time.strftime("%m%d%Y_%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)
    
        document.add_heading(figTitle, level=2)  # Add section title to docx report
    
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Standby_Current_Consumption_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'STBY_I_VAA2V8(mA)'
        d2 = 'STBY_I_VAA1V8(mA)'
        d3 = 'STBY_I_VDD(mA)'
        d4 = 'STBY_I_VDD_PHY(mA)'
        d5 = 'STBY_I_VDD_IO(mA)'
        d6 = 'STBY_I_VAA_PIX(mA)'
        d7 = 'STBY_I_VDD_SLVS(mA)'
        d8 = 'STBY_I_TOTAL(mA)'
    
        figTitle = 'Standby_Current_Consumption'
        ylabel = 'Standby_Current (mA)'
        numDataCols = 9  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame
    
        currTime = time.strftime("%m%d%Y_%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)
    
        document.add_heading(figTitle, level=2)  # Add section title to docx report
    
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Power_and_Current_Consumption_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'P_VAA2V8(mW)'
        d2 = 'I_VAA2V8(mA)'
        d3 = 'P_VAA1V8(mW)'
        d4 = 'I_VAA1V8(mA)'
        d5 = 'P_VDD(mW)'
        d6 = 'I_VDD(mA)'
        d7 = 'P_VDD_PHY(mW)'
        d8 = 'I_VDD_PHY(mA)'
        d9 = 'P_VDD_IO(mW)'
        d10 = 'I_VDD_IO(mA)'
        d11 = 'P_VAA_PIX(mW)'
        d12 = 'I_VAA_PIX(mA)'
        d13 = 'P_VDD_SLVS(mW)'
        d14 = 'I_VDD_SLVS(mA)'
        d15 = 'P_TOTAL(mW)'
        d16 = 'I_TOTAL(mA)'
    
        figTitle = 'Power_and_Current_Consumption'
        numDataCols = 17  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame
    
        currTime = time.strftime("%m%d%Y_%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)
    
        document.add_heading(figTitle, level=2)  # Add section title to docx report
    
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols, 2):  # 1 to 8
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))], title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         show=showPlt, inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols, 2):  # 1 to 8
                fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("d" + str(x + 1))], title=eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)),
                         legend=groupBy, show=showPlt,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)) + ' & ' + eval("d" + str(x + 1)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + eval("d" + str(x + 1)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Power_Consumption_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'P_VAA2V8(mW)'
        d2 = 'P_VAA1V8(mW)'
        d3 = 'P_VDD(mW)'
        d4 = 'P_VDD_PHY(mW)'
        d5 = 'P_VDD_IO(mW)'
        d6 = 'P_VAA_PIX(mW)'
        d7 = 'P_VDD_SLVS(mW)'
        d8 = 'P_TOTAL(mW)'
    
        figTitle = 'Power_Consumption'
        ylabel = 'Power (mW)'
        numDataCols = 9  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame
    
        currTime = time.strftime("%m%d%Y_%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)
    
        document.add_heading(figTitle, level=2)  # Add section title to docx report
    
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Power_Consumption_Table(dataFrame, groupCol, groupVal, document):
    try:
        if groupCol == None and groupVal == None:  # Dont group data frame
            df = dataFrame
        elif groupCol != None and groupVal != None:  # Group data frame by col and value
            df = VRG_Data_Frame.newdataframe(dataFrame, groupCol, groupVal)
    
        # Column Names in CSV
        d1 = 'P_VAA2V8(mW)'
        d2 = 'P_VAA1V8(mW)'
        d3 = 'P_VDD(mW)'
        d4 = 'P_VDD_PHY(mW)'
        d5 = 'P_VDD_IO(mW)'
        d6 = 'P_VAA_PIX(mW)'
        d7 = 'P_VDD_SLVS(mW)'
        d8 = 'P_TOTAL(mW)'
    
        figTitle = 'Power_Consumption_Table'
        rowLabel1 = 'Supply Name'
        rowLabel2 = 'Supply Mean (mW)'
        numDataCols = 9  # Number of columns + 1 to loop through (last col + 1)
        tableStyle = 'Table Grid'
    
        if groupCol == None and groupVal == None:  # No Dataframe grouping
            document.add_heading(figTitle, level=2) 
            table_count = len(document.tables)
            table = document.add_table(rows=numDataCols, cols=2)
            table.style = tableStyle
            document.tables[table_count].cell(0, 0).text = rowLabel1
            document.tables[table_count].cell(0, 1).text = rowLabel2
            for x in range(1, numDataCols):  # 1 to N
                document.tables[table_count].cell(x, 0).text = eval("d" + str(x))
                document.tables[table_count].cell(x, 1).text = df[eval("d" + str(x))].mean().astype(str)
        elif groupCol != None and groupVal != None:  # Data frame grouped by col and val
            document.add_heading(figTitle + " Grouped by" + groupCol + " = " + groupVal, level=2) 
            df = VRG_Data_Frame.newdataframe()
            table_count = len(document.tables)
            table = document.add_table(rows=numDataCols, cols=2)
            table.style = tableStyle
            document.tables[table_count].cell(0, 0).text = rowLabel1
            document.tables[table_count].cell(0, 1).text = rowLabel2
            for x in range(1, numDataCols):  # 1 to N
                document.tables[table_count].cell(x, 0).text = eval("d" + str(x))
                document.tables[table_count].cell(x, 1).text = df[eval("d" + str(x))].mean().astype(str)
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        if groupCol == None:
            document.add_heading("groupCol Not Used", level=3)
        elif groupCol != None:
            if groupCol in df.columns:
                document.add_heading("groupCol Found: " + groupCol, level=3)  # Add Groupby found
                if groupVal == None:
                    document.add_heading("groupVal Missing", level=3)
                elif groupVal != None:
                    if groupCol in df[groupCol].unique():
                        document.add_heading("groupVal Found: " + groupVal, level=3)  # Add Groupby found
                    else:
                        document.add_heading("groupVal Not Found: " + groupVal, level=3)  # Add Groupby not found
            else:
                document.add_heading("groupCol Not Found: " + groupCol, level=3)  # Add Groupby not found

def Current_Consumption_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'I_VAA2V8(mA)'
        d2 = 'I_VAA1V8(mA)'
        d3 = 'I_VDD(mA)'
        d4 = 'I_VDD_PHY(mA)'
        d5 = 'I_VDD_IO(mA)'
        d6 = 'I_VAA_PIX(mA)'
        d7 = 'I_VDD_SLVS(mA)'
        d8 = 'I_TOTAL(mA)'
    
        figTitle = 'Current_Consumption'
        ylabel = 'Current (mA)'
        numDataCols = 9  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame
    
        currTime = time.strftime("%m%d%Y_%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)
    
        document.add_heading(figTitle, level=2)  # Add section title to docx report
    
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Current_Consumption_Table(dataFrame, groupCol, groupVal, document):
    try:
        if groupCol == None and groupVal == None:  #Dont group data frame
            df = dataFrame
        elif groupCol != None and groupVal != None: #Group data frame by col and value
            df = VRG_Data_Frame.newdataframe(dataFrame, groupCol, groupVal)
    
        # Column Names in CSV
        d1 = 'I_VAA2V8(mA)'
        d2 = 'I_VAA1V8(mA)'
        d3 = 'I_VDD(mA)'
        d4 = 'I_VDD_PHY(mA)'
        d5 = 'I_VDD_IO(mA)'
        d6 = 'I_VAA_PIX(mA)'
        d7 = 'I_VDD_SLVS(mA)'
        d8 = 'I_TOTAL(mA)'
    
        figTitle = 'Current_Consumption_Table'
        rowLabel1 = 'Supply Name'
        rowLabel2 = 'Supply Mean (mA)'
        numDataCols = 9  # Number of columns + 1 to loop through (last col + 1)
        tableStyle = 'Table Grid'
    
    
        if groupCol == None and groupVal == None:  # No Dataframe grouping
            document.add_heading(figTitle, level=2) 
            table_count = len(document.tables)
            table = document.add_table(rows=numDataCols, cols=2)
            table.style = tableStyle
            document.tables[table_count].cell(0, 0).text = rowLabel1
            document.tables[table_count].cell(0, 1).text = rowLabel2
            for x in range(1, numDataCols):  # 1 to N
                document.tables[table_count].cell(x, 0).text = eval("d" + str(x))
                document.tables[table_count].cell(x, 1).text = df[eval("d" + str(x))].mean().astype(str)
        elif groupCol != None and groupVal != None:  # Data frame grouped by col and val
            document.add_heading(figTitle + " Grouped by" + groupCol + " = " + groupVal, level=2) 
            df = VRG_Data_Frame.newdataframe()
            table_count = len(document.tables)
            table = document.add_table(rows=numDataCols, cols=2)
            table.style = tableStyle
            document.tables[table_count].cell(0, 0).text = rowLabel1
            document.tables[table_count].cell(0, 1).text = rowLabel2
            for x in range(1, numDataCols):  # 1 to N
                document.tables[table_count].cell(x, 0).text = eval("d" + str(x))
                document.tables[table_count].cell(x, 1).text = df[eval("d" + str(x))].mean().astype(str)
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupCol == None:
            document.add_heading("groupCol Not Used", level=3)
        elif groupCol != None:
            if groupCol in df.columns:
                document.add_heading("groupCol Found: " + groupCol, level=3)  # Add Groupby found
                if groupVal == None:
                    document.add_heading("groupVal Missing", level=3)
                elif groupVal != None:
                    if groupCol in df[groupCol].unique():
                        document.add_heading("groupVal Found: " + groupVal, level=3)  # Add Groupby found
                    else:
                        document.add_heading("groupVal Not Found: " + groupVal, level=3)  # Add Groupby not found
            else:
                document.add_heading("groupCol Not Found: " + groupCol, level=3)  # Add Groupby not found

'''
Supply Voltage Data
'''
def Supply_Voltage_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'VAA2V8(v)'
        d2 = 'VAA1V8(v)'
        d3 = 'VDD(v)'
        d4 = 'VDD_PHY(v)'
        d5 = 'VDD_IO(v)'
        d6 = 'VAA_PIX(v)'
        d7 = 'VDD_SLVS(v)'
        d8 = 'VDUTIO(v)'

        # d = []
        # d.append(d128)
        # d.append('VAA1V8(v)')

    
        figTitle = 'Supply_Voltage'
        ylabel = 'Voltage(v)'
        numDataCols = 9  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame
    
        currTime = time.strftime("%m%d%Y_%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)
    
        document.add_heading(figTitle, level=2)  # Add section title to docx report
    
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

'''
Reset Power & Current Data
'''
def ResetClkOn_Current_Mean_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'I_VAA2V8_ResetClkOn_Mean(mA)'
        d2 = 'I_VAA1V8_ResetClkOn_Mean(mA)'
        d3 = 'I_VDD_ResetClkOn_Mean(mA)'
        d4 = 'I_VDD_PHY_ResetClkOn_Mean(mA)'
        d5 = 'I_VDD_IO_ResetClkOn_Mean(mA)'
        d6 = 'I_VAA_PIX_ResetClkOn_Mean(mA)'
        d7 = 'I_VDD_SLVS_ResetClkOn_Mean(mA)'
        d8 = 'I_Total__ResetClkOn(mA)'
    
        figTitle = 'ResetClkOn_Current_Mean'
        ylabel = 'Mean (mA)'
        numDataCols = 9  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame
    
        currTime = time.strftime("%m%d%Y_%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)
    
        document.add_heading(figTitle, level=2)  # Add section title to docx report
    
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def ResetClkOn_Current_Std_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'I_VAA2V8_ResetClkOn_Std(mA)'
        d2 = 'I_VAA1V8_ResetClkOn_Std(mA)'
        d3 = 'I_VDD_ResetClkOn_Std(mA)'
        d4 = 'I_VDD_PHY_ResetClkOn_Std(mA)'
        d5 = 'I_VDD_IO_ResetClkOn_Std(mA)'
        d6 = 'I_VAA_PIX_ResetClkOn_Std(mA)'
        d7 = 'I_VDD_SLVS_ResetClkOn_Std(mA)'
        d8 = 'I_Total__ResetClkOn(mA)'
    
        figTitle = 'ResetClkOn_Current_Std'
        ylabel = 'StdDev (mA)'
        numDataCols = 9  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame
    
        currTime = time.strftime("%m%d%Y_%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)
    
        document.add_heading(figTitle, level=2)  # Add section title to docx report
    
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def ResetClkOff_Current_Mean_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'I_VAA2V8_ResetClkOff_Mean(mA)'
        d2 = 'I_VAA1V8_ResetClkOff_Mean(mA)'
        d3 = 'I_VDD_ResetClkOff_Mean(mA)'
        d4 = 'I_VDD_PHY_ResetClkOff_Mean(mA)'
        d5 = 'I_VDD_IO_ResetClkOff_Mean(mA)'
        d6 = 'I_VAA_PIX_ResetClkOff_Mean(mA)'
        d7 = 'I_VDD_SLVS_ResetClkOff_Mean(mA)'
        d8 = 'I_Total__ResetClkOff(mA)'
    
        figTitle = 'ResetClkOff_Current_Mean'
        ylabel = 'Mean (mA)'
        numDataCols = 9  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame
    
        currTime = time.strftime("%m%d%Y_%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)
    
        document.add_heading(figTitle, level=2)  # Add section title to docx report
    
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def ResetClkOff_Current_Std_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'I_VAA2V8_ResetClkOff_Std(mA)'
        d2 = 'I_VAA1V8_ResetClkOff_Std(mA)'
        d3 = 'I_VDD_ResetClkOff_Std(mA)'
        d4 = 'I_VDD_PHY_ResetClkOff_Std(mA)'
        d5 = 'I_VDD_IO_ResetClkOff_Std(mA)'
        d6 = 'I_VAA_PIX_ResetClkOff_Std(mA)'
        d7 = 'I_VDD_SLVS_ResetClkOff_Std(mA)'
        d8 = 'I_Total__ResetClkOff(mA)'
    
        figTitle = 'ResetClkOff_Current_Std'
        ylabel = 'StdDev (mA)'
        numDataCols = 9  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame
    
        currTime = time.strftime("%m%d%Y_%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)
    
        document.add_heading(figTitle, level=2)  # Add section title to docx report
    
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def STREAMING_Current_Mean_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'I_VAA2V8_STREAMING_Mean(mA)'
        d2 = 'I_VAA1V8_STREAMING_Mean(mA)'
        d3 = 'I_VDD_STREAMING_Mean(mA)'
        d4 = 'I_VDD_PHY_STREAMING_Mean(mA)'
        d5 = 'I_VDD_IO_STREAMING_Mean(mA)'
        d6 = 'I_VAA_PIX_STREAMING_Mean(mA)'
        d7 = 'I_VDD_SLVS_STREAMING_Mean(mA)'
        d8 = 'I_Total__STREAMING(mA)'
    
        figTitle = 'STREAMING_Current_Mean'
        ylabel = 'Mean (mA)'
        numDataCols = 9  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame
    
        currTime = time.strftime("%m%d%Y_%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)
    
        document.add_heading(figTitle, level=2)  # Add section title to docx report
    
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def STREAMING_Current_Std_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'I_VAA2V8_STREAMING_Std(mA)'
        d2 = 'I_VAA1V8_STREAMING_Std(mA)'
        d3 = 'I_VDD_STREAMING_Std(mA)'
        d4 = 'I_VDD_PHY_STREAMING_Std(mA)'
        d5 = 'I_VDD_IO_STREAMING_Std(mA)'
        d6 = 'I_VAA_PIX_STREAMING_Std(mA)'
        d7 = 'I_VDD_SLVS_STREAMING_Std(mA)'
        d8 = 'I_Total__STREAMING(mA)'
    
        figTitle = 'STREAMING_Current_Std'
        ylabel = 'StdDev (mA)'
        numDataCols = 9  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame
    
        currTime = time.strftime("%m%d%Y_%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)
    
        document.add_heading(figTitle, level=2)  # Add section title to docx report
    
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

'''
Intermediate Current Data
'''
def Intermediate_Current_Samples_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'I_IntermediateCurrents_Samples'

        figTitle = 'Intermediate_Current_Samples'
        ylabel = 'Samples'
        numDataCols = 2  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y_%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Intermediate_Current_Mean_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'I_VAA2V8_IntermediateCurrents_Mean(mA)'
        d2 = 'I_VDD_PHY_IntermediateCurrents_Mean(mA)'
        d3 = 'I_VDD_IntermediateCurrents_Mean(mA)'
        d4 = 'I_VDD_IO_IntermediateCurrents_Mean(mA)'
        d5 = 'I_VAA1V8_IntermediateCurrents_Mean(mA)'
        d6 = 'I_VAA_PIX_IntermediateCurrents_Mean(mA)'
        d7 = 'I_VDD_SLVS_IntermediateCurrents_Mean(mA)'
        d8 = 'I_Total__IntermediateCurrents(mA)'

        figTitle = 'Intermediate_Current_Mean'
        ylabel = 'Mean (mA)'
        numDataCols = 9  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y_%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Intermediate_Current_Std_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'I_VAA2V8_IntermediateCurrents_Std(mA)'
        d2 = 'I_VDD_PHY_IntermediateCurrents_Std(mA)'
        d3 = 'I_VDD_IntermediateCurrents_Std(mA)'
        d4 = 'I_VDD_IO_IntermediateCurrents_Std(mA)'
        d5 = 'I_VAA1V8_IntermediateCurrents_Std(mA)'
        d6 = 'I_VAA_PIX_IntermediateCurrents_Std(mA)'
        d7 = 'I_VDD_SLVS_IntermediateCurrents_Std(mA)'

        figTitle = 'Intermediate_Current_Std'
        ylabel = 'StdDev (mA)'
        numDataCols = 8  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y_%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found


'''
Booster Voltage Data
'''
def Booster_Voltage_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'VREF_VAACLGLAG'
        d2 = 'VAACLGLAG'
        d3 = 'vref_conn_lghi'
        d4 = 'vout_conn_lghi'
        d5 = 'vref_conn_lgsthi'
        d6 = 'vout_conn_lgsthi'
        d7 = 'vref_conn_vddhi'
        d8 = 'vout_conn_vddhi'
        d9 = 'vref_row_selhi'
        d10 = 'vout_row_selhi'
        d11 = 'vref_sghi'
        d12 = 'vout_sghi'
        d13 = 'vref_tx0hi'
        d14 = 'vout_tx0hi'
        d15 = 'vref_tx1hi'
        d16 = 'vout_tx1hi'
        d17 = 'vref_tx_lghi'
        d18 = 'vout_tx_lghi'
        d19 = 'vref_VDDHILOGIC'
        d20 = 'vout_VDDHILOGIC'
        d21 = 'vref_conn_lgmid'
        d22 = 'vout_conn_lgmid'
        d23 = 'vref_tx1mid'
        d24 = 'vout_tx1mid'
        d25 = 'vref_tx1lo'
        d26 = 'vout_tx1lo'
        d27 = 'vref_tx1lo_3lvl'
        d28 = 'vref_tx1lo_sel'
        d29 = 'vout_tx1lo_sel'
        d30 = 'vref_tx1lo_sel_3lvl'
        d31 = 'vref_conn_vddlo'
        d32 = 'vout_conn_vddlo'
        d33 = 'vref_conn_vddlo_sel'
        d34 = 'vout_conn_vddlo_sel'
        d35 = 'vref_conn_lgstlo'
        d36 = 'vout_conn_lgstlo'
        d37 = 'vref_conn_lgstlo_sel'
        d38 = 'vout_conn_lgstlo_sel'
        d39 = 'vref_VSSHILOGIC'
        d40 = 'vout_VSSHILOGIC'
        d41 = 'vref_VSSRWD'
        d42 = 'vout_VSSRWD'
        d43 = 'vref_sglo'
        d44 = 'vout_sglo'
        d45 = 'vref_sglo_sel'
        d46 = 'vout_sglo_sel'
        d47 = 'vref_conn_fdlo'
        d48 = 'vout_conn_fdlo'
        d49 = 'vref_conn_fdlo_sel'
        d50 = 'vout_conn_fdlo_sel'
        d51 = 'vref_VSSLOGIC'
        d52 = 'vout_VSSLOGIC'
        d53 = 'vref_conn_lglo'
        d54 = 'vout_conn_lglo'
        d55 = 'vref_conn_lglo_sel'
        d56 = 'vout_conn_lglo_sel'
        d57 = 'vref_tx0lo'
        d58 = 'vout_tx0lo'
        d59 = 'vref_tx0lo_sel'
        d60 = 'vout_tx0lo_sel'
        d61 = 'vref_tx_lglo'
        d62 = 'vout_tx_lglo'
        d63 = 'vref_tx_lglo_sel'
        d64 = 'vout_tx_lglo_sel'

        figTitle = 'Booster_Voltage'
        ylabel = 'Booster Voltage (v)'
        numDataCols = 65  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame
    
        currTime = time.strftime("%m%d%Y_%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)
    
        document.add_heading(figTitle, level=2)  # Add section title to docx report
    
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Positive_Booster_Voltage_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'vref_conn_fdhi'
        d2 = 'vout_conn_fdhi'
        d3 = 'vref_conn_lghi'
        d4 = 'vout_conn_lghi'
        d5 = 'vref_conn_lgsthi'
        d6 = 'vout_conn_lgsthi'
        d7 = 'vref_conn_vddhi'
        d8 = 'vout_conn_vddhi'
        d9 = 'vref_row_selhi'
        d10 = 'vout_row_selhi'
        d11 = 'vref_sghi'
        d12 = 'vout_sghi'
        d13 = 'vref_tx0hi'
        d14 = 'vout_tx0hi'
        d15 = 'vref_tx1hi'
        d16 = 'vout_tx1hi'
        d17 = 'vref_tx_lghi'
        d18 = 'vout_tx_lghi'
        d19 = 'vref_VDDHILOGIC'
        d20 = 'vout_VDDHILOGIC'
    
        figTitle = 'Positive_Booster_Voltage'
        ylabel = 'Booster Voltage (v)'
        numDataCols = 21  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame
    
        currTime = time.strftime("%m%d%Y_%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)
    
        document.add_heading(figTitle, level=2)  # Add section title to docx report
    
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Middle_Booster_Voltage_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'vref_conn_lgmid'
        d2 = 'vout_conn_lgmid'
        d3 = 'vref_tx1mid'
        d4 = 'vout_tx1mid'
    
        figTitle = 'Middle_Booster_Voltage'
        ylabel = 'Booster Voltage (v)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame
    
        currTime = time.strftime("%m%d%Y_%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)
    
        document.add_heading(figTitle, level=2)  # Add section title to docx report
    
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Negative_Booster_Voltage_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'vref_tx1lo'
        d2 = 'vout_tx1lo'
        d3 = 'vref_tx1lo_3lvl'
        d4 = 'vref_tx1lo_sel'
        d5 = 'vout_tx1lo_sel'
        d6 = 'vref_tx1lo_sel_3lvl'
        d7 = 'vref_conn_vddlo'
        d8 = 'vout_conn_vddlo'
        d9 = 'vref_conn_vddlo_sel'
        d10 = 'vout_conn_vddlo_sel'
        d11 = 'vref_conn_lgstlo'
        d12 = 'vout_conn_lgstlo'
        d13 = 'vref_conn_lgstlo_sel'
        d14 = 'vout_conn_lgstlo_sel'
        d15 = 'vref_VSSHILOGIC'
        d16 = 'vout_VSSHILOGIC'
        d17 = 'vref_VSSRWD'
        d18 = 'vout_VSSRWD'
        d19 = 'vref_sglo'
        d20 = 'vout_sglo'
        d21 = 'vref_sglo_sel'
        d22 = 'vout_sglo_sel'
        d23 = 'vref_conn_fdlo'
        d24 = 'vout_conn_fdlo'
        d25 = 'vref_conn_fdlo_sel'
        d26 = 'vout_conn_fdlo_sel'
        d27 = 'vref_VSSLOGIC'
        d28 = 'vout_VSSLOGIC'
        d29 = 'vref_conn_lglo'
        d30 = 'vout_conn_lglo'
        d31 = 'vref_conn_lglo_sel'
        d32 = 'vout_conn_lglo_sel'
        d33 = 'vref_tx0lo'
        d34 = 'vout_tx0lo'
        d35 = 'vref_tx0lo_sel'
        d36 = 'vout_tx0lo_sel'
        d37 = 'vref_tx_lglo'
        d38 = 'vout_tx_lglo'
        d39 = 'vref_tx_lglo_sel'
        d40 = 'vout_tx_lglo_sel'
    
        figTitle = 'Negative_Booster_Voltage'
        ylabel = 'Booster Voltage (v)'
        numDataCols = 41  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame
    
        currTime = time.strftime("%m%d%Y_%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)
    
        document.add_heading(figTitle, level=2)  # Add section title to docx report
    
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found


'''
LDO Voltage Data
'''
def LDO_Voltage_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'VREF_VAACLGLAG'
        d2 = 'VAACLGLAG'
        d3 = 'VREF_VAACLGSH'
        d4 = 'VAACLGSH'
        d5 = 'VREF_VAA3P3V'
        d6 = 'VAA3V3'
        d7 = 'VREF_VDDHILOGIC'
        d8 = 'VDDHILOGIC'
        d9 = 'VREF_VDDHRST'
        d10 = 'VDDHRST'
        d11 = 'VREF_VDDRW3V3'
        d12 = 'VDDRW3V3'
        d13 = 'VREF_VDDHGC'
        d14 = 'VDDHGC'
        d15 = 'VREF_VDDHTX'
        d16 = 'VDDHTX'
        d17 = 'VREF_VDDHDCG'
        d18 = 'VDDHDCG'
        d19 = 'VREF_VDDHRS'
        d20 = 'VDDHRS'
        d21 = 'VREF_VAACLGRD'
        d22 = 'VAACLGRD'
        d23 = 'VREF_VDDHDCGMID'
        d24 = 'VDDHDCGMID'
        d25 = 'VAACLGINT'
        d26 = 'VREF_VAALDO2P4'
        d27 = 'VDDROWLOGIC'
        d28 = 'VSSHILOGIC'
        d29 = 'VREF_VSSHILOGIC'
        d30 = 'VSSRWROWDRV'
        d31 = 'VREF_VSSRWROWDRV'
        d32 = 'VSSROWLOGIC'
        d33 = 'VREF_VSSROWLOGIC'
        d34 = 'VSSLORST'
        d35 = 'VREF_VSSLORST'
        d36 = 'VSSLODCG'
        d37 = 'VREF_VSSLODCG'
        d38 = 'VSSLOGC'
        d39 = 'VREF_VSSLOGC'
        d40 = 'VSSLOTX'
        d41 = 'VREF_VSSLOTX'
        d42 = 'VDDPAR_T2_TX'
        d43 = 'VREF_VDDPAR_T2_TX'
        d44 = 'VDDPAR_T1_TX'
        d45 = 'VREF_VDDPAR_T1_TX'
        d46 = 'VDDPARGC'
        d47 = 'VREF_VDDPARGC'
        d48 = 'VSSLOSELRST'
        d49 = 'VREF_VSSLOSELRST'
        d50 = 'VSSLOSELGC'
        d51 = 'VREF_VSSLOSELGC'
        d52 = 'VSSLOSELDCG'
        d53 = 'VREF_VSSLOSELDCG'
        d54 = 'VSSLOSELTX'
        d55 = 'VREF_VSSLOSELTX'

        figTitle = 'LDO_Voltage'
        ylabel = 'LDO Voltage (v)'
        numDataCols = 65  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y_%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def High_LDO_Voltage_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'VREF_VAACLGLAG'
        d2 = 'VAACLGLAG'
        d3 = 'VREF_VAACLGSH'
        d4 = 'VAACLGSH'
        d5 = 'VREF_VAA3P3V'
        d6 = 'VAA3V3'
        d7 = 'VREF_VDDHILOGIC'
        d8 = 'VDDHILOGIC'
        d9 = 'VREF_VDDHRST'
        d10 = 'VDDHRST'
        d11 = 'VREF_VDDRW3V3'
        d12 = 'VDDRW3V3'
        d13 = 'VREF_VDDHGC'
        d14 = 'VDDHGC'
        d15 = 'VREF_VDDHTX'
        d16 = 'VDDHTX'
        d17 = 'VREF_VDDHDCG'
        d18 = 'VDDHDCG'
        d19 = 'VREF_VDDHRS'
        d20 = 'VDDHRS'
        d21 = 'VREF_VAACLGRD'
        d22 = 'VAACLGRD'
        d23 = 'VREF_VDDHDCGMID'
        d24 = 'VDDHDCGMID'

        figTitle = 'High_LDO_Voltage'
        ylabel = 'LDO Voltage (v)'
        numDataCols = 25  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y_%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Middle_LDO_Voltage_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'VAACLGINT'
        d2 = 'VREF_VAALDO2P4'
        d3 = 'VDDROWLOGIC'

        figTitle = 'Middle_LDO_Voltage'
        ylabel = 'LDO Voltage (v)'
        numDataCols = 4  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y_%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Low_LDO_Voltage_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'VSSHILOGIC'
        d2 = 'VREF_VSSHILOGIC'
        d3 = 'VSSRWROWDRV'
        d4 = 'VREF_VSSRWROWDRV'
        d5 = 'VSSROWLOGIC'
        d6 = 'VREF_VSSROWLOGIC'
        d7 = 'VSSLORST'
        d8 = 'VREF_VSSLORST'
        d9 = 'VSSLODCG'
        d10 = 'VREF_VSSLODCG'
        d11 = 'VSSLOGC'
        d12 = 'VREF_VSSLOGC'
        d13 = 'VSSLOTX'
        d14 = 'VREF_VSSLOTX'
        d15 = 'VDDPAR_T2_TX'
        d16 = 'VREF_VDDPAR_T2_TX'
        d17 = 'VDDPAR_T1_TX'
        d18 = 'VREF_VDDPAR_T1_TX'
        d19 = 'VDDPARGC'
        d20 = 'VREF_VDDPARGC'
        d21 = 'VSSLOSELRST'
        d22 = 'VREF_VSSLOSELRST'
        d23 = 'VSSLOSELGC'
        d24 = 'VREF_VSSLOSELGC'
        d25 = 'VSSLOSELDCG'
        d26 = 'VREF_VSSLOSELDCG'
        d27 = 'VSSLOSELTX'
        d28 = 'VREF_VSSLOSELTX'

        figTitle = 'Low_LDO_Voltage'
        ylabel = 'LDO Voltage (v)'
        numDataCols = 29  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y_%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found


'''
Trim Data
'''
def Trim_Calculate_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'I_PTAT_TARGET(A)'
        d2 = 'I_PTAT_TRIM_CODE_1'
        d3 = 'I_PTAT_MEASURE_1(A)'
        d4 = 'I_PTAT_TRIM_CODE_2'
        d5 = 'I_PTAT_MEASURE_2(A)'
        d6 = 'I_PTAT_TRIM_CODE'
        d7 = 'I_PTAT_TRIMMED(A)'
        d8 = 'I_PTAT_ERROR(A)'
        d9 = 'I_PTAT_PERC_ERROR'
        d10 = 'V_VBG_TARGET(v)'
        d11 = 'V_VBG_TRIM_CODE_1'
        d12 = 'V_VBG_MEASURE_1(v)'
        d13 = 'V_VBG_TRIM_CODE_2'
        d14 = 'V_VBG_MEASURE_2(v)'
        d15 = 'V_VBG_TRIM_CODE'
        d16 = 'V_VBG_TRIMMED(v)'
        d17 = 'V_VBG_ERROR(v)'
        d18 = 'V_VBG_PERC_ERROR'
        d19 = 'I_CTAT_TARGET(A)'
        d20 = 'I_CTAT_TRIM_CODE_1'
        d21 = 'I_CTAT_MEASURE_1(A)'
        d22 = 'I_CTAT_TRIM_CODE_2'
        d23 = 'I_CTAT_MEASURE_2(A)'
        d24 = 'I_CTAT_TRIM_CODE'
        d25 = 'I_CTAT_TRIMMED(A)'
        d26 = 'I_CTAT_ERROR(A)'
        d27 = 'I_CTAT_PERC_ERROR'
        d28 = 'I_PTAT_2V8_TARGET(A)'
        d29 = 'I_PTAT_2V8_TRIM_CODE_1'
        d30 = 'I_PTAT_2V8_MEASURE_1(A)'
        d31 = 'I_PTAT_2V8_TRIM_CODE_2'
        d32 = 'I_PTAT_2V8_MEASURE_2(A)'
        d33 = 'I_PTAT_2V8_TRIM_CODE'
        d34 = 'I_PTAT_2V8_TRIMMED(A)'
        d35 = 'I_PTAT_2V8_ERROR(A)'
        d36 = 'I_PTAT_2V8_PERC_ERROR'
        d37 = 'V_VBG_2V8_TARGET(v)'
        d38 = 'V_VBG_2V8_TRIM_CODE_1'
        d39 = 'V_VBG_2V8_MEASURE_1(v)'
        d40 = 'V_VBG_2V8_TRIM_CODE_2'
        d41 = 'V_VBG_2V8_MEASURE_2(v)'
        d42 = 'V_VBG_2V8_TRIM_CODE'
        d43 = 'V_VBG_2V8_TRIMMED(v)'
        d44 = 'V_VBG_2V8_ERROR(v)'
        d45 = 'V_VBG_2V8_PERC_ERROR'
        d46 = 'I_PTAT_1V8_TARGET(A)'
        d47 = 'I_PTAT_1V8_TRIM_CODE_1'
        d48 = 'I_PTAT_1V8_MEASURE_1(A)'
        d49 = 'I_PTAT_1V8_TRIM_CODE_2'
        d50 = 'I_PTAT_1V8_MEASURE_2(A)'
        d51 = 'I_PTAT_1V8_TRIM_CODE'
        d52 = 'I_PTAT_1V8_TRIMMED(A)'
        d53 = 'I_PTAT_1V8_ERROR(A)'
        d54 = 'I_PTAT_1V8_PERC_ERROR'
        d55 = 'V_VBG_1V8_TARGET(v)'
        d56 = 'V_VBG_1V8_TRIM_CODE_1'
        d57 = 'V_VBG_1V8_MEASURE_1(v)'
        d58 = 'V_VBG_1V8_TRIM_CODE_2'
        d59 = 'V_VBG_1V8_MEASURE_2(v)'
        d60 = 'V_VBG_1V8_TRIM_CODE'
        d61 = 'V_VBG_1V8_TRIMMED(v)'
        d62 = 'V_VBG_1V8_ERROR(v)'
        d63 = 'V_VBG_1V8_PERC_ERROR'
        d64 = 'I_CTAT_LDO_TARGET(A)'
        d65 = 'I_CTAT_LDO_TRIM_CODE_1'
        d66 = 'I_CTAT_LDO_MEASURE_1(A)'
        d67 = 'I_CTAT_LDO_TRIM_CODE_2'
        d68 = 'I_CTAT_LDO_MEASURE_2(A)'
        d69 = 'I_CTAT_LDO_TRIM_CODE'
        d70 = 'I_CTAT_LDO_TRIMMED(A)'
        d71 = 'I_CTAT_LDO_ERROR(A)'
        d72 = 'I_CTAT_LDO_PERC_ERROR'
        d73 = 'TSENS_I_VBE_REG_DEFAULT'
        d74 = 'TSENS_I_VBE_TARGET(A)'
        d75 = 'TSENS_I_VBE_TRIM_CODE_1'
        d76 = 'TSENS_I_VBE_MEASURE_1(A)'
        d77 = 'TSENS_I_VBE_TRIM_CODE_2'
        d78 = 'TSENS_I_VBE_MEASURE_2(A)'
        d79 = 'TSENS_I_VBE_TRIM_CODE'
        d80 = 'TSENS_I_VBE_TRIMMED(A)'
        d81 = 'TSENS_I_VBE_ERROR(A)'
        d82 = 'TSENS_I_VBE_PERC_ERROR'
        d83 = 'TSENS_I_VBG_REG_DEFAULT'
        d84 = 'TSENS_I_VBG_TARGET(A)'
        d85 = 'TSENS_I_VBG_TRIM_CODE_1'
        d86 = 'TSENS_I_VBG_MEASURE_1(A)'
        d87 = 'TSENS_I_VBG_TRIM_CODE_2'
        d88 = 'TSENS_I_VBG_MEASURE_2(A)'
        d89 = 'TSENS_I_VBG_TRIM_CODE'
        d90 = 'TSENS_I_VBG_TRIMMED(A)'
        d91 = 'TSENS_I_VBG_ERROR(A)'
        d92 = 'TSENS_I_VBG_PERC_ERROR'
        d93 = 'TSENS_V_VBG_TARGET(v)'
        d94 = 'TSENS_V_VBG_TRIM_CODE_1'
        d95 = 'TSENS_V_VBG_MEASURE_1(v)'
        d96 = 'TSENS_V_VBG_TRIM_CODE_2'
        d97 = 'TSENS_V_VBG_MEASURE_2(v)'
        d98 = 'TSENS_V_VBG_TRIM_CODE'
        d99 = 'TSENS_V_VBG_TRIMMED(v)'
        d100 = 'TSENS_V_VBG_ERROR(v)'
        d101 = 'TSENS_V_VBG_PERC_ERROR'
        d102 = 'TSENS_V_VCM_REG_DEFAULT'
        d103 = 'TSENS_V_VCM_TARGET(v)'
        d104 = 'TSENS_V_VCM_TRIM_CODE_1'
        d105 = 'TSENS_V_VCM_MEASURE_1(v)'
        d106 = 'TSENS_V_VCM_TRIM_CODE_2'
        d107 = 'TSENS_V_VCM_MEASURE_2(v)'
        d108 = 'TSENS_V_VCM_TRIM_CODE'
        d109 = 'TSENS_V_VCM_TRIMMED(v)'
        d110 = 'TSENS_V_VCM_ERROR(v)'
        d111 = 'TSENS_V_VCM_PERC_ERROR'
        d112 = 'V_PIXOUT_NMOS_CLAMP_TARGET(v)'
        d113 = 'V_PIXOUT_NMOS_CLAMP_TRIM_CODE_1'
        d114 = 'V_PIXOUT_NMOS_CLAMP_MEASURE_1(v)'
        d115 = 'V_PIXOUT_NMOS_CLAMP_TRIM_CODE_2'
        d116 = 'V_PIXOUT_NMOS_CLAMP_MEASURE_2(v)'
        d117 = 'V_PIXOUT_PMOS_CLAMP_TARGET(v)'
        d118 = 'V_PIXOUT_PMOS_CLAMP_TRIM_CODE_1 '
        d119 = 'V_PIXOUT_PMOS_CLAMP_MEASURE_1(v)'
        d120 = 'V_PIXOUT_PMOS_CLAMP_TRIM_CODE_2'
        d121 = 'V_PIXOUT_PMOS_CLAMP_MEASURE_2(v)'
        d122 = 'V_E1_SHR_TARGET(v)'
        d123 = 'V_E1_SHR_TRIM_CODE'
        d124 = 'V_E1_SHR_TRIMMED(v)'
        d125 = 'V_E1_SHR_ERROR'
        d126 = 'V_E1_SHS_TARGET(v)'
        d127 = 'V_E1_SHS_TRIM_CODE'
        d128 = 'V_E1_SHS_TRIMMED(v)'
        d129 = 'V_E1_SHS_ERROR'
        d130 = 'V_E2_SHR_TARGET(v)'
        d131 = 'V_E2_SHR_TRIM_CODE'
        d132 = 'V_E2_SHR_TRIMMED(v)'
        d133 = 'V_E2_SHR_ERROR'
        d134 = 'V_E3_SHR_TARGET(v)'
        d135 = 'V_E3_SHR_TRIM_CODE'
        d136 = 'V_E3_SHR_TRIMMED(v)'
        d137 = 'V_E3_SHR_ERROR'
        d138 = 'V_E3_SHS_TARGET(v)'
        d139 = 'V_E3_SHS_TRIM_CODE'
        d140 = 'V_E3_SHS_TRIMMED(v)'
        d141 = 'V_E3_SHS_ERROR'
        d142 = 'V_OVERDRIVE_4T_AMP_SHR_TARGET(v)'
        d143 = 'V_OVERDRIVE_4T_AMP_SHR_TRIM_CODE'
        d144 = 'V_OVERDRIVE_4T_AMP_SHR_TRIMMED(v)'
        d145 = 'V_OVERDRIVE_4T_AMP_SHR_ERROR'
        d146 = 'V_OVERDRIVE_4T_AMP_SHS_TARGET(v)'
        d147 = 'V_OVERDRIVE_4T_AMP_SHS_TRIM_CODE'
        d148 = 'V_OVERDRIVE_4T_AMP_SHS_TRIMMED(v)'
        d149 = 'V_OVERDRIVE_4T_AMP_SHS_ERROR'
        d150 = 'V_OVERDRIVE_3T_AMP_SHR_TARGET(v)'
        d151 = 'V_OVERDRIVE_3T_AMP_SHR_TRIM_CODE'
        d152 = 'V_OVERDRIVE_3T_AMP_SHR_TRIMMED(v)'
        d153 = 'V_OVERDRIVE_3T_AMP_SHR_ERROR'
        d154 = 'V_OVERDRIVE_3T_AMP_SHS_TARGET(v)'
        d155 = 'V_OVERDRIVE_3T_AMP_SHS_TRIM_CODE'
        d156 = 'V_OVERDRIVE_3T_AMP_SHS_TRIMMED(v)'
        d157 = 'V_OVERDRIVE_3T_AMP_SHS_ERROR'
        d158 = 'V_ADC_CODE012_SHR_TARGET(v)'
        d159 = 'V_ADC_CODE012_SHR_TRIM_CODE'
        d160 = 'V_ADC_CODE012_SHR_TRIMMED(v)'
        d161 = 'V_ADC_CODE012_SHR_ERROR'
        d162 = 'V_ADC_CODE0_SHS_TARGET(v)'
        d163 = 'V_ADC_CODE0_SHS_TRIM_CODE'
        d164 = 'V_ADC_CODE0_SHS_TRIMMED(v)'
        d165 = 'V_ADC_CODE0_SHS_ERROR'
        d166 = 'V_ADC_CODE1_SHS_TARGET(v)'
        d167 = 'V_ADC_CODE1_SHS_TRIM_CODE'
        d168 = 'V_ADC_CODE1_SHS_TRIMMED(v)'
        d169 = 'V_ADC_CODE1_SHS_ERROR'
        d170 = 'V_ADC_CODE2_SHS_TARGET(v)'
        d171 = 'V_ADC_CODE2_SHS_TRIM_CODE'
        d172 = 'V_ADC_CODE2_SHS_TRIMMED(v)'
        d173 = 'V_ADC_CODE2_SHS_ERROR'
        d174 = 'V_OVERDRIVE_ROW12_ZEBRA_SHS_TARGET(v)'
        d175 = 'V_OVERDRIVE_ROW12_ZEBRA_SHS_TRIM_CODE'
        d176 = 'V_OVERDRIVE_ROW12_ZEBRA_SHS_TRIMMED(v)'
        d177 = 'V_OVERDRIVE_ROW12_ZEBRA_SHS_ERROR'
        d178 = 'V_VERTICAL_TEST_SHS_TARGET(v)'
        d179 = 'V_VERTICAL_TEST_SHS_TRIM_CODE'
        d180 = 'V_VERTICAL_TEST_SHS_TRIMMED(v)'
        d181 = 'V_VERTICAL_TEST_SHS_ERROR'

        figTitle = 'Trim_Results'
        numDataCols = 182  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y_%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Current_Trim_Reference_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'I_PTAT_TRIMMED(A)'
        d2 = 'I_CTAT_TRIMMED(A)'
        d3 = 'I_PTAT_2V8_TRIMMED(A)'
        d4 = 'I_PTAT_1V8_TRIMMED(A)'
        d5 = 'I_CTAT_LDO_TRIMMED(A)'
        d6 = 'TSENS_I_VBE_TRIMMED(A)'
        d7 = 'TSENS_I_VBG_TRIMMED(A)'
    
        figTitle = 'Current_Trim_Reference'
        ylabel = 'Current (A)'
        numDataCols = 8  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame
    
        currTime = time.strftime("%m%d%Y_%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)
    
        document.add_heading(figTitle, level=2)  # Add section title to docx report
    
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Voltage_Trim_Reference_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'V_VBG_TRIMMED(v)'
        d2 = 'V_VBG_2V8_TRIMMED(v)'
        d3 = 'V_VBG_1V8_TRIMMED(v)'
        d4 = 'TSENS_V_VBG_TRIMMED(v)'
        d5 = 'TSENS_V_VCM_TRIMMED(v)'
        d5 = 'V_E1_SHR_TRIMMED(v)'
        d6 = 'V_E1_SHS_TRIMMED(v)'
        d7 = 'V_E2_SHR_TRIMMED(v)'
        d8 = 'V_E3_SHR_TRIMMED(v)'
        d9 = 'V_OVERDRIVE_4T_AMP_SHR_TRIMMED(v)'
        d10 = 'V_OVERDRIVE_4T_AMP_SHS_TRIMMED(v)'
        d11 = 'V_OVERDRIVE_3T_AMP_SHR_TRIMMED(v)'
        d12 = 'V_OVERDRIVE_3T_AMP_SHS_TRIMMED(v)'
        d13 = 'V_ADC_CODE012_SHR_TRIMMED(v)'
        d14 = 'V_ADC_CODE0_SHS_TRIMMED(v)'
        d15 = 'V_ADC_CODE1_SHS_TRIMMED(v)'
        d16 = 'V_ADC_CODE2_SHS_TRIMMED(v)'
        d17 = 'V_OVERDRIVE_ROW12_ZEBRA_SHR_TRIMMED(v)'
        d18 = 'V_OVERDRIVE_ROW12_ZEBRA_SHS_TRIMMED(v)'
        d19 = 'V_VERTICAL_TEST_SHS_TRIMMED(v)'
    
        figTitle = 'Voltage_Trim_Reference'
        ylabel = 'Voltage (v)'
        numDataCols = 20  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame
    
        currTime = time.strftime("%m%d%Y_%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)
    
        document.add_heading(figTitle, level=2)  # Add section title to docx report
    
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
                
def Current_Reference_vs_Trim_vs_TestNo_Plot(dataFrame, groupCol, groupVal, document, pltPath, showPlt, **kwargs):
    try:
        if groupCol == None and groupVal == None:  #Dont group data frame
            df = dataFrame
        elif groupCol != None and groupVal != None: #Group data frame by col and value
            df = VRG_Data_Frame.newdataframe(dataFrame, groupCol, groupVal)
            
        d1 = 'I_PTAT_TRIMMED Trim'
        d2 = 'I_CTAT_TRIMMED Trim'
        d3 = 'I_PTAT_2V8_TRIMMED Trim'
        d4 = 'I_PTAT_1V8_TRIMMED Trim'
        d5 = 'I_CTAT_LDO_TRIMMED Trim'
        d6 = 'TSENS_I_VBE_TRIMMED Trim'
        d7 = 'TSENS_I_VBG_TRIMMED Trim'

        # get data columns
        t1_cols = [x for x in df.columns[df.columns.str.contains(d1)]]
        t2_cols = [x for x in df.columns[df.columns.str.contains(d2)]]
        t3_cols = [x for x in df.columns[df.columns.str.contains(d3)]]
        t4_cols = [x for x in df.columns[df.columns.str.contains(d4)]]
        t5_cols = [x for x in df.columns[df.columns.str.contains(d5)]]
        t6_cols = [x for x in df.columns[df.columns.str.contains(d6)]]
        t7_cols = [x for x in df.columns[df.columns.str.contains(d7)]]

        # subset df
        t1 = df[t1_cols]
        t2 = df[t2_cols]
        t3 = df[t3_cols]
        t4 = df[t4_cols]
        t5 = df[t5_cols]
        t6 = df[t6_cols]
        t7 = df[t7_cols]
        
        # rename columns to get read number
        for dc in t1_cols:
            t1 = t1.rename(columns={dc: dc.split(' ')[2]})  # get the integer (2) value from the name
        for dc in t2_cols:
            t2 = t2.rename(columns={dc: dc.split(' ')[2]})  # get the integer (2) value from the name
        for dc in t3_cols:
            t3 = t3.rename(columns={dc: dc.split(' ')[2]})  # get the integer (2) value from the name
        for dc in t4_cols:
            t4 = t4.rename(columns={dc: dc.split(' ')[2]})  # get the integer (2) value from the name
        for dc in t5_cols:
            t5 = t5.rename(columns={dc: dc.split(' ')[2]})  # get the integer (2) value from the name
        for dc in t6_cols:
            t6 = t6.rename(columns={dc: dc.split(' ')[2]})  # get the integer (2) value from the name
        for dc in t7_cols:
            t7 = t7.rename(columns={dc: dc.split(' ')[2]})  # get the integer (2) value from the name

        # transpose
        t1 = t1.T
        t2 = t2.T
        t3 = t3.T
        t4 = t4.T
        t5 = t5.T
        t6 = t6.T
        t7 = t7.T

        # add an index column
        t1['Trim'] = t1.index
        t2['Trim'] = t2.index
        t3['Trim'] = t3.index
        t4['Trim'] = t4.index
        t5['Trim'] = t5.index
        t6['Trim'] = t6.index
        t7['Trim'] = t7.index

        figTitle = 'Current_Reference_vs_Trim_vs_TestNo'
        numDataColsT1 = len(t1.index)
        numDataColsT2 = len(t2.index)
        numDataColsT3 = len(t3.index)
        numDataColsT4 = len(t4.index)
        numDataColsT5 = len(t5.index)
        numDataColsT6 = len(t6.index)
        numDataColsT7 = len(t7.index)
        titleFontSize = 12
        yFontsize = 8
        xFontsize = 8
        legFontSize = 6

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupCol == None and groupVal == None:  # No Dataframe grouping
            document.add_heading(d1 + " vs. Test #", level=2)
            for x in range(1, numDataColsT1):
                fcp.plot(t1, x='Trim', y=x, title="Test #" + str(x), show=showPlt,
                         inline=showPlt, label_y=d1, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
                document.add_heading(d1 + " Test #" + str(x), level=3)
                document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
            document.add_heading(d2 + " vs. Test #", level=2)
            for x in range(1, numDataColsT2):
                fcp.plot(t2, x='Trim', y=x, title="Test #" + str(x), show=showPlt,
                         inline=showPlt, label_y=d2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d2 + '_' + timestamp + '.png')
                document.add_heading(d2 + " Test #" + str(x), level=3)
                document.add_picture(pltPath + d2 + '_' + timestamp + '.png')  # Add figure to report
            document.add_heading(d3 + " vs. Test #", level=2)
            for x in range(1, numDataColsT3):
                fcp.plot(t3, x='Trim', y=x, title="Test #" + str(x), show=showPlt,
                         inline=showPlt, label_y=d3, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d3 + '_' + timestamp + '.png')
                document.add_heading(d3 + " Test #" + str(x), level=3)
                document.add_picture(pltPath + d3 + '_' + timestamp + '.png')  # Add figure to report
            document.add_heading(d4 + " vs. Test #", level=2)
            for x in range(1, numDataColsT4):
                fcp.plot(t4, x='Trim', y=x, title="Test #" + str(x), show=showPlt,
                         inline=showPlt, label_y=d4, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d4 + '_' + timestamp + '.png')
                document.add_heading(d4 + " Test #" + str(x), level=3)
                document.add_picture(pltPath + d4 + '_' + timestamp + '.png')  # Add figure to report
            for x in range(1, numDataColsT5):
                fcp.plot(t5, x='Trim', y=x, title="Test #" + str(x), show=showPlt,
                         inline=showPlt, label_y=d5, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d5 + '_' + timestamp + '.png')
                document.add_heading(d5 + " Test #" + str(x), level=3)
                document.add_picture(pltPath + d5 + '_' + timestamp + '.png')  # Add figure to report
            for x in range(1, numDataColsT6):
                fcp.plot(t6, x='Trim', y=x, title="Test #" + str(x), show=showPlt,
                         inline=showPlt, label_y=d6, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d6 + '_' + timestamp + '.png')
                document.add_heading(d6 + " Test #" + str(x), level=3)
                document.add_picture(pltPath + d6 + '_' + timestamp + '.png')  # Add figure to report
            for x in range(1, numDataColsT7):
                fcp.plot(t7, x='Trim', y=x, title="Test #" + str(x), show=showPlt,
                         inline=showPlt, label_y=d7, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d7 + '_' + timestamp + '.png')
                document.add_heading(d7 + " Test #" + str(x), level=3)
                document.add_picture(pltPath + d7 + '_' + timestamp + '.png')  # Add figure to report
        elif groupCol != None and groupVal != None: # Data frame grouped by col and val
            document.add_heading(d1 + " vs. Test # Groupedby: " + groupCol + ' = ' + str(groupVal), level=2)
            for x in range(1, numDataColsT1):
                fcp.plot(t1, x='Trim', y=x, title="Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal), show=showPlt,
                         inline=showPlt, label_y=d1, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
                document.add_heading(d1 + " Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
                document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
            document.add_heading(d2 + " vs. Test # Groupedby: " + groupCol + ' = ' + str(groupVal), level=2)
            for x in range(1, numDataColsT2):
                fcp.plot(t2, x='Trim', y=x, title="Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal), show=showPlt,
                         inline=showPlt, label_y=d2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d2 + '_' + timestamp + '.png')
                document.add_heading(d2 + " Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
                document.add_picture(pltPath + d2 + '_' + timestamp + '.png')  # Add figure to report
            document.add_heading(d3 + " vs. Test # Groupedby: " + groupCol + ' = ' + str(groupVal), level=2)
            for x in range(1, numDataColsT3):
                fcp.plot(t3, x='Trim', y=x, title="Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal), show=showPlt,
                         inline=showPlt, label_y=d3, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d3 + '_' + timestamp + '.png')
                document.add_heading(d3 + " Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
                document.add_picture(pltPath + d3 + '_' + timestamp + '.png')  # Add figure to report
            document.add_heading(d4 + " vs. Test # Groupedby: " + groupCol + ' = ' + str(groupVal), level=2)
            for x in range(1, numDataColsT4):
                fcp.plot(t4, x='Trim', y=x, title="Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal), show=showPlt,
                         inline=showPlt, label_y=d4, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d4 + '_' + timestamp + '.png')
                document.add_heading(d4 + " Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
                document.add_picture(pltPath + d4 + '_' + timestamp + '.png')  # Add figure to report
            for x in range(1, numDataColsT5):
                fcp.plot(t5, x='Trim', y=x, title="Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal), show=showPlt,
                         inline=showPlt, label_y=d5, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d5 + '_' + timestamp + '.png')
                document.add_heading(d5 + " Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
                document.add_picture(pltPath + d5 + '_' + timestamp + '.png')  # Add figure to report
            for x in range(1, numDataColsT6):
                fcp.plot(t6, x='Trim', y=x, title="Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal), show=showPlt,
                         inline=showPlt, label_y=d6, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d6 + '_' + timestamp + '.png')
                document.add_heading(d6 + " Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
                document.add_picture(pltPath + d6 + '_' + timestamp + '.png')  # Add figure to report
            for x in range(1, numDataColsT7):
                fcp.plot(t7, x='Trim', y=x, title="Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal), show=showPlt,
                         inline=showPlt, label_y=d7, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d7 + '_' + timestamp + '.png')
                document.add_heading(d7 + " Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
                document.add_picture(pltPath + d7 + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for dc in t1_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t2_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t3_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t4_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t5_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t6_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t7_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        if groupCol == None:
            document.add_heading("groupCol Not Used", level=3)
        elif groupCol != None:
            if groupCol in df.columns:
                document.add_heading("groupCol Found: " + groupCol, level=3)  # Add Groupby found
                if groupVal == None:
                    document.add_heading("groupVal Missing", level=3)
                elif groupVal != None:
                    if groupCol in df[groupCol].unique():
                        document.add_heading("groupVal Found: " + groupVal, level=3)  # Add Groupby found
                    else:
                        document.add_heading("groupVal Not Found: " + groupVal, level=3)  # Add Groupby not found
            else:
                document.add_heading("groupCol Not Found: " + groupCol, level=3)  # Add Groupby not found

def Current_Reference_vs_Trim__vs_Time_Plot(dataFrame, groupCol, groupVal, document, pltPath, showPlt, **kwargs):
    try:
        if groupCol == None and groupVal == None:  #Dont group data frame
            df = dataFrame
        elif groupCol != None and groupVal != None: #Group data frame by col and value
            df = VRG_Data_Frame.newdataframe(dataFrame, groupCol, groupVal)

        d1 = 'I_PTAT_TRIMMED Trim'
        d2 = 'I_CTAT_TRIMMED Trim'
        d3 = 'I_PTAT_2V8_TRIMMED Trim'
        d4 = 'I_PTAT_1V8_TRIMMED Trim'
        d5 = 'I_CTAT_LDO_TRIMMED Trim'
        d6 = 'TSENS_I_VBE_TRIMMED Trim'
        d7 = 'TSENS_I_VBG_TRIMMED Trim'

        # get data columns
        t1_cols = [x for x in df.columns[df.columns.str.contains(d1)]]
        t2_cols = [x for x in df.columns[df.columns.str.contains(d2)]]
        t3_cols = [x for x in df.columns[df.columns.str.contains(d3)]]
        t4_cols = [x for x in df.columns[df.columns.str.contains(d4)]]
        t5_cols = [x for x in df.columns[df.columns.str.contains(d5)]]
        t6_cols = [x for x in df.columns[df.columns.str.contains(d6)]]
        t7_cols = [x for x in df.columns[df.columns.str.contains(d7)]]

        # subset df
        t1 = df[t1_cols]
        t2 = df[t2_cols]
        t3 = df[t3_cols]
        t4 = df[t4_cols]
        t5 = df[t5_cols]
        t6 = df[t6_cols]
        t7 = df[t7_cols]

        # rename columns to get read number
        for dc in t1_cols:
            t1 = t1.rename(columns={dc: dc.split(' ')[2]}) # get the integer (2) value from the name
        for dc in t2_cols:
            t2 = t2.rename(columns={dc: dc.split(' ')[2]}) # get the integer (2) value from the name
        for dc in t3_cols:
            t3 = t3.rename(columns={dc: dc.split(' ')[2]}) # get the integer (2) value from the name
        for dc in t4_cols:
            t4 = t4.rename(columns={dc: dc.split(' ')[2]}) # get the integer (2) value from the name
        for dc in t5_cols:
            t5 = t5.rename(columns={dc: dc.split(' ')[2]}) # get the integer (2) value from the name
        for dc in t6_cols:
            t6 = t6.rename(columns={dc: dc.split(' ')[2]}) # get the integer (2) value from the name
        for dc in t7_cols:
            t7 = t7.rename(columns={dc: dc.split(' ')[2]}) # get the integer (2) value from the name
        
        # transpose
        t1 = t1.T
        t2 = t2.T
        t3 = t3.T
        t4 = t4.T
        t5 = t5.T
        t6 = t6.T
        t7 = t7.T
        
        # add an index column
        t1['Trim'] = t1.index
        t2['Trim'] = t2.index
        t3['Trim'] = t3.index
        t4['Trim'] = t4.index
        t5['Trim'] = t5.index
        t6['Trim'] = t6.index
        t7['Trim'] = t7.index
        
        colList = []
        for index in df.index:
            colList.append(index)

        figTitle = 'Current_Reference_vs_Trim_vs_Time'
        titleFontSize = 12
        yFontsize = 8
        xFontsize = 8
        legFontSize = 6

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupCol == None and groupVal == None:  # No Dataframe grouping
                fcp.plot(t1, x='Trim', y=colList, title=d1, legend_title="Test #", show=showPlt,
                         inline=showPlt, label_y=d1, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
                document.add_heading(d1, level=3)
                document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
                fcp.plot(t2, x='Trim', y=colList, title=d2, legend_title="Test #", show=showPlt,
                         inline=showPlt, label_y=d2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d2 + '_' + timestamp + '.png')
                document.add_heading(d2, level=3)
                document.add_picture(pltPath + d2 + '_' + timestamp + '.png')  # Add figure to report
                fcp.plot(t3, x='Trim', y=colList, title=d3, legend_title="Test #", show=showPlt,
                         inline=showPlt, label_y=d3, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d3 + '_' + timestamp + '.png')
                document.add_heading(d3, level=3)
                document.add_picture(pltPath + d3 + '_' + timestamp + '.png')  # Add figure to report
                fcp.plot(t4, x='Trim', y=colList, title=d4, legend_title="Test #", show=showPlt,
                         inline=showPlt, label_y=d4, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d4 + '_' + timestamp + '.png')
                document.add_heading(d4, level=3)
                document.add_picture(pltPath + d4 + '_' + timestamp + '.png')  # Add figure to report
                fcp.plot(t5, x='Trim', y=colList, title=d5, legend_title="Test #", show=showPlt,
                         inline=showPlt, label_y=d5, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d5 + '_' + timestamp + '.png')
                document.add_heading(d5, level=3)
                document.add_picture(pltPath + d5 + '_' + timestamp + '.png')  # Add figure to report
                fcp.plot(t6, x='Trim', y=colList, title=d6, legend_title="Test #", show=showPlt,
                         inline=showPlt, label_y=d6, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d6 + '_' + timestamp + '.png')
                document.add_heading(d6, level=3)
                document.add_picture(pltPath + d6 + '_' + timestamp + '.png')  # Add figure to report
                fcp.plot(t7, x='Trim', y=colList, title=d7, legend_title="Test #", show=showPlt,
                         inline=showPlt, label_y=d7, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d7 + '_' + timestamp + '.png')
                document.add_heading(d7, level=3)
                document.add_picture(pltPath + d7 + '_' + timestamp + '.png')  # Add figure to report
        elif groupCol != None and groupVal != None: # Data frame grouped by col and val
                fcp.plot(t1, x='Trim', y=colList, title=d1 + " Groupedby: " + groupCol + ' = ' + str(groupVal), show=showPlt,
                         inline=showPlt, legend_title="Test #", label_y=d1, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
                document.add_heading(d1 + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
                document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
                fcp.plot(t2, x='Trim', y=colList, title=d2 + " Groupedby: " + groupCol + ' = ' + str(groupVal), show=showPlt,
                         inline=showPlt, legend_title="Test #", label_y=d2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d2 + '_' + timestamp + '.png')
                document.add_heading(d2 + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
                document.add_picture(pltPath + d2 + '_' + timestamp + '.png')  # Add figure to report
                fcp.plot(t3, x='Trim', y=colList, title=d3 + " Groupedby: " + groupCol + ' = ' + str(groupVal), show=showPlt,
                         inline=showPlt, legend_title="Test #", label_y=d3, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d3 + '_' + timestamp + '.png')
                document.add_heading(d3 + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
                document.add_picture(pltPath + d3 + '_' + timestamp + '.png')  # Add figure to report
                fcp.plot(t4, x='Trim', y=colList, title=d4 + " Groupedby: " + groupCol + ' = ' + str(groupVal), show=showPlt,
                         inline=showPlt, legend_title="Test #", label_y=d4, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d4 + '_' + timestamp + '.png')
                document.add_heading(d4 + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
                document.add_picture(pltPath + d4 + '_' + timestamp + '.png')  # Add figure to report
                fcp.plot(t5, x='Trim', y=colList, title=d5 + " Groupedby: " + groupCol + ' = ' + str(groupVal), show=showPlt,
                         inline=showPlt, legend_title="Test #", label_y=d5, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d5 + '_' + timestamp + '.png')
                document.add_heading(d5 + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
                document.add_picture(pltPath + d5 + '_' + timestamp + '.png')  # Add figure to report
                fcp.plot(t6, x='Trim', y=colList, title=d6 + " Groupedby: " + groupCol + ' = ' + str(groupVal), show=showPlt,
                         inline=showPlt, legend_title="Test #", label_y=d6, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d6 + '_' + timestamp + '.png')
                document.add_heading(d6 + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
                document.add_picture(pltPath + d6 + '_' + timestamp + '.png')  # Add figure to report
                fcp.plot(t7, x='Trim', y=colList, title=d7 + " Groupedby: " + groupCol + ' = ' + str(groupVal), show=showPlt,
                         inline=showPlt, legend_title="Test #", label_y=d7, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d7 + '_' + timestamp + '.png')
                document.add_heading(d7 + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
                document.add_picture(pltPath + d7 + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for dc in t1_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t2_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t3_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t4_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t5_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t6_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t7_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        if groupCol == None:
            document.add_heading("groupCol Not Used", level=3)
        elif groupCol != None:
            if groupCol in df.columns:
                document.add_heading("groupCol Found: " + groupCol, level=3)  # Add Groupby found
                if groupVal == None:
                    document.add_heading("groupVal Missing", level=3)
                elif groupVal != None:
                    if groupCol in df[groupCol].unique():
                        document.add_heading("groupVal Found: " + groupVal, level=3)  # Add Groupby found
                    else:
                        document.add_heading("groupVal Not Found: " + groupVal, level=3)  # Add Groupby not found
            else:
                document.add_heading("groupCol Not Found: " + groupCol, level=3)  # Add Groupby not found

def Voltage_Reference_vs_Trim_vs_TestNo_Plot(dataFrame, groupCol, groupVal, document, pltPath, showPlt, **kwargs):
    try:
        if groupCol == None and groupVal == None:  # Dont group data frame
            df = dataFrame
        elif groupCol != None and groupVal != None:  # Group data frame by col and value
            df = VRG_Data_Frame.newdataframe(dataFrame, groupCol, groupVal)

        d1 = 'V_VBG_TRIMMED Trim'
        d2 = 'V_VBG_2V8_TRIMMED Trim'
        d3 = 'V_VBG_1V8_TRIMMED Trim'
        d4 = 'TSENS_V_VBG_TRIMMED Trim'
        d5 = 'TSENS_V_VCM_TRIMMED Trim'
        d5 = 'V_E1_SHR_TRIMMED Trim'
        d6 = 'V_E1_SHS_TRIMMED Trim'
        d7 = 'V_E2_SHR_TRIMMED Trim'
        d8 = 'V_E3_SHR_TRIMMED Trim'
        d9 = 'V_OVERDRIVE_4T_AMP_SHR_TRIMMED Trim'
        d10 = 'V_OVERDRIVE_4T_AMP_SHS_TRIMMED Trim'
        d11 = 'V_OVERDRIVE_3T_AMP_SHR_TRIMMED Trim'
        d12 = 'V_OVERDRIVE_3T_AMP_SHS_TRIMMED Trim'
        d13 = 'V_ADC_CODE012_SHR_TRIMMED Trim'
        d14 = 'V_ADC_CODE0_SHS_TRIMMED Trim'
        d15 = 'V_ADC_CODE1_SHS_TRIMMED Trim'
        d16 = 'V_ADC_CODE2_SHS_TRIMMED Trim'
        d17 = 'V_OVERDRIVE_ROW12_ZEBRA_SHR_TRIMMED Trim'
        d18 = 'V_OVERDRIVE_ROW12_ZEBRA_SHS_TRIMMED Trim'
        d19 = 'V_VERTICAL_TEST_SHS_TRIMMED Trim'

        # get data columns
        t1_cols = [x for x in df.columns[df.columns.str.contains(d1)]]
        t2_cols = [x for x in df.columns[df.columns.str.contains(d2)]]
        t3_cols = [x for x in df.columns[df.columns.str.contains(d3)]]
        t4_cols = [x for x in df.columns[df.columns.str.contains(d4)]]
        t5_cols = [x for x in df.columns[df.columns.str.contains(d5)]]
        t6_cols = [x for x in df.columns[df.columns.str.contains(d6)]]
        t7_cols = [x for x in df.columns[df.columns.str.contains(d7)]]
        t8_cols = [x for x in df.columns[df.columns.str.contains(d8)]]
        t9_cols = [x for x in df.columns[df.columns.str.contains(d9)]]
        t10_cols = [x for x in df.columns[df.columns.str.contains(d10)]]
        t11_cols = [x for x in df.columns[df.columns.str.contains(d11)]]
        t12_cols = [x for x in df.columns[df.columns.str.contains(d12)]]
        t13_cols = [x for x in df.columns[df.columns.str.contains(d13)]]
        t14_cols = [x for x in df.columns[df.columns.str.contains(d14)]]
        t15_cols = [x for x in df.columns[df.columns.str.contains(d15)]]
        t16_cols = [x for x in df.columns[df.columns.str.contains(d16)]]
        t17_cols = [x for x in df.columns[df.columns.str.contains(d17)]]
        t18_cols = [x for x in df.columns[df.columns.str.contains(d18)]]
        t19_cols = [x for x in df.columns[df.columns.str.contains(d19)]]

        # subset df
        t1 = df[t1_cols]
        t2 = df[t2_cols]
        t3 = df[t3_cols]
        t4 = df[t4_cols]
        t5 = df[t5_cols]
        t6 = df[t6_cols]
        t7 = df[t7_cols]
        t8 = df[t8_cols]
        t9 = df[t9_cols]
        t10 = df[t10_cols]
        t11 = df[t11_cols]
        t12 = df[t12_cols]
        t13 = df[t13_cols]
        t14 = df[t14_cols]
        t15 = df[t15_cols]
        t16 = df[t16_cols]
        t17 = df[t17_cols]
        t18 = df[t18_cols]
        t19 = df[t19_cols]

        # rename columns to get read number
        for dc in t1_cols:
            t1 = t1.rename(columns={dc: dc.split(' ')[2]})  # get the integer (2) value from the name
        for dc in t2_cols:
            t2 = t2.rename(columns={dc: dc.split(' ')[2]})  # get the integer (2) value from the name
        for dc in t3_cols:
            t3 = t3.rename(columns={dc: dc.split(' ')[2]})  # get the integer (2) value from the name
        for dc in t4_cols:
            t4 = t4.rename(columns={dc: dc.split(' ')[2]})  # get the integer (2) value from the name
        for dc in t5_cols:
            t5 = t5.rename(columns={dc: dc.split(' ')[2]})  # get the integer (2) value from the name
        for dc in t6_cols:
            t6 = t6.rename(columns={dc: dc.split(' ')[2]})  # get the integer (2) value from the name
        for dc in t7_cols:
            t7 = t7.rename(columns={dc: dc.split(' ')[2]})  # get the integer (2) value from the name
        for dc in t8_cols:
            t8 = t8.rename(columns={dc: dc.split(' ')[2]})  # get the integer (2) value from the name
        for dc in t9_cols:
            t9 = t9.rename(columns={dc: dc.split(' ')[2]})  # get the integer (2) value from the name
        for dc in t10_cols:
            t10 = t10.rename(columns={dc: dc.split(' ')[2]})  # get the integer (2) value from the name
        for dc in t11_cols:
            t11 = t11.rename(columns={dc: dc.split(' ')[2]})  # get the integer (2) value from the name
        for dc in t12_cols:
            t12 = t12.rename(columns={dc: dc.split(' ')[2]})  # get the integer (2) value from the name
        for dc in t13_cols:
            t13 = t13.rename(columns={dc: dc.split(' ')[2]})  # get the integer (2) value from the name
        for dc in t14_cols:
            t14 = t14.rename(columns={dc: dc.split(' ')[2]})  # get the integer (2) value from the name
        for dc in t15_cols:
            t15 = t15.rename(columns={dc: dc.split(' ')[2]})  # get the integer (2) value from the name
        for dc in t16_cols:
            t16 = t16.rename(columns={dc: dc.split(' ')[2]})  # get the integer (2) value from the name
        for dc in t17_cols:
            t17 = t17.rename(columns={dc: dc.split(' ')[2]})  # get the integer (2) value from the name
        for dc in t18_cols:
            t18 = t18.rename(columns={dc: dc.split(' ')[2]})  # get the integer (2) value from the name
        for dc in t19_cols:
            t19 = t19.rename(columns={dc: dc.split(' ')[2]})  # get the integer (2) value from the name

        # transpose
        t1 = t1.T
        t2 = t2.T
        t3 = t3.T
        t4 = t4.T
        t5 = t5.T
        t6 = t6.T
        t7 = t7.T
        t8 = t8.T
        t9 = t9.T
        t10 = t10.T
        t11 = t11.T
        t12 = t12.T
        t13 = t13.T
        t14 = t14.T
        t15 = t15.T
        t16 = t16.T
        t17 = t17.T
        t18 = t18.T
        t19 = t19.T

        # add an index column
        t1['Trim'] = t1.index
        t2['Trim'] = t2.index
        t3['Trim'] = t3.index
        t4['Trim'] = t4.index
        t5['Trim'] = t5.index
        t6['Trim'] = t6.index
        t7['Trim'] = t7.index
        t8['Trim'] = t8.index
        t9['Trim'] = t9.index
        t10['Trim'] = t10.index
        t11['Trim'] = t11.index
        t12['Trim'] = t12.index
        t13['Trim'] = t13.index
        t14['Trim'] = t14.index
        t15['Trim'] = t15.index
        t16['Trim'] = t16.index
        t17['Trim'] = t17.index
        t18['Trim'] = t18.index
        t19['Trim'] = t19.index

        figTitle = 'Voltage_Reference_vs_Trim_vs_TestNo'
        numDataColsT1 = len(t1.index)
        numDataColsT2 = len(t2.index)
        numDataColsT3 = len(t3.index)
        numDataColsT4 = len(t4.index)
        numDataColsT5 = len(t5.index)
        numDataColsT6 = len(t6.index)
        numDataColsT7 = len(t7.index)
        numDataColsT8 = len(t8.index)
        numDataColsT9 = len(t9.index)
        numDataColsT10 = len(t10.index)
        numDataColsT11 = len(t11.index)
        numDataColsT12 = len(t12.index)
        numDataColsT13 = len(t13.index)
        numDataColsT14 = len(t14.index)
        numDataColsT15 = len(t15.index)
        numDataColsT16 = len(t16.index)
        numDataColsT17 = len(t17.index)
        numDataColsT18 = len(t18.index)
        numDataColsT19 = len(t19.index)
        titleFontSize = 12
        yFontsize = 8
        xFontsize = 8
        legFontSize = 6

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupCol == None and groupVal == None:  # No Dataframe grouping
            document.add_heading(d1 + " vs. Test #", level=2)
            for x in range(1, numDataColsT1):
                fcp.plot(t1, x='Trim', y=x, title="Test #" + str(x), show=showPlt,
                         inline=showPlt, label_y=d1, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
                document.add_heading(d1 + " Test #" + str(x), level=3)
                document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
            document.add_heading(d2 + " vs. Test #", level=2)
            for x in range(1, numDataColsT2):
                fcp.plot(t2, x='Trim', y=x, title="Test #" + str(x), show=showPlt,
                         inline=showPlt, label_y=d2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d2 + '_' + timestamp + '.png')
                document.add_heading(d2 + " Test #" + str(x), level=3)
                document.add_picture(pltPath + d2 + '_' + timestamp + '.png')  # Add figure to report
            document.add_heading(d3 + " vs. Test #", level=2)
            for x in range(1, numDataColsT3):
                fcp.plot(t3, x='Trim', y=x, title="Test #" + str(x), show=showPlt,
                         inline=showPlt, label_y=d3, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d3 + '_' + timestamp + '.png')
                document.add_heading(d3 + " Test #" + str(x), level=3)
                document.add_picture(pltPath + d3 + '_' + timestamp + '.png')  # Add figure to report
            document.add_heading(d4 + " vs. Test #", level=2)
            for x in range(1, numDataColsT4):
                fcp.plot(t4, x='Trim', y=x, title="Test #" + str(x), show=showPlt,
                         inline=showPlt, label_y=d4, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d4 + '_' + timestamp + '.png')
                document.add_heading(d4 + " Test #" + str(x), level=3)
                document.add_picture(pltPath + d4 + '_' + timestamp + '.png')  # Add figure to report
            for x in range(1, numDataColsT5):
                fcp.plot(t5, x='Trim', y=x, title="Test #" + str(x), show=showPlt,
                         inline=showPlt, label_y=d5, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d5 + '_' + timestamp + '.png')
                document.add_heading(d5 + " Test #" + str(x), level=3)
                document.add_picture(pltPath + d5 + '_' + timestamp + '.png')  # Add figure to report
            for x in range(1, numDataColsT6):
                fcp.plot(t6, x='Trim', y=x, title="Test #" + str(x), show=showPlt,
                         inline=showPlt, label_y=d6, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d6 + '_' + timestamp + '.png')
                document.add_heading(d6 + " Test #" + str(x), level=3)
                document.add_picture(pltPath + d6 + '_' + timestamp + '.png')  # Add figure to report
            for x in range(1, numDataColsT7):
                fcp.plot(t7, x='Trim', y=x, title="Test #" + str(x), show=showPlt,
                         inline=showPlt, label_y=d7, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d7 + '_' + timestamp + '.png')
                document.add_heading(d7 + " Test #" + str(x), level=3)
                document.add_picture(pltPath + d7 + '_' + timestamp + '.png')  # Add figure to report
            for x in range(1, numDataColsT8):
                fcp.plot(t8, x='Trim', y=x, title="Test #" + str(x), show=showPlt,
                         inline=showPlt, label_y=d8, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d8 + '_' + timestamp + '.png')
                document.add_heading(d8 + " Test #" + str(x), level=3)
                document.add_picture(pltPath + d8 + '_' + timestamp + '.png')  # Add figure to report
            for x in range(1, numDataColsT9):
                fcp.plot(t9, x='Trim', y=x, title="Test #" + str(x), show=showPlt,
                         inline=showPlt, label_y=d9, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d9 + '_' + timestamp + '.png')
                document.add_heading(d9 + " Test #" + str(x), level=3)
                document.add_picture(pltPath + d9 + '_' + timestamp + '.png')  # Add figure to report
            for x in range(1, numDataColsT10):
                fcp.plot(t10, x='Trim', y=x, title="Test #" + str(x), show=showPlt,
                         inline=showPlt, label_y=d10, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d10 + '_' + timestamp + '.png')
                document.add_heading(d10 + " Test #" + str(x), level=3)
                document.add_picture(pltPath + d10 + '_' + timestamp + '.png')  # Add figure to report
            for x in range(1, numDataColsT11):
                fcp.plot(t11, x='Trim', y=x, title="Test #" + str(x), show=showPlt,
                         inline=showPlt, label_y=d11, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d11 + '_' + timestamp + '.png')
                document.add_heading(d11 + " Test #" + str(x), level=3)
                document.add_picture(pltPath + d11 + '_' + timestamp + '.png')  # Add figure to report
            for x in range(1, numDataColsT12):
                fcp.plot(t12, x='Trim', y=x, title="Test #" + str(x), show=showPlt,
                         inline=showPlt, label_y=d12, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d12 + '_' + timestamp + '.png')
                document.add_heading(d12 + " Test #" + str(x), level=3)
                document.add_picture(pltPath + d12 + '_' + timestamp + '.png')  # Add figure to report
            for x in range(1, numDataColsT13):
                fcp.plot(t13, x='Trim', y=x, title="Test #" + str(x), show=showPlt,
                         inline=showPlt, label_y=d13, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d13 + '_' + timestamp + '.png')
                document.add_heading(d13 + " Test #" + str(x), level=3)
                document.add_picture(pltPath + d13 + '_' + timestamp + '.png')  # Add figure to report
            for x in range(1, numDataColsT14):
                fcp.plot(t14, x='Trim', y=x, title="Test #" + str(x), show=showPlt,
                         inline=showPlt, label_y=d14, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d14 + '_' + timestamp + '.png')
                document.add_heading(d14 + " Test #" + str(x), level=3)
                document.add_picture(pltPath + d14 + '_' + timestamp + '.png')  # Add figure to report
            for x in range(1, numDataColsT15):
                fcp.plot(t15, x='Trim', y=x, title="Test #" + str(x), show=showPlt,
                         inline=showPlt, label_y=d15, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d15 + '_' + timestamp + '.png')
                document.add_heading(d15 + " Test #" + str(x), level=3)
                document.add_picture(pltPath + d15 + '_' + timestamp + '.png')  # Add figure to report
            for x in range(1, numDataColsT16):
                fcp.plot(t16, x='Trim', y=x, title="Test #" + str(x), show=showPlt,
                         inline=showPlt, label_y=d16, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d16 + '_' + timestamp + '.png')
                document.add_heading(d16 + " Test #" + str(x), level=3)
                document.add_picture(pltPath + d16 + '_' + timestamp + '.png')  # Add figure to report
            for x in range(1, numDataColsT17):
                fcp.plot(t17, x='Trim', y=x, title="Test #" + str(x), show=showPlt,
                         inline=showPlt, label_y=d17, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d17 + '_' + timestamp + '.png')
                document.add_heading(d17 + " Test #" + str(x), level=3)
                document.add_picture(pltPath + d17 + '_' + timestamp + '.png')  # Add figure to report
            for x in range(1, numDataColsT18):
                fcp.plot(t18, x='Trim', y=x, title="Test #" + str(x), show=showPlt,
                         inline=showPlt, label_y=d18, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d18 + '_' + timestamp + '.png')
                document.add_heading(d18 + " Test #" + str(x), level=3)
                document.add_picture(pltPath + d18 + '_' + timestamp + '.png')  # Add figure to report
            for x in range(1, numDataColsT19):
                fcp.plot(t19, x='Trim', y=x, title="Test #" + str(x), show=showPlt,
                         inline=showPlt, label_y=d19, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d19 + '_' + timestamp + '.png')
                document.add_heading(d19 + " Test #" + str(x), level=3)
                document.add_picture(pltPath + d19 + '_' + timestamp + '.png')  # Add figure to report
        elif groupCol != None and groupVal != None:  # Data frame grouped by col and val
            document.add_heading(d1 + " vs. Test # Groupedby: " + groupCol + ' = ' + str(groupVal), level=2)
            for x in range(1, numDataColsT1):
                fcp.plot(t1, x='Trim', y=x, title="Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                         show=showPlt,
                         inline=showPlt, label_y=d1, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
                document.add_heading(d1 + " Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                                     level=3)
                document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
            document.add_heading(d2 + " vs. Test # Groupedby: " + groupCol + ' = ' + str(groupVal), level=2)
            for x in range(1, numDataColsT2):
                fcp.plot(t2, x='Trim', y=x, title="Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                         show=showPlt,
                         inline=showPlt, label_y=d2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d2 + '_' + timestamp + '.png')
                document.add_heading(d2 + " Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                                     level=3)
                document.add_picture(pltPath + d2 + '_' + timestamp + '.png')  # Add figure to report
            document.add_heading(d3 + " vs. Test # Groupedby: " + groupCol + ' = ' + str(groupVal), level=2)
            for x in range(1, numDataColsT3):
                fcp.plot(t3, x='Trim', y=x, title="Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                         show=showPlt,
                         inline=showPlt, label_y=d3, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d3 + '_' + timestamp + '.png')
                document.add_heading(d3 + " Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                                     level=3)
                document.add_picture(pltPath + d3 + '_' + timestamp + '.png')  # Add figure to report
            document.add_heading(d4 + " vs. Test # Groupedby: " + groupCol + ' = ' + str(groupVal), level=2)
            for x in range(1, numDataColsT4):
                fcp.plot(t4, x='Trim', y=x, title="Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                         show=showPlt,
                         inline=showPlt, label_y=d4, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d4 + '_' + timestamp + '.png')
                document.add_heading(d4 + " Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                                     level=3)
                document.add_picture(pltPath + d4 + '_' + timestamp + '.png')  # Add figure to report
            for x in range(1, numDataColsT5):
                fcp.plot(t5, x='Trim', y=x, title="Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                         show=showPlt,
                         inline=showPlt, label_y=d5, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d5 + '_' + timestamp + '.png')
                document.add_heading(d5 + " Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                                     level=3)
                document.add_picture(pltPath + d5 + '_' + timestamp + '.png')  # Add figure to report
            for x in range(1, numDataColsT6):
                fcp.plot(t6, x='Trim', y=x, title="Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                         show=showPlt,
                         inline=showPlt, label_y=d6, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d6 + '_' + timestamp + '.png')
                document.add_heading(d6 + " Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                                     level=3)
                document.add_picture(pltPath + d6 + '_' + timestamp + '.png')  # Add figure to report
            for x in range(1, numDataColsT7):
                fcp.plot(t7, x='Trim', y=x, title="Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                         show=showPlt,
                         inline=showPlt, label_y=d7, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d7 + '_' + timestamp + '.png')
                document.add_heading(d7 + " Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                                     level=3)
                document.add_picture(pltPath + d7 + '_' + timestamp + '.png')  # Add figure to report
            for x in range(1, numDataColsT8):
                fcp.plot(t8, x='Trim', y=x, title="Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                         show=showPlt,
                         inline=showPlt, label_y=d8, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d8 + '_' + timestamp + '.png')
                document.add_heading(d8 + " Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                                     level=3)
                document.add_picture(pltPath + d8 + '_' + timestamp + '.png')  # Add figure to report
            for x in range(1, numDataColsT9):
                fcp.plot(t9, x='Trim', y=x, title="Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                         show=showPlt,
                         inline=showPlt, label_y=d9, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d9 + '_' + timestamp + '.png')
                document.add_heading(d9 + " Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                                     level=3)
                document.add_picture(pltPath + d9 + '_' + timestamp + '.png')  # Add figure to report
            for x in range(1, numDataColsT10):
                fcp.plot(t10, x='Trim', y=x, title="Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                         show=showPlt,
                         inline=showPlt, label_y=d10, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d10 + '_' + timestamp + '.png')
                document.add_heading(d10 + " Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                                     level=3)
                document.add_picture(pltPath + d10 + '_' + timestamp + '.png')  # Add figure to report
            for x in range(1, numDataColsT11):
                fcp.plot(t11, x='Trim', y=x, title="Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                         show=showPlt,
                         inline=showPlt, label_y=d11, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d11 + '_' + timestamp + '.png')
                document.add_heading(d11 + " Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                                     level=3)
                document.add_picture(pltPath + d11 + '_' + timestamp + '.png')  # Add figure to report
            for x in range(1, numDataColsT12):
                fcp.plot(t12, x='Trim', y=x, title="Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                         show=showPlt,
                         inline=showPlt, label_y=d12, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d12 + '_' + timestamp + '.png')
                document.add_heading(d12 + " Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                                     level=3)
                document.add_picture(pltPath + d12 + '_' + timestamp + '.png')  # Add figure to report
            for x in range(1, numDataColsT13):
                fcp.plot(t13, x='Trim', y=x, title="Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                         show=showPlt,
                         inline=showPlt, label_y=d13, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d13 + '_' + timestamp + '.png')
                document.add_heading(d13 + " Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                                     level=3)
                document.add_picture(pltPath + d13 + '_' + timestamp + '.png')  # Add figure to report
            for x in range(1, numDataColsT14):
                fcp.plot(t14, x='Trim', y=x, title="Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                         show=showPlt,
                         inline=showPlt, label_y=d14, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d14 + '_' + timestamp + '.png')
                document.add_heading(d14 + " Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                                     level=3)
                document.add_picture(pltPath + d14 + '_' + timestamp + '.png')  # Add figure to report
            for x in range(1, numDataColsT15):
                fcp.plot(t15, x='Trim', y=x, title="Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                         show=showPlt,
                         inline=showPlt, label_y=d15, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d15 + '_' + timestamp + '.png')
                document.add_heading(d15 + " Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                                     level=3)
                document.add_picture(pltPath + d15 + '_' + timestamp + '.png')  # Add figure to report
            for x in range(1, numDataColsT16):
                fcp.plot(t16, x='Trim', y=x, title="Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                         show=showPlt,
                         inline=showPlt, label_y=d16, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d16 + '_' + timestamp + '.png')
                document.add_heading(d16 + " Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                                     level=3)
                document.add_picture(pltPath + d16 + '_' + timestamp + '.png')  # Add figure to report
            for x in range(1, numDataColsT17):
                fcp.plot(t17, x='Trim', y=x, title="Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                         show=showPlt,
                         inline=showPlt, label_y=d17, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d17 + '_' + timestamp + '.png')
                document.add_heading(d17 + " Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                                     level=3)
                document.add_picture(pltPath + d17 + '_' + timestamp + '.png')  # Add figure to report
            for x in range(1, numDataColsT18):
                fcp.plot(t18, x='Trim', y=x, title="Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                         show=showPlt,
                         inline=showPlt, label_y=d18, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d18 + '_' + timestamp + '.png')
                document.add_heading(d18 + " Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                                     level=3)
                document.add_picture(pltPath + d18 + '_' + timestamp + '.png')  # Add figure to report
            for x in range(1, numDataColsT19):
                fcp.plot(t19, x='Trim', y=x, title="Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                         show=showPlt,
                         inline=showPlt, label_y=d19, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d19 + '_' + timestamp + '.png')
                document.add_heading(d19 + " Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                                     level=3)
                document.add_picture(pltPath + d19 + '_' + timestamp + '.png')  # Add figure to report
            
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for dc in t1_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t2_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t3_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t4_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t5_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t6_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t7_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t8_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t9_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t10_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t11_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t12_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t13_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t14_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t15_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t16_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t17_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t18_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t19_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        if groupCol == None:
            document.add_heading("groupCol Not Used", level=3)
        elif groupCol != None:
            if groupCol in df.columns:
                document.add_heading("groupCol Found: " + groupCol, level=3)  # Add Groupby found
                if groupVal == None:
                    document.add_heading("groupVal Missing", level=3)
                elif groupVal != None:
                    if groupCol in df[groupCol].unique():
                        document.add_heading("groupVal Found: " + groupVal, level=3)  # Add Groupby found
                    else:
                        document.add_heading("groupVal Not Found: " + groupVal, level=3)  # Add Groupby not found
            else:
                document.add_heading("groupCol Not Found: " + groupCol, level=3)  # Add Groupby not found

def Voltage_Reference_vs_Trim__vs_Time_Plot(dataFrame, groupCol, groupVal, document, pltPath, showPlt, **kwargs):
    try:
        if groupCol == None and groupVal == None:  # Dont group data frame
            df = dataFrame
        elif groupCol != None and groupVal != None:  # Group data frame by col and value
            df = VRG_Data_Frame.newdataframe(dataFrame, groupCol, groupVal)

        d1 = 'V_VBG_TRIMMED Trim'
        d2 = 'V_VBG_2V8_TRIMMED Trim'
        d3 = 'V_VBG_1V8_TRIMMED Trim'
        d4 = 'TSENS_V_VBG_TRIMMED Trim'
        d5 = 'TSENS_V_VCM_TRIMMED Trim'
        d5 = 'V_E1_SHR_TRIMMED Trim'
        d6 = 'V_E1_SHS_TRIMMED Trim'
        d7 = 'V_E2_SHR_TRIMMED Trim'
        d8 = 'V_E3_SHR_TRIMMED Trim'
        d9 = 'V_OVERDRIVE_4T_AMP_SHR_TRIMMED Trim'
        d10 = 'V_OVERDRIVE_4T_AMP_SHS_TRIMMED Trim'
        d11 = 'V_OVERDRIVE_3T_AMP_SHR_TRIMMED Trim'
        d12 = 'V_OVERDRIVE_3T_AMP_SHS_TRIMMED Trim'
        d13 = 'V_ADC_CODE012_SHR_TRIMMED Trim'
        d14 = 'V_ADC_CODE0_SHS_TRIMMED Trim'
        d15 = 'V_ADC_CODE1_SHS_TRIMMED Trim'
        d16 = 'V_ADC_CODE2_SHS_TRIMMED Trim'
        d17 = 'V_OVERDRIVE_ROW12_ZEBRA_SHR_TRIMMED Trim'
        d18 = 'V_OVERDRIVE_ROW12_ZEBRA_SHS_TRIMMED Trim'
        d19 = 'V_VERTICAL_TEST_SHS_TRIMMED Trim'

        # get data columns
        t1_cols = [x for x in df.columns[df.columns.str.contains(d1)]]
        t2_cols = [x for x in df.columns[df.columns.str.contains(d2)]]
        t3_cols = [x for x in df.columns[df.columns.str.contains(d3)]]
        t4_cols = [x for x in df.columns[df.columns.str.contains(d4)]]
        t5_cols = [x for x in df.columns[df.columns.str.contains(d5)]]
        t6_cols = [x for x in df.columns[df.columns.str.contains(d6)]]
        t7_cols = [x for x in df.columns[df.columns.str.contains(d7)]]
        t8_cols = [x for x in df.columns[df.columns.str.contains(d8)]]
        t9_cols = [x for x in df.columns[df.columns.str.contains(d9)]]
        t10_cols = [x for x in df.columns[df.columns.str.contains(d10)]]
        t11_cols = [x for x in df.columns[df.columns.str.contains(d11)]]
        t12_cols = [x for x in df.columns[df.columns.str.contains(d12)]]
        t13_cols = [x for x in df.columns[df.columns.str.contains(d13)]]
        t14_cols = [x for x in df.columns[df.columns.str.contains(d14)]]
        t15_cols = [x for x in df.columns[df.columns.str.contains(d15)]]
        t16_cols = [x for x in df.columns[df.columns.str.contains(d16)]]
        t17_cols = [x for x in df.columns[df.columns.str.contains(d17)]]
        t18_cols = [x for x in df.columns[df.columns.str.contains(d18)]]
        t19_cols = [x for x in df.columns[df.columns.str.contains(d19)]]

        # subset df
        t1 = df[t1_cols]
        t2 = df[t2_cols]
        t3 = df[t3_cols]
        t4 = df[t4_cols]
        t5 = df[t5_cols]
        t6 = df[t6_cols]
        t7 = df[t7_cols]
        t8 = df[t8_cols]
        t9 = df[t9_cols]
        t10 = df[t10_cols]
        t11 = df[t11_cols]
        t12 = df[t12_cols]
        t13 = df[t13_cols]
        t14 = df[t14_cols]
        t15 = df[t15_cols]
        t16 = df[t16_cols]
        t17 = df[t17_cols]
        t18 = df[t18_cols]
        t19 = df[t19_cols]

        # rename columns to get read number
        for dc in t1_cols:
            t1 = t1.rename(columns={dc: dc.split(' ')[2]})  # get the integer (2) value from the name
        for dc in t2_cols:
            t2 = t2.rename(columns={dc: dc.split(' ')[2]})  # get the integer (2) value from the name
        for dc in t3_cols:
            t3 = t3.rename(columns={dc: dc.split(' ')[2]})  # get the integer (2) value from the name
        for dc in t4_cols:
            t4 = t4.rename(columns={dc: dc.split(' ')[2]})  # get the integer (2) value from the name
        for dc in t5_cols:
            t5 = t5.rename(columns={dc: dc.split(' ')[2]})  # get the integer (2) value from the name
        for dc in t6_cols:
            t6 = t6.rename(columns={dc: dc.split(' ')[2]})  # get the integer (2) value from the name
        for dc in t7_cols:
            t7 = t7.rename(columns={dc: dc.split(' ')[2]})  # get the integer (2) value from the name
        for dc in t8_cols:
            t8 = t8.rename(columns={dc: dc.split(' ')[2]})  # get the integer (2) value from the name
        for dc in t9_cols:
            t9 = t9.rename(columns={dc: dc.split(' ')[2]})  # get the integer (2) value from the name
        for dc in t10_cols:
            t10 = t10.rename(columns={dc: dc.split(' ')[2]})  # get the integer (2) value from the name
        for dc in t11_cols:
            t11 = t11.rename(columns={dc: dc.split(' ')[2]})  # get the integer (2) value from the name
        for dc in t12_cols:
            t12 = t12.rename(columns={dc: dc.split(' ')[2]})  # get the integer (2) value from the name
        for dc in t13_cols:
            t13 = t13.rename(columns={dc: dc.split(' ')[2]})  # get the integer (2) value from the name
        for dc in t14_cols:
            t14 = t14.rename(columns={dc: dc.split(' ')[2]})  # get the integer (2) value from the name
        for dc in t15_cols:
            t15 = t15.rename(columns={dc: dc.split(' ')[2]})  # get the integer (2) value from the name
        for dc in t16_cols:
            t16 = t16.rename(columns={dc: dc.split(' ')[2]})  # get the integer (2) value from the name
        for dc in t17_cols:
            t17 = t17.rename(columns={dc: dc.split(' ')[2]})  # get the integer (2) value from the name
        for dc in t18_cols:
            t18 = t18.rename(columns={dc: dc.split(' ')[2]})  # get the integer (2) value from the name
        for dc in t19_cols:
            t19 = t19.rename(columns={dc: dc.split(' ')[2]})  # get the integer (2) value from the name

        # transpose
        t1 = t1.T
        t2 = t2.T
        t3 = t3.T
        t4 = t4.T
        t5 = t5.T
        t6 = t6.T
        t7 = t7.T
        t8 = t8.T
        t9 = t9.T
        t10 = t10.T
        t11 = t11.T
        t12 = t12.T
        t13 = t13.T
        t14 = t14.T
        t15 = t15.T
        t16 = t16.T
        t17 = t17.T
        t18 = t18.T
        t19 = t19.T

        # add an index column
        t1['Trim'] = t1.index
        t2['Trim'] = t2.index
        t3['Trim'] = t3.index
        t4['Trim'] = t4.index
        t5['Trim'] = t5.index
        t6['Trim'] = t6.index
        t7['Trim'] = t7.index
        t8['Trim'] = t8.index
        t9['Trim'] = t9.index
        t10['Trim'] = t10.index
        t11['Trim'] = t11.index
        t12['Trim'] = t12.index
        t13['Trim'] = t13.index
        t14['Trim'] = t14.index
        t15['Trim'] = t15.index
        t16['Trim'] = t16.index
        t17['Trim'] = t17.index
        t18['Trim'] = t18.index
        t19['Trim'] = t19.index

        colList = []
        for index in df.index:
            colList.append(index)

        figTitle = 'Voltage_Reference_vs_Trim_vs_Time'
        titleFontSize = 12
        yFontsize = 8
        xFontsize = 8
        legFontSize = 6

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupCol == None and groupVal == None:  # No Dataframe grouping
            fcp.plot(t1, x='Trim', y=colList, title=d1, legend_title="Test #", show=showPlt,
                     inline=showPlt, label_y=d1, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_heading(d1, level=3)
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t2, x='Trim', y=colList, title=d2, legend_title="Test #", show=showPlt,
                     inline=showPlt, label_y=d2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d2 + '_' + timestamp + '.png')
            document.add_heading(d2, level=3)
            document.add_picture(pltPath + d2 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t3, x='Trim', y=colList, title=d3, legend_title="Test #", show=showPlt,
                     inline=showPlt, label_y=d3, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d3 + '_' + timestamp + '.png')
            document.add_heading(d3, level=3)
            document.add_picture(pltPath + d3 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t4, x='Trim', y=colList, title=d4, legend_title="Test #", show=showPlt,
                     inline=showPlt, label_y=d4, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d4 + '_' + timestamp + '.png')
            document.add_heading(d4, level=3)
            document.add_picture(pltPath + d4 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t5, x='Trim', y=colList, title=d5, legend_title="Test #", show=showPlt,
                     inline=showPlt, label_y=d5, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d5 + '_' + timestamp + '.png')
            document.add_heading(d5, level=3)
            document.add_picture(pltPath + d5 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t6, x='Trim', y=colList, title=d6, legend_title="Test #", show=showPlt,
                     inline=showPlt, label_y=d6, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d6 + '_' + timestamp + '.png')
            document.add_heading(d6, level=3)
            document.add_picture(pltPath + d6 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t7, x='Trim', y=colList, title=d7, legend_title="Test #", show=showPlt,
                     inline=showPlt, label_y=d7, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d7 + '_' + timestamp + '.png')
            document.add_heading(d7, level=3)
            document.add_picture(pltPath + d7 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t8, x='Trim', y=colList, title=d8, legend_title="Test #", show=showPlt,
                     inline=showPlt, label_y=d8, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d8 + '_' + timestamp + '.png')
            document.add_heading(d8, level=3)
            document.add_picture(pltPath + d8 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t9, x='Trim', y=colList, title=d9, legend_title="Test #", show=showPlt,
                     inline=showPlt, label_y=d9, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d9 + '_' + timestamp + '.png')
            document.add_heading(d9, level=3)
            document.add_picture(pltPath + d9 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t10, x='Trim', y=colList, title=d10, legend_title="Test #", show=showPlt,
                     inline=showPlt, label_y=d10, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d10 + '_' + timestamp + '.png')
            document.add_heading(d10, level=3)
            document.add_picture(pltPath + d10 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t11, x='Trim', y=colList, title=d11, legend_title="Test #", show=showPlt,
                     inline=showPlt, label_y=d11, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d11 + '_' + timestamp + '.png')
            document.add_heading(d11, level=3)
            document.add_picture(pltPath + d11 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t12, x='Trim', y=colList, title=d12, legend_title="Test #", show=showPlt,
                     inline=showPlt, label_y=d12, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d12 + '_' + timestamp + '.png')
            document.add_heading(d12, level=3)
            document.add_picture(pltPath + d12 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t13, x='Trim', y=colList, title=d13, legend_title="Test #", show=showPlt,
                     inline=showPlt, label_y=d13, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d13 + '_' + timestamp + '.png')
            document.add_heading(d13, level=3)
            document.add_picture(pltPath + d13 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t14, x='Trim', y=colList, title=d14, legend_title="Test #", show=showPlt,
                     inline=showPlt, label_y=d14, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d14 + '_' + timestamp + '.png')
            document.add_heading(d14, level=3)
            document.add_picture(pltPath + d14 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t15, x='Trim', y=colList, title=d15, legend_title="Test #", show=showPlt,
                     inline=showPlt, label_y=d15, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d15 + '_' + timestamp + '.png')
            document.add_heading(d15, level=3)
            document.add_picture(pltPath + d15 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t16, x='Trim', y=colList, title=d16, legend_title="Test #", show=showPlt,
                     inline=showPlt, label_y=d16, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d16 + '_' + timestamp + '.png')
            document.add_heading(d16, level=3)
            document.add_picture(pltPath + d16 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t17, x='Trim', y=colList, title=d17, legend_title="Test #", show=showPlt,
                     inline=showPlt, label_y=d17, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d17 + '_' + timestamp + '.png')
            document.add_heading(d17, level=3)
            document.add_picture(pltPath + d17 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t18, x='Trim', y=colList, title=d18, legend_title="Test #", show=showPlt,
                     inline=showPlt, label_y=d18, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d18 + '_' + timestamp + '.png')
            document.add_heading(d18, level=3)
            document.add_picture(pltPath + d18 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t19, x='Trim', y=colList, title=d19, legend_title="Test #", show=showPlt,
                     inline=showPlt, label_y=d19, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d19 + '_' + timestamp + '.png')
            document.add_heading(d19, level=3)
            document.add_picture(pltPath + d19 + '_' + timestamp + '.png')  # Add figure to report
        elif groupCol != None and groupVal != None:  # Data frame grouped by col and val
            fcp.plot(t1, x='Trim', y=colList, title=d1 + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                     show=showPlt,
                     inline=showPlt, legend_title="Test #", label_y=d1, title_font_size=titleFontSize,
                     label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_heading(d1 + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t2, x='Trim', y=colList, title=d2 + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                     show=showPlt,
                     inline=showPlt, legend_title="Test #", label_y=d2, title_font_size=titleFontSize,
                     label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d2 + '_' + timestamp + '.png')
            document.add_heading(d2 + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
            document.add_picture(pltPath + d2 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t3, x='Trim', y=colList, title=d3 + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                     show=showPlt,
                     inline=showPlt, legend_title="Test #", label_y=d3, title_font_size=titleFontSize,
                     label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d3 + '_' + timestamp + '.png')
            document.add_heading(d3 + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
            document.add_picture(pltPath + d3 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t4, x='Trim', y=colList, title=d4 + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                     show=showPlt,
                     inline=showPlt, legend_title="Test #", label_y=d4, title_font_size=titleFontSize,
                     label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d4 + '_' + timestamp + '.png')
            document.add_heading(d4 + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
            document.add_picture(pltPath + d4 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t5, x='Trim', y=colList, title=d5 + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                     show=showPlt,
                     inline=showPlt, legend_title="Test #", label_y=d5, title_font_size=titleFontSize,
                     label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d5 + '_' + timestamp + '.png')
            document.add_heading(d5 + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
            document.add_picture(pltPath + d5 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t6, x='Trim', y=colList, title=d6 + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                     show=showPlt,
                     inline=showPlt, legend_title="Test #", label_y=d6, title_font_size=titleFontSize,
                     label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d6 + '_' + timestamp + '.png')
            document.add_heading(d6 + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
            document.add_picture(pltPath + d6 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t7, x='Trim', y=colList, title=d7 + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                     show=showPlt,
                     inline=showPlt, legend_title="Test #", label_y=d7, title_font_size=titleFontSize,
                     label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d7 + '_' + timestamp + '.png')
            document.add_heading(d7 + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
            document.add_picture(pltPath + d7 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t8, x='Trim', y=colList, title=d8 + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                     show=showPlt,
                     inline=showPlt, legend_title="Test #", label_y=d8, title_font_size=titleFontSize,
                     label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d8 + '_' + timestamp + '.png')
            document.add_heading(d8 + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
            document.add_picture(pltPath + d8 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t9, x='Trim', y=colList, title=d9 + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                     show=showPlt,
                     inline=showPlt, legend_title="Test #", label_y=d9, title_font_size=titleFontSize,
                     label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d9 + '_' + timestamp + '.png')
            document.add_heading(d9 + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
            document.add_picture(pltPath + d9 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t10, x='Trim', y=colList, title=d10 + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                     show=showPlt,
                     inline=showPlt, legend_title="Test #", label_y=d10, title_font_size=titleFontSize,
                     label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d10 + '_' + timestamp + '.png')
            document.add_heading(d10 + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
            document.add_picture(pltPath + d10 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t11, x='Trim', y=colList, title=d11 + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                     show=showPlt,
                     inline=showPlt, legend_title="Test #", label_y=d11, title_font_size=titleFontSize,
                     label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d11 + '_' + timestamp + '.png')
            document.add_heading(d11 + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
            document.add_picture(pltPath + d11 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t12, x='Trim', y=colList, title=d12 + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                     show=showPlt,
                     inline=showPlt, legend_title="Test #", label_y=d12, title_font_size=titleFontSize,
                     label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d12 + '_' + timestamp + '.png')
            document.add_heading(d12 + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
            document.add_picture(pltPath + d12 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t13, x='Trim', y=colList, title=d13 + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                     show=showPlt,
                     inline=showPlt, legend_title="Test #", label_y=d13, title_font_size=titleFontSize,
                     label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d13 + '_' + timestamp + '.png')
            document.add_heading(d13 + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
            document.add_picture(pltPath + d13 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t14, x='Trim', y=colList, title=d14 + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                     show=showPlt,
                     inline=showPlt, legend_title="Test #", label_y=d14, title_font_size=titleFontSize,
                     label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d14 + '_' + timestamp + '.png')
            document.add_heading(d14 + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
            document.add_picture(pltPath + d14 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t15, x='Trim', y=colList, title=d15 + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                     show=showPlt,
                     inline=showPlt, legend_title="Test #", label_y=d15, title_font_size=titleFontSize,
                     label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d15 + '_' + timestamp + '.png')
            document.add_heading(d15 + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
            document.add_picture(pltPath + d15 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t16, x='Trim', y=colList, title=d16 + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                     show=showPlt,
                     inline=showPlt, legend_title="Test #", label_y=d16, title_font_size=titleFontSize,
                     label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d16 + '_' + timestamp + '.png')
            document.add_heading(d16 + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
            document.add_picture(pltPath + d16 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t17, x='Trim', y=colList, title=d17 + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                     show=showPlt,
                     inline=showPlt, legend_title="Test #", label_y=d17, title_font_size=titleFontSize,
                     label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d17 + '_' + timestamp + '.png')
            document.add_heading(d17 + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
            document.add_picture(pltPath + d17 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t18, x='Trim', y=colList, title=d18 + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                     show=showPlt,
                     inline=showPlt, legend_title="Test #", label_y=d18, title_font_size=titleFontSize,
                     label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d18 + '_' + timestamp + '.png')
            document.add_heading(d18 + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
            document.add_picture(pltPath + d18 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t19, x='Trim', y=colList, title=d19 + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                     show=showPlt,
                     inline=showPlt, legend_title="Test #", label_y=d19, title_font_size=titleFontSize,
                     label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d19 + '_' + timestamp + '.png')
            document.add_heading(d19 + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
            document.add_picture(pltPath + d19 + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for dc in t1_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t2_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t3_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t4_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t5_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t6_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t7_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t8_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t9_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t10_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t11_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t12_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t13_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t14_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t15_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t16_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t17_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t18_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t19_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        if groupCol == None:
            document.add_heading("groupCol Not Used", level=3)
        elif groupCol != None:
            if groupCol in df.columns:
                document.add_heading("groupCol Found: " + groupCol, level=3)  # Add Groupby found
                if groupVal == None:
                    document.add_heading("groupVal Missing", level=3)
                elif groupVal != None:
                    if groupCol in df[groupCol].unique():
                        document.add_heading("groupVal Found: " + groupVal, level=3)  # Add Groupby found
                    else:
                        document.add_heading("groupVal Not Found: " + groupVal, level=3)  # Add Groupby not found
            else:
                document.add_heading("groupCol Not Found: " + groupCol, level=3)  # Add Groupby not found



'''
POR (Power On Reset) Data
'''
def PowerOnReset_Voltage_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'Vtrig_falling'
        d2 = 'Vtrig_rising'
    
        figTitle = 'Power_On_Reset_Voltages'
        ylabel = 'Falling Voltage (V), (0 = Indeterminate)'
        ylabel2 = 'Rising Voltage (V), (0 = Indeterminate)'
        numDataCols = 3  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame
    
        fail = 'Unable to determine'
        df[d1] = df[d1].replace(fail, 0)
        df[d2] = df[d2].replace(fail, 0)
    
        currTime = time.strftime("%m%d%Y_%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)
    
        document.add_heading(figTitle, level=2)  # Add section title to docx report
    
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                if x == 1:
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
                elif x == 2:
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                if x == 1:
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
                elif x == 2:
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

'''
PSRR (Power Supply Rejection Ratio) Data
'''
def PSSR_Input_Signal_Voltage_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'PSSR_V_Noise(v)'
        d2 = 'PSSR_V(v)'
    
        figTitle = 'PSSR_Input_Signal_Voltage'
        ylabel = 'Input Voltage With Noise (v)'
        ylabel2 = 'Input Voltage Without Noise (v)'
        numDataCols = 3  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame
    
        currTime = time.strftime("%m%d%Y_%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)
    
        document.add_heading(figTitle, level=2)  # Add section title to docx report
    
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                if x == 1:
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
                elif x == 2:
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot both supplies
            fcp.plot(df, x='Step', y=[d1, d2], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                if x == 1:
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
                elif x == 2:
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
            # Plot both supplies
            fcp.plot(df, x='Step', y=[d1, d2], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 , level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def PSSR_Input_Signal_Voltage_vs_Supply_Plot(dataFrame, groupBy, document, pltPath, pwrSupply, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'PSSR_V_Noise(v)'
        d2 = 'PSSR_V(v)'
        d3 = pwrSupply
    
        figTitle = 'PSSR_Input_Signal_Voltage_vs_Supply'
        ylabel = 'Voltage (v)'
        numDataCols = 4
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame
    
        currTime = time.strftime("%m%d%Y_%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)
    
        document.add_heading(figTitle, level=2)  # Add section title to docx report
    
        if groupBy == None:  # Remove Legend= keyword
            fcp.plot(df, x='Step', y=[d1, d2, d3], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            fcp.plot(df, x='Step', y=[d1, d2, d3], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def PSSR_Measurement_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1='PSRR(dB)'
    
        figTitle = 'PSRR_Measurement'
        ylabel = 'PSRR(dB)'
        numDataCols = 2  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame
    
        fail1 = 'Error: Sigma == SigmaB'
        fail2 = 'Error: Sigma < SigmaB'
        fail3 = 'Error: SigmaA < SigmaB'
        df[d1] = df[d1].replace(fail1, np.NaN, regex=True)
        df[d1] = df[d1].replace(fail2, np.NaN, regex=True)
        df[d1] = df[d1].replace(fail3, np.NaN, regex=True)
        df[d1] = df[d1].replace(np.NaN, 0)
        df[d1] = df[d1].astype(float)
    
        # Remove data that doesnt seem valid
        # df = df[df[d1] != 0]
        df = df[df[d1] >= 3]
    
        currTime = time.strftime("%m%d%Y_%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)
    
        document.add_heading(figTitle, level=2)  # Add section title to docx report
    
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def PSRR_Statistics_Table(dataFrame, groupCol, groupVal, document):
    try:
        if groupCol == None and groupVal == None:  # Dont group data frame
            df = dataFrame
        elif groupCol != None and groupVal != None:  # Group data frame by col and value
            df = VRG_Data_Frame.newdataframe(dataFrame, groupCol, groupVal)
    
        dp = 'PSRR(dB)'
        fail1 = 'Error: Sigma == SigmaB'
        fail2 = 'Error: Sigma < SigmaB'
        fail3 = 'Error: SigmaA < SigmaB'
        df[dp] = df[dp].replace(fail1, np.NaN, regex=True)
        df[dp] = df[dp].replace(fail2, np.NaN, regex=True)
        df[dp] = df[dp].replace(fail3, np.NaN, regex=True)
        df[dp] = df[dp].replace(np.NaN, 0)
        df[dp] = df[dp].astype(float)
        # Remove data that doesnt seem valid
        df = df[df[dp] >= 3]
    
        # Column Names in CSV
        d1 = 'PSRR(dB) Min'
        d2 = 'PSRR(dB) Mean'
        d3 = 'PSRR(dB) Max'
    
        df[d1] = df[dp].min()
        df[d2] = df[dp].mean()
        df[d3] = df[dp].max()
    
        figTitle = 'PSRR_Statistics_Table'
        rowLabel1 = 'PSRR Statistic'
        rowLabel2 = 'decibel (dB)'
        numDataCols = 4  # Number of columns + 1 to loop through (last col + 1)
        tableStyle = 'Table Grid'
    
        if groupCol == None and groupVal == None:  # No Dataframe grouping
            document.add_heading(figTitle, level=2)
            table_count = len(document.tables)
            table = document.add_table(rows=numDataCols, cols=2)
            table.style = tableStyle
            document.tables[table_count].cell(0, 0).text = rowLabel1
            document.tables[table_count].cell(0, 1).text = rowLabel2
            for x in range(1, numDataCols):  # 1 to N
                document.tables[table_count].cell(x, 0).text = eval("d" + str(x))
                document.tables[table_count].cell(x, 1).text = df[eval("d" + str(x))].mean().astype(str)
        elif groupCol != None and groupVal != None:  # Data frame grouped by col and val
            document.add_heading(figTitle + " Grouped by" + groupCol + " = " + groupVal, level=2)
            df = VRG_Data_Frame.newdataframe()
            table_count = len(document.tables)
            table = document.add_table(rows=numDataCols, cols=2)
            table.style = tableStyle
            document.tables[table_count].cell(0, 0).text = rowLabel1
            document.tables[table_count].cell(0, 1).text = rowLabel2
            for x in range(1, numDataCols):  # 1 to N
                document.tables[table_count].cell(x, 0).text = eval("d" + str(x))
                document.tables[table_count].cell(x, 1).text = df[eval("d" + str(x))].mean().astype(str)
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupCol == None:
            document.add_heading("groupCol Not Used", level=3)
        elif groupCol != None:
            if groupCol in df.columns:
                document.add_heading("groupCol Found: " + groupCol, level=3)  # Add Groupby found
                if groupVal == None:
                    document.add_heading("groupVal Missing", level=3)
                elif groupVal != None:
                    if groupCol in df[groupCol].unique():
                        document.add_heading("groupVal Found: " + groupVal, level=3)  # Add Groupby found
                    else:
                        document.add_heading("groupVal Not Found: " + groupVal, level=3)  # Add Groupby not found
            else:
                document.add_heading("groupCol Not Found: " + groupCol, level=3)  # Add Groupby not found

def PSSR_vs_Noise_Frequency_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'PSRR(dB)'
        d2 = 'GpibSignalFreq_PSRR'
    
        figTitle = 'PSRR_Measurement_vs_Noise_Frequency'
        ylabel = 'PSRR(dB)'
        xlabel = 'Noise Signal Frequency (Hz)'
        numDataCols = 2  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame
    
        fail1 = 'Error: Sigma == SigmaB'
        fail2 = 'Error: Sigma < SigmaB'
        fail3 = 'Error: SigmaA < SigmaB'
        df[d1] = df[d1].replace(fail1, np.NaN, regex=True)
        df[d1] = df[d1].replace(fail2, np.NaN, regex=True)
        df[d1] = df[d1].replace(fail3, np.NaN, regex=True)
        df[d1] = df[d1].replace(np.NaN, 0)
        df[d1] = df[d1].astype(float)
    
        # Remove data that doesnt seem valid
        # df = df[df[d1] != 0]
        df = df[df[d1] >= 3]
    
        currTime = time.strftime("%m%d%Y_%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)
    
        document.add_heading(figTitle, level=2)  # Add section title to docx report
    
        if groupBy == None:  # Remove Legend= keyword
            fcp.plot(df, x=d2, y=d1, title=figTitle, show=showPlt,
                     inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(figTitle, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            fcp.plot(df, x=d2, y=d1, title=figTitle, legend=groupBy, show=showPlt,
                     inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(figTitle, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def PSSR_vs_Noise_Amplitude_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'PSRR(dB)'
        d2 = 'GpibSignalAmplitude_PSRR'
    
        figTitle = 'PSRR_Measurement_vs_Noise_Amplitude'
        ylabel = 'PSRR(dB)'
        xlabel = 'Noise Signal Amplitude (v)'
        numDataCols = 2  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame
    
        fail1 = 'Error: Sigma == SigmaB'
        fail2 = 'Error: Sigma < SigmaB'
        fail3 = 'Error: SigmaA < SigmaB'
        df[d1] = df[d1].replace(fail1, np.NaN, regex=True)
        df[d1] = df[d1].replace(fail2, np.NaN, regex=True)
        df[d1] = df[d1].replace(fail3, np.NaN, regex=True)
        df[d1] = df[d1].replace(np.NaN, 0)
        df[d1] = df[d1].astype(float)
    
        # Remove data that doesnt seem valid
        # df = df[df[d1] != 0]
        df = df[df[d1] >= 3]
    
        currTime = time.strftime("%m%d%Y_%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)
    
        document.add_heading(figTitle, level=2)  # Add section title to docx report
    
        if groupBy == None:  # Remove Legend= keyword
            fcp.plot(df, x=d2, y=d1, title=figTitle, show=showPlt,
                     inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                     label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(figTitle, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            fcp.plot(df, x=d2, y=d1, title=figTitle, legend=groupBy, show=showPlt,
                     inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                     label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(figTitle, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def PSSR_Sigma_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'SigmaA'
        d2 = 'SigmaB'
    
        figTitle = 'PSRR_Sigma_Values'
        ylabel = 'SigmaA (Noise Image _ RowStdDev)'
        ylabel2 = 'SigmaB (Standard Image _ RowStdDev)'
        numDataCols = 3  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame
    
        # Remove data that doesnt seem valid
        df = df[df[d1] >= .1]
        df = df[df[d2] >= .1]
    
        currTime = time.strftime("%m%d%Y_%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)
    
        document.add_heading(figTitle, level=2)  # Add section title to docx report
    
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                if x == 1:
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
                elif x == 2:
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                if x == 1:
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
                elif x == 2:
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def PSSR_Noise_Signal_Frequency_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1='GpibSignalFreq_PSRR'
    
        figTitle = 'PSRR_Measurement'
        ylabel = 'Noise Signal Frequency (Hz)'
        numDataCols = 2  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame
    
        currTime = time.strftime("%m%d%Y_%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)
    
        document.add_heading(figTitle, level=2)  # Add section title to docx report
    
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def PSSR_Noise_Signal_Amplitude_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1='GpibSignalAmplitude_PSRR'
    
        figTitle = 'PSSR_Noise_Signal_Amplitude'
        ylabel = 'Noise Signal Amplitude (v)'
        numDataCols = 2  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame
    
        currTime = time.strftime("%m%d%Y_%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)
    
        document.add_heading(figTitle, level=2)  # Add section title to docx report
    
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def PSSR_Noise_Signal_Offset_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1='GpibSignalOffset_PSRR'
    
        figTitle = 'PSSR_Noise_Signal_Offset'
        ylabel = 'Noise Signal Offset (v)'
        numDataCols = 2  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame
    
        currTime = time.strftime("%m%d%Y_%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)
    
        document.add_heading(figTitle, level=2)  # Add section title to docx report
    
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def PSSR_Noise_Signal_Type_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1='GpibSignalType_PSRR'
        figTitle = 'PSSR_Noise_Signal_Type'
        ylabel = 'Noise Signal Type (1 = Sinusoid)'
        numDataCols = 2  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame
    
        signal = 'SINUSOID'
        df[d1] = df[d1].replace(signal, 1)
    
        currTime = time.strftime("%m%d%Y_%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)
    
        document.add_heading(figTitle, level=2)  # Add section title to docx report
    
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found














