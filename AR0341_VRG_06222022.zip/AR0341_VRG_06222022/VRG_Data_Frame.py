import matplotlib
import matplotlib.pyplot as plt
from matplotlib import pyplot
from docx import Document
from docx.shared import Inches
from docx.shared import Pt
from tkinter import *
from tkinter import filedialog
from tkinter import messagebox
import numpy as np
import csv
import argparse
import os
import pandas as pd
import pixelcrunch as pc
import fivecentplots as fcp
import bokeh
import sys
import io
import multiprocessing
import VRG_Safety_Data
import VRG_Calculate
import VRG_Data_Frame
import VRG_Doc
import VRG_General_Data
import VRG_Image_Analysis
import VRG_Image_Utils
import VRG_Macro_Data
import VRG_OTPM_Data
import VRG_Pins_Data
import VRG_Power_Data
import VRG_Register_Data
import VRG_Stats_Arr
import VRG_Stats_ArrCenter
import VRG_Stats_ArrQuad1
import VRG_Stats_ArrQuad2
import VRG_Stats_ArrQuad3
import VRG_Stats_ArrQuad4
import VRG_Stats_ArrRoi1
import VRG_Stats_ArrRoi2
import VRG_Stats_ArrRoi3
import VRG_Stats_ArrRoi4
import VRG_Stats_ArrRoi5
import VRG_Stats_ArrRoi6
import VRG_Stats_ArrRoi7
import VRG_Stats_ArrRoi8
import VRG_Stats_ArrRoi9
import VRG_Stats_DBLC
import VRG_Stats_Frame
import VRG_Stats_Lag
import VRG_Stats_RNC
import VRG_Stats_Tilt
import VRG_Tempsensor_Data
import VRG_Reports
import time

def readdataframe(filePath, skipRows):
    data = pd.read_csv(filePath, skiprows=skipRows)
    df = pd.DataFrame(data)
    df['Step'] = df.Step.apply(lambda x: int(x.split(' ')[0])) # Makes Step column numerical
    return df

def dataframe(filePath):
    # Pixel Crunch to reformat column names
    df, meta = pc.dataio.read_data(filePath)  # Return just the df [0], not metadata [1]
    df['Result'] = 'Complete' # work around for frame-aquistion timeout
    df, data, groupby, summ_cols, abort = pc.utilities.dfutils.reformat_validation(df)  # reformat column names
    df['Step'] = df.Step.apply(lambda x: int(x.split(' ')[0]))  # Makes Step column numerical
    print("DataFrame Reformated Using PixelCrunch")
    return df

def dataframe_imagelink(df, fileDir):
    if 'ImageLink1' in df.columns:
        # Update ImageLink with stripped characters
        il1 = df['ImageLink1'].str.split('\\', n=1, expand=True)
        df['ImageLink1'] = il1[1] # Relabel ImageLink column
        il1 = df['ImageLink1'].str.split('"', n=1, expand=True)
        df['ImageLink1'] = il1[0] # Relabel ImageLink column
        df['ImageLinkDir1'] = fileDir # append directory to all imagelinks
    print("DataFrame ImageLinks Updated")
    return df

def dataframe_configure(df):
    df = df.reset_index(drop=True)  # Reset Index to be 1 to N
    df['TestStep'] = df['Step']  # Copy step column to TempStep, which is based on temperature
    df['Step'] = df.index  # Copy reset index into Step for plotting
    print("DataFrame Configured")
    return df

def newdataframe(df, column, value):
    df1 = df.copy() #have to copy to prevent destruction of original dataframe
    df1.drop(df1.loc[df[column] != value].index, inplace=True) #drop all rows not equal to column and value
    df_new = df1.reset_index(drop=True) # re-index the dataframe
    return df_new

def dataframe_column_rename(df):
    df.columns = df.columns.str.replace('::', '__') # replace all column names with register bits for file naming
    df.columns = [col.replace(" [V", "(v").replace("]", ")") for col in df.columns] # fix pixel crunch changing of (v) to [V] on some supplies
    df.columns = df.columns.str.replace('-', '_') # replace hyphens with underscores
    df = df.replace('AR0341.AR0341_REV1_DV.', '', regex=True) # replace pathnames for smaller strings

    # if 'RegWr00_ASIL_CHECK_ENABLES_02__ADDRESS_SM_CRC_ENABLE' in df.columns: # fix for asil runtime and runtime fault injection
    #     df['ASIL_CHECK_ENABLES_02__ADDRESS_SM_CRC_ENABLE'] = df['RegWr00_ASIL_CHECK_ENABLES_02__ADDRESS_SM_CRC_ENABLE'] # add power column for PSRR test
    # else:
    #     pass
    # if 'RegWr01_ASIL_PIN_ENABLES_02__ADDRESS_SM_CRC_PIN_ENABLE' in df.columns: # fix for asil runtime and runtime fault injection
    #     df['ASIL_PIN_ENABLES_02__ADDRESS_SM_CRC_PIN_ENABLE'] = df['RegWr01_ASIL_PIN_ENABLES_02__ADDRESS_SM_CRC_PIN_ENABLE'] # add power column for PSRR test
    # else:
    #     pass
    #
    # if 'RegWr01_&H3034' in df.columns: # fix for asil runtime and runtime fault injection
    #     df['RegWr01_CTX_CONTROL_REG'] = df['RegWr01_&H3034'] # add power column for PSRR test
    # else:
    #     pass
    #
    # if 'PSRR_Power' in df.columns:
    #     df['Power'] = df['PSRR_Power'] # add power column for PSRR test
    # else:
    #     pass
    #
    # # Column renaming fix for RRC
    # if 'RowDriver_1_max' in df.columns:
    #     pass
    # else:
    #     df.rename(columns= {'RowDriver_1 max': 'RowDriver_1_max',
    #                         'RowDriver_1 min': 'RowDriver_1_min',
    #                         'RowDriver_1 mean': 'RowDriver_1_mean',
    #                         'RowDriver_1 std': 'RowDriver_1_std',
    #                         'RowDriver_2 max': 'RowDriver_2_max',
    #                         'RowDriver_2 min': 'RowDriver_2_min',
    #                         'RowDriver_2 mean': 'RowDriver_2_mean',
    #                         'RowDriver_2 std': 'RowDriver_2_std',
    #                         'RowDriver_3 max': 'RowDriver_3_max',
    #                         'RowDriver_3 min': 'RowDriver_3_min',
    #                         'RowDriver_3 mean': 'RowDriver_3_mean',
    #                         'RowDriver_3 std': 'RowDriver_3_std',
    #                         'RowDriver_4 max': 'RowDriver_4_max',
    #                         'RowDriver_4 min': 'RowDriver_4_min',
    #                         'RowDriver_4 mean': 'RowDriver_4_mean',
    #                         'RowDriver_4 std': 'RowDriver_4_std',
    #                         'RowDriver_5 max': 'RowDriver_5_max',
    #                         'RowDriver_5 min': 'RowDriver_5_min',
    #                         'RowDriver_5 mean': 'RowDriver_5_mean',
    #                         'RowDriver_5 std': 'RowDriver_5_std',
    #                         'RowDriver_6 max': 'RowDriver_6_max',
    #                         'RowDriver_6 min': 'RowDriver_6_min',
    #                         'RowDriver_6 mean': 'RowDriver_6_mean',
    #                         'RowDriver_6 std': 'RowDriver_6_std',
    #                         'RowDriver_7 max': 'RowDriver_7_max',
    #                         'RowDriver_7 min': 'RowDriver_7_min',
    #                         'RowDriver_7 mean': 'RowDriver_7_mean',
    #                         'RowDriver_7 std': 'RowDriver_7_std',
    #                         'RowDriver_8 max': 'RowDriver_8_max',
    #                         'RowDriver_8 min': 'RowDriver_8_min',
    #                         'RowDriver_8 mean': 'RowDriver_8_mean',
    #                         'RowDriver_8 std': 'RowDriver_8_std'}, inplace = True)
    #
    # # Column renaming fix for DTR
    # if 'DTR CRC Row# 1' in df.columns:
    #     pass
    # else:
    #     df.rename(columns= {'DTR CRC Row# 2': 'DTR CRC Row# 1', 'DTR CRC Row# 3': 'DTR CRC Row# 2',
    #                         'DTR CRC Row# 4': 'DTR CRC Row# 3', 'DTR CRC Row# 5': 'DTR CRC Row# 4',
    #                         'DTR CRC Row# 6': 'DTR CRC Row# 5', 'DTR CRC Row# 7': 'DTR CRC Row# 6',
    #                         'DTR CRC Row# 8': 'DTR CRC Row# 7', 'DTR CRC Row# 9': 'DTR CRC Row# 8'}, inplace = True)

    print("DataFrame Columns Renamed")
    return df