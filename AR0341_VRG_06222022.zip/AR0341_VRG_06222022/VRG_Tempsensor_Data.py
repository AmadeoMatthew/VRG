import matplotlib
import matplotlib.pyplot as plt
from matplotlib import pyplot
from docx import Document
from docx.shared import Inches
from docx.shared import Pt
from tkinter import *
from tkinter import filedialog
from tkinter import messagebox
import numpy as np
import csv
import argparse
import os
import pandas as pd
import pixelcrunch as pc
import fivecentplots as fcp
import bokeh
import sys
import io
import multiprocessing
import VRG_Safety_Data
import VRG_Calculate
import VRG_Data_Frame
import VRG_Doc
import VRG_General_Data
import VRG_Image_Analysis
import VRG_Image_Utils
import VRG_Macro_Data
import VRG_OTPM_Data
import VRG_Pins_Data
import VRG_Power_Data
import VRG_Register_Data
import VRG_Stats_Arr
import VRG_Stats_ArrCenter
import VRG_Stats_ArrQuad1
import VRG_Stats_ArrQuad2
import VRG_Stats_ArrQuad3
import VRG_Stats_ArrQuad4
import VRG_Stats_ArrRoi1
import VRG_Stats_ArrRoi2
import VRG_Stats_ArrRoi3
import VRG_Stats_ArrRoi4
import VRG_Stats_ArrRoi5
import VRG_Stats_ArrRoi6
import VRG_Stats_ArrRoi7
import VRG_Stats_ArrRoi8
import VRG_Stats_ArrRoi9
import VRG_Stats_DBLC
import VRG_Stats_Frame
import VRG_Stats_Lag
import VRG_Stats_RNC
import VRG_Stats_Tilt
import VRG_Tempsensor_Data
import VRG_Reports
import time

'''
Registers vs Tempsensor Data
'''
def Reg_vs_Tempsensor_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'TEMPSENS1_DATA_K_REG'
        d2 = 'TEMP_DATA_K_SP'
        d3 = 'TEMP_DATA_K_D1'
        d4 = 'TEMP_DATA_K_D2'
        d5 = 'TEMPSENS1_DATA_K_REG Kelvin'
        d6 = 'TEMP_DATA_K_SP Kelvin'
        d7 = 'TEMP_DATA_K_D1 Kelvin'
        d8 = 'TEMP_DATA_K_D2 Kelvin'
        d9 = 'TEMPSENS1_DATA_K_REG Celsius'
        d10 = 'TEMP_DATA_K_SP Celsius'
        d11 = 'TEMP_DATA_K_D1 Celsius'
        d12 = 'TEMP_DATA_K_D2 Celsius'

        figTitle = 'Tempsensor_Data'
        xlabel = register
        ylabel = 'RegVal (Dec)'
        ylabel2 = 'Kelvin (K)'
        ylabel3 = 'Celsius (C)'
        numDataCols = 13  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 10
        xFontsize = 10
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):
                if x < 5:  # All other results
                    fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                             label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                    document.add_picture(
                        pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
                elif x > 4 and x < 9:  # Kelvin
                    fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_x=xlabel, label_y=ylabel2, title_font_size=titleFontSize,
                             label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                    document.add_picture(
                        pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
                elif x > 8:  # Celsius
                    fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_x=xlabel, label_y=ylabel3, title_font_size=titleFontSize,
                             label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                    document.add_picture(
                        pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):
                if x < 5:  # All other results
                    fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy,
                             show=showPlt,
                             inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                             label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                    document.add_picture(
                        pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
                elif x > 4 and x < 9:  # Kelvin
                    fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy,
                             show=showPlt,
                             inline=showPlt, label_x=xlabel, label_y=ylabel2, title_font_size=titleFontSize,
                             label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                    document.add_picture(
                        pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
                elif x > 8:  # Celsius
                    fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy,
                             show=showPlt,
                             inline=showPlt, label_x=xlabel, label_y=ylabel3, title_font_size=titleFontSize,
                             label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                    document.add_picture(
                        pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

'''
Tempsensor Register Data
'''
def Tempsensor_Register_vs_Time_Plot(dataFrame, groupCol, groupVal, document, pltPath, colName, showPlt, **kwargs):
    try:
        if groupCol == None and groupVal == None:  #Dont group data frame
            df = dataFrame
        elif groupCol != None and groupVal != None: #Group data frame by col and value
            df = VRG_Data_Frame.newdataframe(dataFrame, groupCol, groupVal)

        d1 = colName

        figTitle = 'Tempsensor_Reg_vs_Time'
        titleFontSize = 12
        yFontsize = 8
        xFontsize = 8
        legFontSize = 6

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        t1_cols = [x for x in df.columns[df.columns.str.contains(d1)]]
        t1 = df[t1_cols]

        for dc in t1_cols:
            t1 = t1.rename(columns={dc: dc.split(' ')[2]})

        t1 = t1.T
        t1['Read Num'] = t1.index

        colList = []
        for index in df.index:
            colList.append(index)

        if groupCol == None and groupVal == None:  # No Dataframe grouping
            fcp.plot(t1, x='Read Num', y=colList, title=d1, legend_title="Test #", label_y=d1, show=showPlt,
                     inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_heading(d1, level=3)
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
        elif groupCol != None and groupVal != None: # Data frame grouped by col and val
            fcp.plot(t1, x='Read Num', y=colList, title=d1 + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                     legend_title="Test #", label_y=d1, show=showPlt,
                     inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_heading(d1 + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for dc in t1_cols:  # 1 to 4
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        if groupCol == None:
            document.add_heading("groupCol Not Used", level=3)
        elif groupCol != None:
            if groupCol in df.columns:
                document.add_heading("groupCol Found: " + groupCol, level=3)  # Add Groupby found
                if groupVal == None:
                    document.add_heading("groupVal Missing", level=3)
                elif groupVal != None:
                    if groupCol in df[groupCol].unique():
                        document.add_heading("groupVal Found: " + groupVal, level=3)  # Add Groupby found
                    else:
                        document.add_heading("groupVal Not Found: " + groupVal, level=3)  # Add Groupby not found
            else:
                document.add_heading("groupCol Not Found: " + groupCol, level=3)  # Add Groupby not found

def Tempsensor_Register_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = register

        figTitle = 'Tempsensor_Register_Data'
        numDataCols = 2
        titleFontSize = 14
        yFontsize = 10
        xFontsize = 10
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, show=showPlt, inline=showPlt,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_heading(d1, level=3)
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, legend=groupBy, show=showPlt, inline=showPlt,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_heading(d1, level=3)
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Tempsensor_Register_Average_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = register

        # get data columns
        df = dataFrame

        t1_cols = [x for x in df.columns[df.columns.str.contains(d1)]]

        dt1 = d1.split(' ')[0]

        t1 = dt1 + '_AVG'
        df[t1] = df[t1_cols].mean(axis=1)

        figTitle = 'Tempsensor_Register_Average'
        titleFontSize = 14
        yFontsize = 10
        xFontsize = 10
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=t1, title=t1, show=showPlt, inline=showPlt,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + t1 + '_' + timestamp + '.png')
            document.add_heading(t1, level=3)
            document.add_picture(pltPath + t1 + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=t1, title=t1, legend=groupBy, show=showPlt, inline=showPlt,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + t1 + '_' + timestamp + '.png')
            document.add_heading(t1, level=3)
            document.add_picture(pltPath + t1 + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for dc in t1_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found


'''
Tempsensor Read Data
'''
def Tempsensor_Read_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'TEMPSENS1_DATA_K_REG'
        d2 = 'TEMP_DATA_K_SP'
        d3 = 'TEMP_DATA_K_D1'
        d4 = 'TEMP_DATA_K_D2'
        d5 = 'TEMPSENS1_DATA_K_REG Kelvin'
        d6 = 'TEMP_DATA_K_SP Kelvin'
        d7 = 'TEMP_DATA_K_D1 Kelvin'
        d8 = 'TEMP_DATA_K_D2 Kelvin'
        d9 = 'TEMPSENS1_DATA_K_REG Celsius'
        d10 = 'TEMP_DATA_K_SP Celsius'
        d11 = 'TEMP_DATA_K_D1 Celsius'
        d12 = 'TEMP_DATA_K_D2 Celsius'

        figTitle = 'Tempsensor_Data'
        ylabel = 'RegVal (Dec)'
        ylabel2 = 'Kelvin (K)'
        ylabel3 = 'Celsius (C)'
        numDataCols = 13  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 10
        xFontsize = 10
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):
                if x < 5:  # All other results
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
                elif x > 4 and x < 9:  # Kelvin
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
                elif x > 8:  # Celsius
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel3, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):
                if x < 5: # All other results
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
                elif x > 4 and x < 9:  # Kelvin
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
                elif x > 8:  # Celsius
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel3, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Tempsensor_Complete_Read_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'TEMPSENS1_DATA_K_REG'
        d2 = 'TEMP_DATA_K_SP'
        d3 = 'TEMP_DATA_K_D1'
        d4 = 'TEMP_DATA_K_D2'
        d5 = 'TEMPSENS1_DATA_K_REG Kelvin'
        d6 = 'TEMP_DATA_K_SP Kelvin'
        d7 = 'TEMP_DATA_K_D1 Kelvin'
        d8 = 'TEMP_DATA_K_D2 Kelvin'
        d9 = 'TEMPSENS1_DATA_K_REG Celsius'
        d10 = 'TEMP_DATA_K_SP Celsius'
        d11 = 'TEMP_DATA_K_D1 Celsius'
        d12 = 'TEMP_DATA_K_D2 Celsius'

        figTitle = 'Tempsensor_Data'
        ylabel = 'RegVal (Dec)'
        ylabel2 = 'Kelvin (K)'
        ylabel3 = 'Celsius (C)'
        numDataCols = 13  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 10
        xFontsize = 10
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):
                if x < 5:  # All other results
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(
                        pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
                elif x > 4 and x < 9:  # Kelvin
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel2, title_font_size=titleFontSize,
                             label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(
                        pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
                elif x > 8:  # Celsius
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel3, title_font_size=titleFontSize,
                             label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(
                        pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):
                if x < 5:  # All other results
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(
                        pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
                elif x > 4 and x < 9:  # Kelvin
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel2, title_font_size=titleFontSize,
                             label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(
                        pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
                elif x > 8:  # Celsius
                    fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel3, title_font_size=titleFontSize,
                             label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("d" + str(x)), level=3)
                    document.add_picture(
                        pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report

        Tempsensor_SM_Data_Stream_Read_Plot(df, groupBy, document, pltPath, showPlt)
        Tempsensor_SM_Data_Standby_Read_Plot(df, groupBy, document, pltPath, showPlt)

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

'''
Tempsensor Data K Read Data
'''
def Tempsensor_Data_K_Read_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'TEMPSENS1_DATA_K_REG'
        d2 = 'TEMP_DATA_K_SP'
        d3 = 'TEMP_DATA_K_D1'
        d4 = 'TEMP_DATA_K_D2'

        figTitle = 'Tempsensor_Data_k_Data'
        ylabel = 'RegVal (Dec)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 10
        xFontsize = 10
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Tempsensor_Data_K_Read_vs_TestNo_Plot(dataFrame, groupCol, groupVal, document, pltPath, showPlt, **kwargs):
    try:
        if groupCol == None and groupVal == None:  #Dont group data frame
            df = dataFrame
        elif groupCol != None and groupVal != None: #Group data frame by col and value
            df = VRG_Data_Frame.newdataframe(dataFrame, groupCol, groupVal)

        d1 = 'TEMPSENS1_DATA_K_REG Read'
        d2 = 'TEMP_DATA_K_SP Read'
        d3 = 'TEMP_DATA_K_D1 Read'
        d4 = 'TEMP_DATA_K_D2 Read'

        # get data columns
        t1_cols = [x for x in df.columns[df.columns.str.contains(d1)]]
        t2_cols = [x for x in df.columns[df.columns.str.contains(d2)]]
        t3_cols = [x for x in df.columns[df.columns.str.contains(d3)]]
        t4_cols = [x for x in df.columns[df.columns.str.contains(d4)]]

        # subset df
        t1 = df[t1_cols]
        t2 = df[t2_cols]
        t3 = df[t3_cols]
        t4 = df[t4_cols]

        # rename columns to get read number
        for dc in t1_cols:
            t1 = t1.rename(columns={dc: dc.split(' ')[2]})
        for dc in t2_cols:
            t2 = t2.rename(columns={dc: dc.split(' ')[2]})
        for dc in t3_cols:
            t3 = t3.rename(columns={dc: dc.split(' ')[2]})
        for dc in t4_cols:
            t4 = t4.rename(columns={dc: dc.split(' ')[2]})

        # transpose
        t1 = t1.T
        t2 = t2.T
        t3 = t3.T
        t4 = t4.T

        # add an index column
        t1['Read Num'] = t1.index
        t2['Read Num'] = t2.index
        t3['Read Num'] = t3.index
        t4['Read Num'] = t4.index

        figTitle = 'Tempsensor_Data_K_Read_vs_TestNo'
        numDataCols = len(df.index)  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 12
        yFontsize = 8
        xFontsize = 8
        legFontSize = 6

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupCol == None and groupVal == None:  # No Dataframe grouping
            document.add_heading(d1 + " vs. Test #", level=2)
            for x in range(1, numDataCols):
                fcp.plot(t1, x='Read Num', y=x, title="Test #" + str(x), show=showPlt,
                         inline=showPlt, label_y=d1, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
                document.add_heading(d1 + " Test #" + str(x), level=3)
                document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
            document.add_heading(d2 + " vs. Test #", level=2)
            for x in range(1, numDataCols):
                fcp.plot(t2, x='Read Num', y=x, title="Test #" + str(x), show=showPlt,
                         inline=showPlt, label_y=d2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d2 + '_' + timestamp + '.png')
                document.add_heading(d2 + " Test #" + str(x), level=3)
                document.add_picture(pltPath + d2 + '_' + timestamp + '.png')  # Add figure to report
            document.add_heading(d3 + " vs. Test #", level=2)
            for x in range(1, numDataCols):
                fcp.plot(t3, x='Read Num', y=x, title="Test #" + str(x), show=showPlt,
                         inline=showPlt, label_y=d3, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d3 + '_' + timestamp + '.png')
                document.add_heading(d3 + " Test #" + str(x), level=3)
                document.add_picture(pltPath + d3 + '_' + timestamp + '.png')  # Add figure to report
            document.add_heading(d4 + " vs. Test #", level=2)
            for x in range(1, numDataCols):
                fcp.plot(t4, x='Read Num', y=x, title="Test #" + str(x), show=showPlt,
                         inline=showPlt, label_y=d4, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d4 + '_' + timestamp + '.png')
                document.add_heading(d4 + " Test #" + str(x), level=3)
                document.add_picture(pltPath + d4 + '_' + timestamp + '.png')  # Add figure to report
        elif groupCol != None and groupVal != None: # Data frame grouped by col and val
            document.add_heading(d1 + " vs. Test # Groupedby: " + groupCol + ' = ' + str(groupVal), level=2)
            for x in range(1, numDataCols):
                fcp.plot(t1, x='Read Num', y=x, title="Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal), show=showPlt,
                         inline=showPlt, label_y=d1, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
                document.add_heading(d1 + " Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
                document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
            document.add_heading(d2 + " vs. Test # Groupedby: " + groupCol + ' = ' + str(groupVal), level=2)
            for x in range(1, numDataCols):
                fcp.plot(t2, x='Read Num', y=x, title="Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal), show=showPlt,
                         inline=showPlt, label_y=d2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d2 + '_' + timestamp + '.png')
                document.add_heading(d2 + " Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
                document.add_picture(pltPath + d2 + '_' + timestamp + '.png')  # Add figure to report
            document.add_heading(d3 + " vs. Test # Groupedby: " + groupCol + ' = ' + str(groupVal), level=2)
            for x in range(1, numDataCols):
                fcp.plot(t3, x='Read Num', y=x, title="Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal), show=showPlt,
                         inline=showPlt, label_y=d3, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d3 + '_' + timestamp + '.png')
                document.add_heading(d3 + " Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
                document.add_picture(pltPath + d3 + '_' + timestamp + '.png')  # Add figure to report
            document.add_heading(d4 + " vs. Test # Groupedby: " + groupCol + ' = ' + str(groupVal), level=2)
            for x in range(1, numDataCols):
                fcp.plot(t4, x='Read Num', y=x, title="Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal), show=showPlt,
                         inline=showPlt, label_y=d4, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d4 + '_' + timestamp + '.png')
                document.add_heading(d4 + " Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
                document.add_picture(pltPath + d4 + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for dc in t1_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t2_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t3_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t4_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        if groupCol == None:
            document.add_heading("groupCol Not Used", level=3)
        elif groupCol != None:
            if groupCol in df.columns:
                document.add_heading("groupCol Found: " + groupCol, level=3)  # Add Groupby found
                if groupVal == None:
                    document.add_heading("groupVal Missing", level=3)
                elif groupVal != None:
                    if groupCol in df[groupCol].unique():
                        document.add_heading("groupVal Found: " + groupVal, level=3)  # Add Groupby found
                    else:
                        document.add_heading("groupVal Not Found: " + groupVal, level=3)  # Add Groupby not found
            else:
                document.add_heading("groupCol Not Found: " + groupCol, level=3)  # Add Groupby not found

def Tempsensor_Data_K_Read_vs_Time_Plot(dataFrame, groupCol, groupVal, document, pltPath, showPlt, **kwargs):
    try:
        if groupCol == None and groupVal == None:  #Dont group data frame
            df = dataFrame
        elif groupCol != None and groupVal != None: #Group data frame by col and value
            df = VRG_Data_Frame.newdataframe(dataFrame, groupCol, groupVal)

        d1 = 'TEMPSENS1_DATA_K_REG Read'
        d2 = 'TEMP_DATA_K_SP Read'
        d3 = 'TEMP_DATA_K_D1 Read'
        d4 = 'TEMP_DATA_K_D2 Read'

        # get data columns
        t1_cols = [x for x in df.columns[df.columns.str.contains(d1)]]
        t2_cols = [x for x in df.columns[df.columns.str.contains(d2)]]
        t3_cols = [x for x in df.columns[df.columns.str.contains(d3)]]
        t4_cols = [x for x in df.columns[df.columns.str.contains(d4)]]

        # subset df
        t1 = df[t1_cols]
        t2 = df[t2_cols]
        t3 = df[t3_cols]
        t4 = df[t4_cols]

        # rename columns to get read number
        for dc in t1_cols:
            t1 = t1.rename(columns={dc: dc.split(' ')[2]}) # get the integer (2) value from the name
        for dc in t2_cols:
            t2 = t2.rename(columns={dc: dc.split(' ')[2]}) # get the integer (2) value from the name
        for dc in t3_cols:
            t3 = t3.rename(columns={dc: dc.split(' ')[2]}) # get the integer (2) value from the name
        for dc in t4_cols:
            t4 = t4.rename(columns={dc: dc.split(' ')[2]}) # get the integer (2) value from the name

        # transpose
        t1 = t1.T
        t2 = t2.T
        t3 = t3.T
        t4 = t4.T

        # add an index column
        t1['Read Num'] = t1.index
        t2['Read Num'] = t2.index
        t3['Read Num'] = t3.index
        t4['Read Num'] = t4.index

        colList = []
        for index in df.index:
            colList.append(index)

        figTitle = 'Tempsensor_Data_K_Read_vs_Time'
        titleFontSize = 12
        yFontsize = 8
        xFontsize = 8
        legFontSize = 6

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupCol == None and groupVal == None:  # No Dataframe grouping
                fcp.plot(t1, x='Read Num', y=colList, title=d1, legend_title="Test #", show=showPlt,
                         inline=showPlt, label_y=d1, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
                document.add_heading(d1, level=3)
                document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
                fcp.plot(t2, x='Read Num', y=colList, title=d2, legend_title="Test #", show=showPlt,
                         inline=showPlt, label_y=d2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d2 + '_' + timestamp + '.png')
                document.add_heading(d2, level=3)
                document.add_picture(pltPath + d2 + '_' + timestamp + '.png')  # Add figure to report
                fcp.plot(t3, x='Read Num', y=colList, title=d3, legend_title="Test #", show=showPlt,
                         inline=showPlt, label_y=d3, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d3 + '_' + timestamp + '.png')
                document.add_heading(d3, level=3)
                document.add_picture(pltPath + d3 + '_' + timestamp + '.png')  # Add figure to report
                fcp.plot(t4, x='Read Num', y=colList, title=d4, legend_title="Test #", show=showPlt,
                         inline=showPlt, label_y=d4, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d4 + '_' + timestamp + '.png')
                document.add_heading(d4, level=3)
                document.add_picture(pltPath + d4 + '_' + timestamp + '.png')  # Add figure to report
        elif groupCol != None and groupVal != None: # Data frame grouped by col and val
                fcp.plot(t1, x='Read Num', y=colList, title=d1 + " Groupedby: " + groupCol + ' = ' + str(groupVal), show=showPlt,
                         inline=showPlt, legend_title="Test #", label_y=d1, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
                document.add_heading(d1 + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
                document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
                fcp.plot(t2, x='Read Num', y=colList, title=d2 + " Groupedby: " + groupCol + ' = ' + str(groupVal), show=showPlt,
                         inline=showPlt, legend_title="Test #", label_y=d2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d2 + '_' + timestamp + '.png')
                document.add_heading(d2 + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
                document.add_picture(pltPath + d2 + '_' + timestamp + '.png')  # Add figure to report
                fcp.plot(t3, x='Read Num', y=colList, title=d3 + " Groupedby: " + groupCol + ' = ' + str(groupVal), show=showPlt,
                         inline=showPlt, legend_title="Test #", label_y=d3, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d3 + '_' + timestamp + '.png')
                document.add_heading(d3 + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
                document.add_picture(pltPath + d3 + '_' + timestamp + '.png')  # Add figure to report
                fcp.plot(t4, x='Read Num', y=colList, title=d4 + " Groupedby: " + groupCol + ' = ' + str(groupVal), show=showPlt,
                         inline=showPlt, legend_title="Test #", label_y=d4, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d4 + '_' + timestamp + '.png')
                document.add_heading(d4 + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
                document.add_picture(pltPath + d4 + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for dc in t1_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t2_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t3_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t4_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        if groupCol == None:
            document.add_heading("groupCol Not Used", level=3)
        elif groupCol != None:
            if groupCol in df.columns:
                document.add_heading("groupCol Found: " + groupCol, level=3)  # Add Groupby found
                if groupVal == None:
                    document.add_heading("groupVal Missing", level=3)
                elif groupVal != None:
                    if groupCol in df[groupCol].unique():
                        document.add_heading("groupVal Found: " + groupVal, level=3)  # Add Groupby found
                    else:
                        document.add_heading("groupVal Not Found: " + groupVal, level=3)  # Add Groupby not found
            else:
                document.add_heading("groupCol Not Found: " + groupCol, level=3)  # Add Groupby not found

def Tempsensor_Data_K_Read_Average_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'TEMPSENS1_DATA_K_REG Read'
        d2 = 'TEMP_DATA_K_SP Read'
        d3 = 'TEMP_DATA_K_D1 Read'
        d4 = 'TEMP_DATA_K_D2 Read'

        # get data columns
        df = dataFrame
        t1_cols = [x for x in df.columns[df.columns.str.contains(d1)]]
        t2_cols = [x for x in df.columns[df.columns.str.contains(d2)]]
        t3_cols = [x for x in df.columns[df.columns.str.contains(d3)]]
        t4_cols = [x for x in df.columns[df.columns.str.contains(d4)]]

        dt1 = d1.split(' ')[0]
        dt2 = d2.split(' ')[0]
        dt3 = d3.split(' ')[0]
        dt4 = d4.split(' ')[0]

        t1 = dt1 + '_AVG'
        t2 = dt2 + '_AVG'
        t3 = dt3 + '_AVG'
        t4 = dt4 + '_AVG'

        df[t1] = df[t1_cols].mean(axis=1)
        df[t2] = df[t2_cols].mean(axis=1)
        df[t3] = df[t3_cols].mean(axis=1)
        df[t4] = df[t4_cols].mean(axis=1)

        figTitle = 'Tempsensor_Data_K_Read_Average'
        ylabel = 'RegVal (Dec)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 10
        xFontsize = 10
        legFontSize = 6

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):
                fcp.plot(df, x='Step', y=eval("t" + str(x)), title=eval("t" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("t" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("t" + str(x)), level=3)
                document.add_picture(pltPath + eval("t" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):
                fcp.plot(df, x='Step', y=eval("t" + str(x)), title=eval("t" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("t" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("t" + str(x)), level=3)
                document.add_picture(pltPath + eval("t" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for dc in t1_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t2_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t3_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t4_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

'''
Tempsensor Kelvin Data
'''
def Tempsensor_Kelvin_Read_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'TEMPSENS1_DATA_K_REG Kelvin'
        d2 = 'TEMP_DATA_K_SP Kelvin'
        d3 = 'TEMP_DATA_K_D1 Kelvin'
        d4 = 'TEMP_DATA_K_D2 Kelvin'

        figTitle = 'Tempsensor_Kelvin_Data'
        ylabel = 'Kelvin (K)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 10
        xFontsize = 10
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
                
def Tempsensor_Kelvin_Read_vs_TestNo_Plot(dataFrame, groupCol, groupVal, document, pltPath, showPlt, **kwargs):
    try:
        if groupCol == None and groupVal == None:  #Dont group data frame
            df = dataFrame
        elif groupCol != None and groupVal != None: #Group data frame by col and value
            df = VRG_Data_Frame.newdataframe(dataFrame, groupCol, groupVal)

        d1 = 'TEMPSENS1_DATA_K_REG_Kelvin Read'
        d2 = 'TEMP_DATA_K_SP_Kelvin Read'
        d3 = 'TEMP_DATA_K_D1_Kelvin Read'
        d4 = 'TEMP_DATA_K_D2_Kelvin Read'

        # get data columns
        t1_cols = [x for x in df.columns[df.columns.str.contains(d1)]]
        t2_cols = [x for x in df.columns[df.columns.str.contains(d2)]]
        t3_cols = [x for x in df.columns[df.columns.str.contains(d3)]]
        t4_cols = [x for x in df.columns[df.columns.str.contains(d4)]]

        # subset df
        t1 = df[t1_cols]
        t2 = df[t2_cols]
        t3 = df[t3_cols]
        t4 = df[t4_cols]

        # rename columns to get read number
        for dc in t1_cols:
            t1 = t1.rename(columns={dc: dc.split(' ')[2]})
        for dc in t2_cols:
            t2 = t2.rename(columns={dc: dc.split(' ')[2]})
        for dc in t3_cols:
            t3 = t3.rename(columns={dc: dc.split(' ')[2]})
        for dc in t4_cols:
            t4 = t4.rename(columns={dc: dc.split(' ')[2]})

        # transpose
        t1 = t1.T
        t2 = t2.T
        t3 = t3.T
        t4 = t4.T

        # add an index column
        t1['Read Num'] = t1.index
        t2['Read Num'] = t2.index
        t3['Read Num'] = t3.index
        t4['Read Num'] = t4.index

        figTitle = 'Tempsensor_Kelvin_Read_vs_TestNo'
        numDataCols = len(df.index)  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 12
        yFontsize = 8
        xFontsize = 8
        legFontSize = 6

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupCol == None and groupVal == None:  # No Dataframe grouping
            document.add_heading(d1 + " vs. Test #", level=2)
            for x in range(1, numDataCols):
                fcp.plot(t1, x='Read Num', y=x, title="Test #" + str(x), show=showPlt,
                         inline=showPlt, label_y=d1, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
                document.add_heading(d1 + " Test #" + str(x), level=3)
                document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
            document.add_heading(d2 + " vs. Test #", level=2)
            for x in range(1, numDataCols):
                fcp.plot(t2, x='Read Num', y=x, title="Test #" + str(x), show=showPlt,
                         inline=showPlt, label_y=d2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d2 + '_' + timestamp + '.png')
                document.add_heading(d2 + " Test #" + str(x), level=3)
                document.add_picture(pltPath + d2 + '_' + timestamp + '.png')  # Add figure to report
            document.add_heading(d3 + " vs. Test #", level=2)
            for x in range(1, numDataCols):
                fcp.plot(t3, x='Read Num', y=x, title="Test #" + str(x), show=showPlt,
                         inline=showPlt, label_y=d3, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d3 + '_' + timestamp + '.png')
                document.add_heading(d3 + " Test #" + str(x), level=3)
                document.add_picture(pltPath + d3 + '_' + timestamp + '.png')  # Add figure to report
            document.add_heading(d4 + " vs. Test #", level=2)
            for x in range(1, numDataCols):
                fcp.plot(t4, x='Read Num', y=x, title="Test #" + str(x), show=showPlt,
                         inline=showPlt, label_y=d4, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d4 + '_' + timestamp + '.png')
                document.add_heading(d4 + " Test #" + str(x), level=3)
                document.add_picture(pltPath + d4 + '_' + timestamp + '.png')  # Add figure to report
        elif groupCol != None and groupVal != None: # Data frame grouped by col and val
            document.add_heading(d1 + " vs. Test # Groupedby: " + groupCol + ' = ' + str(groupVal), level=2)
            for x in range(1, numDataCols):
                fcp.plot(t1, x='Read Num', y=x, title="Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal), show=showPlt,
                         inline=showPlt, label_y=d1, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
                document.add_heading(d1 + " Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
                document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
            document.add_heading(d2 + " vs. Test # Groupedby: " + groupCol + ' = ' + str(groupVal), level=2)
            for x in range(1, numDataCols):
                fcp.plot(t2, x='Read Num', y=x, title="Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal), show=showPlt,
                         inline=showPlt, label_y=d2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d2 + '_' + timestamp + '.png')
                document.add_heading(d2 + " Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
                document.add_picture(pltPath + d2 + '_' + timestamp + '.png')  # Add figure to report
            document.add_heading(d3 + " vs. Test # Groupedby: " + groupCol + ' = ' + str(groupVal), level=2)
            for x in range(1, numDataCols):
                fcp.plot(t3, x='Read Num', y=x, title="Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal), show=showPlt,
                         inline=showPlt, label_y=d3, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d3 + '_' + timestamp + '.png')
                document.add_heading(d3 + " Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
                document.add_picture(pltPath + d3 + '_' + timestamp + '.png')  # Add figure to report
            document.add_heading(d4 + " vs. Test # Groupedby: " + groupCol + ' = ' + str(groupVal), level=2)
            for x in range(1, numDataCols):
                fcp.plot(t4, x='Read Num', y=x, title="Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal), show=showPlt,
                         inline=showPlt, label_y=d4, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d4 + '_' + timestamp + '.png')
                document.add_heading(d4 + " Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
                document.add_picture(pltPath + d4 + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for dc in t1_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t2_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t3_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t4_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        if groupCol == None:
            document.add_heading("groupCol Not Used", level=3)
        elif groupCol != None:
            if groupCol in df.columns:
                document.add_heading("groupCol Found: " + groupCol, level=3)  # Add Groupby found
                if groupVal == None:
                    document.add_heading("groupVal Missing", level=3)
                elif groupVal != None:
                    if groupCol in df[groupCol].unique():
                        document.add_heading("groupVal Found: " + groupVal, level=3)  # Add Groupby found
                    else:
                        document.add_heading("groupVal Not Found: " + groupVal, level=3)  # Add Groupby not found
            else:
                document.add_heading("groupCol Not Found: " + groupCol, level=3)  # Add Groupby not found

def Tempsensor_Kelvin_Read_vs_Time_Plot(dataFrame, groupCol, groupVal, document, pltPath, showPlt, **kwargs):
    try:
        if groupCol == None and groupVal == None:  #Dont group data frame
            df = dataFrame
        elif groupCol != None and groupVal != None: #Group data frame by col and value
            df = VRG_Data_Frame.newdataframe(dataFrame, groupCol, groupVal)

        d1 = 'TEMPSENS1_DATA_K_REG_Kelvin Read'
        d2 = 'TEMP_DATA_K_SP_Kelvin Read'
        d3 = 'TEMP_DATA_K_D1_Kelvin Read'
        d4 = 'TEMP_DATA_K_D2_Kelvin Read'

        # get data columns
        t1_cols = [x for x in df.columns[df.columns.str.contains(d1)]]
        t2_cols = [x for x in df.columns[df.columns.str.contains(d2)]]
        t3_cols = [x for x in df.columns[df.columns.str.contains(d3)]]
        t4_cols = [x for x in df.columns[df.columns.str.contains(d4)]]

        # subset df
        t1 = df[t1_cols]
        t2 = df[t2_cols]
        t3 = df[t3_cols]
        t4 = df[t4_cols]

        # rename columns to get read number
        for dc in t1_cols:
            t1 = t1.rename(columns={dc: dc.split(' ')[2]}) # get the integer (2) value from the name
        for dc in t2_cols:
            t2 = t2.rename(columns={dc: dc.split(' ')[2]}) # get the integer (2) value from the name
        for dc in t3_cols:
            t3 = t3.rename(columns={dc: dc.split(' ')[2]}) # get the integer (2) value from the name
        for dc in t4_cols:
            t4 = t4.rename(columns={dc: dc.split(' ')[2]}) # get the integer (2) value from the name

        # transpose
        t1 = t1.T
        t2 = t2.T
        t3 = t3.T
        t4 = t4.T

        # add an index column
        t1['Read Num'] = t1.index
        t2['Read Num'] = t2.index
        t3['Read Num'] = t3.index
        t4['Read Num'] = t4.index

        colList = []
        for index in df.index:
            colList.append(index)

        figTitle = 'Tempsensor_Kelvin_Read_vs_Time'
        titleFontSize = 12
        yFontsize = 8
        xFontsize = 8
        legFontSize = 6

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupCol == None and groupVal == None:  # No Dataframe grouping
                fcp.plot(t1, x='Read Num', y=colList, title=d1, legend_title="Test #", show=showPlt,
                         inline=showPlt, label_y=d1, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
                document.add_heading(d1, level=3)
                document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
                fcp.plot(t2, x='Read Num', y=colList, title=d2, legend_title="Test #", show=showPlt,
                         inline=showPlt, label_y=d2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d2 + '_' + timestamp + '.png')
                document.add_heading(d2, level=3)
                document.add_picture(pltPath + d2 + '_' + timestamp + '.png')  # Add figure to report
                fcp.plot(t3, x='Read Num', y=colList, title=d3, legend_title="Test #", show=showPlt,
                         inline=showPlt, label_y=d3, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d3 + '_' + timestamp + '.png')
                document.add_heading(d3, level=3)
                document.add_picture(pltPath + d3 + '_' + timestamp + '.png')  # Add figure to report
                fcp.plot(t4, x='Read Num', y=colList, title=d4, legend_title="Test #", show=showPlt,
                         inline=showPlt, label_y=d4, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d4 + '_' + timestamp + '.png')
                document.add_heading(d4, level=3)
                document.add_picture(pltPath + d4 + '_' + timestamp + '.png')  # Add figure to report
        elif groupCol != None and groupVal != None: # Data frame grouped by col and val
                fcp.plot(t1, x='Read Num', y=colList, title=d1 + " Groupedby: " + groupCol + ' = ' + str(groupVal), show=showPlt,
                         inline=showPlt, legend_title="Test #", label_y=d1, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
                document.add_heading(d1 + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
                document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
                fcp.plot(t2, x='Read Num', y=colList, title=d2 + " Groupedby: " + groupCol + ' = ' + str(groupVal), show=showPlt,
                         inline=showPlt, legend_title="Test #", label_y=d2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d2 + '_' + timestamp + '.png')
                document.add_heading(d2 + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
                document.add_picture(pltPath + d2 + '_' + timestamp + '.png')  # Add figure to report
                fcp.plot(t3, x='Read Num', y=colList, title=d3 + " Groupedby: " + groupCol + ' = ' + str(groupVal), show=showPlt,
                         inline=showPlt, legend_title="Test #", label_y=d3, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d3 + '_' + timestamp + '.png')
                document.add_heading(d3 + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
                document.add_picture(pltPath + d3 + '_' + timestamp + '.png')  # Add figure to report
                fcp.plot(t4, x='Read Num', y=colList, title=d4 + " Groupedby: " + groupCol + ' = ' + str(groupVal), show=showPlt,
                         inline=showPlt, legend_title="Test #", label_y=d4, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d4 + '_' + timestamp + '.png')
                document.add_heading(d4 + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
                document.add_picture(pltPath + d4 + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for dc in t1_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t2_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t3_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t4_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        if groupCol == None:
            document.add_heading("groupCol Not Used", level=3)
        elif groupCol != None:
            if groupCol in df.columns:
                document.add_heading("groupCol Found: " + groupCol, level=3)  # Add Groupby found
                if groupVal == None:
                    document.add_heading("groupVal Missing", level=3)
                elif groupVal != None:
                    if groupCol in df[groupCol].unique():
                        document.add_heading("groupVal Found: " + groupVal, level=3)  # Add Groupby found
                    else:
                        document.add_heading("groupVal Not Found: " + groupVal, level=3)  # Add Groupby not found
            else:
                document.add_heading("groupCol Not Found: " + groupCol, level=3)  # Add Groupby not found

def Tempsensor_Kelvin_Read_Average_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'TEMPSENS1_DATA_K_REG_Kelvin Read'
        d2 = 'TEMP_DATA_K_SP_Kelvin Read'
        d3 = 'TEMP_DATA_K_D1_Kelvin Read'
        d4 = 'TEMP_DATA_K_D2_Kelvin Read'

        # get data columns
        df = dataFrame
        t1_cols = [x for x in df.columns[df.columns.str.contains(d1)]]
        t2_cols = [x for x in df.columns[df.columns.str.contains(d2)]]
        t3_cols = [x for x in df.columns[df.columns.str.contains(d3)]]
        t4_cols = [x for x in df.columns[df.columns.str.contains(d4)]]

        dt1 = d1.split(' ')[0]
        dt2 = d2.split(' ')[0]
        dt3 = d3.split(' ')[0]
        dt4 = d4.split(' ')[0]

        t1 = dt1 + '_AVG'
        t2 = dt2 + '_AVG'
        t3 = dt3 + '_AVG'
        t4 = dt4 + '_AVG'

        df[t1] = df[t1_cols].mean(axis=1)
        df[t2] = df[t2_cols].mean(axis=1)
        df[t3] = df[t3_cols].mean(axis=1)
        df[t4] = df[t4_cols].mean(axis=1)

        figTitle = 'Tempsensor_Kelvin_Read_Average'
        ylabel = 'Kelvin (K)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 10
        xFontsize = 10
        legFontSize = 6

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):
                fcp.plot(df, x='Step', y=eval("t" + str(x)), title=eval("t" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("t" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("t" + str(x)), level=3)
                document.add_picture(pltPath + eval("t" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):
                fcp.plot(df, x='Step', y=eval("t" + str(x)), title=eval("t" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("t" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("t" + str(x)), level=3)
                document.add_picture(pltPath + eval("t" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for dc in t1_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t2_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t3_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t4_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

'''
Tempsensor Celsius Data
'''
def Tempsensor_Celsius_Read_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'TEMPSENS1_DATA_K_REG Celsius'
        d2 = 'TEMP_DATA_K_SP Celsius'
        d3 = 'TEMP_DATA_K_D1 Celsius'
        d4 = 'TEMP_DATA_K_D2 Celsius'

        figTitle = 'Tempsensor_Celsius_Data'
        ylabel = 'Celsius (C)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 10
        xFontsize = 10
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Tempsensor_Celsius_Read_vs_TestNo_Plot(dataFrame, groupCol, groupVal, document, pltPath, showPlt, **kwargs):
    try:
        if groupCol == None and groupVal == None:  # Dont group data frame
            df = dataFrame
        elif groupCol != None and groupVal != None:  # Group data frame by col and value
            df = VRG_Data_Frame.newdataframe(dataFrame, groupCol, groupVal)

        d1 = 'TEMPSENS1_DATA_K_REG_Celsius Read'
        d2 = 'TEMP_DATA_K_SP_Celsius Read'
        d3 = 'TEMP_DATA_K_D1_Celsius Read'
        d4 = 'TEMP_DATA_K_D_Celsius Read'

        # get data columns
        t1_cols = [x for x in df.columns[df.columns.str.contains(d1)]]
        t2_cols = [x for x in df.columns[df.columns.str.contains(d2)]]
        t3_cols = [x for x in df.columns[df.columns.str.contains(d3)]]
        t4_cols = [x for x in df.columns[df.columns.str.contains(d4)]]

        # subset df
        t1 = df[t1_cols]
        t2 = df[t2_cols]
        t3 = df[t3_cols]
        t4 = df[t4_cols]

        # rename columns to get read number
        for dc in t1_cols:
            t1 = t1.rename(columns={dc: dc.split(' ')[2]})
        for dc in t2_cols:
            t2 = t2.rename(columns={dc: dc.split(' ')[2]})
        for dc in t3_cols:
            t3 = t3.rename(columns={dc: dc.split(' ')[2]})
        for dc in t4_cols:
            t4 = t4.rename(columns={dc: dc.split(' ')[2]})

        # transpose
        t1 = t1.T
        t2 = t2.T
        t3 = t3.T
        t4 = t4.T

        # add an index column
        t1['Read Num'] = t1.index
        t2['Read Num'] = t2.index
        t3['Read Num'] = t3.index
        t4['Read Num'] = t4.index

        figTitle = 'Tempsensor_Celsius_Read_vs_TestNo'
        numDataCols = len(df.index)  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 12
        yFontsize = 8
        xFontsize = 8
        legFontSize = 6

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupCol == None and groupVal == None:  # No Dataframe grouping
            document.add_heading(d1 + " vs. Test #", level=2)
            for x in range(1, numDataCols):
                fcp.plot(t1, x='Read Num', y=x, title="Test #" + str(x), show=showPlt,
                         inline=showPlt, label_y=d1, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
                document.add_heading(d1 + " Test #" + str(x), level=3)
                document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
            document.add_heading(d2 + " vs. Test #", level=2)
            for x in range(1, numDataCols):
                fcp.plot(t2, x='Read Num', y=x, title="Test #" + str(x), show=showPlt,
                         inline=showPlt, label_y=d2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d2 + '_' + timestamp + '.png')
                document.add_heading(d2 + " Test #" + str(x), level=3)
                document.add_picture(pltPath + d2 + '_' + timestamp + '.png')  # Add figure to report
            document.add_heading(d3 + " vs. Test #", level=2)
            for x in range(1, numDataCols):
                fcp.plot(t3, x='Read Num', y=x, title="Test #" + str(x), show=showPlt,
                         inline=showPlt, label_y=d3, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d3 + '_' + timestamp + '.png')
                document.add_heading(d3 + " Test #" + str(x), level=3)
                document.add_picture(pltPath + d3 + '_' + timestamp + '.png')  # Add figure to report
            document.add_heading(d4 + " vs. Test #", level=2)
            for x in range(1, numDataCols):
                fcp.plot(t4, x='Read Num', y=x, title="Test #" + str(x), show=showPlt,
                         inline=showPlt, label_y=d4, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d4 + '_' + timestamp + '.png')
                document.add_heading(d4 + " Test #" + str(x), level=3)
                document.add_picture(pltPath + d4 + '_' + timestamp + '.png')  # Add figure to report
        elif groupCol != None and groupVal != None:  # Data frame grouped by col and val
            document.add_heading(d1 + " vs. Test # Groupedby: " + groupCol + ' = ' + str(groupVal), level=2)
            for x in range(1, numDataCols):
                fcp.plot(t1, x='Read Num', y=x,
                         title="Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal), show=showPlt,
                         inline=showPlt, label_y=d1, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
                document.add_heading(d1 + " Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                                     level=3)
                document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
            document.add_heading(d2 + " vs. Test # Groupedby: " + groupCol + ' = ' + str(groupVal), level=2)
            for x in range(1, numDataCols):
                fcp.plot(t2, x='Read Num', y=x,
                         title="Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal), show=showPlt,
                         inline=showPlt, label_y=d2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d2 + '_' + timestamp + '.png')
                document.add_heading(d2 + " Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                                     level=3)
                document.add_picture(pltPath + d2 + '_' + timestamp + '.png')  # Add figure to report
            document.add_heading(d3 + " vs. Test # Groupedby: " + groupCol + ' = ' + str(groupVal), level=2)
            for x in range(1, numDataCols):
                fcp.plot(t3, x='Read Num', y=x,
                         title="Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal), show=showPlt,
                         inline=showPlt, label_y=d3, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d3 + '_' + timestamp + '.png')
                document.add_heading(d3 + " Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                                     level=3)
                document.add_picture(pltPath + d3 + '_' + timestamp + '.png')  # Add figure to report
            document.add_heading(d4 + " vs. Test # Groupedby: " + groupCol + ' = ' + str(groupVal), level=2)
            for x in range(1, numDataCols):
                fcp.plot(t4, x='Read Num', y=x,
                         title="Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal), show=showPlt,
                         inline=showPlt, label_y=d4, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d4 + '_' + timestamp + '.png')
                document.add_heading(d4 + " Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                                     level=3)
                document.add_picture(pltPath + d4 + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for dc in t1_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t2_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t3_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t4_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        if groupCol == None:
            document.add_heading("groupCol Not Used", level=3)
        elif groupCol != None:
            if groupCol in df.columns:
                document.add_heading("groupCol Found: " + groupCol, level=3)  # Add Groupby found
                if groupVal == None:
                    document.add_heading("groupVal Missing", level=3)
                elif groupVal != None:
                    if groupCol in df[groupCol].unique():
                        document.add_heading("groupVal Found: " + groupVal, level=3)  # Add Groupby found
                    else:
                        document.add_heading("groupVal Not Found: " + groupVal, level=3)  # Add Groupby not found
            else:
                document.add_heading("groupCol Not Found: " + groupCol, level=3)  # Add Groupby not found

def Tempsensor_Celsius_Read_vs_Time_Plot(dataFrame, groupCol, groupVal, document, pltPath, showPlt, **kwargs):
    try:
        if groupCol == None and groupVal == None:  # Dont group data frame
            df = dataFrame
        elif groupCol != None and groupVal != None:  # Group data frame by col and value
            df = VRG_Data_Frame.newdataframe(dataFrame, groupCol, groupVal)

        d1 = 'TEMPSENS1_DATA_K_REG_Celsius Read'
        d2 = 'TEMP_DATA_K_SP_Celsius Read'
        d3 = 'TEMP_DATA_K_D1_Celsius Read'
        d4 = 'TEMP_DATA_K_D2_Celsius Read'

        # get data columns
        t1_cols = [x for x in df.columns[df.columns.str.contains(d1)]]
        t2_cols = [x for x in df.columns[df.columns.str.contains(d2)]]
        t3_cols = [x for x in df.columns[df.columns.str.contains(d3)]]
        t4_cols = [x for x in df.columns[df.columns.str.contains(d4)]]

        # subset df
        t1 = df[t1_cols]
        t2 = df[t2_cols]
        t3 = df[t3_cols]
        t4 = df[t4_cols]

        # rename columns to get read number
        for dc in t1_cols:
            t1 = t1.rename(columns={dc: dc.split(' ')[2]})  # get the integer (2) value from the name
        for dc in t2_cols:
            t2 = t2.rename(columns={dc: dc.split(' ')[2]})  # get the integer (2) value from the name
        for dc in t3_cols:
            t3 = t3.rename(columns={dc: dc.split(' ')[2]})  # get the integer (2) value from the name
        for dc in t4_cols:
            t4 = t4.rename(columns={dc: dc.split(' ')[2]})  # get the integer (2) value from the name

        # transpose
        t1 = t1.T
        t2 = t2.T
        t3 = t3.T
        t4 = t4.T

        # add an index column
        t1['Read Num'] = t1.index
        t2['Read Num'] = t2.index
        t3['Read Num'] = t3.index
        t4['Read Num'] = t4.index

        colList = []
        for index in df.index:
            colList.append(index)

        figTitle = 'Tempsensor_Celsius_Read_vs_Time'
        titleFontSize = 12
        yFontsize = 8
        xFontsize = 8
        legFontSize = 6

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupCol == None and groupVal == None:  # No Dataframe grouping
            fcp.plot(t1, x='Read Num', y=colList, title=d1, legend_title="Test #", show=showPlt,
                     inline=showPlt, label_y=d1, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_heading(d1, level=3)
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t2, x='Read Num', y=colList, title=d2, legend_title="Test #", show=showPlt,
                     inline=showPlt, label_y=d2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d2 + '_' + timestamp + '.png')
            document.add_heading(d2, level=3)
            document.add_picture(pltPath + d2 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t3, x='Read Num', y=colList, title=d3, legend_title="Test #", show=showPlt,
                     inline=showPlt, label_y=d3, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d3 + '_' + timestamp + '.png')
            document.add_heading(d3, level=3)
            document.add_picture(pltPath + d3 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t4, x='Read Num', y=colList, title=d4, legend_title="Test #", show=showPlt,
                     inline=showPlt, label_y=d4, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d4 + '_' + timestamp + '.png')
            document.add_heading(d4, level=3)
            document.add_picture(pltPath + d4 + '_' + timestamp + '.png')  # Add figure to report
        elif groupCol != None and groupVal != None:  # Data frame grouped by col and val
            fcp.plot(t1, x='Read Num', y=colList, title=d1 + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                     show=showPlt,
                     inline=showPlt, legend_title="Test #", label_y=d1, title_font_size=titleFontSize,
                     label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_heading(d1 + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t2, x='Read Num', y=colList, title=d2 + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                     show=showPlt,
                     inline=showPlt, legend_title="Test #", label_y=d2, title_font_size=titleFontSize,
                     label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d2 + '_' + timestamp + '.png')
            document.add_heading(d2 + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
            document.add_picture(pltPath + d2 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t3, x='Read Num', y=colList, title=d3 + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                     show=showPlt,
                     inline=showPlt, legend_title="Test #", label_y=d3, title_font_size=titleFontSize,
                     label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d3 + '_' + timestamp + '.png')
            document.add_heading(d3 + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
            document.add_picture(pltPath + d3 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t4, x='Read Num', y=colList, title=d4 + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                     show=showPlt,
                     inline=showPlt, legend_title="Test #", label_y=d4, title_font_size=titleFontSize,
                     label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d4 + '_' + timestamp + '.png')
            document.add_heading(d4 + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
            document.add_picture(pltPath + d4 + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for dc in t1_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t2_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t3_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t4_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        if groupCol == None:
            document.add_heading("groupCol Not Used", level=3)
        elif groupCol != None:
            if groupCol in df.columns:
                document.add_heading("groupCol Found: " + groupCol, level=3)  # Add Groupby found
                if groupVal == None:
                    document.add_heading("groupVal Missing", level=3)
                elif groupVal != None:
                    if groupCol in df[groupCol].unique():
                        document.add_heading("groupVal Found: " + groupVal, level=3)  # Add Groupby found
                    else:
                        document.add_heading("groupVal Not Found: " + groupVal, level=3)  # Add Groupby not found
            else:
                document.add_heading("groupCol Not Found: " + groupCol, level=3)  # Add Groupby not found

def Tempsensor_Celsius_Read_Average_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'TEMPSENS1_DATA_K_REG_Celsius Read'
        d2 = 'TEMP_DATA_K_SP_Celsius Read'
        d3 = 'TEMP_DATA_K_D1_Celsius Read'
        d4 = 'TEMP_DATA_K_D2_Celsius Read'

        # get data columns
        df = dataFrame
        t1_cols = [x for x in df.columns[df.columns.str.contains(d1)]]
        t2_cols = [x for x in df.columns[df.columns.str.contains(d2)]]
        t3_cols = [x for x in df.columns[df.columns.str.contains(d3)]]
        t4_cols = [x for x in df.columns[df.columns.str.contains(d4)]]

        dt1 = d1.split(' ')[0]
        dt2 = d2.split(' ')[0]
        dt3 = d3.split(' ')[0]
        dt4 = d4.split(' ')[0]

        t1 = dt1 + '_AVG'
        t2 = dt2 + '_AVG'
        t3 = dt3 + '_AVG'
        t4 = dt4 + '_AVG'

        df[t1] = df[t1_cols].mean(axis=1)
        df[t2] = df[t2_cols].mean(axis=1)
        df[t3] = df[t3_cols].mean(axis=1)
        df[t4] = df[t4_cols].mean(axis=1)

        figTitle = 'Tempsensor_Celsius_Read_Average'
        ylabel = 'Celsius (C)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 10
        xFontsize = 10
        legFontSize = 6

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):
                fcp.plot(df, x='Step', y=eval("t" + str(x)), title=eval("t" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("t" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("t" + str(x)), level=3)
                document.add_picture(pltPath + eval("t" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):
                fcp.plot(df, x='Step', y=eval("t" + str(x)), title=eval("t" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("t" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("t" + str(x)), level=3)
                document.add_picture(pltPath + eval("t" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for dc in t1_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t2_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t3_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t4_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found


'''
Tempsensor SM Data Stream Data
'''
def Tempsensor_SM_Data_Stream_Read_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'TEMPSENS1_SM_DATA_STREAM_TS'
        d2 = 'TEMPSENS1_SM_DATA_STREAM_D1'
        d3 = 'TEMPSENS1_SM_DATA_STREAM_D2'
        d4 = 'TEMPSENS1_SM_DATA_STREAM_SC'
        d5 = 'TEMPSENS1_SM_DATA_STREAM_SP'
        d6 = 'TEMPSENS1_SM_DATA_STREAM_MSB'

        figTitle = 'Tempsensor_SM_Data_Stream_Data'
        ylabel = 'RegVal (Dec)'
        numDataCols = 6  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 10
        xFontsize = 10
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Tempsensor_SM_Data_Stream_Read_vs_TestNo_Plot(dataFrame, groupCol, groupVal, document, pltPath, showPlt, **kwargs):
    try:
        if groupCol == None and groupVal == None:  # Dont group data frame
            df = dataFrame
        elif groupCol != None and groupVal != None:  # Group data frame by col and value
            df = VRG_Data_Frame.newdataframe(dataFrame, groupCol, groupVal)

        d1 = 'TEMPSENS1_SM_DATA_STREAM_TS Read'
        d2 = 'TEMPSENS1_SM_DATA_STREAM_D1 Read'
        d3 = 'TEMPSENS1_SM_DATA_STREAM_D2 Read'
        d4 = 'TEMPSENS1_SM_DATA_STREAM_SC Read'
        d5 = 'TEMPSENS1_SM_DATA_STREAM_SP Read'
        d6 = 'TEMPSENS1_SM_DATA_STREAM_MSB Read'

        # get data columns
        t1_cols = [x for x in df.columns[df.columns.str.contains(d1)]]
        t2_cols = [x for x in df.columns[df.columns.str.contains(d2)]]
        t3_cols = [x for x in df.columns[df.columns.str.contains(d3)]]
        t4_cols = [x for x in df.columns[df.columns.str.contains(d4)]]
        t5_cols = [x for x in df.columns[df.columns.str.contains(d5)]]
        t6_cols = [x for x in df.columns[df.columns.str.contains(d6)]]
        
        # subset df
        t1 = df[t1_cols]
        t2 = df[t2_cols]
        t3 = df[t3_cols]
        t4 = df[t4_cols]
        t5 = df[t5_cols]
        t6 = df[t6_cols]

        # rename columns to get read number
        for dc in t1_cols:
            t1 = t1.rename(columns={dc: dc.split(' ')[2]})
        for dc in t2_cols:
            t2 = t2.rename(columns={dc: dc.split(' ')[2]})
        for dc in t3_cols:
            t3 = t3.rename(columns={dc: dc.split(' ')[2]})
        for dc in t4_cols:
            t4 = t4.rename(columns={dc: dc.split(' ')[2]})
        for dc in t5_cols:
            t5 = t5.rename(columns={dc: dc.split(' ')[2]})
        for dc in t6_cols:
            t6 = t6.rename(columns={dc: dc.split(' ')[2]})
        
        # transpose
        t1 = t1.T
        t2 = t2.T
        t3 = t3.T
        t4 = t4.T
        t5 = t5.T
        t6 = t6.T

        # add an index column
        t1['Read Num'] = t1.index
        t2['Read Num'] = t2.index
        t3['Read Num'] = t3.index
        t4['Read Num'] = t4.index
        t5['Read Num'] = t5.index
        t6['Read Num'] = t6.index

        figTitle = 'Tempsensor_SM_Data_Stream_Read_vs_TestNo'
        numDataCols = len(df.index)  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 12
        yFontsize = 8
        xFontsize = 8
        legFontSize = 6

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupCol == None and groupVal == None:  # No Dataframe grouping
            document.add_heading(d1 + " vs. Test #", level=2)
            for x in range(1, numDataCols):
                fcp.plot(t1, x='Read Num', y=x, title="Test #" + str(x), show=showPlt,
                         inline=showPlt, label_y=d1, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
                document.add_heading(d1 + " Test #" + str(x), level=3)
                document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
            document.add_heading(d2 + " vs. Test #", level=2)
            for x in range(1, numDataCols):
                fcp.plot(t2, x='Read Num', y=x, title="Test #" + str(x), show=showPlt,
                         inline=showPlt, label_y=d2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d2 + '_' + timestamp + '.png')
                document.add_heading(d2 + " Test #" + str(x), level=3)
                document.add_picture(pltPath + d2 + '_' + timestamp + '.png')  # Add figure to report
            document.add_heading(d3 + " vs. Test #", level=2)
            for x in range(1, numDataCols):
                fcp.plot(t3, x='Read Num', y=x, title="Test #" + str(x), show=showPlt,
                         inline=showPlt, label_y=d3, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d3 + '_' + timestamp + '.png')
                document.add_heading(d3 + " Test #" + str(x), level=3)
                document.add_picture(pltPath + d3 + '_' + timestamp + '.png')  # Add figure to report
            document.add_heading(d4 + " vs. Test #", level=2)
            for x in range(1, numDataCols):
                fcp.plot(t4, x='Read Num', y=x, title="Test #" + str(x), show=showPlt,
                         inline=showPlt, label_y=d4, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d4 + '_' + timestamp + '.png')
                document.add_heading(d4 + " Test #" + str(x), level=3)
                document.add_picture(pltPath + d4 + '_' + timestamp + '.png')  # Add figure to report
            document.add_heading(d5 + " vs. Test #", level=2)
            for x in range(1, numDataCols):
                fcp.plot(t5, x='Read Num', y=x, title="Test #" + str(x), show=showPlt,
                         inline=showPlt, label_y=d5, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d5 + '_' + timestamp + '.png')
                document.add_heading(d5 + " Test #" + str(x), level=3)
                document.add_picture(pltPath + d5 + '_' + timestamp + '.png')  # Add figure to report
            document.add_heading(d6 + " vs. Test #", level=2)
            for x in range(1, numDataCols):
                fcp.plot(t6, x='Read Num', y=x, title="Test #" + str(x), show=showPlt,
                         inline=showPlt, label_y=d6, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d6 + '_' + timestamp + '.png')
                document.add_heading(d6 + " Test #" + str(x), level=3)
                document.add_picture(pltPath + d6 + '_' + timestamp + '.png')  # Add figure to report
        elif groupCol != None and groupVal != None:  # Data frame grouped by col and val
            document.add_heading(d1 + " vs. Test # Groupedby: " + groupCol + ' = ' + str(groupVal), level=2)
            for x in range(1, numDataCols):
                fcp.plot(t1, x='Read Num', y=x,
                         title="Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal), show=showPlt,
                         inline=showPlt, label_y=d1, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
                document.add_heading(d1 + " Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                                     level=3)
                document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
            document.add_heading(d2 + " vs. Test # Groupedby: " + groupCol + ' = ' + str(groupVal), level=2)
            for x in range(1, numDataCols):
                fcp.plot(t2, x='Read Num', y=x,
                         title="Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal), show=showPlt,
                         inline=showPlt, label_y=d2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d2 + '_' + timestamp + '.png')
                document.add_heading(d2 + " Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                                     level=3)
                document.add_picture(pltPath + d2 + '_' + timestamp + '.png')  # Add figure to report
            document.add_heading(d3 + " vs. Test # Groupedby: " + groupCol + ' = ' + str(groupVal), level=2)
            for x in range(1, numDataCols):
                fcp.plot(t3, x='Read Num', y=x,
                         title="Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal), show=showPlt,
                         inline=showPlt, label_y=d3, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d3 + '_' + timestamp + '.png')
                document.add_heading(d3 + " Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                                     level=3)
                document.add_picture(pltPath + d3 + '_' + timestamp + '.png')  # Add figure to report
            document.add_heading(d4 + " vs. Test # Groupedby: " + groupCol + ' = ' + str(groupVal), level=2)
            for x in range(1, numDataCols):
                fcp.plot(t4, x='Read Num', y=x,
                         title="Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal), show=showPlt,
                         inline=showPlt, label_y=d4, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d4 + '_' + timestamp + '.png')
                document.add_heading(d4 + " Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                                     level=3)
                document.add_picture(pltPath + d4 + '_' + timestamp + '.png')  # Add figure to report
            document.add_heading(d5 + " vs. Test # Groupedby: " + groupCol + ' = ' + str(groupVal), level=2)
            for x in range(1, numDataCols):
                fcp.plot(t5, x='Read Num', y=x,
                         title="Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal), show=showPlt,
                         inline=showPlt, label_y=d5, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d5 + '_' + timestamp + '.png')
                document.add_heading(d5 + " Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                                     level=3)
                document.add_picture(pltPath + d5 + '_' + timestamp + '.png')  # Add figure to report
            document.add_heading(d6 + " vs. Test # Groupedby: " + groupCol + ' = ' + str(groupVal), level=2)
            for x in range(1, numDataCols):
                fcp.plot(t6, x='Read Num', y=x,
                         title="Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal), show=showPlt,
                         inline=showPlt, label_y=d6, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d6 + '_' + timestamp + '.png')
                document.add_heading(d6 + " Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                                     level=3)
                document.add_picture(pltPath + d6 + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for dc in t1_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t2_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t3_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t4_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t5_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t6_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        if groupCol == None:
            document.add_heading("groupCol Not Used", level=3)
        elif groupCol != None:
            if groupCol in df.columns:
                document.add_heading("groupCol Found: " + groupCol, level=3)  # Add Groupby found
                if groupVal == None:
                    document.add_heading("groupVal Missing", level=3)
                elif groupVal != None:
                    if groupCol in df[groupCol].unique():
                        document.add_heading("groupVal Found: " + groupVal, level=3)  # Add Groupby found
                    else:
                        document.add_heading("groupVal Not Found: " + groupVal, level=3)  # Add Groupby not found
            else:
                document.add_heading("groupCol Not Found: " + groupCol, level=3)  # Add Groupby not found

def Tempsensor_SM_Data_Stream_Read_vs_Time_Plot(dataFrame, groupCol, groupVal, document, pltPath, showPlt, **kwargs):
    try:
        if groupCol == None and groupVal == None:  # Dont group data frame
            df = dataFrame
        elif groupCol != None and groupVal != None:  # Group data frame by col and value
            df = VRG_Data_Frame.newdataframe(dataFrame, groupCol, groupVal)

        d1 = 'TEMPSENS1_SM_DATA_STREAM_TS Read'
        d2 = 'TEMPSENS1_SM_DATA_STREAM_D1 Read'
        d3 = 'TEMPSENS1_SM_DATA_STREAM_D2 Read'
        d4 = 'TEMPSENS1_SM_DATA_STREAM_SC Read'
        d5 = 'TEMPSENS1_SM_DATA_STREAM_SP Read'
        d6 = 'TEMPSENS1_SM_DATA_STREAM_MSB Read'

        # get data columns
        t1_cols = [x for x in df.columns[df.columns.str.contains(d1)]]
        t2_cols = [x for x in df.columns[df.columns.str.contains(d2)]]
        t3_cols = [x for x in df.columns[df.columns.str.contains(d3)]]
        t4_cols = [x for x in df.columns[df.columns.str.contains(d4)]]
        t5_cols = [x for x in df.columns[df.columns.str.contains(d5)]]
        t6_cols = [x for x in df.columns[df.columns.str.contains(d6)]]

        # subset df
        t1 = df[t1_cols]
        t2 = df[t2_cols]
        t3 = df[t3_cols]
        t4 = df[t4_cols]
        t5 = df[t5_cols]
        t6 = df[t6_cols]

        # rename columns to get read number
        for dc in t1_cols:
            t1 = t1.rename(columns={dc: dc.split(' ')[2]})
        for dc in t2_cols:
            t2 = t2.rename(columns={dc: dc.split(' ')[2]})
        for dc in t3_cols:
            t3 = t3.rename(columns={dc: dc.split(' ')[2]})
        for dc in t4_cols:
            t4 = t4.rename(columns={dc: dc.split(' ')[2]})
        for dc in t5_cols:
            t5 = t5.rename(columns={dc: dc.split(' ')[2]})
        for dc in t6_cols:
            t6 = t6.rename(columns={dc: dc.split(' ')[2]})

        # transpose
        t1 = t1.T
        t2 = t2.T
        t3 = t3.T
        t4 = t4.T
        t5 = t5.T
        t6 = t6.T

        # add an index column
        t1['Read Num'] = t1.index
        t2['Read Num'] = t2.index
        t3['Read Num'] = t3.index
        t4['Read Num'] = t4.index
        t5['Read Num'] = t5.index
        t6['Read Num'] = t6.index

        colList = []
        for index in df.index:
            colList.append(index)

        figTitle = 'Tempsensor_SM_Data_Stream_Read_vs_Time'
        titleFontSize = 12
        yFontsize = 8
        xFontsize = 8
        legFontSize = 6

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupCol == None and groupVal == None:  # No Dataframe grouping
            fcp.plot(t1, x='Read Num', y=colList, title=d1, legend_title="Test #", show=showPlt,
                     inline=showPlt, label_y=d1, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_heading(d1, level=3)
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t2, x='Read Num', y=colList, title=d2, legend_title="Test #", show=showPlt,
                     inline=showPlt, label_y=d2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d2 + '_' + timestamp + '.png')
            document.add_heading(d2, level=3)
            document.add_picture(pltPath + d2 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t3, x='Read Num', y=colList, title=d3, legend_title="Test #", show=showPlt,
                     inline=showPlt, label_y=d3, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d3 + '_' + timestamp + '.png')
            document.add_heading(d3, level=3)
            document.add_picture(pltPath + d3 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t4, x='Read Num', y=colList, title=d4, legend_title="Test #", show=showPlt,
                     inline=showPlt, label_y=d4, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d4 + '_' + timestamp + '.png')
            document.add_heading(d4, level=3)
            document.add_picture(pltPath + d4 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t5, x='Read Num', y=colList, title=d5, legend_title="Test #", show=showPlt,
                     inline=showPlt, label_y=d5, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d5 + '_' + timestamp + '.png')
            document.add_heading(d5, level=3)
            document.add_picture(pltPath + d5 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t6, x='Read Num', y=colList, title=d6, legend_title="Test #", show=showPlt,
                     inline=showPlt, label_y=d6, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d6 + '_' + timestamp + '.png')
            document.add_heading(d6, level=3)
            document.add_picture(pltPath + d6 + '_' + timestamp + '.png')  # Add figure to report
        elif groupCol != None and groupVal != None:  # Data frame grouped by col and val
            fcp.plot(t1, x='Read Num', y=colList, title=d1 + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                     show=showPlt,
                     inline=showPlt, legend_title="Test #", label_y=d1, title_font_size=titleFontSize,
                     label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_heading(d1 + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t2, x='Read Num', y=colList, title=d2 + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                     show=showPlt,
                     inline=showPlt, legend_title="Test #", label_y=d2, title_font_size=titleFontSize,
                     label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d2 + '_' + timestamp + '.png')
            document.add_heading(d2 + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
            document.add_picture(pltPath + d2 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t3, x='Read Num', y=colList, title=d3 + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                     show=showPlt,
                     inline=showPlt, legend_title="Test #", label_y=d3, title_font_size=titleFontSize,
                     label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d3 + '_' + timestamp + '.png')
            document.add_heading(d3 + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
            document.add_picture(pltPath + d3 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t4, x='Read Num', y=colList, title=d4 + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                     show=showPlt,
                     inline=showPlt, legend_title="Test #", label_y=d4, title_font_size=titleFontSize,
                     label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d4 + '_' + timestamp + '.png')
            document.add_heading(d4 + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
            document.add_picture(pltPath + d4 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t5, x='Read Num', y=colList, title=d5 + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                     show=showPlt,
                     inline=showPlt, legend_title="Test #", label_y=d5, title_font_size=titleFontSize,
                     label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d5 + '_' + timestamp + '.png')
            document.add_heading(d5 + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
            document.add_picture(pltPath + d5 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t6, x='Read Num', y=colList, title=d6 + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                     show=showPlt,
                     inline=showPlt, legend_title="Test #", label_y=d6, title_font_size=titleFontSize,
                     label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d6 + '_' + timestamp + '.png')
            document.add_heading(d6 + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
            document.add_picture(pltPath + d6 + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for dc in t1_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t2_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t3_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t4_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t5_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t6_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        if groupCol == None:
            document.add_heading("groupCol Not Used", level=3)
        elif groupCol != None:
            if groupCol in df.columns:
                document.add_heading("groupCol Found: " + groupCol, level=3)  # Add Groupby found
                if groupVal == None:
                    document.add_heading("groupVal Missing", level=3)
                elif groupVal != None:
                    if groupCol in df[groupCol].unique():
                        document.add_heading("groupVal Found: " + groupVal, level=3)  # Add Groupby found
                    else:
                        document.add_heading("groupVal Not Found: " + groupVal, level=3)  # Add Groupby not found
            else:
                document.add_heading("groupCol Not Found: " + groupCol, level=3)  # Add Groupby not found

def Tempsensor_SM_Data_Stream_Read_Average_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'TEMPSENS1_SM_DATA_STREAM_TS Read'
        d2 = 'TEMPSENS1_SM_DATA_STREAM_D1 Read'
        d3 = 'TEMPSENS1_SM_DATA_STREAM_D2 Read'
        d4 = 'TEMPSENS1_SM_DATA_STREAM_SC Read'
        d5 = 'TEMPSENS1_SM_DATA_STREAM_SP Read'
        d6 = 'TEMPSENS1_SM_DATA_STREAM_MSB Read'

        # get data columns
        df = dataFrame
        t1_cols = [x for x in df.columns[df.columns.str.contains(d1)]]
        t2_cols = [x for x in df.columns[df.columns.str.contains(d2)]]
        t3_cols = [x for x in df.columns[df.columns.str.contains(d3)]]
        t4_cols = [x for x in df.columns[df.columns.str.contains(d4)]]
        t5_cols = [x for x in df.columns[df.columns.str.contains(d5)]]
        t6_cols = [x for x in df.columns[df.columns.str.contains(d6)]]
        
        dt1 = d1.split(' ')[0]
        dt2 = d2.split(' ')[0]
        dt3 = d3.split(' ')[0]
        dt4 = d4.split(' ')[0]
        dt5 = d5.split(' ')[0]
        dt6 = d6.split(' ')[0]
        
        t1 = dt1 + '_AVG'
        t2 = dt2 + '_AVG'
        t3 = dt3 + '_AVG'
        t4 = dt4 + '_AVG'
        t5 = dt5 + '_AVG'
        t6 = dt6 + '_AVG'

        df[t1] = df[t1_cols].mean(axis=1)
        df[t2] = df[t2_cols].mean(axis=1)
        df[t3] = df[t3_cols].mean(axis=1)
        df[t4] = df[t4_cols].mean(axis=1)
        df[t5] = df[t5_cols].mean(axis=1)
        df[t6] = df[t6_cols].mean(axis=1)

        figTitle = 'Tempsensor_SM_Data_Stream_Read_Average'
        ylabel = 'RegVal (Dec)'
        numDataCols = 7  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 10
        xFontsize = 10
        legFontSize = 6

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):
                fcp.plot(df, x='Step', y=eval("t" + str(x)), title=eval("t" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("t" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("t" + str(x)), level=3)
                document.add_picture(pltPath + eval("t" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):
                fcp.plot(df, x='Step', y=eval("t" + str(x)), title=eval("t" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("t" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("t" + str(x)), level=3)
                document.add_picture(pltPath + eval("t" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for dc in t1_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t2_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t3_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t4_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t5_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t6_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found


'''
Tempsensor SM Data Stream Data
'''
def Tempsensor_SM_Data_Standby_Read_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'TEMPSENS1_SM_DATA_STNDBY_TS'
        d2 = 'TEMPSENS1_SM_DATA_STNDBY_D1'
        d3 = 'TEMPSENS1_SM_DATA_STNDBY_D2'
        d4 = 'TEMPSENS1_SM_DATA_STNDBY_SC'
        d5 = 'TEMPSENS1_SM_DATA_STNDBY_SP'
        d6 = 'TEMPSENS1_SM_DATA_STNDBY_MSB'

        figTitle = 'Tempsensor_SM_Data_Standby_Data'
        ylabel = 'RegVal (Dec)'
        numDataCols = 6  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 10
        xFontsize = 10
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Tempsensor_SM_Data_Standby_Read_vs_TestNo_Plot(dataFrame, groupCol, groupVal, document, pltPath, showPlt, **kwargs):
    try:
        if groupCol == None and groupVal == None:  # Dont group data frame
            df = dataFrame
        elif groupCol != None and groupVal != None:  # Group data frame by col and value
            df = VRG_Data_Frame.newdataframe(dataFrame, groupCol, groupVal)

        d1 = 'TEMPSENS1_SM_DATA_STNDBY_TS Read'
        d2 = 'TEMPSENS1_SM_DATA_STNDBY_D1 Read'
        d3 = 'TEMPSENS1_SM_DATA_STNDBY_D2 Read'
        d4 = 'TEMPSENS1_SM_DATA_STNDBY_SC Read'
        d5 = 'TEMPSENS1_SM_DATA_STNDBY_SP Read'
        d6 = 'TEMPSENS1_SM_DATA_STNDBY_MSB Read'

        # get data columns
        t1_cols = [x for x in df.columns[df.columns.str.contains(d1)]]
        t2_cols = [x for x in df.columns[df.columns.str.contains(d2)]]
        t3_cols = [x for x in df.columns[df.columns.str.contains(d3)]]
        t4_cols = [x for x in df.columns[df.columns.str.contains(d4)]]
        t5_cols = [x for x in df.columns[df.columns.str.contains(d5)]]
        t6_cols = [x for x in df.columns[df.columns.str.contains(d6)]]

        # subset df
        t1 = df[t1_cols]
        t2 = df[t2_cols]
        t3 = df[t3_cols]
        t4 = df[t4_cols]
        t5 = df[t5_cols]
        t6 = df[t6_cols]

        # rename columns to get read number
        for dc in t1_cols:
            t1 = t1.rename(columns={dc: dc.split(' ')[2]})
        for dc in t2_cols:
            t2 = t2.rename(columns={dc: dc.split(' ')[2]})
        for dc in t3_cols:
            t3 = t3.rename(columns={dc: dc.split(' ')[2]})
        for dc in t4_cols:
            t4 = t4.rename(columns={dc: dc.split(' ')[2]})
        for dc in t5_cols:
            t5 = t5.rename(columns={dc: dc.split(' ')[2]})
        for dc in t6_cols:
            t6 = t6.rename(columns={dc: dc.split(' ')[2]})

        # transpose
        t1 = t1.T
        t2 = t2.T
        t3 = t3.T
        t4 = t4.T
        t5 = t5.T
        t6 = t6.T

        # add an index column
        t1['Read Num'] = t1.index
        t2['Read Num'] = t2.index
        t3['Read Num'] = t3.index
        t4['Read Num'] = t4.index
        t5['Read Num'] = t5.index
        t6['Read Num'] = t6.index

        figTitle = 'Tempsensor_SM_Data_Standby_Read_vs_TestNo'
        numDataCols = len(df.index)  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 12
        yFontsize = 8
        xFontsize = 8
        legFontSize = 6

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupCol == None and groupVal == None:  # No Dataframe grouping
            document.add_heading(d1 + " vs. Test #", level=2)
            for x in range(1, numDataCols):
                fcp.plot(t1, x='Read Num', y=x, title="Test #" + str(x), show=showPlt,
                         inline=showPlt, label_y=d1, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
                document.add_heading(d1 + " Test #" + str(x), level=3)
                document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
            document.add_heading(d2 + " vs. Test #", level=2)
            for x in range(1, numDataCols):
                fcp.plot(t2, x='Read Num', y=x, title="Test #" + str(x), show=showPlt,
                         inline=showPlt, label_y=d2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d2 + '_' + timestamp + '.png')
                document.add_heading(d2 + " Test #" + str(x), level=3)
                document.add_picture(pltPath + d2 + '_' + timestamp + '.png')  # Add figure to report
            document.add_heading(d3 + " vs. Test #", level=2)
            for x in range(1, numDataCols):
                fcp.plot(t3, x='Read Num', y=x, title="Test #" + str(x), show=showPlt,
                         inline=showPlt, label_y=d3, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d3 + '_' + timestamp + '.png')
                document.add_heading(d3 + " Test #" + str(x), level=3)
                document.add_picture(pltPath + d3 + '_' + timestamp + '.png')  # Add figure to report
            document.add_heading(d4 + " vs. Test #", level=2)
            for x in range(1, numDataCols):
                fcp.plot(t4, x='Read Num', y=x, title="Test #" + str(x), show=showPlt,
                         inline=showPlt, label_y=d4, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d4 + '_' + timestamp + '.png')
                document.add_heading(d4 + " Test #" + str(x), level=3)
                document.add_picture(pltPath + d4 + '_' + timestamp + '.png')  # Add figure to report
            document.add_heading(d5 + " vs. Test #", level=2)
            for x in range(1, numDataCols):
                fcp.plot(t5, x='Read Num', y=x, title="Test #" + str(x), show=showPlt,
                         inline=showPlt, label_y=d5, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d5 + '_' + timestamp + '.png')
                document.add_heading(d5 + " Test #" + str(x), level=3)
                document.add_picture(pltPath + d5 + '_' + timestamp + '.png')  # Add figure to report
            document.add_heading(d6 + " vs. Test #", level=2)
            for x in range(1, numDataCols):
                fcp.plot(t6, x='Read Num', y=x, title="Test #" + str(x), show=showPlt,
                         inline=showPlt, label_y=d6, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d6 + '_' + timestamp + '.png')
                document.add_heading(d6 + " Test #" + str(x), level=3)
                document.add_picture(pltPath + d6 + '_' + timestamp + '.png')  # Add figure to report
        elif groupCol != None and groupVal != None:  # Data frame grouped by col and val
            document.add_heading(d1 + " vs. Test # Groupedby: " + groupCol + ' = ' + str(groupVal), level=2)
            for x in range(1, numDataCols):
                fcp.plot(t1, x='Read Num', y=x,
                         title="Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal), show=showPlt,
                         inline=showPlt, label_y=d1, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
                document.add_heading(d1 + " Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                                     level=3)
                document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
            document.add_heading(d2 + " vs. Test # Groupedby: " + groupCol + ' = ' + str(groupVal), level=2)
            for x in range(1, numDataCols):
                fcp.plot(t2, x='Read Num', y=x,
                         title="Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal), show=showPlt,
                         inline=showPlt, label_y=d2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d2 + '_' + timestamp + '.png')
                document.add_heading(d2 + " Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                                     level=3)
                document.add_picture(pltPath + d2 + '_' + timestamp + '.png')  # Add figure to report
            document.add_heading(d3 + " vs. Test # Groupedby: " + groupCol + ' = ' + str(groupVal), level=2)
            for x in range(1, numDataCols):
                fcp.plot(t3, x='Read Num', y=x,
                         title="Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal), show=showPlt,
                         inline=showPlt, label_y=d3, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d3 + '_' + timestamp + '.png')
                document.add_heading(d3 + " Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                                     level=3)
                document.add_picture(pltPath + d3 + '_' + timestamp + '.png')  # Add figure to report
            document.add_heading(d4 + " vs. Test # Groupedby: " + groupCol + ' = ' + str(groupVal), level=2)
            for x in range(1, numDataCols):
                fcp.plot(t4, x='Read Num', y=x,
                         title="Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal), show=showPlt,
                         inline=showPlt, label_y=d4, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d4 + '_' + timestamp + '.png')
                document.add_heading(d4 + " Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                                     level=3)
                document.add_picture(pltPath + d4 + '_' + timestamp + '.png')  # Add figure to report
            document.add_heading(d5 + " vs. Test # Groupedby: " + groupCol + ' = ' + str(groupVal), level=2)
            for x in range(1, numDataCols):
                fcp.plot(t5, x='Read Num', y=x,
                         title="Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal), show=showPlt,
                         inline=showPlt, label_y=d5, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d5 + '_' + timestamp + '.png')
                document.add_heading(d5 + " Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                                     level=3)
                document.add_picture(pltPath + d5 + '_' + timestamp + '.png')  # Add figure to report
            document.add_heading(d6 + " vs. Test # Groupedby: " + groupCol + ' = ' + str(groupVal), level=2)
            for x in range(1, numDataCols):
                fcp.plot(t6, x='Read Num', y=x,
                         title="Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal), show=showPlt,
                         inline=showPlt, label_y=d6, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + d6 + '_' + timestamp + '.png')
                document.add_heading(d6 + " Test #" + str(x) + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                                     level=3)
                document.add_picture(pltPath + d6 + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for dc in t1_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t2_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t3_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t4_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t5_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t6_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        if groupCol == None:
            document.add_heading("groupCol Not Used", level=3)
        elif groupCol != None:
            if groupCol in df.columns:
                document.add_heading("groupCol Found: " + groupCol, level=3)  # Add Groupby found
                if groupVal == None:
                    document.add_heading("groupVal Missing", level=3)
                elif groupVal != None:
                    if groupCol in df[groupCol].unique():
                        document.add_heading("groupVal Found: " + groupVal, level=3)  # Add Groupby found
                    else:
                        document.add_heading("groupVal Not Found: " + groupVal, level=3)  # Add Groupby not found
            else:
                document.add_heading("groupCol Not Found: " + groupCol, level=3)  # Add Groupby not found

def Tempsensor_SM_Data_Standby_Read_vs_Time_Plot(dataFrame, groupCol, groupVal, document, pltPath, showPlt, **kwargs):
    try:
        if groupCol == None and groupVal == None:  # Dont group data frame
            df = dataFrame
        elif groupCol != None and groupVal != None:  # Group data frame by col and value
            df = VRG_Data_Frame.newdataframe(dataFrame, groupCol, groupVal)

        d1 = 'TEMPSENS1_SM_DATA_STNDBY_TS Read'
        d2 = 'TEMPSENS1_SM_DATA_STNDBY_D1 Read'
        d3 = 'TEMPSENS1_SM_DATA_STNDBY_D2 Read'
        d4 = 'TEMPSENS1_SM_DATA_STNDBY_SC Read'
        d5 = 'TEMPSENS1_SM_DATA_STNDBY_SP Read'
        d6 = 'TEMPSENS1_SM_DATA_STNDBY_MSB Read'

        # get data columns
        t1_cols = [x for x in df.columns[df.columns.str.contains(d1)]]
        t2_cols = [x for x in df.columns[df.columns.str.contains(d2)]]
        t3_cols = [x for x in df.columns[df.columns.str.contains(d3)]]
        t4_cols = [x for x in df.columns[df.columns.str.contains(d4)]]
        t5_cols = [x for x in df.columns[df.columns.str.contains(d5)]]
        t6_cols = [x for x in df.columns[df.columns.str.contains(d6)]]

        # subset df
        t1 = df[t1_cols]
        t2 = df[t2_cols]
        t3 = df[t3_cols]
        t4 = df[t4_cols]
        t5 = df[t5_cols]
        t6 = df[t6_cols]

        # rename columns to get read number
        for dc in t1_cols:
            t1 = t1.rename(columns={dc: dc.split(' ')[2]})
        for dc in t2_cols:
            t2 = t2.rename(columns={dc: dc.split(' ')[2]})
        for dc in t3_cols:
            t3 = t3.rename(columns={dc: dc.split(' ')[2]})
        for dc in t4_cols:
            t4 = t4.rename(columns={dc: dc.split(' ')[2]})
        for dc in t5_cols:
            t5 = t5.rename(columns={dc: dc.split(' ')[2]})
        for dc in t6_cols:
            t6 = t6.rename(columns={dc: dc.split(' ')[2]})

        # transpose
        t1 = t1.T
        t2 = t2.T
        t3 = t3.T
        t4 = t4.T
        t5 = t5.T
        t6 = t6.T

        # add an index column
        t1['Read Num'] = t1.index
        t2['Read Num'] = t2.index
        t3['Read Num'] = t3.index
        t4['Read Num'] = t4.index
        t5['Read Num'] = t5.index
        t6['Read Num'] = t6.index

        colList = []
        for index in df.index:
            colList.append(index)

        figTitle = 'Tempsensor_SM_Data_Standby_Read_vs_Time'
        titleFontSize = 12
        yFontsize = 8
        xFontsize = 8
        legFontSize = 6

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupCol == None and groupVal == None:  # No Dataframe grouping
            fcp.plot(t1, x='Read Num', y=colList, title=d1, legend_title="Test #", show=showPlt,
                     inline=showPlt, label_y=d1, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_heading(d1, level=3)
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t2, x='Read Num', y=colList, title=d2, legend_title="Test #", show=showPlt,
                     inline=showPlt, label_y=d2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d2 + '_' + timestamp + '.png')
            document.add_heading(d2, level=3)
            document.add_picture(pltPath + d2 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t3, x='Read Num', y=colList, title=d3, legend_title="Test #", show=showPlt,
                     inline=showPlt, label_y=d3, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d3 + '_' + timestamp + '.png')
            document.add_heading(d3, level=3)
            document.add_picture(pltPath + d3 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t4, x='Read Num', y=colList, title=d4, legend_title="Test #", show=showPlt,
                     inline=showPlt, label_y=d4, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d4 + '_' + timestamp + '.png')
            document.add_heading(d4, level=3)
            document.add_picture(pltPath + d4 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t5, x='Read Num', y=colList, title=d5, legend_title="Test #", show=showPlt,
                     inline=showPlt, label_y=d5, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d5 + '_' + timestamp + '.png')
            document.add_heading(d5, level=3)
            document.add_picture(pltPath + d5 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t6, x='Read Num', y=colList, title=d6, legend_title="Test #", show=showPlt,
                     inline=showPlt, label_y=d6, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d6 + '_' + timestamp + '.png')
            document.add_heading(d6, level=3)
            document.add_picture(pltPath + d6 + '_' + timestamp + '.png')  # Add figure to report
        elif groupCol != None and groupVal != None:  # Data frame grouped by col and val
            fcp.plot(t1, x='Read Num', y=colList, title=d1 + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                     show=showPlt,
                     inline=showPlt, legend_title="Test #", label_y=d1, title_font_size=titleFontSize,
                     label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_heading(d1 + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t2, x='Read Num', y=colList, title=d2 + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                     show=showPlt,
                     inline=showPlt, legend_title="Test #", label_y=d2, title_font_size=titleFontSize,
                     label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d2 + '_' + timestamp + '.png')
            document.add_heading(d2 + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
            document.add_picture(pltPath + d2 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t3, x='Read Num', y=colList, title=d3 + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                     show=showPlt,
                     inline=showPlt, legend_title="Test #", label_y=d3, title_font_size=titleFontSize,
                     label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d3 + '_' + timestamp + '.png')
            document.add_heading(d3 + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
            document.add_picture(pltPath + d3 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t4, x='Read Num', y=colList, title=d4 + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                     show=showPlt,
                     inline=showPlt, legend_title="Test #", label_y=d4, title_font_size=titleFontSize,
                     label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d4 + '_' + timestamp + '.png')
            document.add_heading(d4 + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
            document.add_picture(pltPath + d4 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t5, x='Read Num', y=colList, title=d5 + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                     show=showPlt,
                     inline=showPlt, legend_title="Test #", label_y=d5, title_font_size=titleFontSize,
                     label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d5 + '_' + timestamp + '.png')
            document.add_heading(d5 + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
            document.add_picture(pltPath + d5 + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(t6, x='Read Num', y=colList, title=d6 + " Groupedby: " + groupCol + ' = ' + str(groupVal),
                     show=showPlt,
                     inline=showPlt, legend_title="Test #", label_y=d6, title_font_size=titleFontSize,
                     label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d6 + '_' + timestamp + '.png')
            document.add_heading(d6 + " Groupedby: " + groupCol + ' = ' + str(groupVal), level=3)
            document.add_picture(pltPath + d6 + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for dc in t1_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t2_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t3_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t4_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t5_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t6_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        if groupCol == None:
            document.add_heading("groupCol Not Used", level=3)
        elif groupCol != None:
            if groupCol in df.columns:
                document.add_heading("groupCol Found: " + groupCol, level=3)  # Add Groupby found
                if groupVal == None:
                    document.add_heading("groupVal Missing", level=3)
                elif groupVal != None:
                    if groupCol in df[groupCol].unique():
                        document.add_heading("groupVal Found: " + groupVal, level=3)  # Add Groupby found
                    else:
                        document.add_heading("groupVal Not Found: " + groupVal, level=3)  # Add Groupby not found
            else:
                document.add_heading("groupCol Not Found: " + groupCol, level=3)  # Add Groupby not found

def Tempsensor_SM_Data_Standby_Read_Average_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'TEMPSENS1_SM_DATA_STNDBY_TS Read'
        d2 = 'TEMPSENS1_SM_DATA_STNDBY_D1 Read'
        d3 = 'TEMPSENS1_SM_DATA_STNDBY_D2 Read'
        d4 = 'TEMPSENS1_SM_DATA_STNDBY_SC Read'
        d5 = 'TEMPSENS1_SM_DATA_STNDBY_SP Read'
        d6 = 'TEMPSENS1_SM_DATA_STNDBY_MSB Read'

        # get data columns
        df = dataFrame
        t1_cols = [x for x in df.columns[df.columns.str.contains(d1)]]
        t2_cols = [x for x in df.columns[df.columns.str.contains(d2)]]
        t3_cols = [x for x in df.columns[df.columns.str.contains(d3)]]
        t4_cols = [x for x in df.columns[df.columns.str.contains(d4)]]
        t5_cols = [x for x in df.columns[df.columns.str.contains(d5)]]
        t6_cols = [x for x in df.columns[df.columns.str.contains(d6)]]

        dt1 = d1.split(' ')[0]
        dt2 = d2.split(' ')[0]
        dt3 = d3.split(' ')[0]
        dt4 = d4.split(' ')[0]
        dt5 = d5.split(' ')[0]
        dt6 = d6.split(' ')[0]

        t1 = dt1 + '_AVG'
        t2 = dt2 + '_AVG'
        t3 = dt3 + '_AVG'
        t4 = dt4 + '_AVG'
        t5 = dt5 + '_AVG'
        t6 = dt6 + '_AVG'

        df[t1] = df[t1_cols].mean(axis=1)
        df[t2] = df[t2_cols].mean(axis=1)
        df[t3] = df[t3_cols].mean(axis=1)
        df[t4] = df[t4_cols].mean(axis=1)
        df[t5] = df[t5_cols].mean(axis=1)
        df[t6] = df[t6_cols].mean(axis=1)

        figTitle = 'Tempsensor_SM_Data_Standby_Read_Average'
        ylabel = 'RegVal (Dec)'
        numDataCols = 7  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 10
        xFontsize = 10
        legFontSize = 6

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):
                fcp.plot(df, x='Step', y=eval("t" + str(x)), title=eval("t" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("t" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("t" + str(x)), level=3)
                document.add_picture(pltPath + eval("t" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):
                fcp.plot(df, x='Step', y=eval("t" + str(x)), title=eval("t" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("t" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("t" + str(x)), level=3)
                document.add_picture(pltPath + eval("t" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for dc in t1_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t2_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t3_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t4_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t5_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        for dc in t6_cols:
            if dc in df.columns:
                document.add_heading("Column Found: " + dc, level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + dc, level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found


'''
Thermal Impedance Data
'''
def Thermal_Impedance_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        df = dataFrame

        # Column Names in CSV
        d1 = 'TEMPSENS1_DATA_K_REG_Celsius Read'
        dp1 = 'P_TOTAL(mW)'

        # get data columns
        t1_cols = [x for x in df.columns[df.columns.str.contains(d1)]]
        dt1 = d1.split(' ')[0]

        t1 = dt1 + '_AVG' # Calcuated Average Temperature in Celsius
        t2 = 'TemperatureSetPoint' # Ambient
        t3 = 'P_TOTAL(mW)'
        t4 = 'Thermal_Impedance'  # Calculated Temperature Coefficient column names

        df[t1] = df[t1_cols].mean(axis=1) # Calculate the Average
        df[t4] = ((df[t1] - df[t2]) / df[dp1]) # Thermal Impedance = (Tj - Ta)/ Power dissipation

        figTitle = 'Thermal_Impedance'
        ylabel = 'Junction Temp Celsius (C)'
        ylabel2 = 'Ambient Temp Celsius (C)'
        ylabel3 = 'Total Power Dissipation (mW)'
        ylabel4 = 'Thermal Impedance (C/mW)'
        numDataCols = 5 # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):
                if x == 1:  # Junction Temp
                    fcp.plot(df, x='Step', y=eval("t" + str(x)), title=eval("t" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("t" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("t" + str(x)), level=3)
                    document.add_picture(pltPath + eval("t" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
                elif x == 2:  # Ambient Temp
                    fcp.plot(df, x='Step', y=eval("t" + str(x)), title=eval("t" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("t" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("t" + str(x)), level=3)
                    document.add_picture(pltPath + eval("t" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
                elif x == 3:  # Power Dissipation
                    fcp.plot(df, x='Step', y=eval("t" + str(x)), title=eval("t" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel3, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("t" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("t" + str(x)), level=3)
                    document.add_picture(pltPath + eval("t" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
                elif x == 4:  # Thermal Impedance
                    fcp.plot(df, x='Step', y=eval("t" + str(x)), title=eval("t" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel4, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("t" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("t" + str(x)), level=3)
                    document.add_picture(pltPath + eval("t" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):
                if x == 1:  # Junction Temp
                    fcp.plot(df, x='Step', y=eval("t" + str(x)), title=eval("t" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("t" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("t" + str(x)), level=3)
                    document.add_picture(pltPath + eval("t" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
                elif x == 2:  # Ambient Temp
                    fcp.plot(df, x='Step', y=eval("t" + str(x)), title=eval("t" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("t" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("t" + str(x)), level=3)
                    document.add_picture(pltPath + eval("t" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
                elif x == 3:  # Power Dissipation
                    fcp.plot(df, x='Step', y=eval("t" + str(x)), title=eval("t" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel3, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("t" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("t" + str(x)), level=3)
                    document.add_picture(pltPath + eval("t" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
                elif x == 4:  # Thermal Impedance
                    fcp.plot(df, x='Step', y=eval("t" + str(x)), title=eval("t" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel4, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("t" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("t" + str(x)), level=3)
                    document.add_picture(pltPath + eval("t" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("t" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("t" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("t" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found