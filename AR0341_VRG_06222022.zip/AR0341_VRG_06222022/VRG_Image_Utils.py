#!/usr/bin/env python
# needs python3
#
# AR0820 DTR CRC and Frame CRC calculator.

import re
import struct
import os
from PIL import Image
from PIL import ImageFont
from PIL import ImageDraw
from docx.shared import Inches

# for debug
g_verbose = 0

##########################################################################
# CRC_FLEXRAY_24 calculation
#
# width: 24
# polynomial:   0x5D6DCB
# initial data: 0xABCDEF
#
##########################################################################

# by applying the loop structure from the FlexRay spec
def new_flex_bit(old_crc, bit_to_add):
    new_crc = old_crc
    xor_flag = bit_to_add ^ (1 & (new_crc >> 23))
    new_crc = new_crc << 1
    if xor_flag:
        new_crc = new_crc ^ 0x5d6dcb
    return 0xffffff & new_crc

def new_flex(old_crc, add_this_value):
    global g_verbose
    new_crc = old_crc
    for bit in range(23,-1,-1):
        new_crc = new_flex_bit(new_crc, 1 & (add_this_value >> bit))
    if g_verbose:
        print("in new_flex old crc: 0x%06x data applied: 0x%06x new crc: 0x%06x" % (old_crc, add_this_value, new_crc))
    return new_crc

##########################################################################
# Frame CRC

def init_frame_crc(val):
    global g_fr_crc
    g_fr_crc = val
    return g_fr_crc

def append_fr_crc(val):
    global g_fr_crc
    g_fr_crc = new_flex(g_fr_crc, val)
    return g_fr_crc

def current_fr_crc():
    global g_fr_crc
    return g_fr_crc

##########################################################################
# Compute CRC from RTL simulation .pix file
#
# This provides restricted capability:
# - assumes only embedded, DTR and active regions present
# - only reports on the 1st frame in the .pix file
# - assumes DTR size of 8 rows (normal)

# given a list of bytes, din, return a list repacked as pixels
# in accordance with the MIPI packing rules.
# bits_per_pixel determines the packing rule. Each pixel is then
# right-shifted by final_rightshift to discard low-order bits.
def byte_to_pix(din, bits_per_pixel, final_rightshift):
    dout = []
    while din:
        if bits_per_pixel == 12:
            # 3 bytes to make 2 pixels
            word1=din.pop(0) << 4
            word2=din.pop(0) << 4
            runt=din.pop(0)
            word1=word1 | (runt & 0x0f)
            word2=word2 | ((runt & 0xf0) >> 4)
            dout.extend([word1>>final_rightshift, word2>>final_rightshift])
        if bits_per_pixel == 16:
            # the easy one - 2 bytes to make 1 pixel
            word1=din.pop(0) << 8
            word1=word1 | din.pop(0)
            dout.append(word1>>final_rightshift)
        elif bits_per_pixel == 20:
            # 5 bytes to make 2 pixels
            word1=din.pop(0) << 12
            word1=word1 | (din.pop(0) << 2)
            word2=din.pop(0) << 12
            word2=word2 | (din.pop(0) << 2)
            runt=din.pop(0)
            word1=word1 | ((runt & 0x03) << 10) # take runt bits LS first
            word1=word1 | ((runt & 0x0c) >> 2)
            word2=word2 | ((runt & 0x30) << 6)
            word2=word2 | ((runt & 0xc0) >> 6)
            dout.extend([word1>>final_rightshift, word2>>final_rightshift])
        elif bits_per_pixel == 24:
            # 3 bytes to make 1 pixel
            word1=din.pop(0) << (12+4)
            word1=word1 | (din.pop(0) << 4)
            runt=din.pop(0)
            word1=word1 | ((runt & 0x0f) << 8 ) | ((runt & 0xf0) >> 4)
            dout.append(word1>>final_rightshift)
    return dout

def compute_frame_crc_from_pix(filename, bits_per_pixel):
    PFILE = open(filename, "r")
    region=0 # 0=look for header 1=embedded 2=dtr 3=active
    count=0  # which row in this region
    pixels=0 # pixels per row
    shift=0  # packing rule

    addr_embed = 0
    tag_embed = 0
    embed_state = 0 # 0=expect SOL 1=expect tag 2=expect data
    embedded = {}

    if bits_per_pixel == 12:
        shift=0
    elif bits_per_pixel == 16:
        shift=8
    elif bits_per_pixel == 20:
        shift=10
    elif bits_per_pixel == 24:
        shift=12
    else:
        print("ERROR no support for %d bits-per-pixel" % bits_per_pixel)
        return

    for aline in PFILE:
        nxt_region=region # default
        if re.match('^External start', aline):
            if region==0:
                # first frame and this is what we expected to happen
                pass
            else:
                # end of earlier frame, start of a new one.
                print("\nThis is frame 0x%02x%02x from %s" % (embedded[0x2002], embedded[0x2003], filename))
                print("Previous frame's   DTR CRC is 0x%02x%02x%02x" % (embedded[0x335c], embedded[0x3358], embedded[0x3359]))
                print("Previous frame's Frame CRC is 0x%02x%02x%02x" % (embedded[0x335d], embedded[0x332e], embedded[0x332f]))
                print("Final DTR   CRC is 0x%06x" % dtr_crc)
                print("Final FRAME CRC is 0x%06x" % fr_crc)
                print("Image had %d active rows and %d columns\n" % (count, pixels))

            # initial CRC values -- Channel B initialiser
            dtr_crc = 0xabcdef
            fr_crc = 0xabcdef

            nxt_region=1
            count=0

        elif region==0:
            print("ERROR expected start of frame but found: %s" % aline)
            return
        elif region==1:
            # embedded row. Parse the data and populate dictionary "embedded" with
            # byte_address/byte_value pairs

            row_data =[int(n, base=16) for n in aline.split()]
            pix = byte_to_pix(row_data, bits_per_pixel, bits_per_pixel-8)
            for this_pix in pix:
                #print("process row %d value 0x%x with embed_state %d tag_embed=0x%x" % (count, this_pix, embed_state, tag_embed))
                if embed_state == 0:
                    if this_pix == 0xa:
                        embed_state = 1
                    elif this_pix == 0x7:
                        pass
                    else:
                        print("ERROR expected SOL tag 0xa, found 0x%x" % this_pix);
                elif embed_state == 1:
                    tag_embed = this_pix
                    if tag_embed == 0x7:
                        embed_state = 0 # EOD so look for SOL
                    else:
                        embed_state = 2
                else:
                    # value - action depends on previous tag
                    embed_state = 1 # expect tag next
                    if tag_embed == 0xaa: # ADDR HI
                        addr_embed = this_pix << 8
                    elif tag_embed == 0xa5: # ADDR LO
                        addr_embed = (addr_embed & 0xff00) | this_pix
                    elif tag_embed == 0x5a: # DATA
                        #print("Store value for address 0x%04x" % addr_embed)
                        embedded[addr_embed] = this_pix
                        addr_embed = addr_embed + 1
                    else:
                        print("ERROR got value for tag 0x%x" % this_pix);

            count=count+1
            if count==2:
                nxt_region=2
                count=0
        elif region==2:
            count=count+1
            # Check line format, convert to pixels and apply to frame CRC
            # Each line starts 01234500 which is skipped, followed by a sequence of hex values.
            # For the DTR, the values are bytes and the pixel stream has to be recreated in
            # a fiddly way. Having done this, apply each to
            # the CRC generator, while tracking the line width.
            row_data =[int(n, base=16) for n in aline.split()]
            if row_data[0] != 0x1234500:
                print("ERROR expected DTR line marked with 01234500 but found: %s" % aline)
                return
            row_data.pop(0)
            pix = byte_to_pix(row_data, bits_per_pixel, 0)
            pixels_this_line=0
            for this_pix in pix:
                dtr_crc = new_flex(dtr_crc, this_pix)
                pixels_this_line = pixels_this_line + 1

            #print("found %d pixels on row %d" % (pixels_this_line, count))
            if pixels==0:
                pixels=pixels_this_line
            elif pixels!=pixels_this_line:
                print("ERROR expected %d pixels but found %d on DTR row %d" % (pixels, pixels_this_line, count))

            if count==8:
                nxt_region=3
                count=0
        elif region==3:
                count=count+1
                # Check line format, convert to pixels and apply to frame CRC
                # Each line does NOT start with 01234500 but simply a sequence of hex values
                # take the hex values in pairs to create pixel values and apply each to
                # the CRC generator, while tracking the line width.
                num =[int(n, base=16) for n in aline.split()]
                if num[0] == 0x1234500:
                    print("ERROR expected active image but found: %s" % aline)
                pixels_this_line=0
                while (num):
                    word=num.pop(0) << shift
                    if shift != 0:
                        # 0 => 1 byte/pixel; for all other values, 2 bytes/pixel
                        word=word | num.pop(0)
                    fr_crc=new_flex(fr_crc, word)
                    pixels_this_line=pixels_this_line+1
                #print("found %d pixels on row %d" % (pixels_this_line, count))
                if pixels==0:
                    pixels=pixels_this_line
                elif pixels!=pixels_this_line:
                    print("ERROR expected %d pixels but found %d on Active row %d" % (pixels, pixels_this_line, count))

        region=nxt_region


    print("File was %s\n\n" % filename)
    PFILE.close()

##########################################################################
# Compute CRC from DevWare .raw file
#
# In DevWare, need to set Data Interpretation->Decompress to
# "Not compressed, or don't decompress".
#
# This example is set up for 3exposure 20-bit, companded to 12 bits,
# output as 12-bit data. In the .raw file each 12-bit value is presented
# as 2 bytes with little-endian ordering.
#
def compute_frame_crc_from_raw(filename):
    # these should not be hard-coded.. they should be extracted from
    # the info file.
    # Assumes embedded, dtr and active regions ONLY. The active region
    # is what's left after the embed and DTR regions. This also works
    # with black rows shown becasue they ajoin the active region and
    # are treated in the same way as the active region.
    image_width = 3848
    image_embed = 4
    image_dtr = 8

    # initial CRC values -- Channel B initialiser
    dtr_crc = 0xabcdef
    fr_crc = 0xabcdef

    PFILE = open(filename, "rb")
    posx = 0
    posy = 0

    addr_embed = 0
    tag_embed = 0
    embed_state = 0 # 0=expect SOL 1=expect tag 2=expect data
    embedded = {}

    for xx in struct.iter_unpack('<H',PFILE.read()):     # when it's 16-bit per pixel
        chunk = xx[0]

        # process chunk for current x/y position
        # posx goes from 0..image_width-1
        # posy goes from 0..image_height-1

        if posy in range (0,image_embed):
            # embedded row. Parse the data and populate dictionary "embedded" with
            # byte_address/byte_value pairs
            chunk = chunk >> 4
            if embed_state == 0:
                if chunk == 0xa:
                    embed_state = 1
                elif chunk == 0x7:
                    pass
                else:
                    print("ERROR row %d col %d expected SOL tag 0xa, found 0x%x" % (posy, posx, chunk));
            elif embed_state == 1:
                tag_embed = chunk
                if tag_embed == 0x7:
                    embed_state = 0 # EOD so look for SOL
                else:
                    embed_state = 2
            else:
                # value - action depends on previous tag
                embed_state = 1 # expect tag next
                if tag_embed == 0xaa: # ADDR HI
                    addr_embed = chunk << 8
                elif tag_embed == 0xa5: # ADDR LO
                    addr_embed = (addr_embed & 0xff00) | chunk
                elif tag_embed == 0x5a: # DATA
                    #print("Store value for address 0x%04x" % addr_embed)
                    embedded[addr_embed] = chunk
                    addr_embed = addr_embed + 1
                else:
                    print("ERROR row %d col %d got value for tag 0x%x" % (posy, posx, chunk));


        elif posy in range (image_embed-1,image_embed+image_dtr):
            #print("DTR Row %d Col %d value 0x%x" % (posy, posx, chunk))
            dtr_crc = new_flex(dtr_crc, chunk)
        else:
            fr_crc = new_flex(fr_crc, chunk)

        posx = posx + 1
        if posx == image_width:
            posx = 0
            posy = posy + 1
            if (posy % 100) == 0:
                print("Line %d.." % posy, end='', flush=True)


    PFILE.close()
    # at this point posy should have counted the final line
    # and there should be no left-over bytes
    # so, expect posy==image_height, posx==0
    print("\nThis is frame 0x%02x%02x" % (embedded[0x2002], embedded[0x2003]))
    print("Previous frame's   DTR CRC is 0x%02x%02x%02x" % (embedded[0x335c], embedded[0x3358], embedded[0x3359]))
    print("Previous frame's Frame CRC is 0x%02x%02x%02x" % (embedded[0x335d], embedded[0x332e], embedded[0x332f]))

    print("Found %d lines (runt=%d)" % (posy, posx))
    print("Final DTR   CRC is 0x%06x" % dtr_crc)
    print("Final Frame CRC is 0x%06x" % fr_crc)

def Frame_CRC(imgDir, imgFileName):
    imgFilePath = str(os.path.join(imgDir, imgFileName))

    compute_frame_crc_from_raw(imgFilePath)

    ##########################################################################
    # Test frame CRC

    #print("\nINFO start test of frame CRC, example 1")

    ## compute CRCs from DevWare capture, example 1
    #compute_frame_crc_from_raw("/home/jtmxyj/frame_crc/active00.raw")
    #compute_frame_crc_from_raw("/home/jtmxyj/frame_crc/active01.raw")
    #compute_frame_crc_from_raw("/home/jtmxyj/frame_crc/active02.raw")
    #compute_frame_crc_from_raw("/home/jtmxyj/frame_crc/active03.raw")

    #print("\nINFO start test of frame CRC, example 2")

    ## compute CRCs from DevWare capture, example 3
    #compute_frame_crc_from_raw("/home/jtmxyj/frame_crc/active_dark00.raw")
    #compute_frame_crc_from_raw("/home/jtmxyj/frame_crc/active_dark01.raw")
    #compute_frame_crc_from_raw("/home/jtmxyj/frame_crc/active_dark02.raw")
    #compute_frame_crc_from_raw("/home/jtmxyj/frame_crc/active_dark03.raw")

    #exit()

    #print("\nINFO start test of frame CRC from RTL simulation")

    # compute CRCs from RTL simulation pixel file
    # $ bsub -Is ./dotest stream_tiny_1exp -copt Dreg=tpg_control__0x9 -copt Dreg=crc_control_reg__0x8021 -copt Dreg=asil_check_enables_02__0x7fff -copt Dreg=dark_control__0x2000 -copt frames=2 -ncbuild -ncsim
    # compute_frame_crc_from_pix("/sim/tmp/jtmxyj/b_C_AR0820_REV2/asic/logic/top/run_ar0820/stream_tiny_1exp/stream_tiny_1exp.pix", 12)
    # compute_frame_crc_from_pix("/sim/tmp/jtmxyj/b_C_AR0820_REV2/asic/logic/top/run_ar0820/stream_tiny_2exp/stream_tiny_2exp.pix", 16)
    # compute_frame_crc_from_pix("/sim/tmp/jtmxyj/b_C_AR0820_REV2/asic/logic/top/run_ar0820/stream_tiny_3exp/stream_tiny_3exp.pix", 20)
    # compute_frame_crc_from_pix("/sim/tmp/jtmxyj/b_C_AR0820_REV2/asic/logic/top/run_ar0820/stream_tiny_4exp/stream_tiny_4exp.pix", 24)

def External_Image_Crop(imgDir, imgFileName, document, yStart, xStart, yEnd, xEnd, showPlt):
    try:
        imgWidth = 7.25  # size of img (inches)
        baseSize = 500 # x y size in # of pixels

        xDiff = xEnd - xStart
        yDiff = yEnd - yStart
        xyratio = xDiff/yDiff
        yxratio = yDiff/xDiff
        # print('xDiff', xDiff)
        # print('yDiff',yDiff)
        # print('xyratio',xyratio)
        # print('yxratio',yxratio)

        # X & Y size of cropped image
        if xyratio < 1:
            xSize = int(baseSize - (baseSize * (1 - xyratio)))
            ySize = baseSize
            # print(xSize)
            # print(ySize)
        elif (xyratio >=1):
            xSize = baseSize
            ySize = int(baseSize - (baseSize * (1 - (1 / xyratio))))
            # print(xSize)
            # print(ySize)

        # XYSR = xSize/ySize
        # print('XYSIZERATIO', XYSR)

        for file in os.scandir(imgDir):
            if file.name.endswith(".png") or file.name.endswith(".PNG"):
                if file.name == imgFileName:
                    imgFilePath = str(os.path.join(imgDir, imgFileName))
                    img = Image.open(imgFilePath)
                    # w, h = img.size
                    # print(w, h)
                    area = (xStart, yStart, xEnd, yEnd) # left, top, right, bottom'
                    cropped_img = img.crop(area)
                    resized_img = cropped_img.resize((xSize, ySize))
                    vrg_filename = imgFilePath[:-4] + "_crop.png"
                    resized_img.save(vrg_filename)
                    resized_img.close()
                    if showPlt == True:
                        newImg = Image.open(vrg_filename)
                        newImg.show()
                    document.add_heading('Cropped Image', level=2)
                    document.add_heading(imgFileName, level=3)
                    document.add_picture(vrg_filename)
                    #document.add_picture(vrg_filename, width=Inches(imgWidth), height=Inches(imgWidth))  # Add Image to report
    except:
        document.add_heading("Failed To External_Image_Crop: ", level=2)
        document.add_heading("imgDir Used: " + imgDir, level=3)
        document.add_heading("imgFileName Used: " + imgFileName, level=3)
        document.add_heading("yStart Used: " + yStart, level=3)
        document.add_heading("xStart Used: " + xStart, level=3)
        document.add_heading("yEnd Used: " + yEnd, level=3)
        document.add_heading("xEnd Used: " + xEnd, level=3)

def Image_Crop(dataframe, imgNum, document, yStart, xStart, yEnd, xEnd, showPlt):
    try:
        i0 = 'ImageLinkDir1'
        i1 = 'ImageLink1'

        numDataCols = 3
        df = dataframe
        imgWidth = 7  # size of img (inches)
        baseSize = 500 # x y size in # of pixels
        xDiff = xEnd - xStart
        yDiff = yEnd - yStart
        xyratio = xDiff/yDiff
        yxratio = yDiff/xDiff

        # X & Y size of cropped image
        if xyratio < 1:
            xSize = int(baseSize - (baseSize * (1 - xyratio)))
            ySize = baseSize
        elif (xyratio >=1):
            xSize = baseSize
            ySize = int(baseSize - (baseSize * (1 - (1 / xyratio))))

        imgNum = imgNum - 1 # Convert to dataframe step
        imgDir = df[i0].loc[imgNum]
        imgFileName = df[i1].loc[imgNum]
        imgLinkLen = len(df[i0])

        if imgNum > 0 and imgNum <= imgLinkLen:
            for file in os.scandir(imgDir):
                if file.name.endswith(".png") or file.name.endswith(".PNG"):
                    if file.name == imgFileName:
                        imgFilePath = str(os.path.join(imgDir, imgFileName))
                        img = Image.open(imgFilePath)
                        # w, h = img.size
                        area = (xStart, yStart, xEnd, yEnd) # left, top, right, bottom'
                        cropped_img = img.crop(area)
                        resized_img = cropped_img.resize((xSize, ySize))
                        vrg_filename = imgFilePath[:-4] + "_crop.png"
                        resized_img.save(vrg_filename)
                        resized_img.close()
                        if showPlt == True:
                            newImg = Image.open(vrg_filename)
                            newImg.show()
                        document.add_heading('Cropped Image', level=2)
                        document.add_paragraph('Y_START = ' + str(yStart) + ', Y_END = ' + str(yEnd) + ', X_START = ' + str(xStart) + ', X_END = ' + str(xEnd) + ', Y_SIZE = ' + str(yDiff) + ', X_SIZE = ' + str(xDiff))
                        document.add_heading(imgFileName, level=3)
                        document.add_picture(vrg_filename)
    except:
        document.add_heading("Failed To Image_Crop: ", level=2)
        document.add_heading("imgNum Used: " + imgNum, level=3)
        for x in range(1, numDataCols):  # 1 to 4
            if eval("i" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("i" + str(x)), level=3)  # Add columns found
                if imgNum in df[eval("i" + str(x))].unique():
                    document.add_heading("imgNum Found: " + imgNum + " in " + eval("i" + str(x)),  level=3)  # Add Groupby found
                else:
                    document.add_heading("imgNum Not Found: " + imgNum + " in " + eval("i" + str(x)), level=3)  # Add Groupby not found
            else:
                document.add_heading("Column Not Found: " + eval("i" + str(x)), level=3)  # Add columns not found
        document.add_heading("yStart Used: " + yStart, level=3)
        document.add_heading("xStart Used: " + xStart, level=3)
        document.add_heading("yEnd Used: " + yEnd, level=3)
        document.add_heading("xEnd Used: " + xEnd, level=3)