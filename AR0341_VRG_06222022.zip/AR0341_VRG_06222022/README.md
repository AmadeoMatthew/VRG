# VRG
Validation Report Generation
1) Added column name fix to replace '::' with '__' so filenaming doesnt have a failure
    A) User needs to know '::' is not allowed
2) Look at combining reg_vs_reg and reg_vs by having if statments
3) Try combining RGN_MEAN_ and MEAN_ with if statements
4) Add a Min/Mean/Max/STD column calculation for the tempsensor data to lower the number of plots occurring
5) Add a tempsensor accuracy or error plot, add potential horizontal line with temperatures in the plots
6) Updated to remove :: from all column names