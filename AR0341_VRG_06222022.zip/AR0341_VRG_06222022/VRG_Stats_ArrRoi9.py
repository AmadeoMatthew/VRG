import matplotlib
import matplotlib.pyplot as plt
from matplotlib import pyplot
from docx import Document
from docx.shared import Inches
from docx.shared import Pt
from tkinter import *
from tkinter import filedialog
from tkinter import messagebox
import numpy as np
import csv
import argparse
import os
import pandas as pd
import pixelcrunch as pc
import fivecentplots as fcp
import bokeh
import sys
import io
import multiprocessing
import VRG_Safety_Data
import VRG_Calculate
import VRG_Data_Frame
import VRG_Doc
import VRG_General_Data
import VRG_Image_Analysis
import VRG_Image_Utils
import VRG_Macro_Data
import VRG_OTPM_Data
import VRG_Pins_Data
import VRG_Power_Data
import VRG_Register_Data
import VRG_Stats_Arr
import VRG_Stats_ArrCenter
import VRG_Stats_ArrQuad1
import VRG_Stats_ArrQuad2
import VRG_Stats_ArrQuad3
import VRG_Stats_ArrQuad4
import VRG_Stats_ArrRoi1
import VRG_Stats_ArrRoi2
import VRG_Stats_ArrRoi3
import VRG_Stats_ArrRoi4
import VRG_Stats_ArrRoi5
import VRG_Stats_ArrRoi6
import VRG_Stats_ArrRoi7
import VRG_Stats_ArrRoi8
import VRG_Stats_ArrRoi9
import VRG_Stats_DBLC
import VRG_Stats_Frame
import VRG_Stats_Lag
import VRG_Stats_RNC
import VRG_Stats_Tilt
import VRG_Tempsensor_Data
import VRG_Reports
import time

# ArrRoi9 Stats
def ArrRoi9_Mean_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_Mean_GreenR'
        d2 = 'ArrRoi9_Mean_Red'
        d3 = 'ArrRoi9_Mean_GreenB'
        d4 = 'ArrRoi9_Mean_Blue'

        figTitle = 'ArrRoi9_Mean'
        ylabel = 'Mean (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def ArrRoi9_StdDev_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_StdDev_GreenR'
        d2 = 'ArrRoi9_StdDev_Red'
        d3 = 'ArrRoi9_StdDev_GreenB'
        d4 = 'ArrRoi9_StdDev_Blue'

        figTitle = 'ArrRoi9_StdDev'
        ylabel = 'StdDev (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def ArrRoi9_TotalNoise_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_TotalNoise_Blue'
        d2 = 'ArrRoi9_TotalNoise_GreenB'
        d3 = 'ArrRoi9_TotalNoise_Red'
        d4 = 'ArrRoi9_TotalNoise_GreenR'

        figTitle = 'ArrRoi9_TotalNoise'
        ylabel = 'TotalNoise (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def ArrRoi9_FPN_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_FPN_Blue'
        d2 = 'ArrRoi9_FPN_GreenB'
        d3 = 'ArrRoi9_FPN_Red'
        d4 = 'ArrRoi9_FPN_GreenR'

        figTitle = 'ArrRoi9_FPN'
        ylabel = 'FPN (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def ArrRoi9_Temporal_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_Temporal_Blue'
        d2 = 'ArrRoi9_Temporal_GreenB'
        d3 = 'ArrRoi9_Temporal_Red'
        d4 = 'ArrRoi9_Temporal_GreenR'

        figTitle = 'ArrRoi9_Temporal'
        ylabel = 'Temporal (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def ArrRoi9_RowStdDev_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_RowStdDev_Blue'
        d2 = 'ArrRoi9_RowStdDev_GreenB'
        d3 = 'ArrRoi9_RowStdDev_Red'
        d4 = 'ArrRoi9_RowStdDev_GreenR'

        figTitle = 'ArrRoi9_RowStdDev'
        ylabel = 'RowStdDev (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def ArrRoi9_RowTotalNoise_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_RowTotalNoise_Blue'
        d2 = 'ArrRoi9_RowTotalNoise_GreenB'
        d3 = 'ArrRoi9_RowTotalNoise_Red'
        d4 = 'ArrRoi9_RowTotalNoise_GreenR'

        figTitle = 'ArrRoi9_RowTotalNoise'
        ylabel = 'RowTotalNoise (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def ArrRoi9_RowFPN_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_RowFPN_Blue'
        d2 = 'ArrRoi9_RowFPN_GreenB'
        d3 = 'ArrRoi9_RowFPN_Red'
        d4 = 'ArrRoi9_RowFPN_GreenR'

        figTitle = 'ArrRoi9_RowFPN'
        ylabel = 'RowFPN (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def ArrRoi9_RowTempNoise_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_RowTempNoise_Blue'
        d2 = 'ArrRoi9_RowTempNoise_GreenB'
        d3 = 'ArrRoi9_RowTempNoise_Red'
        d4 = 'ArrRoi9_RowTempNoise_GreenR'

        figTitle = 'ArrRoi9_RowTempNoise'
        ylabel = 'RowTempNoise (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def ArrRoi9_ColStdDev_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_ColStdDev_Blue'
        d2 = 'ArrRoi9_ColStdDev_GreenB'
        d3 = 'ArrRoi9_ColStdDev_Red'
        d4 = 'ArrRoi9_ColStdDev_GreenR'

        figTitle = 'ArrRoi9_ColStdDev'
        ylabel = 'ColStdDev (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def ArrRoi9_ColTotalNoise_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_ColTotalNoise_Blue'
        d2 = 'ArrRoi9_ColTotalNoise_GreenB'
        d3 = 'ArrRoi9_ColTotalNoise_Red'
        d4 = 'ArrRoi9_ColTotalNoise_GreenR'

        figTitle = 'ArrRoi9_ColTotalNoise'
        ylabel = 'ColTotalNoise (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def ArrRoi9_ColFPN_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_ColFPN_Blue'
        d2 = 'ArrRoi9_ColFPN_GreenB'
        d3 = 'ArrRoi9_ColFPN_Red'
        d4 = 'ArrRoi9_ColFPN_GreenR'

        figTitle = 'ArrRoi9_ColFPN'
        ylabel = 'ColFPN (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def ArrRoi9_ColTempNoise_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_ColTempNoise_Blue'
        d2 = 'ArrRoi9_ColTempNoise_GreenB'
        d3 = 'ArrRoi9_ColTempNoise_Red'
        d4 = 'ArrRoi9_ColTempNoise_GreenR'

        figTitle = 'ArrRoi9_ColTempNoise'
        ylabel = 'ColTempNoise (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def ArrRoi9_Flicker_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_Flicker_Blue'
        d2 = 'ArrRoi9_Flicker_GreenB'
        d3 = 'ArrRoi9_Flicker_Red'
        d4 = 'ArrRoi9_Flicker_GreenR'

        figTitle = 'ArrRoi9_Flicker'
        ylabel = 'Flicker (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def ArrRoi9_PixelTotalNoise_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_PixelTotalNoise_GreenR'
        d2 = 'ArrRoi9_PixelTotalNoise_Red'
        d3 = 'ArrRoi9_PixelTotalNoise_GreenB'
        d4 = 'ArrRoi9_PixelTotalNoise_Blue'

        figTitle = 'ArrRoi9_PixelTotalNoise'
        ylabel = 'PixelTotalNoise(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def ArrRoi9_PixelTemporalNoise_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_PixelTemporalNoise_GreenR'
        d2 = 'ArrRoi9_PixelTemporalNoise_Red'
        d3 = 'ArrRoi9_PixelTemporalNoise_GreenB'
        d4 = 'ArrRoi9_PixelTemporalNoise_Blue'

        figTitle = 'ArrRoi9_PixelTemporalNoise'
        ylabel = 'PixelTemporalNoise(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def ArrRoi9_PixelFPN_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_PixelFPN_GreenR'
        d2 = 'ArrRoi9_PixelFPN_Red'
        d3 = 'ArrRoi9_PixelFPN_GreenB'
        d4 = 'ArrRoi9_PixelFPN_Blue'

        figTitle = 'ArrRoi9_PixelFPN'
        ylabel = 'PixelFPN(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def ArrRoi9_RowTemporalNoiseRatio_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_RowTemporalNoiseRatio_GreenR'
        d2 = 'ArrRoi9_RowTemporalNoiseRatio_Red'
        d3 = 'ArrRoi9_RowTemporalNoiseRatio_GreenB'
        d4 = 'ArrRoi9_RowTemporalNoiseRatio_Blue'

        figTitle = 'ArrRoi9_RowTemporalNoiseRatio'
        ylabel = 'RowTemporalNoiseRatio(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def ArrRoi9_ColumnTemporalNoiseRatio_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_ColumnTemporalNoiseRatio_GreenR'
        d2 = 'ArrRoi9_ColumnTemporalNoiseRatio_Red'
        d3 = 'ArrRoi9_ColumnTemporalNoiseRatio_GreenB'
        d4 = 'ArrRoi9_ColumnTemporalNoiseRatio_Blue'

        figTitle = 'ArrRoi9_ColumnTemporalNoiseRatio'
        ylabel = 'ColumnTemporalNoiseRatio(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def ArrRoi9_RowFPNRatio_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_RowFPNRatio_GreenR'
        d2 = 'ArrRoi9_RowFPNRatio_Red'
        d3 = 'ArrRoi9_RowFPNRatio_GreenB'
        d4 = 'ArrRoi9_RowFPNRatio_Blue'

        figTitle = 'ArrRoi9_RowFPNRatio'
        ylabel = 'RowFPNRatio(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def ArrRoi9_ColumnFPNRatio_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_ColumnFPNRatio_GreenR'
        d2 = 'ArrRoi9_ColumnFPNRatio_Red'
        d3 = 'ArrRoi9_ColumnFPNRatio_GreenB'
        d4 = 'ArrRoi9_ColumnFPNRatio_Blue'

        figTitle = 'ArrRoi9_ColumnFPNRatio'
        ylabel = 'ColumnFPNRatio(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found


'''
Region vs Register Plots
'''
def Reg_vs_ArrRoi9_Mean_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_Mean_GreenR'
        d2 = 'ArrRoi9_Mean_Red'
        d3 = 'ArrRoi9_Mean_GreenB'
        d4 = 'ArrRoi9_Mean_Blue'

        figTitle = 'Register_vs_ArrRoi9Mean'
        xlabel = register
        ylabel = 'Mean (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_ArrRoi9_StdDev_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_StdDev_GreenR'
        d2 = 'ArrRoi9_StdDev_Red'
        d3 = 'ArrRoi9_StdDev_GreenB'
        d4 = 'ArrRoi9_StdDev_Blue'

        figTitle = 'Register_vs_ArrRoi9StdDev'
        xlabel = register
        ylabel = 'StdDev (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_ArrRoi9_TotalNoise_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_TotalNoise_Blue'
        d2 = 'ArrRoi9_TotalNoise_GreenB'
        d3 = 'ArrRoi9_TotalNoise_Red'
        d4 = 'ArrRoi9_TotalNoise_GreenR'

        figTitle = 'Register_vs_ArrRoi9_TotalNoise'
        xlabel = register
        ylabel = 'TotalNoise (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_ArrRoi9_FPN_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_FPN_Blue'
        d2 = 'ArrRoi9_FPN_GreenB'
        d3 = 'ArrRoi9_FPN_Red'
        d4 = 'ArrRoi9_FPN_GreenR'

        figTitle = 'Register_vs_ArrRoi9_FPN'
        xlabel = register
        ylabel = 'FPN (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_ArrRoi9_Temporal_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_Temporal_Blue'
        d2 = 'ArrRoi9_Temporal_GreenB'
        d3 = 'ArrRoi9_Temporal_Red'
        d4 = 'ArrRoi9_Temporal_GreenR'

        figTitle = 'Register_vs_ArrRoi9_Temporal'
        xlabel = register
        ylabel = 'Temporal (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_ArrRoi9_RowStdDev_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_RowStdDev_Blue'
        d2 = 'ArrRoi9_RowStdDev_GreenB'
        d3 = 'ArrRoi9_RowStdDev_Red'
        d4 = 'ArrRoi9_RowStdDev_GreenR'

        figTitle = 'Register_vs_ArrRoi9_RowStdDev'
        xlabel = register
        ylabel = 'RowStdDev (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_ArrRoi9_RowTotalNoise_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_RowTotalNoise_Blue'
        d2 = 'ArrRoi9_RowTotalNoise_GreenB'
        d3 = 'ArrRoi9_RowTotalNoise_Red'
        d4 = 'ArrRoi9_RowTotalNoise_GreenR'

        figTitle = 'Register_vs_ArrRoi9_RowTotalNoise'
        xlabel = register
        ylabel = 'RowTotalNoise (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_ArrRoi9_RowFPN_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_RowFPN_Blue'
        d2 = 'ArrRoi9_RowFPN_GreenB'
        d3 = 'ArrRoi9_RowFPN_Red'
        d4 = 'ArrRoi9_RowFPN_GreenR'

        figTitle = 'Register_vs_ArrRoi9_RowFPN'
        xlabel = register
        ylabel = 'RowFPN (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_ArrRoi9_RowTempNoise_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_RowTempNoise_Blue'
        d2 = 'ArrRoi9_RowTempNoise_GreenB'
        d3 = 'ArrRoi9_RowTempNoise_Red'
        d4 = 'ArrRoi9_RowTempNoise_GreenR'

        figTitle = 'Register_vs_ArrRoi9_RowTempNoise'
        xlabel = register
        ylabel = 'RowTempNoise (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_ArrRoi9_ColStdDev_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_ColStdDev_Blue'
        d2 = 'ArrRoi9_ColStdDev_GreenB'
        d3 = 'ArrRoi9_ColStdDev_Red'
        d4 = 'ArrRoi9_ColStdDev_GreenR'

        figTitle = 'Register_vs_ArrRoi9_ColStdDev'
        xlabel = register
        ylabel = 'ColStdDev (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_ArrRoi9_ColTotalNoise_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_ColTotalNoise_Blue'
        d2 = 'ArrRoi9_ColTotalNoise_GreenB'
        d3 = 'ArrRoi9_ColTotalNoise_Red'
        d4 = 'ArrRoi9_ColTotalNoise_GreenR'

        figTitle = 'Register_vs_ArrRoi9_ColTotalNoise'
        xlabel = register
        ylabel = 'ColTotalNoise (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_ArrRoi9_ColFPN_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_ColFPN_Blue'
        d2 = 'ArrRoi9_ColFPN_GreenB'
        d3 = 'ArrRoi9_ColFPN_Red'
        d4 = 'ArrRoi9_ColFPN_GreenR'

        figTitle = 'Register_vs_ArrRoi9_ColFPN'
        xlabel = register
        ylabel = 'ColFPN (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_ArrRoi9_ColTempNoise_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_ColTempNoise_Blue'
        d2 = 'ArrRoi9_ColTempNoise_GreenB'
        d3 = 'ArrRoi9_ColTempNoise_Red'
        d4 = 'ArrRoi9_ColTempNoise_GreenR'

        figTitle = 'Register_vs_ArrRoi9_ColTempNoise'
        xlabel = register
        ylabel = 'ColTempNoise (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_ArrRoi9_Flicker_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_Flicker_Blue'
        d2 = 'ArrRoi9_Flicker_GreenB'
        d3 = 'ArrRoi9_Flicker_Red'
        d4 = 'ArrRoi9_Flicker_GreenR'

        figTitle = 'Register_vs_ArrRoi9_Flicker'
        xlabel = register
        ylabel = 'Flicker (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_ArrRoi9_PixelTotalNoise_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_PixelTotalNoise_GreenR'
        d2 = 'ArrRoi9_PixelTotalNoise_Red'
        d3 = 'ArrRoi9_PixelTotalNoise_GreenB'
        d4 = 'ArrRoi9_PixelTotalNoise_Blue'

        figTitle = 'Register_vs_ArrRoi9_PixelTotalNoise'
        xlabel = register
        ylabel = 'PixelTotalNoise(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_ArrRoi9_PixelTemporalNoise_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_PixelTemporalNoise_GreenR'
        d2 = 'ArrRoi9_PixelTemporalNoise_Red'
        d3 = 'ArrRoi9_PixelTemporalNoise_GreenB'
        d4 = 'ArrRoi9_PixelTemporalNoise_Blue'

        figTitle = 'Register_vs_ArrRoi9_PixelTemporalNoise'
        xlabel = register
        ylabel = 'PixelTemporalNoise(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_ArrRoi9_PixelFPN_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_PixelFPN_GreenR'
        d2 = 'ArrRoi9_PixelFPN_Red'
        d3 = 'ArrRoi9_PixelFPN_GreenB'
        d4 = 'ArrRoi9_PixelFPN_Blue'

        figTitle = 'Register_vs_ArrRoi9_PixelFPN'
        xlabel = register
        ylabel = 'PixelFPN(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_ArrRoi9_RowTemporalNoiseRatio_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_RowTemporalNoiseRatio_GreenR'
        d2 = 'ArrRoi9_RowTemporalNoiseRatio_Red'
        d3 = 'ArrRoi9_RowTemporalNoiseRatio_GreenB'
        d4 = 'ArrRoi9_RowTemporalNoiseRatio_Blue'

        figTitle = 'Register_vs_ArrRoi9_RowTemporalNoiseRatio'
        xlabel = register
        ylabel = 'RowTemporalNoiseRatio(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_ArrRoi9_ColumnTemporalNoiseRatio_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_ColumnTemporalNoiseRatio_GreenR'
        d2 = 'ArrRoi9_ColumnTemporalNoiseRatio_Red'
        d3 = 'ArrRoi9_ColumnTemporalNoiseRatio_GreenB'
        d4 = 'ArrRoi9_ColumnTemporalNoiseRatio_Blue'

        figTitle = 'Register_vs_ArrRoi9_ColumnTemporalNoiseRatio'
        xlabel = register
        ylabel = 'ColumnTemporalNoiseRatio(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_ArrRoi9_RowFPNRatio_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_RowFPNRatio_GreenR'
        d2 = 'ArrRoi9_RowFPNRatio_Red'
        d3 = 'ArrRoi9_RowFPNRatio_GreenB'
        d4 = 'ArrRoi9_RowFPNRatio_Blue'

        figTitle = 'Register_vs_ArrRoi9_RowFPNRatio'
        xlabel = register
        ylabel = 'RowFPNRatio(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_ArrRoi9_ColumnFPNRatio_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_ColumnFPNRatio_GreenR'
        d2 = 'ArrRoi9_ColumnFPNRatio_Red'
        d3 = 'ArrRoi9_ColumnFPNRatio_GreenB'
        d4 = 'ArrRoi9_ColumnFPNRatio_Blue'

        figTitle = 'Register_vs_ArrRoi9_ColumnFPNRatio'
        xlabel = register
        ylabel = 'ColumnFPNRatio(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found


'''
Region vs Dual Register Plots
'''

def Reg_vs_Reg_vs_ArrRoi9_Mean_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_Mean_GreenR'
        d2 = 'ArrRoi9_Mean_Red'
        d3 = 'ArrRoi9_Mean_GreenB'
        d4 = 'ArrRoi9_Mean_Blue'

        figTitle = 'Reg_vs_Reg_vs_ArrRoi9Mean'
        ylabel = 'Mean (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_ArrRoi9_StdDev_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_StdDev_GreenR'
        d2 = 'ArrRoi9_StdDev_Red'
        d3 = 'ArrRoi9_StdDev_GreenB'
        d4 = 'ArrRoi9_StdDev_Blue'

        figTitle = 'Reg_vs_Reg_vs_ArrRoi9StdDev'
        ylabel = 'StdDev (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_ArrRoi9_TotalNoise_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_TotalNoise_Blue'
        d2 = 'ArrRoi9_TotalNoise_GreenB'
        d3 = 'ArrRoi9_TotalNoise_Red'
        d4 = 'ArrRoi9_TotalNoise_GreenR'

        figTitle = 'Reg_vs_Reg_vs_ArrRoi9_TotalNoise'
        ylabel = 'TotalNoise (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_ArrRoi9_FPN_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_FPN_Blue'
        d2 = 'ArrRoi9_FPN_GreenB'
        d3 = 'ArrRoi9_FPN_Red'
        d4 = 'ArrRoi9_FPN_GreenR'

        figTitle = 'Reg_vs_Reg_vs_ArrRoi9_FPN'
        ylabel = 'FPN (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_ArrRoi9_Temporal_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_Temporal_Blue'
        d2 = 'ArrRoi9_Temporal_GreenB'
        d3 = 'ArrRoi9_Temporal_Red'
        d4 = 'ArrRoi9_Temporal_GreenR'

        figTitle = 'Reg_vs_Reg_vs_ArrRoi9_Temporal'
        ylabel = 'Temporal (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_ArrRoi9_RowStdDev_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_RowStdDev_Blue'
        d2 = 'ArrRoi9_RowStdDev_GreenB'
        d3 = 'ArrRoi9_RowStdDev_Red'
        d4 = 'ArrRoi9_RowStdDev_GreenR'

        figTitle = 'Reg_vs_Reg_vs_ArrRoi9_RowStdDev'
        ylabel = 'RowStdDev (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_ArrRoi9_RowTotalNoise_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_RowTotalNoise_Blue'
        d2 = 'ArrRoi9_RowTotalNoise_GreenB'
        d3 = 'ArrRoi9_RowTotalNoise_Red'
        d4 = 'ArrRoi9_RowTotalNoise_GreenR'

        figTitle = 'Reg_vs_Reg_vs_ArrRoi9_RowTotalNoise'
        ylabel = 'RowTotalNoise (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_ArrRoi9_RowFPN_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_RowFPN_Blue'
        d2 = 'ArrRoi9_RowFPN_GreenB'
        d3 = 'ArrRoi9_RowFPN_Red'
        d4 = 'ArrRoi9_RowFPN_GreenR'

        figTitle = 'Reg_vs_Reg_vs_ArrRoi9_RowFPN'
        ylabel = 'RowFPN (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_ArrRoi9_RowTempNoise_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_RowTempNoise_Blue'
        d2 = 'ArrRoi9_RowTempNoise_GreenB'
        d3 = 'ArrRoi9_RowTempNoise_Red'
        d4 = 'ArrRoi9_RowTempNoise_GreenR'

        figTitle = 'Reg_vs_Reg_vs_ArrRoi9_RowTempNoise'
        ylabel = 'RowTempNoise (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_ArrRoi9_ColStdDev_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_ColStdDev_Blue'
        d2 = 'ArrRoi9_ColStdDev_GreenB'
        d3 = 'ArrRoi9_ColStdDev_Red'
        d4 = 'ArrRoi9_ColStdDev_GreenR'

        figTitle = 'Reg_vs_Reg_vs_ArrRoi9_ColStdDev'
        ylabel = 'ColStdDev (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_ArrRoi9_ColTotalNoise_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_ColTotalNoise_Blue'
        d2 = 'ArrRoi9_ColTotalNoise_GreenB'
        d3 = 'ArrRoi9_ColTotalNoise_Red'
        d4 = 'ArrRoi9_ColTotalNoise_GreenR'

        figTitle = 'Reg_vs_Reg_vs_ArrRoi9_ColTotalNoise'
        ylabel = 'ColTotalNoise (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_ArrRoi9_ColFPN_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_ColFPN_Blue'
        d2 = 'ArrRoi9_ColFPN_GreenB'
        d3 = 'ArrRoi9_ColFPN_Red'
        d4 = 'ArrRoi9_ColFPN_GreenR'

        figTitle = 'Reg_vs_Reg_vs_ArrRoi9_ColFPN'
        ylabel = 'ColFPN (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_ArrRoi9_ColTempNoise_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_ColTempNoise_Blue'
        d2 = 'ArrRoi9_ColTempNoise_GreenB'
        d3 = 'ArrRoi9_ColTempNoise_Red'
        d4 = 'ArrRoi9_ColTempNoise_GreenR'

        figTitle = 'Reg_vs_Reg_vs_ArrRoi9_ColTempNoise'
        ylabel = 'ColTempNoise (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_ArrRoi9_Flicker_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_Flicker_Blue'
        d2 = 'ArrRoi9_Flicker_GreenB'
        d3 = 'ArrRoi9_Flicker_Red'
        d4 = 'ArrRoi9_Flicker_GreenR'

        figTitle = 'Reg_vs_Reg_vs_ArrRoi9_Flicker'
        ylabel = 'Flicker (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_ArrRoi9_PixelTotalNoise_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_PixelTotalNoise_GreenR'
        d2 = 'ArrRoi9_PixelTotalNoise_Red'
        d3 = 'ArrRoi9_PixelTotalNoise_GreenB'
        d4 = 'ArrRoi9_PixelTotalNoise_Blue'

        figTitle = 'Reg_vs_Reg_vs_ArrRoi9_PixelTotalNoise'
        ylabel = 'PixelTotalNoise(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_ArrRoi9_PixelTemporalNoise_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_PixelTemporalNoise_GreenR'
        d2 = 'ArrRoi9_PixelTemporalNoise_Red'
        d3 = 'ArrRoi9_PixelTemporalNoise_GreenB'
        d4 = 'ArrRoi9_PixelTemporalNoise_Blue'

        figTitle = 'Reg_vs_Reg_vs_ArrRoi9_PixelTemporalNoise'
        ylabel = 'PixelTemporalNoise(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_ArrRoi9_PixelFPN_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_PixelFPN_GreenR'
        d2 = 'ArrRoi9_PixelFPN_Red'
        d3 = 'ArrRoi9_PixelFPN_GreenB'
        d4 = 'ArrRoi9_PixelFPN_Blue'

        figTitle = 'Reg_vs_Reg_vs_ArrRoi9_PixelFPN'
        ylabel = 'PixelFPN(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_ArrRoi9_RowTemporalNoiseRatio_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_RowTemporalNoiseRatio_GreenR'
        d2 = 'ArrRoi9_RowTemporalNoiseRatio_Red'
        d3 = 'ArrRoi9_RowTemporalNoiseRatio_GreenB'
        d4 = 'ArrRoi9_RowTemporalNoiseRatio_Blue'

        figTitle = 'Reg_vs_Reg_vs_ArrRoi9_RowTemporalNoiseRatio'
        ylabel = 'RowTemporalNoiseRatio(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_ArrRoi9_ColumnTemporalNoiseRatio_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_ColumnTemporalNoiseRatio_GreenR'
        d2 = 'ArrRoi9_ColumnTemporalNoiseRatio_Red'
        d3 = 'ArrRoi9_ColumnTemporalNoiseRatio_GreenB'
        d4 = 'ArrRoi9_ColumnTemporalNoiseRatio_Blue'

        figTitle = 'Reg_vs_Reg_vs_ArrRoi9_ColumnTemporalNoiseRatio'
        ylabel = 'ColumnTemporalNoiseRatio(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_ArrRoi9_RowFPNRatio_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_RowFPNRatio_GreenR'
        d2 = 'ArrRoi9_RowFPNRatio_Red'
        d3 = 'ArrRoi9_RowFPNRatio_GreenB'
        d4 = 'ArrRoi9_RowFPNRatio_Blue'

        figTitle = 'Reg_vs_Reg_vs_ArrRoi9_RowFPNRatio'
        ylabel = 'RowFPNRatio(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_ArrRoi9_ColumnFPNRatio_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        d1 = 'ArrRoi9_ColumnFPNRatio_GreenR'
        d2 = 'ArrRoi9_ColumnFPNRatio_Red'
        d3 = 'ArrRoi9_ColumnFPNRatio_GreenB'
        d4 = 'ArrRoi9_ColumnFPNRatio_Blue'

        figTitle = 'Reg_vs_Reg_vs_ArrRoi9_ColumnFPNRatio'
        ylabel = 'ColumnFPNRatio(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found