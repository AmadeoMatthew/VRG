import matplotlib
import matplotlib.pyplot as plt
from matplotlib import pyplot
import csv
import os
import pandas as pd
import fivecentplots as fcp
import bokeh
from PIL import Image
import sys
import io
import numpy as np
from docx import Document
from docx.shared import Inches
from docx.shared import Pt
from tkinter import *
import multiprocessing
import VRG_Safety_Data
import VRG_Calculate
import VRG_Data_Frame
import VRG_Doc
import VRG_General_Data
import VRG_Image_Analysis
import VRG_Image_Utils
import VRG_Macro_Data
import VRG_OTPM_Data
import VRG_Pins_Data
import VRG_Power_Data
import VRG_Register_Data
import VRG_Stats_Arr
import VRG_Stats_ArrCenter
import VRG_Stats_ArrQuad1
import VRG_Stats_ArrQuad2
import VRG_Stats_ArrQuad3
import VRG_Stats_ArrQuad4
import VRG_Stats_ArrRoi1
import VRG_Stats_ArrRoi2
import VRG_Stats_ArrRoi3
import VRG_Stats_ArrRoi4
import VRG_Stats_ArrRoi5
import VRG_Stats_ArrRoi6
import VRG_Stats_ArrRoi7
import VRG_Stats_ArrRoi8
import VRG_Stats_ArrRoi9
import VRG_Stats_DBLC
import VRG_Stats_Frame
import VRG_Stats_Lag
import VRG_Stats_RNC
import VRG_Stats_Tilt
import VRG_Tempsensor_Data
import VRG_Reports
import time

def Stats_Mean_Plot(dataFrame, groupBy, document, pltPath, rgnName, showPlt, **kwargs):
    try:
        dname_1 = 'Mean_GreenR'
        dname_2 = 'Mean_Red'
        dname_3 = 'Mean_GreenB'
        dname_4 = 'Mean_Blue'

        df = dataFrame

        # get data columns
        t1_cols = [x for x in df.columns[df.columns.str.contains(dname_1)]]
        t2_cols = [x for x in df.columns[df.columns.str.contains(dname_2)]]
        t3_cols = [x for x in df.columns[df.columns.str.contains(dname_3)]]
        t4_cols = [x for x in df.columns[df.columns.str.contains(dname_4)]]

        d1 = [x for x in t1_cols.str.contains(rgnName)]
        d2 = [x for x in t2_cols.str.contains(rgnName)]
        d3 = [x for x in t3_cols.str.contains(rgnName)]
        d4 = [x for x in t4_cols.str.contains(rgnName)]


        figTitle = rgnName + '_Mean'
        ylabel = 'Mean (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

# BOXPLOTS
def Img_Mean_BoxPlot(dataFrame, groupBy, groupings, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'Mean_GreenR'
        d2 = 'Mean_Red'
        d3 = 'Mean_GreenB'
        d4 = 'Mean_Blue'

        figTitle = 'Img_Mean'
        ylabel = 'Mean (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None and groupings == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.boxplot(df, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                            inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                            label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                            **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.boxplot(df, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                        label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                        label_y_font_size=yFontsize,
                        legend_font_size=legFontSize, legend_marker_size=legFontSize,
                        **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None and groupings == None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.boxplot(df, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                            inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                            label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                            **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.boxplot(df, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                        label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                        label_y_font_size=yFontsize,
                        legend_font_size=legFontSize, legend_marker_size=legFontSize,
                        **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy == None and groupings != None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.boxplot(df, y=eval("d" + str(x)), title=eval("d" + str(x)), groups=groupings, show=showPlt,
                            inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                            label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                            **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.boxplot(df, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                        label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                        label_y_font_size=yFontsize,
                        legend_font_size=legFontSize, legend_marker_size=legFontSize,
                        **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None and groupings != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.boxplot(df, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, groups=groupings, show=showPlt,
                            inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                            label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                            **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.boxplot(df, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                        label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                        label_y_font_size=yFontsize,
                        legend_font_size=legFontSize, legend_marker_size=legFontSize,
                        **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Img_StdDev_BoxPlot(dataFrame, groupBy, groupings, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'StdDev_GreenR'
        d2 = 'StdDev_Red'
        d3 = 'StdDev_GreenB'
        d4 = 'StdDev_Blue'

        figTitle = 'Img_StdDev'
        ylabel = 'StdDev (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report


        # Plot combined data in one plot
        if groupBy == None and groupings == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.boxplot(df, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                            inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                            label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                            **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.boxplot(df, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                        label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                        label_y_font_size=yFontsize,
                        legend_font_size=legFontSize, legend_marker_size=legFontSize,
                        **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None and groupings == None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.boxplot(df, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                            inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                            label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                            **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.boxplot(df, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                        label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                        label_y_font_size=yFontsize,
                        legend_font_size=legFontSize, legend_marker_size=legFontSize,
                        **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy == None and groupings != None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.boxplot(df, y=eval("d" + str(x)), title=eval("d" + str(x)), groups=groupings, show=showPlt,
                            inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                            label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                            **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.boxplot(df, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                        label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                        label_y_font_size=yFontsize,
                        legend_font_size=legFontSize, legend_marker_size=legFontSize,
                        **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None and groupings != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.boxplot(df, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, groups=groupings,
                            show=showPlt,
                            inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                            label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                            **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.boxplot(df, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                        label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                        label_y_font_size=yFontsize,
                        legend_font_size=legFontSize, legend_marker_size=legFontSize,
                        **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found


# New Plots
def Reg_vs_RgnV2_Mean_Plot(dataFrame, region, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        if region == None:
            d1 = 'Mean_GreenR'
            d2 = 'Mean_Red'
            d3 = 'Mean_GreenB'
            d4 = 'Mean_Blue'
        elif region != None:
            d1 = region + '_Mean_GreenR'
            d2 = region + '_Mean_Red'
            d3 = region + '_Mean_GreenB'
            d4 = region + '_Mean_Blue'

        figTitle = 'Register_vs_RgnMean'
        xlabel = register
        ylabel = 'Mean (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

# IMG STATS
def Img_Mean_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'Mean_GreenR'
        d2 = 'Mean_Red'
        d3 = 'Mean_GreenB'
        d4 = 'Mean_Blue'

        figTitle = 'Img_Mean'
        ylabel = 'Mean (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Img_StdDev_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'StdDev_GreenR'
        d2 = 'StdDev_Red'
        d3 = 'StdDev_GreenB'
        d4 = 'StdDev_Blue'

        figTitle = 'Img_StdDev'
        ylabel = 'StdDev (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Img_TotalNoise_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'TotalNoise_GreenR'
        d2 = 'TotalNoise_Red'
        d3 = 'TotalNoise_GreenB'
        d4 = 'TotalNoise_Blue'

        figTitle = 'Img_TotalNoise'
        ylabel = 'TotalNoise (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Img_FPN_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'FPN_GreenR'
        d2 = 'FPN_Red'
        d3 = 'FPN_GreenB'
        d4 = 'FPN_Blue'

        figTitle = 'Img_FPN'
        ylabel = 'FPN (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Img_Temporal_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'Temporal_GreenR'
        d2 = 'Temporal_Red'
        d3 = 'Temporal_GreenB'
        d4 = 'Temporal_Blue'

        figTitle = 'Img_Temporal'
        ylabel = 'Temporal (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Img_RowStdDev_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'RowStdDev_GreenR'
        d2 = 'RowStdDev_Red'
        d3 = 'RowStdDev_GreenB'
        d4 = 'RowStdDev_Blue'

        figTitle = 'Img_RowStdDev'
        ylabel = 'RowStdDev(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Img_RowTotalNoise_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'RowTotalNoise_GreenR'
        d2 = 'RowTotalNoise_Red'
        d3 = 'RowTotalNoise_GreenB'
        d4 = 'RowTotalNoise_Blue'

        figTitle = 'Img_RowTotalNoise'
        ylabel = 'RowTotalNoise(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Img_RowFPN_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'RowFPN_GreenR'
        d2 = 'RowFPN_Red'
        d3 = 'RowFPN_GreenB'
        d4 = 'RowFPN_Blue'

        figTitle = 'Img_RowFPN'
        ylabel = 'RowFPN(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Img_RowTempNoise_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'RowTempNoise_GreenR'
        d2 = 'RowTempNoise_Red'
        d3 = 'RowTempNoise_GreenB'
        d4 = 'RowTempNoise_Blue'

        figTitle = 'Img_RowTempNoise'
        ylabel = 'RowTempNoise(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Img_ColStdDev_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ColStdDev_GreenR'
        d2 = 'ColStdDev_Red'
        d3 = 'ColStdDev_GreenB'
        d4 = 'ColStdDev_Blue'

        figTitle = 'Img_ColStdDev'
        ylabel = 'ColStdDev(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Img_ColTotalNoise_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ColTotalNoise_GreenR'
        d2 = 'ColTotalNoise_Red'
        d3 = 'ColTotalNoise_GreenB'
        d4 = 'ColTotalNoise_Blue'

        figTitle = 'Img_ColTotalNoise'
        ylabel = 'ColTotalNoise(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Img_ColFPN_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ColFPN_GreenR'
        d2 = 'ColFPN_Red'
        d3 = 'ColFPN_GreenB'
        d4 = 'ColFPN_Blue'

        figTitle = 'Img_ColFPN'
        ylabel = 'ColFPN(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Img_ColTempNoise_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ColTempNoise_GreenR'
        d2 = 'ColTempNoise_Red'
        d3 = 'ColTempNoise_GreenB'
        d4 = 'ColTempNoise_Blue'

        figTitle = 'Img_ColTempNoise'
        ylabel = 'ColTempNoise(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Img_Flicker_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'Flicker_GreenR'
        d2 = 'Flicker_Red'
        d3 = 'Flicker_GreenB'
        d4 = 'Flicker_Blue'

        figTitle = 'Img_Flicker'
        ylabel = 'Flicker(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Img_PixelTotalNoise_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'PixelTotalNoise_GreenR'
        d2 = 'PixelTotalNoise_Red'
        d3 = 'PixelTotalNoise_GreenB'
        d4 = 'PixelTotalNoise_Blue'

        figTitle = 'Img_PixelTotalNoise'
        ylabel = 'PixelTotalNoise(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Img_PixelTemporalNoise_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'PixelTemporalNoise_GreenR'
        d2 = 'PixelTemporalNoise_Red'
        d3 = 'PixelTemporalNoise_GreenB'
        d4 = 'PixelTemporalNoise_Blue'

        figTitle = 'Img_PixelTemporalNoise'
        ylabel = 'PixelTemporalNoise(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Img_PixelFPN_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'PixelFPN_GreenR'
        d2 = 'PixelFPN_Red'
        d3 = 'PixelFPN_GreenB'
        d4 = 'PixelFPN_Blue'

        figTitle = 'Img_PixelFPN'
        ylabel = 'PixelFPN(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Img_RowTemporalNoiseRatio_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'RowTemporalNoiseRatio_GreenR'
        d2 = 'RowTemporalNoiseRatio_Red'
        d3 = 'RowTemporalNoiseRatio_GreenB'
        d4 = 'RowTemporalNoiseRatio_Blue'

        figTitle = 'Img_RowTemporalNoiseRatio'
        ylabel = 'RowTemporalNoiseRatio(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Img_ColumnTemporalNoiseRatio_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ColumnTemporalNoiseRatio_GreenR'
        d2 = 'ColumnTemporalNoiseRatio_Red'
        d3 = 'ColumnTemporalNoiseRatio_GreenB'
        d4 = 'ColumnTemporalNoiseRatio_Blue'

        figTitle = 'Img_ColumnTemporalNoiseRatio'
        ylabel = 'ColumnTemporalNoiseRatio(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Img_RowFPNRatio_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'RowFPNRatio_GreenR'
        d2 = 'RowFPNRatio_Red'
        d3 = 'RowFPNRatio_GreenB'
        d4 = 'RowFPNRatio_Blue'

        figTitle = 'Img_RowFPNRatio'
        ylabel = 'RowFPNRatio(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Img_ColumnFPNRatio_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ColumnFPNRatio_GreenR'
        d2 = 'ColumnFPNRatio_Red'
        d3 = 'ColumnFPNRatio_GreenB'
        d4 = 'ColumnFPNRatio_Blue'

        figTitle = 'Img_ColumnFPNRatio'
        ylabel = 'ColumnFPNRatio(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

# RGN STATSdef Rgn_Mean_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'Rgn_Mean_GreenR'
        d2 = 'Rgn_Mean_Red'
        d3 = 'Rgn_Mean_GreenB'
        d4 = 'Rgn_Mean_Blue'

        figTitle = 'Rgn_Mean'
        ylabel = 'Mean (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Rgn_StdDev_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'Rgn_StdDev_GreenR'
        d2 = 'Rgn_StdDev_Red'
        d3 = 'Rgn_StdDev_GreenB'
        d4 = 'Rgn_StdDev_Blue'

        figTitle = 'Rgn_StdDev'
        ylabel = 'StdDev (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Rgn_TotalNoise_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'Rgn_TotalNoise_Blue'
        d2 = 'Rgn_TotalNoise_GreenB'
        d3 = 'Rgn_TotalNoise_Red'
        d4 = 'Rgn_TotalNoise_GreenR'

        figTitle = 'Rgn_TotalNoise'
        ylabel = 'TotalNoise (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Rgn_FPN_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'Rgn_FPN_Blue'
        d2 = 'Rgn_FPN_GreenB'
        d3 = 'Rgn_FPN_Red'
        d4 = 'Rgn_FPN_GreenR'

        figTitle = 'Rgn_FPN'
        ylabel = 'FPN (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Rgn_Temporal_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'Rgn_Temporal_Blue'
        d2 = 'Rgn_Temporal_GreenB'
        d3 = 'Rgn_Temporal_Red'
        d4 = 'Rgn_Temporal_GreenR'

        figTitle = 'Rgn_Temporal'
        ylabel = 'Temporal (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Rgn_RowStdDev_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'Rgn_RowStdDev_Blue'
        d2 = 'Rgn_RowStdDev_GreenB'
        d3 = 'Rgn_RowStdDev_Red'
        d4 = 'Rgn_RowStdDev_GreenR'

        figTitle = 'Rgn_RowStdDev'
        ylabel = 'RowStdDev (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Rgn_RowTotalNoise_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'Rgn_RowTotalNoise_Blue'
        d2 = 'Rgn_RowTotalNoise_GreenB'
        d3 = 'Rgn_RowTotalNoise_Red'
        d4 = 'Rgn_RowTotalNoise_GreenR'

        figTitle = 'Rgn_RowTotalNoise'
        ylabel = 'RowTotalNoise (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Rgn_RowFPN_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'Rgn_RowFPN_Blue'
        d2 = 'Rgn_RowFPN_GreenB'
        d3 = 'Rgn_RowFPN_Red'
        d4 = 'Rgn_RowFPN_GreenR'

        figTitle = 'Rgn_RowFPN'
        ylabel = 'RowFPN (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Rgn_RowTempNoise_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'Rgn_RowTempNoise_Blue'
        d2 = 'Rgn_RowTempNoise_GreenB'
        d3 = 'Rgn_RowTempNoise_Red'
        d4 = 'Rgn_RowTempNoise_GreenR'

        figTitle = 'Rgn_RowTempNoise'
        ylabel = 'RowTempNoise (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Rgn_ColStdDev_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'Rgn_ColStdDev_Blue'
        d2 = 'Rgn_ColStdDev_GreenB'
        d3 = 'Rgn_ColStdDev_Red'
        d4 = 'Rgn_ColStdDev_GreenR'

        figTitle = 'Rgn_ColStdDev'
        ylabel = 'ColStdDev (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Rgn_ColTotalNoise_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'Rgn_ColTotalNoise_Blue'
        d2 = 'Rgn_ColTotalNoise_GreenB'
        d3 = 'Rgn_ColTotalNoise_Red'
        d4 = 'Rgn_ColTotalNoise_GreenR'

        figTitle = 'Rgn_ColTotalNoise'
        ylabel = 'ColTotalNoise (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Rgn_ColFPN_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'Rgn_ColFPN_Blue'
        d2 = 'Rgn_ColFPN_GreenB'
        d3 = 'Rgn_ColFPN_Red'
        d4 = 'Rgn_ColFPN_GreenR'

        figTitle = 'Rgn_ColFPN'
        ylabel = 'ColFPN (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Rgn_ColTempNoise_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'Rgn_ColTempNoise_Blue'
        d2 = 'Rgn_ColTempNoise_GreenB'
        d3 = 'Rgn_ColTempNoise_Red'
        d4 = 'Rgn_ColTempNoise_GreenR'

        figTitle = 'Rgn_ColTempNoise'
        ylabel = 'ColTempNoise (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Rgn_Flicker_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'Rgn_Flicker_Blue'
        d2 = 'Rgn_Flicker_GreenB'
        d3 = 'Rgn_Flicker_Red'
        d4 = 'Rgn_Flicker_GreenR'

        figTitle = 'Rgn_Flicker'
        ylabel = 'Flicker (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Rgn_PixelTotalNoise_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'Rgn_PixelTotalNoise_GreenR'
        d2 = 'Rgn_PixelTotalNoise_Red'
        d3 = 'Rgn_PixelTotalNoise_GreenB'
        d4 = 'Rgn_PixelTotalNoise_Blue'

        figTitle = 'Rgn_PixelTotalNoise'
        ylabel = 'PixelTotalNoise(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Rgn_PixelTemporalNoise_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'Rgn_PixelTemporalNoise_GreenR'
        d2 = 'Rgn_PixelTemporalNoise_Red'
        d3 = 'Rgn_PixelTemporalNoise_GreenB'
        d4 = 'Rgn_PixelTemporalNoise_Blue'

        figTitle = 'Rgn_PixelTemporalNoise'
        ylabel = 'PixelTemporalNoise(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Rgn_PixelFPN_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'Rgn_PixelFPN_GreenR'
        d2 = 'Rgn_PixelFPN_Red'
        d3 = 'Rgn_PixelFPN_GreenB'
        d4 = 'Rgn_PixelFPN_Blue'

        figTitle = 'Rgn_PixelFPN'
        ylabel = 'PixelFPN(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Rgn_RowTemporalNoiseRatio_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'Rgn_RowTemporalNoiseRatio_GreenR'
        d2 = 'Rgn_RowTemporalNoiseRatio_Red'
        d3 = 'Rgn_RowTemporalNoiseRatio_GreenB'
        d4 = 'Rgn_RowTemporalNoiseRatio_Blue'

        figTitle = 'Rgn_RowTemporalNoiseRatio'
        ylabel = 'RowTemporalNoiseRatio(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Rgn_ColumnTemporalNoiseRatio_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'Rgn_ColumnTemporalNoiseRatio_GreenR'
        d2 = 'Rgn_ColumnTemporalNoiseRatio_Red'
        d3 = 'Rgn_ColumnTemporalNoiseRatio_GreenB'
        d4 = 'Rgn_ColumnTemporalNoiseRatio_Blue'

        figTitle = 'Rgn_ColumnTemporalNoiseRatio'
        ylabel = 'ColumnTemporalNoiseRatio(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Rgn_RowFPNRatio_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'Rgn_RowFPNRatio_GreenR'
        d2 = 'Rgn_RowFPNRatio_Red'
        d3 = 'Rgn_RowFPNRatio_GreenB'
        d4 = 'Rgn_RowFPNRatio_Blue'

        figTitle = 'Rgn_RowFPNRatio'
        ylabel = 'RowFPNRatio(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def Rgn_ColumnFPNRatio_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'Rgn_ColumnFPNRatio_GreenR'
        d2 = 'Rgn_ColumnFPNRatio_Red'
        d3 = 'Rgn_ColumnFPNRatio_GreenB'
        d4 = 'Rgn_ColumnFPNRatio_Blue'

        figTitle = 'Rgn_ColumnFPNRatio'
        ylabel = 'ColumnFPNRatio(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found


'''
Full-Res vs Single Register Plots
'''

def Reg_vs_Img_Mean_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'Mean_GreenR'
        d2 = 'Mean_Red'
        d3 = 'Mean_GreenB'
        d4 = 'Mean_Blue'

        figTitle = 'Register_vs_ImgMean'
        xlabel = register
        ylabel = 'Mean (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
def Reg_vs_Img_StdDev_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'StdDev_GreenR'
        d2 = 'StdDev_Red'
        d3 = 'StdDev_GreenB'
        d4 = 'StdDev_Blue'

        figTitle = 'Register_vs_ImgStdDev'
        xlabel = register
        ylabel = 'StdDev (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_Img_TotalNoise_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'TotalNoise_GreenR'
        d2 = 'TotalNoise_Red'
        d3 = 'TotalNoise_GreenB'
        d4 = 'TotalNoise_Blue'

        figTitle = 'Register_vs_Img_TotalNoise'
        xlabel = register
        ylabel = 'TotalNoise (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_Img_FPN_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'FPN_GreenR'
        d2 = 'FPN_Red'
        d3 = 'FPN_GreenB'
        d4 = 'FPN_Blue'

        figTitle = 'Register_vs_Img_FPN'
        xlabel = register
        ylabel = 'FPN (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_Img_Temporal_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'Temporal_GreenR'
        d2 = 'Temporal_Red'
        d3 = 'Temporal_GreenB'
        d4 = 'Temporal_Blue'

        figTitle = 'Register_vs_Img_Temporal'
        xlabel = register
        ylabel = 'Temporal (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_Img_RowStdDev_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'RowStdDev_GreenR'
        d2 = 'RowStdDev_Red'
        d3 = 'RowStdDev_GreenB'
        d4 = 'RowStdDev_Blue'

        figTitle = 'Register_vs_Img_RowStdDev'
        xlabel = register
        ylabel = 'RowStdDev(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_Img_RowTotalNoise_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'RowTotalNoise_GreenR'
        d2 = 'RowTotalNoise_Red'
        d3 = 'RowTotalNoise_GreenB'
        d4 = 'RowTotalNoise_Blue'

        figTitle = 'Register_vs_Img_RowTotalNoise'
        xlabel = register
        ylabel = 'RowTotalNoise(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_Img_RowFPN_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'RowFPN_GreenR'
        d2 = 'RowFPN_Red'
        d3 = 'RowFPN_GreenB'
        d4 = 'RowFPN_Blue'

        figTitle = 'Register_vs_Img_RowFPN'
        xlabel = register
        ylabel = 'RowFPN(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_Img_RowTempNoise_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'RowTempNoise_GreenR'
        d2 = 'RowTempNoise_Red'
        d3 = 'RowTempNoise_GreenB'
        d4 = 'RowTempNoise_Blue'

        figTitle = 'Register_vs_Img_RowTempNoise'
        xlabel = register
        ylabel = 'RowTempNoise(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_Img_ColStdDev_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'ColStdDev_GreenR'
        d2 = 'ColStdDev_Red'
        d3 = 'ColStdDev_GreenB'
        d4 = 'ColStdDev_Blue'

        figTitle = 'Register_vs_Img_ColStdDev'
        xlabel = register
        ylabel = 'ColStdDev(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_Img_ColTotalNoise_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'ColTotalNoise_GreenR'
        d2 = 'ColTotalNoise_Red'
        d3 = 'ColTotalNoise_GreenB'
        d4 = 'ColTotalNoise_Blue'

        figTitle = 'Register_vs_Img_ColTotalNoise'
        xlabel = register
        ylabel = 'ColTotalNoise(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_Img_ColFPN_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'ColFPN_GreenR'
        d2 = 'ColFPN_Red'
        d3 = 'ColFPN_GreenB'
        d4 = 'ColFPN_Blue'

        figTitle = 'Register_vs_Img_ColFPN'
        xlabel = register
        ylabel = 'ColFPN(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_Img_ColTempNoise_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'ColTempNoise_GreenR'
        d2 = 'ColTempNoise_Red'
        d3 = 'ColTempNoise_GreenB'
        d4 = 'ColTempNoise_Blue'

        figTitle = 'Register_vs_Img_ColTempNoise'
        xlabel = register
        ylabel = 'ColTempNoise(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_Img_Flicker_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'Flicker_GreenR'
        d2 = 'Flicker_Red'
        d3 = 'Flicker_GreenB'
        d4 = 'Flicker_Blue'

        figTitle = 'Register_vs_Img_Flicker'
        xlabel = register
        ylabel = 'Flicker(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_Img_PixelTotalNoise_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'PixelTotalNoise_GreenR'
        d2 = 'PixelTotalNoise_Red'
        d3 = 'PixelTotalNoise_GreenB'
        d4 = 'PixelTotalNoise_Blue'

        figTitle = 'Register_vs_Img_PixelTotalNoise'
        xlabel = register
        ylabel = 'PixelTotalNoise(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_Img_PixelTemporalNoise_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'PixelTemporalNoise_GreenR'
        d2 = 'PixelTemporalNoise_Red'
        d3 = 'PixelTemporalNoise_GreenB'
        d4 = 'PixelTemporalNoise_Blue'

        figTitle = 'Register_vs_Img_PixelTemporalNoise'
        xlabel = register
        ylabel = 'PixelTemporalNoise(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_Img_PixelFPN_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'PixelFPN_GreenR'
        d2 = 'PixelFPN_Red'
        d3 = 'PixelFPN_GreenB'
        d4 = 'PixelFPN_Blue'

        figTitle = 'Register_vs_Img_PixelFPN'
        xlabel = register
        ylabel = 'PixelFPN(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_Img_RowTemporalNoiseRatio_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'RowTemporalNoiseRatio_GreenR'
        d2 = 'RowTemporalNoiseRatio_Red'
        d3 = 'RowTemporalNoiseRatio_GreenB'
        d4 = 'RowTemporalNoiseRatio_Blue'

        figTitle = 'Register_vs_Img_RowTemporalNoiseRatio'
        xlabel = register
        ylabel = 'RowTemporalNoiseRatio(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_Img_ColumnTemporalNoiseRatio_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'ColumnTemporalNoiseRatio_GreenR'
        d2 = 'ColumnTemporalNoiseRatio_Red'
        d3 = 'ColumnTemporalNoiseRatio_GreenB'
        d4 = 'ColumnTemporalNoiseRatio_Blue'

        figTitle = 'Register_vs_Img_ColumnTemporalNoiseRatio'
        xlabel = register
        ylabel = 'ColumnTemporalNoiseRatio(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_Img_RowFPNRatio_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'RowFPNRatio_GreenR'
        d2 = 'RowFPNRatio_Red'
        d3 = 'RowFPNRatio_GreenB'
        d4 = 'RowFPNRatio_Blue'

        figTitle = 'Register_vs_Img_RowFPNRatio'
        xlabel = register
        ylabel = 'RowFPNRatio(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_Img_ColumnFPNRatio_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'ColumnFPNRatio_GreenR'
        d2 = 'ColumnFPNRatio_Red'
        d3 = 'ColumnFPNRatio_GreenB'
        d4 = 'ColumnFPNRatio_Blue'

        figTitle = 'Register_vs_Img_ColumnFPNRatio'
        xlabel = register
        ylabel = 'ColumnFPNRatio(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report



    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found


'''
Region vs Single Register Plots
'''
def Reg_vs_Rgn_Mean_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'Rgn_Mean_GreenR'
        d2 = 'Rgn_Mean_Red'
        d3 = 'Rgn_Mean_GreenB'
        d4 = 'Rgn_Mean_Blue'

        figTitle = 'Register_vs_RgnMean'
        xlabel = register
        ylabel = 'Mean (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_Rgn_StdDev_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'Rgn_StdDev_GreenR'
        d2 = 'Rgn_StdDev_Red'
        d3 = 'Rgn_StdDev_GreenB'
        d4 = 'Rgn_StdDev_Blue'

        figTitle = 'Register_vs_RgnStdDev'
        xlabel = register
        ylabel = 'StdDev (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_Rgn_TotalNoise_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'Rgn_TotalNoise_Blue'
        d2 = 'Rgn_TotalNoise_GreenB'
        d3 = 'Rgn_TotalNoise_Red'
        d4 = 'Rgn_TotalNoise_GreenR'

        figTitle = 'Register_vs_Rgn_TotalNoise'
        xlabel = register
        ylabel = 'TotalNoise (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_Rgn_FPN_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'Rgn_FPN_Blue'
        d2 = 'Rgn_FPN_GreenB'
        d3 = 'Rgn_FPN_Red'
        d4 = 'Rgn_FPN_GreenR'

        figTitle = 'Register_vs_Rgn_FPN'
        xlabel = register
        ylabel = 'FPN (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_Rgn_Temporal_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'Rgn_Temporal_Blue'
        d2 = 'Rgn_Temporal_GreenB'
        d3 = 'Rgn_Temporal_Red'
        d4 = 'Rgn_Temporal_GreenR'

        figTitle = 'Register_vs_Rgn_Temporal'
        xlabel = register
        ylabel = 'Temporal (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_Rgn_RowStdDev_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'Rgn_RowStdDev_Blue'
        d2 = 'Rgn_RowStdDev_GreenB'
        d3 = 'Rgn_RowStdDev_Red'
        d4 = 'Rgn_RowStdDev_GreenR'

        figTitle = 'Register_vs_Rgn_RowStdDev'
        xlabel = register
        ylabel = 'RowStdDev (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_Rgn_RowTotalNoise_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'Rgn_RowTotalNoise_Blue'
        d2 = 'Rgn_RowTotalNoise_GreenB'
        d3 = 'Rgn_RowTotalNoise_Red'
        d4 = 'Rgn_RowTotalNoise_GreenR'

        figTitle = 'Register_vs_Rgn_RowTotalNoise'
        xlabel = register
        ylabel = 'RowTotalNoise (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_Rgn_RowFPN_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'Rgn_RowFPN_Blue'
        d2 = 'Rgn_RowFPN_GreenB'
        d3 = 'Rgn_RowFPN_Red'
        d4 = 'Rgn_RowFPN_GreenR'

        figTitle = 'Register_vs_Rgn_RowFPN'
        xlabel = register
        ylabel = 'RowFPN (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_Rgn_RowTempNoise_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'Rgn_RowTempNoise_Blue'
        d2 = 'Rgn_RowTempNoise_GreenB'
        d3 = 'Rgn_RowTempNoise_Red'
        d4 = 'Rgn_RowTempNoise_GreenR'

        figTitle = 'Register_vs_Rgn_RowTempNoise'
        xlabel = register
        ylabel = 'RowTempNoise (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_Rgn_ColStdDev_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'Rgn_ColStdDev_Blue'
        d2 = 'Rgn_ColStdDev_GreenB'
        d3 = 'Rgn_ColStdDev_Red'
        d4 = 'Rgn_ColStdDev_GreenR'

        figTitle = 'Register_vs_Rgn_ColStdDev'
        xlabel = register
        ylabel = 'ColStdDev (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_Rgn_ColTotalNoise_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'Rgn_ColTotalNoise_Blue'
        d2 = 'Rgn_ColTotalNoise_GreenB'
        d3 = 'Rgn_ColTotalNoise_Red'
        d4 = 'Rgn_ColTotalNoise_GreenR'

        figTitle = 'Register_vs_Rgn_ColTotalNoise'
        xlabel = register
        ylabel = 'ColTotalNoise (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_Rgn_ColFPN_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'Rgn_ColFPN_Blue'
        d2 = 'Rgn_ColFPN_GreenB'
        d3 = 'Rgn_ColFPN_Red'
        d4 = 'Rgn_ColFPN_GreenR'

        figTitle = 'Register_vs_Rgn_ColFPN'
        xlabel = register
        ylabel = 'ColFPN (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_Rgn_ColTempNoise_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'Rgn_ColTempNoise_Blue'
        d2 = 'Rgn_ColTempNoise_GreenB'
        d3 = 'Rgn_ColTempNoise_Red'
        d4 = 'Rgn_ColTempNoise_GreenR'

        figTitle = 'Register_vs_Rgn_ColTempNoise'
        xlabel = register
        ylabel = 'ColTempNoise (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_Rgn_Flicker_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'Rgn_Flicker_Blue'
        d2 = 'Rgn_Flicker_GreenB'
        d3 = 'Rgn_Flicker_Red'
        d4 = 'Rgn_Flicker_GreenR'

        figTitle = 'Register_vs_Rgn_Flicker'
        xlabel = register
        ylabel = 'Flicker (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_Rgn_PixelTotalNoise_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'Rgn_PixelTotalNoise_GreenR'
        d2 = 'Rgn_PixelTotalNoise_Red'
        d3 = 'Rgn_PixelTotalNoise_GreenB'
        d4 = 'Rgn_PixelTotalNoise_Blue'

        figTitle = 'Register_vs_Rgn_PixelTotalNoise'
        xlabel = register
        ylabel = 'PixelTotalNoise(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_Rgn_PixelTemporalNoise_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'Rgn_PixelTemporalNoise_GreenR'
        d2 = 'Rgn_PixelTemporalNoise_Red'
        d3 = 'Rgn_PixelTemporalNoise_GreenB'
        d4 = 'Rgn_PixelTemporalNoise_Blue'

        figTitle = 'Register_vs_Rgn_PixelTemporalNoise'
        xlabel = register
        ylabel = 'PixelTemporalNoise(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_Rgn_PixelFPN_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'Rgn_PixelFPN_GreenR'
        d2 = 'Rgn_PixelFPN_Red'
        d3 = 'Rgn_PixelFPN_GreenB'
        d4 = 'Rgn_PixelFPN_Blue'

        figTitle = 'Register_vs_Rgn_PixelFPN'
        xlabel = register
        ylabel = 'PixelFPN(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_Rgn_RowTemporalNoiseRatio_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'Rgn_RowTemporalNoiseRatio_GreenR'
        d2 = 'Rgn_RowTemporalNoiseRatio_Red'
        d3 = 'Rgn_RowTemporalNoiseRatio_GreenB'
        d4 = 'Rgn_RowTemporalNoiseRatio_Blue'

        figTitle = 'Register_vs_Rgn_RowTemporalNoiseRatio'
        xlabel = register
        ylabel = 'RowTemporalNoiseRatio(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_Rgn_ColumnTemporalNoiseRatio_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'Rgn_ColumnTemporalNoiseRatio_GreenR'
        d2 = 'Rgn_ColumnTemporalNoiseRatio_Red'
        d3 = 'Rgn_ColumnTemporalNoiseRatio_GreenB'
        d4 = 'Rgn_ColumnTemporalNoiseRatio_Blue'

        figTitle = 'Register_vs_Rgn_ColumnTemporalNoiseRatio'
        xlabel = register
        ylabel = 'ColumnTemporalNoiseRatio(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_Rgn_RowFPNRatio_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'Rgn_RowFPNRatio_GreenR'
        d2 = 'Rgn_RowFPNRatio_Red'
        d3 = 'Rgn_RowFPNRatio_GreenB'
        d4 = 'Rgn_RowFPNRatio_Blue'

        figTitle = 'Register_vs_Rgn_RowFPNRatio'
        xlabel = register
        ylabel = 'RowFPNRatio(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found

def Reg_vs_Rgn_ColumnFPNRatio_Plot(dataFrame, groupBy, document, pltPath, register, showPlt, **kwargs):
    try:
        d1 = 'Rgn_ColumnFPNRatio_GreenR'
        d2 = 'Rgn_ColumnFPNRatio_Red'
        d3 = 'Rgn_ColumnFPNRatio_GreenB'
        d4 = 'Rgn_ColumnFPNRatio_Blue'

        figTitle = 'Register_vs_Rgn_ColumnFPNRatio'
        xlabel = register
        ylabel = 'ColumnFPNRatio(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_x=xlabel, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found


'''
Full-Res vs Dual Register Plots
'''

def Reg_vs_Reg_vs_Img_Mean_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        d1 = 'Mean_GreenR'
        d2 = 'Mean_Red'
        d3 = 'Mean_GreenB'
        d4 = 'Mean_Blue'

        figTitle = 'Reg_vs_Reg_vs_ImgMean'
        ylabel = 'Mean (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_Img_StdDev_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        d1 = 'StdDev_GreenR'
        d2 = 'StdDev_Red'
        d3 = 'StdDev_GreenB'
        d4 = 'StdDev_Blue'

        figTitle = 'Reg_vs_Reg_vs_ImgStdDev'
        ylabel = 'StdDev (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt, inline=showPlt, label_y=ylabel, title_font_size=titleFontSize,
                         label_x_font_size=xFontsize, label_y_font_size=yFontsize, legend_font_size=legFontSize,
                         legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_Img_TotalNoise_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        d1 = 'TotalNoise_GreenR'
        d2 = 'TotalNoise_Red'
        d3 = 'TotalNoise_GreenB'
        d4 = 'TotalNoise_Blue'

        figTitle = 'Reg_vs_Reg_vs_Img_TotalNoise'
        ylabel = 'TotalNoise (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_Img_FPN_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        d1 = 'FPN_GreenR'
        d2 = 'FPN_Red'
        d3 = 'FPN_GreenB'
        d4 = 'FPN_Blue'

        figTitle = 'Reg_vs_Reg_vs_Img_FPN'
        ylabel = 'FPN (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_Img_Temporal_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        d1 = 'Temporal_GreenR'
        d2 = 'Temporal_Red'
        d3 = 'Temporal_GreenB'
        d4 = 'Temporal_Blue'

        figTitle = 'Reg_vs_Reg_vs_Img_Temporal'
        ylabel = 'Temporal (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_Img_RowStdDev_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        d1 = 'RowStdDev_GreenR'
        d2 = 'RowStdDev_Red'
        d3 = 'RowStdDev_GreenB'
        d4 = 'RowStdDev_Blue'

        figTitle = 'Reg_vs_Reg_vs_Img_RowStdDev'
        ylabel = 'RowStdDev(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_Img_RowTotalNoise_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        d1 = 'RowTotalNoise_GreenR'
        d2 = 'RowTotalNoise_Red'
        d3 = 'RowTotalNoise_GreenB'
        d4 = 'RowTotalNoise_Blue'

        figTitle = 'Reg_vs_Reg_vs_Img_RowTotalNoise'
        ylabel = 'RowTotalNoise(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_Img_RowFPN_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        d1 = 'RowFPN_GreenR'
        d2 = 'RowFPN_Red'
        d3 = 'RowFPN_GreenB'
        d4 = 'RowFPN_Blue'

        figTitle = 'Reg_vs_Reg_vs_Img_RowFPN'
        ylabel = 'RowFPN(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_Img_RowTempNoise_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        d1 = 'RowTempNoise_GreenR'
        d2 = 'RowTempNoise_Red'
        d3 = 'RowTempNoise_GreenB'
        d4 = 'RowTempNoise_Blue'

        figTitle = 'Reg_vs_Reg_vs_Img_RowTempNoise'
        ylabel = 'RowTempNoise(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_Img_ColStdDev_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        d1 = 'ColStdDev_GreenR'
        d2 = 'ColStdDev_Red'
        d3 = 'ColStdDev_GreenB'
        d4 = 'ColStdDev_Blue'

        figTitle = 'Reg_vs_Reg_vs_Img_ColStdDev'
        ylabel = 'ColStdDev(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_Img_ColTotalNoise_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        d1 = 'ColTotalNoise_GreenR'
        d2 = 'ColTotalNoise_Red'
        d3 = 'ColTotalNoise_GreenB'
        d4 = 'ColTotalNoise_Blue'

        figTitle = 'Reg_vs_Reg_vs_Img_ColTotalNoise'
        ylabel = 'ColTotalNoise(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_Img_ColFPN_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        d1 = 'ColFPN_GreenR'
        d2 = 'ColFPN_Red'
        d3 = 'ColFPN_GreenB'
        d4 = 'ColFPN_Blue'

        figTitle = 'Reg_vs_Reg_vs_Img_ColFPN'
        ylabel = 'ColFPN(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_Img_ColTempNoise_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        d1 = 'ColTempNoise_GreenR'
        d2 = 'ColTempNoise_Red'
        d3 = 'ColTempNoise_GreenB'
        d4 = 'ColTempNoise_Blue'

        figTitle = 'Reg_vs_Reg_vs_Img_ColTempNoise'
        ylabel = 'ColTempNoise(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_Img_Flicker_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        d1 = 'Flicker_GreenR'
        d2 = 'Flicker_Red'
        d3 = 'Flicker_GreenB'
        d4 = 'Flicker_Blue'

        figTitle = 'Reg_vs_Reg_vs_Img_Flicker'
        ylabel = 'Flicker(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_Img_PixelTotalNoise_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt,
                                           **kwargs):
    try:
        d1 = 'PixelTotalNoise_GreenR'
        d2 = 'PixelTotalNoise_Red'
        d3 = 'PixelTotalNoise_GreenB'
        d4 = 'PixelTotalNoise_Blue'

        figTitle = 'Reg_vs_Reg_vs_Img_PixelTotalNoise'
        ylabel = 'PixelTotalNoise(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_Img_PixelTemporalNoise_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt,
                                              **kwargs):
    try:
        d1 = 'PixelTemporalNoise_GreenR'
        d2 = 'PixelTemporalNoise_Red'
        d3 = 'PixelTemporalNoise_GreenB'
        d4 = 'PixelTemporalNoise_Blue'

        figTitle = 'Reg_vs_Reg_vs_Img_PixelTemporalNoise'
        ylabel = 'PixelTemporalNoise(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_Img_PixelFPN_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        d1 = 'PixelFPN_GreenR'
        d2 = 'PixelFPN_Red'
        d3 = 'PixelFPN_GreenB'
        d4 = 'PixelFPN_Blue'

        figTitle = 'Reg_vs_Reg_vs_Img_PixelFPN'
        ylabel = 'PixelFPN(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_Img_RowTemporalNoiseRatio_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt,
                                                 **kwargs):
    try:
        d1 = 'RowTemporalNoiseRatio_GreenR'
        d2 = 'RowTemporalNoiseRatio_Red'
        d3 = 'RowTemporalNoiseRatio_GreenB'
        d4 = 'RowTemporalNoiseRatio_Blue'

        figTitle = 'Reg_vs_Reg_vs_Img_RowTemporalNoiseRatio'
        ylabel = 'RowTemporalNoiseRatio(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_Img_ColumnTemporalNoiseRatio_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt,
                                                    **kwargs):
    try:
        d1 = 'ColumnTemporalNoiseRatio_GreenR'
        d2 = 'ColumnTemporalNoiseRatio_Red'
        d3 = 'ColumnTemporalNoiseRatio_GreenB'
        d4 = 'ColumnTemporalNoiseRatio_Blue'

        figTitle = 'Reg_vs_Reg_vs_Img_ColumnTemporalNoiseRatio'
        ylabel = 'ColumnTemporalNoiseRatio(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_Img_RowFPNRatio_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        d1 = 'RowFPNRatio_GreenR'
        d2 = 'RowFPNRatio_Red'
        d3 = 'RowFPNRatio_GreenB'
        d4 = 'RowFPNRatio_Blue'

        figTitle = 'Reg_vs_Reg_vs_Img_RowFPNRatio'
        ylabel = 'RowFPNRatio(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_Img_ColumnFPNRatio_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt,
                                          **kwargs):
    try:
        d1 = 'ColumnFPNRatio_GreenR'
        d2 = 'ColumnFPNRatio_Red'
        d3 = 'ColumnFPNRatio_GreenB'
        d4 = 'ColumnFPNRatio_Blue'

        figTitle = 'Reg_vs_Reg_vs_Img_ColumnFPNRatio'
        ylabel = 'ColumnFPNRatio(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found


'''
Region vs Dual Register Plots
'''

def Reg_vs_Reg_vs_Rgn_Mean_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        d1 = 'Rgn_Mean_GreenR'
        d2 = 'Rgn_Mean_Red'
        d3 = 'Rgn_Mean_GreenB'
        d4 = 'Rgn_Mean_Blue'

        figTitle = 'Reg_vs_Reg_vs_RgnMean'
        ylabel = 'Mean (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_Rgn_StdDev_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        d1 = 'Rgn_StdDev_GreenR'
        d2 = 'Rgn_StdDev_Red'
        d3 = 'Rgn_StdDev_GreenB'
        d4 = 'Rgn_StdDev_Blue'

        figTitle = 'Reg_vs_Reg_vs_RgnStdDev'
        ylabel = 'StdDev (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_Rgn_TotalNoise_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        d1 = 'Rgn_TotalNoise_Blue'
        d2 = 'Rgn_TotalNoise_GreenB'
        d3 = 'Rgn_TotalNoise_Red'
        d4 = 'Rgn_TotalNoise_GreenR'

        figTitle = 'Reg_vs_Reg_vs_Rgn_TotalNoise'
        ylabel = 'TotalNoise (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_Rgn_FPN_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        d1 = 'Rgn_FPN_Blue'
        d2 = 'Rgn_FPN_GreenB'
        d3 = 'Rgn_FPN_Red'
        d4 = 'Rgn_FPN_GreenR'

        figTitle = 'Reg_vs_Reg_vs_Rgn_FPN'
        ylabel = 'FPN (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_Rgn_Temporal_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        d1 = 'Rgn_Temporal_Blue'
        d2 = 'Rgn_Temporal_GreenB'
        d3 = 'Rgn_Temporal_Red'
        d4 = 'Rgn_Temporal_GreenR'

        figTitle = 'Reg_vs_Reg_vs_Rgn_Temporal'
        ylabel = 'Temporal (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_Rgn_RowStdDev_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        d1 = 'Rgn_RowStdDev_Blue'
        d2 = 'Rgn_RowStdDev_GreenB'
        d3 = 'Rgn_RowStdDev_Red'
        d4 = 'Rgn_RowStdDev_GreenR'

        figTitle = 'Reg_vs_Reg_vs_Rgn_RowStdDev'
        ylabel = 'RowStdDev (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_Rgn_RowTotalNoise_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        d1 = 'Rgn_RowTotalNoise_Blue'
        d2 = 'Rgn_RowTotalNoise_GreenB'
        d3 = 'Rgn_RowTotalNoise_Red'
        d4 = 'Rgn_RowTotalNoise_GreenR'

        figTitle = 'Reg_vs_Reg_vs_Rgn_RowTotalNoise'
        ylabel = 'RowTotalNoise (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_Rgn_RowFPN_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        d1 = 'Rgn_RowFPN_Blue'
        d2 = 'Rgn_RowFPN_GreenB'
        d3 = 'Rgn_RowFPN_Red'
        d4 = 'Rgn_RowFPN_GreenR'

        figTitle = 'Reg_vs_Reg_vs_Rgn_RowFPN'
        ylabel = 'RowFPN (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_Rgn_RowTempNoise_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        d1 = 'Rgn_RowTempNoise_Blue'
        d2 = 'Rgn_RowTempNoise_GreenB'
        d3 = 'Rgn_RowTempNoise_Red'
        d4 = 'Rgn_RowTempNoise_GreenR'

        figTitle = 'Reg_vs_Reg_vs_Rgn_RowTempNoise'
        ylabel = 'RowTempNoise (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_Rgn_ColStdDev_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        d1 = 'Rgn_ColStdDev_Blue'
        d2 = 'Rgn_ColStdDev_GreenB'
        d3 = 'Rgn_ColStdDev_Red'
        d4 = 'Rgn_ColStdDev_GreenR'

        figTitle = 'Reg_vs_Reg_vs_Rgn_ColStdDev'
        ylabel = 'ColStdDev (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_Rgn_ColTotalNoise_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        d1 = 'Rgn_ColTotalNoise_Blue'
        d2 = 'Rgn_ColTotalNoise_GreenB'
        d3 = 'Rgn_ColTotalNoise_Red'
        d4 = 'Rgn_ColTotalNoise_GreenR'

        figTitle = 'Reg_vs_Reg_vs_Rgn_ColTotalNoise'
        ylabel = 'ColTotalNoise (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_Rgn_ColFPN_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        d1 = 'Rgn_ColFPN_Blue'
        d2 = 'Rgn_ColFPN_GreenB'
        d3 = 'Rgn_ColFPN_Red'
        d4 = 'Rgn_ColFPN_GreenR'

        figTitle = 'Reg_vs_Reg_vs_Rgn_ColFPN'
        ylabel = 'ColFPN (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_Rgn_ColTempNoise_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        d1 = 'Rgn_ColTempNoise_Blue'
        d2 = 'Rgn_ColTempNoise_GreenB'
        d3 = 'Rgn_ColTempNoise_Red'
        d4 = 'Rgn_ColTempNoise_GreenR'

        figTitle = 'Reg_vs_Reg_vs_Rgn_ColTempNoise'
        ylabel = 'ColTempNoise (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_Rgn_Flicker_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        d1 = 'Rgn_Flicker_Blue'
        d2 = 'Rgn_Flicker_GreenB'
        d3 = 'Rgn_Flicker_Red'
        d4 = 'Rgn_Flicker_GreenR'

        figTitle = 'Reg_vs_Reg_vs_Rgn_Flicker'
        ylabel = 'Flicker (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_Rgn_PixelTotalNoise_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt,
                                           **kwargs):
    try:
        d1 = 'Rgn_PixelTotalNoise_GreenR'
        d2 = 'Rgn_PixelTotalNoise_Red'
        d3 = 'Rgn_PixelTotalNoise_GreenB'
        d4 = 'Rgn_PixelTotalNoise_Blue'

        figTitle = 'Reg_vs_Reg_vs_Rgn_PixelTotalNoise'
        ylabel = 'PixelTotalNoise(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_Rgn_PixelTemporalNoise_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt,
                                              **kwargs):
    try:
        d1 = 'Rgn_PixelTemporalNoise_GreenR'
        d2 = 'Rgn_PixelTemporalNoise_Red'
        d3 = 'Rgn_PixelTemporalNoise_GreenB'
        d4 = 'Rgn_PixelTemporalNoise_Blue'

        figTitle = 'Reg_vs_Reg_vs_Rgn_PixelTemporalNoise'
        ylabel = 'PixelTemporalNoise(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_Rgn_PixelFPN_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        d1 = 'Rgn_PixelFPN_GreenR'
        d2 = 'Rgn_PixelFPN_Red'
        d3 = 'Rgn_PixelFPN_GreenB'
        d4 = 'Rgn_PixelFPN_Blue'

        figTitle = 'Reg_vs_Reg_vs_Rgn_PixelFPN'
        ylabel = 'PixelFPN(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_Rgn_RowTemporalNoiseRatio_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt,
                                                 **kwargs):
    try:
        d1 = 'Rgn_RowTemporalNoiseRatio_GreenR'
        d2 = 'Rgn_RowTemporalNoiseRatio_Red'
        d3 = 'Rgn_RowTemporalNoiseRatio_GreenB'
        d4 = 'Rgn_RowTemporalNoiseRatio_Blue'

        figTitle = 'Reg_vs_Reg_vs_Rgn_RowTemporalNoiseRatio'
        ylabel = 'RowTemporalNoiseRatio(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_Rgn_ColumnTemporalNoiseRatio_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt,
                                                    **kwargs):
    try:
        d1 = 'Rgn_ColumnTemporalNoiseRatio_GreenR'
        d2 = 'Rgn_ColumnTemporalNoiseRatio_Red'
        d3 = 'Rgn_ColumnTemporalNoiseRatio_GreenB'
        d4 = 'Rgn_ColumnTemporalNoiseRatio_Blue'

        figTitle = 'Reg_vs_Reg_vs_Rgn_ColumnTemporalNoiseRatio'
        ylabel = 'ColumnTemporalNoiseRatio(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_Rgn_RowFPNRatio_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt, **kwargs):
    try:
        d1 = 'Rgn_RowFPNRatio_GreenR'
        d2 = 'Rgn_RowFPNRatio_Red'
        d3 = 'Rgn_RowFPNRatio_GreenB'
        d4 = 'Rgn_RowFPNRatio_Blue'

        figTitle = 'Reg_vs_Reg_vs_Rgn_RowFPNRatio'
        ylabel = 'RowFPNRatio(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found

def Reg_vs_Reg_vs_Rgn_ColumnFPNRatio_Plot(dataFrame, groupBy, document, pltPath, register, register2, showPlt,
                                          **kwargs):
    try:
        d1 = 'Rgn_ColumnFPNRatio_GreenR'
        d2 = 'Rgn_ColumnFPNRatio_Red'
        d3 = 'Rgn_ColumnFPNRatio_GreenB'
        d4 = 'Rgn_ColumnFPNRatio_Blue'

        figTitle = 'Reg_vs_Reg_vs_Rgn_ColumnFPNRatio'
        ylabel = 'ColumnFPNRatio(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            for x in range(1, numDataCols):  # 1 to 4
                # Plot each data frame column
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=register2, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=register2, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=register, y=eval("d" + str(x)), title=eval("d" + str(x)), legend=[register2, groupBy],
                         show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(register + ' vs. ' + register2 + ' vs. ' + eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
            fcp.plot(df, x=register, y=[d1, d2, d3, d4], title=figTitle, legend=[register2, groupBy], show=showPlt,
                     inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
            document.add_heading(register + ' vs. ' + register2 + ' vs. ' + d1 + ' ' + d2 + ' ' + d3 + ' ' + d4,
                                 level=3)
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found
        if register2 in df.columns:
            document.add_heading("register2 Found: " + register2, level=3)  # Add register found
        else:
            document.add_heading("register2 Not Found: " + register2, level=3)  # Add register not found