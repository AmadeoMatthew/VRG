import matplotlib
import matplotlib.pyplot as plt
from matplotlib import pyplot
from docx import Document
from docx.shared import Inches
from docx.shared import Pt
from tkinter import *
from tkinter import filedialog
from tkinter import messagebox
import numpy as np
import csv
import argparse
import os
import pandas as pd
import pixelcrunch as pc
import fivecentplots as fcp
import bokeh
import sys
import io
import multiprocessing
import VRG_Safety_Data
import VRG_Calculate
import VRG_Data_Frame
import VRG_Doc
import VRG_General_Data
import VRG_Image_Analysis
import VRG_Image_Utils
import VRG_Macro_Data
import VRG_OTPM_Data
import VRG_Pins_Data
import VRG_Power_Data
import VRG_Register_Data
import VRG_Stats_Arr
import VRG_Stats_ArrCenter
import VRG_Stats_ArrQuad1
import VRG_Stats_ArrQuad2
import VRG_Stats_ArrQuad3
import VRG_Stats_ArrQuad4
import VRG_Stats_ArrRoi1
import VRG_Stats_ArrRoi2
import VRG_Stats_ArrRoi3
import VRG_Stats_ArrRoi4
import VRG_Stats_ArrRoi5
import VRG_Stats_ArrRoi6
import VRG_Stats_ArrRoi7
import VRG_Stats_ArrRoi8
import VRG_Stats_ArrRoi9
import VRG_Stats_DBLC
import VRG_Stats_Frame
import VRG_Stats_Lag
import VRG_Stats_RNC
import VRG_Stats_Tilt
import VRG_Tempsensor_Data
import VRG_Reports
import time
def KWARGS_EX1(df, document, imgPath, pltPath):  # Custom Test Code
    showPlt = True  # Show Plots (T/F)
    temp = 'TemperatureSetPoint' # Group Plots by Temperatures
    die = 'Die' # Group Plots by Die
    intTime = 'RegWr00_COARSE_INTEGRATION_TIME_'
    nomIntTime = 934
    digGain = 'RegWr01_GLOBAL_GAIN'
    nomDigGain = 128
    anaGain = 'DVM_3_09_Analog_Gain'
    nomAnaGain = 1.11

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[intTime].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))# closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)
        df_digGainN = VRG_Data_Frame.newdataframe(df_img, digGain, nomDigGain)
        df_anaGainN = VRG_Data_Frame.newdataframe(df_digGainN, anaGain, nomAnaGain)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Image Statistics vs. Nominal Digital & Analog Gain vs. Integration time', level=2)
        VRG_ImageData.Img_Mean_Plot(df_img, intTime, document, pltPath, showPlt, row=digGain, ax_size=[225, 225], ax_hlines=[600])

def KWARGS_EX2(df, document, imgPath, pltPath):  # Custom Test Code
    showPlt = True  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    intTime = 'RegWr00_COARSE_INTEGRATION_TIME_'
    nomIntTime = 934
    digGain = 'RegWr01_GLOBAL_GAIN'
    nomDigGain = 128
    anaGain = 'DVM_3_09_Analog_Gain'
    nomAnaGain = 1.11

    kwargs = {}
    kwargs['row'] = digGain

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[intTime].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)
        df_digGainN = VRG_Data_Frame.newdataframe(df_img, digGain, nomDigGain)
        df_anaGainN = VRG_Data_Frame.newdataframe(df_digGainN, anaGain, nomAnaGain)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Image Statistics vs. Nominal Digital & Analog Gain vs. Integration time',
                             level=2)
        VRG_ImageData.Img_Mean_Plot(df_img, intTime, document, pltPath, showPlt, **kwargs)

def DV_1_01_POWER_UP_SEQUENCE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    powerSeq = 'DVM_Nom_PowerUp_Test'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('ASIL Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # All Data
    document.add_heading('Combined Data' + ' Standby Power & Current vs. Power-Up Sequence')
    VRG_Power_Data.Standby_Power_Consumption_Plot(df, [die, temp, powerSeq], document, pltPath, showPlt)
    VRG_Power_Data.Standby_Current_Consumption_Plot(df, [die, temp, powerSeq], document, pltPath, showPlt)
    document.add_heading('Combined Data' + ' Operating Power & Current vs. Power-Up Sequence')
    VRG_Power_Data.Power_Consumption_Plot(df, [die, temp, powerSeq], document, pltPath, showPlt)
    VRG_Power_Data.Current_Consumption_Plot(df, [die, temp, powerSeq], document, pltPath, showPlt)


    document.add_heading('Combined Data' + ' Img Mean vs Power-Up Sequence')
    VRG_Stats_Frame.Img_Mean_Plot(df, [die, temp, powerSeq], document, pltPath, showPlt)
    document.add_heading('Combined Data' + ' Img StdDev vs Power-Up Sequence')
    VRG_Stats_Frame.Img_StdDev_Plot(df, [die, temp, powerSeq], document, pltPath, showPlt)
    document.add_heading('Combined Data' + ' Frame Rate vs Power-Up Sequence')
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp, powerSeq], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[powerSeq].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Standby Power & Current vs. Power-Up Sequence', level=2)
        VRG_Power_Data.Standby_Power_Consumption_Plot(df_img, [die, temp, powerSeq], document, pltPath, showPlt)
        VRG_Power_Data.Standby_Current_Consumption_Plot(df_img, [die, temp, powerSeq], document, pltPath, showPlt)
        document.add_heading(i + ' Operating Power & Current vs. Power-Up Sequence', level=2)
        VRG_Power_Data.Power_Consumption_Plot(df_img, [die, temp, powerSeq], document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, [die, temp, powerSeq], document, pltPath, showPlt)

        document.add_heading(i + ' Img Mean vs Power-Up Sequence', level=2)
        VRG_Stats_Frame.Img_Mean_Plot(df_img, [die, temp, powerSeq], document, pltPath, showPlt)
        document.add_heading(i + ' Img StdDev vs Power-Up Sequence', level=2)
        VRG_Stats_Frame.Img_StdDev_Plot(df_img, [die, temp, powerSeq], document, pltPath, showPlt)
        document.add_heading(i + ' Frame Rate vs Power-Up Sequence', level=2)
        VRG_General_Data.Sensor_FPS_Plot(df_img, [die, temp, powerSeq], document, pltPath, showPlt)

        for tst in TEST:  # Powerup sequence
            df_test = VRG_Data_Frame.newdataframe(df_img, powerSeq, tst)
            for tmp in TEMP:  # Temperature
                df_tmp = VRG_Data_Frame.newdataframe(df_test, temp, tmp)
                if tmp == nomTemp:
                    document.add_heading(i + ' Image Capture (' + powerSeq + ' = ' + str(tst) + ')', level=2)
                    VRG_Image_Analysis.Add_Image(df_tmp, 1, document, showPlt)


# DTR STATS
def DTR_Mean_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'DTR_Mean_GreenR'
        d2 = 'DTR_Mean_Red'
        d3 = 'DTR_Mean_GreenB'
        d4 = 'DTR_Mean_Blue'

        figTitle = 'DTR_Mean'
        ylabel = 'Mean (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def DTR_StdDev_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'DTR_StdDev_GreenR'
        d2 = 'DTR_StdDev_Red'
        d3 = 'DTR_StdDev_GreenB'
        d4 = 'DTR_StdDev_Blue'

        figTitle = 'DTR_StdDev'
        ylabel = 'StdDev (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def DTR_TotalNoise_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'DTR_TotalNoise_Blue'
        d2 = 'DTR_TotalNoise_GreenB'
        d3 = 'DTR_TotalNoise_Red'
        d4 = 'DTR_TotalNoise_GreenR'

        figTitle = 'DTR_TotalNoise'
        ylabel = 'TotalNoise (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def DTR_FPN_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'DTR_FPN_Blue'
        d2 = 'DTR_FPN_GreenB'
        d3 = 'DTR_FPN_Red'
        d4 = 'DTR_FPN_GreenR'

        figTitle = 'DTR_FPN'
        ylabel = 'FPN (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def DTR_Temporal_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'DTR_Temporal_Blue'
        d2 = 'DTR_Temporal_GreenB'
        d3 = 'DTR_Temporal_Red'
        d4 = 'DTR_Temporal_GreenR'

        figTitle = 'DTR_Temporal'
        ylabel = 'Temporal (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def DTR_RowStdDev_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'DTR_RowStdDev_Blue'
        d2 = 'DTR_RowStdDev_GreenB'
        d3 = 'DTR_RowStdDev_Red'
        d4 = 'DTR_RowStdDev_GreenR'

        figTitle = 'DTR_RowStdDev'
        ylabel = 'RowStdDev (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def DTR_RowTotalNoise_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'DTR_RowTotalNoise_Blue'
        d2 = 'DTR_RowTotalNoise_GreenB'
        d3 = 'DTR_RowTotalNoise_Red'
        d4 = 'DTR_RowTotalNoise_GreenR'

        figTitle = 'DTR_RowTotalNoise'
        ylabel = 'RowTotalNoise (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def DTR_RowFPN_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'DTR_RowFPN_Blue'
        d2 = 'DTR_RowFPN_GreenB'
        d3 = 'DTR_RowFPN_Red'
        d4 = 'DTR_RowFPN_GreenR'

        figTitle = 'DTR_RowFPN'
        ylabel = 'RowFPN (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def DTR_RowTempNoise_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'DTR_RowTempNoise_Blue'
        d2 = 'DTR_RowTempNoise_GreenB'
        d3 = 'DTR_RowTempNoise_Red'
        d4 = 'DTR_RowTempNoise_GreenR'

        figTitle = 'DTR_RowTempNoise'
        ylabel = 'RowTempNoise (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def DTR_ColStdDev_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'DTR_ColStdDev_Blue'
        d2 = 'DTR_ColStdDev_GreenB'
        d3 = 'DTR_ColStdDev_Red'
        d4 = 'DTR_ColStdDev_GreenR'

        figTitle = 'DTR_ColStdDev'
        ylabel = 'ColStdDev (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def DTR_ColTotalNoise_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'DTR_ColTotalNoise_Blue'
        d2 = 'DTR_ColTotalNoise_GreenB'
        d3 = 'DTR_ColTotalNoise_Red'
        d4 = 'DTR_ColTotalNoise_GreenR'

        figTitle = 'DTR_ColTotalNoise'
        ylabel = 'ColTotalNoise (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def DTR_ColFPN_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'DTR_ColFPN_Blue'
        d2 = 'DTR_ColFPN_GreenB'
        d3 = 'DTR_ColFPN_Red'
        d4 = 'DTR_ColFPN_GreenR'

        figTitle = 'DTR_ColFPN'
        ylabel = 'ColFPN (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def DTR_ColTempNoise_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'DTR_ColTempNoise_Blue'
        d2 = 'DTR_ColTempNoise_GreenB'
        d3 = 'DTR_ColTempNoise_Red'
        d4 = 'DTR_ColTempNoise_GreenR'

        figTitle = 'DTR_ColTempNoise'
        ylabel = 'ColTempNoise (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def DTR_Flicker_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'DTR_Flicker_Blue'
        d2 = 'DTR_Flicker_GreenB'
        d3 = 'DTR_Flicker_Red'
        d4 = 'DTR_Flicker_GreenR'

        figTitle = 'DTR_Flicker'
        ylabel = 'Flicker (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def DTR_PixelTotalNoise_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'DTR_PixelTotalNoise_GreenR'
        d2 = 'DTR_PixelTotalNoise_Red'
        d3 = 'DTR_PixelTotalNoise_GreenB'
        d4 = 'DTR_PixelTotalNoise_Blue'

        figTitle = 'DTR_PixelTotalNoise'
        ylabel = 'PixelTotalNoise(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def DTR_PixelTemporalNoise_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'DTR_PixelTemporalNoise_GreenR'
        d2 = 'DTR_PixelTemporalNoise_Red'
        d3 = 'DTR_PixelTemporalNoise_GreenB'
        d4 = 'DTR_PixelTemporalNoise_Blue'

        figTitle = 'DTR_PixelTemporalNoise'
        ylabel = 'PixelTemporalNoise(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def DTR_PixelFPN_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'DTR_PixelFPN_GreenR'
        d2 = 'DTR_PixelFPN_Red'
        d3 = 'DTR_PixelFPN_GreenB'
        d4 = 'DTR_PixelFPN_Blue'

        figTitle = 'DTR_PixelFPN'
        ylabel = 'PixelFPN(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def DTR_RowTemporalNoiseRatio_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'DTR_RowTemporalNoiseRatio_GreenR'
        d2 = 'DTR_RowTemporalNoiseRatio_Red'
        d3 = 'DTR_RowTemporalNoiseRatio_GreenB'
        d4 = 'DTR_RowTemporalNoiseRatio_Blue'

        figTitle = 'DTR_RowTemporalNoiseRatio'
        ylabel = 'RowTemporalNoiseRatio(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def DTR_ColumnTemporalNoiseRatio_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'DTR_ColumnTemporalNoiseRatio_GreenR'
        d2 = 'DTR_ColumnTemporalNoiseRatio_Red'
        d3 = 'DTR_ColumnTemporalNoiseRatio_GreenB'
        d4 = 'DTR_ColumnTemporalNoiseRatio_Blue'

        figTitle = 'DTR_ColumnTemporalNoiseRatio'
        ylabel = 'ColumnTemporalNoiseRatio(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def DTR_RowFPNRatio_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'DTR_RowFPNRatio_GreenR'
        d2 = 'DTR_RowFPNRatio_Red'
        d3 = 'DTR_RowFPNRatio_GreenB'
        d4 = 'DTR_RowFPNRatio_Blue'

        figTitle = 'DTR_RowFPNRatio'
        ylabel = 'RowFPNRatio(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def DTR_ColumnFPNRatio_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'DTR_ColumnFPNRatio_GreenR'
        d2 = 'DTR_ColumnFPNRatio_Red'
        d3 = 'DTR_ColumnFPNRatio_GreenB'
        d4 = 'DTR_ColumnFPNRatio_Blue'

        figTitle = 'DTR_ColumnFPNRatio'
        ylabel = 'ColumnFPNRatio(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found


# RRC STATS
def RRC_Mean_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'RRC_Mean_GreenR'
        d2 = 'RRC_Mean_Red'
        d3 = 'RRC_Mean_GreenB'
        d4 = 'RRC_Mean_Blue'

        figTitle = 'RRC_Mean'
        ylabel = 'Mean (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def RRC_StdDev_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'RRC_StdDev_GreenR'
        d2 = 'RRC_StdDev_Red'
        d3 = 'RRC_StdDev_GreenB'
        d4 = 'RRC_StdDev_Blue'

        figTitle = 'RRC_StdDev'
        ylabel = 'StdDev (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def RRC_TotalNoise_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'RRC_TotalNoise_Blue'
        d2 = 'RRC_TotalNoise_GreenB'
        d3 = 'RRC_TotalNoise_Red'
        d4 = 'RRC_TotalNoise_GreenR'

        figTitle = 'RRC_TotalNoise'
        ylabel = 'TotalNoise (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def RRC_FPN_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'RRC_FPN_Blue'
        d2 = 'RRC_FPN_GreenB'
        d3 = 'RRC_FPN_Red'
        d4 = 'RRC_FPN_GreenR'

        figTitle = 'RRC_FPN'
        ylabel = 'FPN (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def RRC_Temporal_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'RRC_Temporal_Blue'
        d2 = 'RRC_Temporal_GreenB'
        d3 = 'RRC_Temporal_Red'
        d4 = 'RRC_Temporal_GreenR'

        figTitle = 'RRC_Temporal'
        ylabel = 'Temporal (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def RRC_RowStdDev_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'RRC_RowStdDev_Blue'
        d2 = 'RRC_RowStdDev_GreenB'
        d3 = 'RRC_RowStdDev_Red'
        d4 = 'RRC_RowStdDev_GreenR'

        figTitle = 'RRC_RowStdDev'
        ylabel = 'RowStdDev (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def RRC_RowTotalNoise_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'RRC_RowTotalNoise_Blue'
        d2 = 'RRC_RowTotalNoise_GreenB'
        d3 = 'RRC_RowTotalNoise_Red'
        d4 = 'RRC_RowTotalNoise_GreenR'

        figTitle = 'RRC_RowTotalNoise'
        ylabel = 'RowTotalNoise (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def RRC_RowFPN_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'RRC_RowFPN_Blue'
        d2 = 'RRC_RowFPN_GreenB'
        d3 = 'RRC_RowFPN_Red'
        d4 = 'RRC_RowFPN_GreenR'

        figTitle = 'RRC_RowFPN'
        ylabel = 'RowFPN (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def RRC_RowTempNoise_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'RRC_RowTempNoise_Blue'
        d2 = 'RRC_RowTempNoise_GreenB'
        d3 = 'RRC_RowTempNoise_Red'
        d4 = 'RRC_RowTempNoise_GreenR'

        figTitle = 'RRC_RowTempNoise'
        ylabel = 'RowTempNoise (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def RRC_ColStdDev_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'RRC_ColStdDev_Blue'
        d2 = 'RRC_ColStdDev_GreenB'
        d3 = 'RRC_ColStdDev_Red'
        d4 = 'RRC_ColStdDev_GreenR'

        figTitle = 'RRC_ColStdDev'
        ylabel = 'ColStdDev (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def RRC_ColTotalNoise_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'RRC_ColTotalNoise_Blue'
        d2 = 'RRC_ColTotalNoise_GreenB'
        d3 = 'RRC_ColTotalNoise_Red'
        d4 = 'RRC_ColTotalNoise_GreenR'

        figTitle = 'RRC_ColTotalNoise'
        ylabel = 'ColTotalNoise (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def RRC_ColFPN_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'RRC_ColFPN_Blue'
        d2 = 'RRC_ColFPN_GreenB'
        d3 = 'RRC_ColFPN_Red'
        d4 = 'RRC_ColFPN_GreenR'

        figTitle = 'RRC_ColFPN'
        ylabel = 'ColFPN (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def RRC_ColTempNoise_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'RRC_ColTempNoise_Blue'
        d2 = 'RRC_ColTempNoise_GreenB'
        d3 = 'RRC_ColTempNoise_Red'
        d4 = 'RRC_ColTempNoise_GreenR'

        figTitle = 'RRC_ColTempNoise'
        ylabel = 'ColTempNoise (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def RRC_Flicker_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'RRC_Flicker_Blue'
        d2 = 'RRC_Flicker_GreenB'
        d3 = 'RRC_Flicker_Red'
        d4 = 'RRC_Flicker_GreenR'

        figTitle = 'RRC_Flicker'
        ylabel = 'Flicker (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def RRC_PixelTotalNoise_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'RRC_PixelTotalNoise_GreenR'
        d2 = 'RRC_PixelTotalNoise_Red'
        d3 = 'RRC_PixelTotalNoise_GreenB'
        d4 = 'RRC_PixelTotalNoise_Blue'

        figTitle = 'RRC_PixelTotalNoise'
        ylabel = 'PixelTotalNoise(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def RRC_PixelTemporalNoise_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'RRC_PixelTemporalNoise_GreenR'
        d2 = 'RRC_PixelTemporalNoise_Red'
        d3 = 'RRC_PixelTemporalNoise_GreenB'
        d4 = 'RRC_PixelTemporalNoise_Blue'

        figTitle = 'RRC_PixelTemporalNoise'
        ylabel = 'PixelTemporalNoise(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def RRC_PixelFPN_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'RRC_PixelFPN_GreenR'
        d2 = 'RRC_PixelFPN_Red'
        d3 = 'RRC_PixelFPN_GreenB'
        d4 = 'RRC_PixelFPN_Blue'

        figTitle = 'RRC_PixelFPN'
        ylabel = 'PixelFPN(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def RRC_RowTemporalNoiseRatio_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'RRC_RowTemporalNoiseRatio_GreenR'
        d2 = 'RRC_RowTemporalNoiseRatio_Red'
        d3 = 'RRC_RowTemporalNoiseRatio_GreenB'
        d4 = 'RRC_RowTemporalNoiseRatio_Blue'

        figTitle = 'RRC_RowTemporalNoiseRatio'
        ylabel = 'RowTemporalNoiseRatio(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def RRC_ColumnTemporalNoiseRatio_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'RRC_ColumnTemporalNoiseRatio_GreenR'
        d2 = 'RRC_ColumnTemporalNoiseRatio_Red'
        d3 = 'RRC_ColumnTemporalNoiseRatio_GreenB'
        d4 = 'RRC_ColumnTemporalNoiseRatio_Blue'

        figTitle = 'RRC_ColumnTemporalNoiseRatio'
        ylabel = 'ColumnTemporalNoiseRatio(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def RRC_RowFPNRatio_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'RRC_RowFPNRatio_GreenR'
        d2 = 'RRC_RowFPNRatio_Red'
        d3 = 'RRC_RowFPNRatio_GreenB'
        d4 = 'RRC_RowFPNRatio_Blue'

        figTitle = 'RRC_RowFPNRatio'
        ylabel = 'RowFPNRatio(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def RRC_ColumnFPNRatio_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'RRC_ColumnFPNRatio_GreenR'
        d2 = 'RRC_ColumnFPNRatio_Red'
        d3 = 'RRC_ColumnFPNRatio_GreenB'
        d4 = 'RRC_ColumnFPNRatio_Blue'

        figTitle = 'RRC_ColumnFPNRatio'
        ylabel = 'ColumnFPNRatio(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found


# SIC STATS
def SIC_Mean_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'SIC_Mean_GreenR'
        d2 = 'SIC_Mean_Red'
        d3 = 'SIC_Mean_GreenB'
        d4 = 'SIC_Mean_Blue'

        figTitle = 'SIC_Mean'
        ylabel = 'Mean (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SIC_StdDev_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'SIC_StdDev_GreenR'
        d2 = 'SIC_StdDev_Red'
        d3 = 'SIC_StdDev_GreenB'
        d4 = 'SIC_StdDev_Blue'

        figTitle = 'SIC_StdDev'
        ylabel = 'StdDev (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SIC_TotalNoise_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'SIC_TotalNoise_Blue'
        d2 = 'SIC_TotalNoise_GreenB'
        d3 = 'SIC_TotalNoise_Red'
        d4 = 'SIC_TotalNoise_GreenR'

        figTitle = 'SIC_TotalNoise'
        ylabel = 'TotalNoise (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SIC_FPN_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'SIC_FPN_Blue'
        d2 = 'SIC_FPN_GreenB'
        d3 = 'SIC_FPN_Red'
        d4 = 'SIC_FPN_GreenR'

        figTitle = 'SIC_FPN'
        ylabel = 'FPN (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SIC_Temporal_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'SIC_Temporal_Blue'
        d2 = 'SIC_Temporal_GreenB'
        d3 = 'SIC_Temporal_Red'
        d4 = 'SIC_Temporal_GreenR'

        figTitle = 'SIC_Temporal'
        ylabel = 'Temporal (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SIC_RowStdDev_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'SIC_RowStdDev_Blue'
        d2 = 'SIC_RowStdDev_GreenB'
        d3 = 'SIC_RowStdDev_Red'
        d4 = 'SIC_RowStdDev_GreenR'

        figTitle = 'SIC_RowStdDev'
        ylabel = 'RowStdDev (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SIC_RowTotalNoise_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'SIC_RowTotalNoise_Blue'
        d2 = 'SIC_RowTotalNoise_GreenB'
        d3 = 'SIC_RowTotalNoise_Red'
        d4 = 'SIC_RowTotalNoise_GreenR'

        figTitle = 'SIC_RowTotalNoise'
        ylabel = 'RowTotalNoise (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SIC_RowFPN_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'SIC_RowFPN_Blue'
        d2 = 'SIC_RowFPN_GreenB'
        d3 = 'SIC_RowFPN_Red'
        d4 = 'SIC_RowFPN_GreenR'

        figTitle = 'SIC_RowFPN'
        ylabel = 'RowFPN (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SIC_RowTempNoise_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'SIC_RowTempNoise_Blue'
        d2 = 'SIC_RowTempNoise_GreenB'
        d3 = 'SIC_RowTempNoise_Red'
        d4 = 'SIC_RowTempNoise_GreenR'

        figTitle = 'SIC_RowTempNoise'
        ylabel = 'RowTempNoise (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SIC_ColStdDev_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'SIC_ColStdDev_Blue'
        d2 = 'SIC_ColStdDev_GreenB'
        d3 = 'SIC_ColStdDev_Red'
        d4 = 'SIC_ColStdDev_GreenR'

        figTitle = 'SIC_ColStdDev'
        ylabel = 'ColStdDev (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SIC_ColTotalNoise_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'SIC_ColTotalNoise_Blue'
        d2 = 'SIC_ColTotalNoise_GreenB'
        d3 = 'SIC_ColTotalNoise_Red'
        d4 = 'SIC_ColTotalNoise_GreenR'

        figTitle = 'SIC_ColTotalNoise'
        ylabel = 'ColTotalNoise (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SIC_ColFPN_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'SIC_ColFPN_Blue'
        d2 = 'SIC_ColFPN_GreenB'
        d3 = 'SIC_ColFPN_Red'
        d4 = 'SIC_ColFPN_GreenR'

        figTitle = 'SIC_ColFPN'
        ylabel = 'ColFPN (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SIC_ColTempNoise_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'SIC_ColTempNoise_Blue'
        d2 = 'SIC_ColTempNoise_GreenB'
        d3 = 'SIC_ColTempNoise_Red'
        d4 = 'SIC_ColTempNoise_GreenR'

        figTitle = 'SIC_ColTempNoise'
        ylabel = 'ColTempNoise (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SIC_Flicker_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'SIC_Flicker_Blue'
        d2 = 'SIC_Flicker_GreenB'
        d3 = 'SIC_Flicker_Red'
        d4 = 'SIC_Flicker_GreenR'

        figTitle = 'SIC_Flicker'
        ylabel = 'Flicker (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SIC_PixelTotalNoise_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'SIC_PixelTotalNoise_GreenR'
        d2 = 'SIC_PixelTotalNoise_Red'
        d3 = 'SIC_PixelTotalNoise_GreenB'
        d4 = 'SIC_PixelTotalNoise_Blue'

        figTitle = 'SIC_PixelTotalNoise'
        ylabel = 'PixelTotalNoise(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SIC_PixelTemporalNoise_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'SIC_PixelTemporalNoise_GreenR'
        d2 = 'SIC_PixelTemporalNoise_Red'
        d3 = 'SIC_PixelTemporalNoise_GreenB'
        d4 = 'SIC_PixelTemporalNoise_Blue'

        figTitle = 'SIC_PixelTemporalNoise'
        ylabel = 'PixelTemporalNoise(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SIC_PixelFPN_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'SIC_PixelFPN_GreenR'
        d2 = 'SIC_PixelFPN_Red'
        d3 = 'SIC_PixelFPN_GreenB'
        d4 = 'SIC_PixelFPN_Blue'

        figTitle = 'SIC_PixelFPN'
        ylabel = 'PixelFPN(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SIC_RowTemporalNoiseRatio_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'SIC_RowTemporalNoiseRatio_GreenR'
        d2 = 'SIC_RowTemporalNoiseRatio_Red'
        d3 = 'SIC_RowTemporalNoiseRatio_GreenB'
        d4 = 'SIC_RowTemporalNoiseRatio_Blue'

        figTitle = 'SIC_RowTemporalNoiseRatio'
        ylabel = 'RowTemporalNoiseRatio(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SIC_ColumnTemporalNoiseRatio_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'SIC_ColumnTemporalNoiseRatio_GreenR'
        d2 = 'SIC_ColumnTemporalNoiseRatio_Red'
        d3 = 'SIC_ColumnTemporalNoiseRatio_GreenB'
        d4 = 'SIC_ColumnTemporalNoiseRatio_Blue'

        figTitle = 'SIC_ColumnTemporalNoiseRatio'
        ylabel = 'ColumnTemporalNoiseRatio(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SIC_RowFPNRatio_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'SIC_RowFPNRatio_GreenR'
        d2 = 'SIC_RowFPNRatio_Red'
        d3 = 'SIC_RowFPNRatio_GreenB'
        d4 = 'SIC_RowFPNRatio_Blue'

        figTitle = 'SIC_RowFPNRatio'
        ylabel = 'RowFPNRatio(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def SIC_ColumnFPNRatio_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'SIC_ColumnFPNRatio_GreenR'
        d2 = 'SIC_ColumnFPNRatio_Red'
        d3 = 'SIC_ColumnFPNRatio_GreenB'
        d4 = 'SIC_ColumnFPNRatio_Blue'

        figTitle = 'SIC_ColumnFPNRatio'
        ylabel = 'ColumnFPNRatio(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found


# ATR STATS
def ATR_Mean_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ATR_Mean_GreenR'
        d2 = 'ATR_Mean_Red'
        d3 = 'ATR_Mean_GreenB'
        d4 = 'ATR_Mean_Blue'

        figTitle = 'ATR_Mean'
        ylabel = 'Mean (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def ATR_StdDev_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ATR_StdDev_GreenR'
        d2 = 'ATR_StdDev_Red'
        d3 = 'ATR_StdDev_GreenB'
        d4 = 'ATR_StdDev_Blue'

        figTitle = 'ATR_StdDev'
        ylabel = 'StdDev (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def ATR_TotalNoise_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ATR_TotalNoise_Blue'
        d2 = 'ATR_TotalNoise_GreenB'
        d3 = 'ATR_TotalNoise_Red'
        d4 = 'ATR_TotalNoise_GreenR'

        figTitle = 'ATR_TotalNoise'
        ylabel = 'TotalNoise (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def ATR_FPN_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ATR_FPN_Blue'
        d2 = 'ATR_FPN_GreenB'
        d3 = 'ATR_FPN_Red'
        d4 = 'ATR_FPN_GreenR'

        figTitle = 'ATR_FPN'
        ylabel = 'FPN (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def ATR_Temporal_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ATR_Temporal_Blue'
        d2 = 'ATR_Temporal_GreenB'
        d3 = 'ATR_Temporal_Red'
        d4 = 'ATR_Temporal_GreenR'

        figTitle = 'ATR_Temporal'
        ylabel = 'Temporal (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def ATR_RowStdDev_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ATR_RowStdDev_Blue'
        d2 = 'ATR_RowStdDev_GreenB'
        d3 = 'ATR_RowStdDev_Red'
        d4 = 'ATR_RowStdDev_GreenR'

        figTitle = 'ATR_RowStdDev'
        ylabel = 'RowStdDev (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def ATR_RowTotalNoise_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ATR_RowTotalNoise_Blue'
        d2 = 'ATR_RowTotalNoise_GreenB'
        d3 = 'ATR_RowTotalNoise_Red'
        d4 = 'ATR_RowTotalNoise_GreenR'

        figTitle = 'ATR_RowTotalNoise'
        ylabel = 'RowTotalNoise (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def ATR_RowFPN_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ATR_RowFPN_Blue'
        d2 = 'ATR_RowFPN_GreenB'
        d3 = 'ATR_RowFPN_Red'
        d4 = 'ATR_RowFPN_GreenR'

        figTitle = 'ATR_RowFPN'
        ylabel = 'RowFPN (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def ATR_RowTempNoise_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ATR_RowTempNoise_Blue'
        d2 = 'ATR_RowTempNoise_GreenB'
        d3 = 'ATR_RowTempNoise_Red'
        d4 = 'ATR_RowTempNoise_GreenR'

        figTitle = 'ATR_RowTempNoise'
        ylabel = 'RowTempNoise (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def ATR_ColStdDev_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ATR_ColStdDev_Blue'
        d2 = 'ATR_ColStdDev_GreenB'
        d3 = 'ATR_ColStdDev_Red'
        d4 = 'ATR_ColStdDev_GreenR'

        figTitle = 'ATR_ColStdDev'
        ylabel = 'ColStdDev (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def ATR_ColTotalNoise_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ATR_ColTotalNoise_Blue'
        d2 = 'ATR_ColTotalNoise_GreenB'
        d3 = 'ATR_ColTotalNoise_Red'
        d4 = 'ATR_ColTotalNoise_GreenR'

        figTitle = 'ATR_ColTotalNoise'
        ylabel = 'ColTotalNoise (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def ATR_ColFPN_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ATR_ColFPN_Blue'
        d2 = 'ATR_ColFPN_GreenB'
        d3 = 'ATR_ColFPN_Red'
        d4 = 'ATR_ColFPN_GreenR'

        figTitle = 'ATR_ColFPN'
        ylabel = 'ColFPN (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def ATR_ColTempNoise_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ATR_ColTempNoise_Blue'
        d2 = 'ATR_ColTempNoise_GreenB'
        d3 = 'ATR_ColTempNoise_Red'
        d4 = 'ATR_ColTempNoise_GreenR'

        figTitle = 'ATR_ColTempNoise'
        ylabel = 'ColTempNoise (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def ATR_Flicker_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ATR_Flicker_Blue'
        d2 = 'ATR_Flicker_GreenB'
        d3 = 'ATR_Flicker_Red'
        d4 = 'ATR_Flicker_GreenR'

        figTitle = 'ATR_Flicker'
        ylabel = 'Flicker (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def ATR_PixelTotalNoise_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ATR_PixelTotalNoise_GreenR'
        d2 = 'ATR_PixelTotalNoise_Red'
        d3 = 'ATR_PixelTotalNoise_GreenB'
        d4 = 'ATR_PixelTotalNoise_Blue'

        figTitle = 'ATR_PixelTotalNoise'
        ylabel = 'PixelTotalNoise(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def ATR_PixelTemporalNoise_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ATR_PixelTemporalNoise_GreenR'
        d2 = 'ATR_PixelTemporalNoise_Red'
        d3 = 'ATR_PixelTemporalNoise_GreenB'
        d4 = 'ATR_PixelTemporalNoise_Blue'

        figTitle = 'ATR_PixelTemporalNoise'
        ylabel = 'PixelTemporalNoise(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def ATR_PixelFPN_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ATR_PixelFPN_GreenR'
        d2 = 'ATR_PixelFPN_Red'
        d3 = 'ATR_PixelFPN_GreenB'
        d4 = 'ATR_PixelFPN_Blue'

        figTitle = 'ATR_PixelFPN'
        ylabel = 'PixelFPN(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def ATR_RowTemporalNoiseRatio_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ATR_RowTemporalNoiseRatio_GreenR'
        d2 = 'ATR_RowTemporalNoiseRatio_Red'
        d3 = 'ATR_RowTemporalNoiseRatio_GreenB'
        d4 = 'ATR_RowTemporalNoiseRatio_Blue'

        figTitle = 'ATR_RowTemporalNoiseRatio'
        ylabel = 'RowTemporalNoiseRatio(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def ATR_ColumnTemporalNoiseRatio_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ATR_ColumnTemporalNoiseRatio_GreenR'
        d2 = 'ATR_ColumnTemporalNoiseRatio_Red'
        d3 = 'ATR_ColumnTemporalNoiseRatio_GreenB'
        d4 = 'ATR_ColumnTemporalNoiseRatio_Blue'

        figTitle = 'ATR_ColumnTemporalNoiseRatio'
        ylabel = 'ColumnTemporalNoiseRatio(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def ATR_RowFPNRatio_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ATR_RowFPNRatio_GreenR'
        d2 = 'ATR_RowFPNRatio_Red'
        d3 = 'ATR_RowFPNRatio_GreenB'
        d4 = 'ATR_RowFPNRatio_Blue'

        figTitle = 'ATR_RowFPNRatio'
        ylabel = 'RowFPNRatio(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

def ATR_ColumnFPNRatio_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        d1 = 'ATR_ColumnFPNRatio_GreenR'
        d2 = 'ATR_ColumnFPNRatio_Red'
        d3 = 'ATR_ColumnFPNRatio_GreenB'
        d4 = 'ATR_ColumnFPNRatio_Blue'

        figTitle = 'ATR_ColumnFPNRatio'
        ylabel = 'ColumnFPNRatio(DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x='Step', y=eval("d" + str(x)), title=eval("d" + str(x)), legend=groupBy, show=showPlt,
                         inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x='Step', y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found