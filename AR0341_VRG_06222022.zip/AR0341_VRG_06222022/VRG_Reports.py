import matplotlib
import matplotlib.pyplot as plt
from matplotlib import pyplot
from docx import Document
from docx.shared import Inches
from docx.shared import Pt
from tkinter import *
from tkinter import filedialog
from tkinter import messagebox
import numpy as np
import csv
import argparse
import os
import pandas as pd
import pixelcrunch as pc
import fivecentplots as fcp
import bokeh
import sys
import io
import multiprocessing
import VRG_Safety_Data
import VRG_Calculate
import VRG_Data_Frame
import VRG_Doc
import VRG_General_Data
import VRG_Image_Analysis
import VRG_Image_Utils
import VRG_Macro_Data
import VRG_OTPM_Data
import VRG_Pins_Data
import VRG_Power_Data
import VRG_Register_Data
import VRG_Stats_Arr
import VRG_Stats_ArrCenter
import VRG_Stats_ArrQuad1
import VRG_Stats_ArrQuad2
import VRG_Stats_ArrQuad3
import VRG_Stats_ArrQuad4
import VRG_Stats_ArrRoi1
import VRG_Stats_ArrRoi2
import VRG_Stats_ArrRoi3
import VRG_Stats_ArrRoi4
import VRG_Stats_ArrRoi5
import VRG_Stats_ArrRoi6
import VRG_Stats_ArrRoi7
import VRG_Stats_ArrRoi8
import VRG_Stats_ArrRoi9
import VRG_Stats_DBLC
import VRG_Stats_Frame
import VRG_Stats_Lag
import VRG_Stats_RNC
import VRG_Stats_Tilt
import VRG_Tempsensor_Data
import VRG_Reports
import time

'''
CUSTOM TESTS
'''

def DV_CUSTOM_TEST_1(df, document, imgPath, pltPath):   # Custom Test Code
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)

    # for x in range(1, numDataCols):
    #     if eval("d" + str(x)) in df.columns:
    #         None
    #     else:
    #         raise Exception("Column Name:" + eval("d"+str(x))+"not found")

    # document.add_heading('Voltage Level')
    # VRG_Power_Data.Supply_Voltage_Plot(df, [die, temp, 'ImgMode'], document, pltPath, showPlt)

    # document.add_heading('Standby Power & Current vs. Die vs. Temp vs. Die vs. ImgMode')
    # VRG_Power_Data.Standby_Power_Consumption_Plot(df, [die, temp, 'Power', 'ImgMode'], document, pltPath, showPlt)
    # VRG_Power_Data.Standby_Current_Consumption_Plot(df, [die, temp, 'Power', 'ImgMode'], document, pltPath, showPlt)
    #
    # document.add_heading('Standby Power & Current vs. Temp vs. Power vs. ImgMode')
    # VRG_Power_Data.Standby_Power_Consumption_Plot(df, [temp, 'Power', 'ImgMode'], document, pltPath, showPlt)
    # VRG_Power_Data.Standby_Current_Consumption_Plot(df, [temp, 'Power', 'ImgMode'], document, pltPath, showPlt)
    #
    # document.add_heading('Operating Power & Current vs. Die vs. Temp vs. Die vs. ImgMode')
    # VRG_Power_Data.Power_Consumption_Plot(df, [die, temp, 'Power', 'ImgMode'], document, pltPath, showPlt)
    # VRG_Power_Data.Current_Consumption_Plot(df, [die, temp, 'Power', 'ImgMode'], document, pltPath, showPlt)
    #
    # document.add_heading('Operating Power & Current vs. Temp vs. Power vs. ImgMode')
    # VRG_Power_Data.Power_Consumption_Plot(df, [temp, 'Power', 'ImgMode'], document, pltPath, showPlt)
    # VRG_Power_Data.Current_Consumption_Plot(df, [temp, 'Power', 'ImgMode'], document, pltPath, showPlt)
    #
    # TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    # for i in TEMP:
    #     df_temp = VRG_Data_Frame.newdataframe(df, temp, i)
    #     document.add_heading(str(i), level=1)
    #
    #     document.add_heading('Standby Power & Current vs. Temp vs. Power vs. ImgMode')
    #     VRG_Power_Data.Standby_Power_Consumption_Plot(df_temp, [temp, 'Power', 'ImgMode'], document, pltPath, showPlt)
    #     VRG_Power_Data.Standby_Current_Consumption_Plot(df_temp, [temp, 'Power', 'ImgMode'], document, pltPath, showPlt)
    #
    #     document.add_heading('Operating Power & Current vs. Temp vs. Power vs. ImgMode')
    #     VRG_Power_Data.Power_Consumption_Plot(df_temp, [temp, 'Power', 'ImgMode'], document, pltPath, showPlt)
    #     VRG_Power_Data.Current_Consumption_Plot(df_temp, [temp, 'Power', 'ImgMode'], document, pltPath, showPlt)


    # vdd_unique_vals = df['VDD(v)'].unique()
    # vddphy_unique_vals = df['VDD_PHY(v)'].unique()
    #
    # df_new = pd.DataFrame()
    # # df_new['VDD(v)'] = vdd_unique_vals
    # # df_new['VDD_PHY(v)'] = vddphy_unique_vals
    #
    #
    # print(df_new)


    # d1 = 'STBY_P_VAA2V8(mW)'
    # fig = px.scatter(df, x='Step', y=d1, color='Power', facet_col='Clk', facet_row='RegWr00_OTPM_EXPR__ECC_BYPASS')
    # fig.show()
    #
    # fig = px.box(df, y=d1)
    # fig.show()

    # VRG_Power_Data.Plotly_Stby(df, None, document, pltPath, showPlt)
    # VRG_Power_Data.Plotly_Stby(df, 'Power', document, pltPath, showPlt)

    # d1 = 'PASS_FAIL'
    # numdatacols= 2
    # for x in range(1, numdatacols):
    #     if df[eval("d" + str(x))].dtype == object:
    #         if ((df[eval("d" + str(x))] == 'PASS') | (df[eval("d" + str(x))] == 'FAIL')).any():
    #             df[eval("d" + str(x))] = df[eval("d" + str(x))].eq('PASS').mul(1)  # Replace OK with 1, Fail with 0
    # print(df[d1])

    # document.add_heading('Standby Power & Current vs. Clk')
    # VRG_Power_Data.Standby_Power_Consumption_Plot(df, ['Power', temp, 'Clk'], document, pltPath, showPlt)
    # VRG_Power_Data.Standby_Current_Consumption_Plot(df, ['Power', temp, 'Clk'], document, pltPath, showPlt)

    # d1 = 'ASIL_STARTUP_PIN_ENABLES'  # Columns to find
    # # get data columns
    # t1_cols = [x for x in df.columns[df.columns.str.contains(d1)]]
    # print(len(t1_cols))
    #
    # for x in t1_cols:
    #     print(x)

    # ULcolor = '#ff0000'
    # LLcolor = '#0000ff'
    #
    # limit1 = 'LIMIT__Sensor_30FPS'
    # limit2 = 'LIMIT__Sensor_45FPS'
    # limit3 = 'LIMIT__Sensor_60FPS'
    #
    # VRG_General_Data.Sensor_FPS_Plot(df, 'Clk', document, pltPath, showPlt,
    #                                    ax_hlines=[(limit1, LLcolor, '--', 2, 1), (limit2, LLcolor, '--', 2, 1),
    #                                               (limit3, ULcolor, '--', 2, 1)])



    # powerseq = ['Light', 'RegWr00_COARSE_INTEGRATION_TIME_']
    #
    # document.add_heading('General Test Data')
    # VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    #
    # for pwrseq in powerseq:
    #     print(df[pwrseq])

    # reg = 'RegWr00_COARSE_INTEGRATION_TIME_'
    # # GeneralData
    # document.add_heading('General Test Data')
    # VRG_Stats_Frame.Reg_vs_Rgn_Mean_Plot(df, None, document, pltPath, reg, showPlt)
    # VRG_Stats_Frame.Reg_vs_RgnV2_Mean_Plot(df, None, None, document, pltPath, reg, showPlt)
    # VRG_Stats_Frame.Reg_vs_RgnV2_Mean_Plot(df, 'Arr', None, document, pltPath, reg, showPlt)
    # VRG_Stats_Frame.Reg_vs_RgnV2_Mean_Plot(df, 'ArrQuad1', None, document, pltPath, reg, showPlt)
    # VRG_Stats_Frame.Reg_vs_RgnV2_Mean_Plot(df, 'DBLC', None, document, pltPath, reg, showPlt)
    # VRG_Stats_Frame.Reg_vs_RgnV2_Mean_Plot(df, 'DTR', None, document, pltPath, reg, showPlt)
    # VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    # VRG_Stats_Arr.Arr_Mean_Plot(df, None, document, pltPath, showPlt)
    # VRG_Stats_Arr.Arr_Mean_Plot(df, temp, document, pltPath, showPlt)
    # VRG_Stats_Arr.Arr_Mean_Plot(df, 'Cint', document, pltPath, showPlt)
    # VRG_AsilData.SM_EMBEDDED_DATA_CRC_vs_Time_Plot(df, 'Die', 10, document,pltPath,showPlt)
    # VRG_AsilData.SM_EMBEDDED_DATA_CRC_vs_Time_Plot(df, 'Die', 10, document, pltPath, showPlt)

    # showPlt = True  # Show Plots (T/F)
    # temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    # die = 'Die'  # Group Plots by Die
    # anaGain = 'DVM_3_09_Analog_Gain'
    # nomAnaGain = 1
    # dataPedestalVal = 168
    # anaGainReg1 = 'RegVal_OCL_T1_GAIN_'
    # anaGainReg2 = 'RegVal_OCL_T1_GAIN2'
    # expBypass = 'RegWr01_LFM2_T1_CTRL'
    # E1_E2 = 32929
    # E1_byp = 33445
    # minLight = 500
    # maxLight = 20000
    #
    # # IMAGE MODE SPECIFIC DATA
    # IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    # TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    # nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    # for i in IMG:
    #     df_img = VRG_DataFrame.newdataframe(df, 'ImgMode', i)
    #     df_img_minLight = VRG_DataFrame.newdataframe(df_img, 'Light', minLight)
    #     df_img_maxLight = VRG_DataFrame.newdataframe(df_img, 'Light', maxLight)
    #     df_E1_E2 = VRG_DataFrame.newdataframe(df_img, expBypass, E1_E2)
    #     df_E1_byp = VRG_DataFrame.newdataframe(df_img, expBypass, E1_byp)
    #     df_E1_E2_minLight = VRG_DataFrame.newdataframe(df_img_minLight, expBypass, E1_E2)
    #     df_E1_E2_maxLight = VRG_DataFrame.newdataframe(df_img_maxLight, expBypass, E1_E2)
    #     df_E1_byp_minLight = VRG_DataFrame.newdataframe(df_img_minLight, expBypass, E1_byp)
    #     df_E1_byp_maxLight = VRG_DataFrame.newdataframe(df_img_maxLight, expBypass, E1_byp)
    #
    #     document.add_heading(i, level=1)
    #
    #     document.add_heading(i + ' Calculated Analog Gain @ Mid Light', level=2)
    #     VRG_Calculate.Calc_AnalogGain_Plot(df_img_maxLight, None, document, pltPath, anaGain, nomAnaGain,
    #                                        dataPedestalVal, showPlt)
    #     document.add_heading(i + ' Calculated Analog Gain % Error @ Mid Light', level=2)
    #     VRG_Calculate.Calc_AnalogGain_Error_Plot(df_img_maxLight, None, document, pltPath, anaGain, nomAnaGain,
    #                                              dataPedestalVal, showPlt)
    # showPlt = False # Show Plots (T/F)
    # temp = 'TemperatureSetPoint' # Group Plots by Temperatures
    # die = 'Die' # Group Plots by Die
    # IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    # TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    # nomTemp = min(TEMP, key=lambda x: abs(x - 60))# closest temp to 60C
    # for i in IMG:
    #     df_img = VRG_DataFrame.newdataframe(df, 'ImgMode', i)
    #     document.add_heading(i, level=1)
    #     document.add_heading(i + ' SM_ATR Image @ Starting Location', level=2)
    #     VRG_ImageUtils.Image_Crop(df_img, 2, document, 3140, 32, 3159, 80, showPlt)  # ATR start
    #     document.add_heading(i + ' SM_ATR Image @ Center Location', level=2)
    #     VRG_ImageUtils.Image_Crop(df_img, 2, document, 3140, 2000, 3159, 2048, showPlt)  # ATR mid
    #     document.add_heading(i + ' SM_ATR Image @ Ending Location', level=2)
    #     VRG_ImageUtils.Image_Crop(df_img, 2, document, 3140, 4088, 3159, 4136, showPlt)  # ATR end

    # thr1 = 'ATR_CHECK_MT_EXPECT_B'
    # thr2 = 'ATR_CHECK_MT_EXPECT_W'
    # thresh = '_THRESH'
    # th1 = thr1 + thresh
    # th2 = thr2 + thresh
    # df[th1] = df[thr1].mean()
    # df[th2] = df[thr2].mean()
    # ULcolor = '#FF0000'
    # LLcolor = '#0000ff'
    # # IMAGE MODE SPECIFIC DATA
    # IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    # TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    # nomTemp = min(TEMP, key=lambda x: abs(x - 60))# closest temp to 60C
    # for i in IMG:
    #     df_img = VRG_DataFrame.newdataframe(df, 'ImgMode', i)
    #     document.add_heading(i, level=1)
    #     #VRG_AsilData.SM_ATR_COLUMN_MEMORY_TEST_1_vs_Threshold(df_img, None, document, pltPath, showPlt, ax_hlines=[(th1, LLcolor, '--', 3, 1),(th2, ULcolor, '--', 3, 1)])
    #     document.add_heading(i + ' SM_ATR Test Data vs. Thresholds', level=2)
    #     VRG_AsilData.SM_ATR_OVERDRIVE_1_vs_Threshold(df_img, None, document, pltPath, showPlt)
    #     #VRG_AsilData.SM_Analog_Test_Rows_vs_Thresholds_Plot(df_img, None, document, pltPath, showPlt)
    #     # document.add_heading(i + ' SM_ATR Test Data vs. Thresholds vs. Die', level=2)
    #     # VRG_AsilData.SM_Analog_Test_Rows_vs_Thresholds_Plot(df_img, die, document, pltPath, showPlt)
    #     # document.add_heading(i + ' SM_ATR Test Data vs. Thresholds vs. Power', level=2)
    #     # VRG_AsilData.SM_Analog_Test_Rows_vs_Thresholds_Plot(df_img, 'Power', document, pltPath, showPlt)

    # reg1 = 'ATR_CHECK_CONTROL'
    # reg2 = 'LINE_LENGTH_PCK_'
    # reg3 = 'SMIA_TEST'
    # reg4 = 'READ_MODE'
    # reg5 = 'TEST_ASIL_ROWS'
    # reg6 = 'DARK_CONTROL'
    # reg7 = 'DBLC_CONTROL'
    # reg8 = 'LFM2_T1_DBLC_TILT_ATR_CTRL'
    # imgSize = 'Macro5'
    # rrcAddrHi = 'RRC_ADDR_HI_THRESH'
    # rrcAddrLo = 'RRC_ADDR_LO_THRESH'
    #
    # # IMAGE MODE SPECIFIC DATA
    # IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    # TEST = np.asarray(df[imgSize].unique())
    # TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    # nomTemp = min(TEMP, key=lambda x: abs(x - 60))# closest temp to 60C
    # for i in IMG:
    #     df_img = VRG_DataFrame.newdataframe(df, 'ImgMode', i)
    #     document.add_heading(i, level=1)
    #     document.add_heading(i + ' SM_AHM_ROW_ROM VS. IMAGE SIZE', level=1)
    #     document.add_heading(i + ' SM_AHM_ROW_ROM Address CRC & Statistics Values vs. Image Size', level=2)
    #     VRG_AsilData.SM_Row_Rom_Address_Columns_Plot(df_img, imgSize, document, pltPath, showPlt)
    #     document.add_heading(i + ' SM_AHM_ROW_ROM Address CRC & Statistics Values Expanded vs. Image Size', level=2)
    #     VRG_AsilData.SM_Row_Rom_Address_Columns_Expanded_Plot(df_img, imgSize, document, pltPath, showPlt)
    #
    #     document.add_heading(i + ' SM_AHM_ROW_ROM LDO Signal Integrity Columns Statistics vs. Image Size', level=2)
    #     VRG_AsilData.SM_Row_Rom_SIC_Plot(df_img, imgSize, document, pltPath, showPlt)
    #     document.add_heading(i + ' SM_AHM_ROW_ROM LDO Signal Integrity Columns Statistics Expanded vs. Image Size',
    #                          level=2)
    #     VRG_AsilData.SM_Row_Rom_SIC_Expanded_Plot(df_img, imgSize, document, pltPath, showPlt)

    # time = 'Time (ms)'
    # bmon0 = 'wB_20B4_VHI_BMON_0_RD1'
    #
    # VRG_General_Data.Data_vs_Data_Plot(df, None, document, pltPath, time, bmon0, showPlt)

    # challenge = 'MASTER_FSM_REQ_CODE'
    # response = 'MASTER_FSM_RSP_CODE'
    # calcResp = 'CALC_MASTER_FSM_RSP_CODE'
    # status = 'MASTER_FSM_STATUS'
    #
    # # IMAGE MODE SPECIFIC DATA
    # IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    # TEST = np.asarray(df[challenge].unique())
    # print(TEST)
    # TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    # nomTemp = min(TEMP, key=lambda x: abs(x - 60))# closest temp to 60C
    # for i in IMG:
    #     df_img = VRG_DataFrame.newdataframe(df, 'ImgMode', i)
    #
    #     for tst in TEST:  # Test
    #         df_test = VRG_DataFrame.newdataframe(df_img, challenge, tst)
    #
    #         print(i)
    #         print(str(tst))
    #
    #         document.add_heading(i + ' SM_MASTER_STATE_CHA_RES vs. Challenge = ' + str(tst), level=1)
    #         document.add_heading(i + ' SM_MASTER_STATE_CHA_RES Results vs. Challenge = ' + str(tst), level=2)
    #         VRG_AsilData.SM_MASTER_STATE_CHA_RES(df_test, challenge, document, pltPath, showPlt)

    # deltaDk = 'DELTA_DK_CONTROL'
    # calcHi = 'CRC_FR_DTR_CALC_CHECKSUM_HIGH__CRC_FR_CALC_CHECKSUM_HIGH'
    # calcLo = 'CRC_FR_CALC_CHECKSUM_LOW'
    # wrtHi = 'CRC_FR_DTR_WRT_CHECKSUM_HIGH__CRC_FR_WRT_CHECKSUM_HIGH'
    # wrtLo = 'CRC_FR_WRT_CHECKSUM_LOW'
    # rnc = 'DARK_CONTROL__DARK_CONTROL_ROW_NOISE_CORRECTION_EN'
    # dataPed = 'DATA_PEDESTAL_'
    # crcContReg = 'CRC_CONTROL_REG'
    # framePattern = 'Macro5'
    #
    # # IMAGE MODE SPECIFIC DATA
    # IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    # TEST = np.asarray(df[framePattern].unique())
    # TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    # nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    # for i in IMG:
    #     df_img = VRG_DataFrame.newdataframe(df, 'ImgMode', i)
    #
    #     for tst in TEST:  # Test
    #         df_test = VRG_DataFrame.newdataframe(df_img, framePattern, tst)
    #         print(df_test[framePattern])
    #         print(df_test)
    #         document.add_heading(i + ' Frame Pattern: ' + str(tst), level=1)
    #         document.add_heading(i + ' Frame Pattern: ' + str(tst) + ' Standby Test Frame Register Values', level=2)
    #         VRG_AsilData.SM_STANDBY_TEST_FRAME(df_test, tst, document, pltPath, showPlt)

    # try:
    # VRG_AsilData.SM_STANDBY_TEST_FRAME(df, None, document, pltPath, showPlt)
    # except:
    #     pass

    # showPlt = False  # Show Plots (T/F)
    # temp = 'TemperatureSetPoint' # Group Plots by Temperatures
    # die = 'Die' # Group Plots by Die
    # STBY = 2136 # value of reset register in standby
    # STRM = 2140 # value of reset register in standby
    # tempH = 125 # High temp
    # tempN = 60 # Nom temp
    # tempL = -40 # Low temp
    # df_stby = VRG_DataFrame.newdataframe(df, 'RegWr00_MODE_SELECT', STBY)
    # df_strm = VRG_DataFrame.newdataframe(df, 'RegWr00_MODE_SELECT', STRM)
    #
    # # IMAGE MODE SPECIFIC DATA
    # IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    # for i in IMG:
    #     df_img = VRG_DataFrame.newdataframe(df, 'ImgMode', i)
    #     df_img_stby = VRG_DataFrame.newdataframe(df_img, 'RegWr00_MODE_SELECT', STBY)
    #     df_img_strm = VRG_DataFrame.newdataframe(df_img, 'RegWr00_MODE_SELECT', STRM)
    #
    #     document.add_heading(i, level=1)
    #     document.add_heading(i + ' Temperature Sensor Data Average')
    #     VRG_TempsensorData.Tempsensor_Read_Average_Plot(df_img, [temp, die], document, pltPath, showPlt)
    #
    #     document.add_heading('Temperature Sensor Data at ' + str(tempN))
    #     VRG_TempsensorData.Tempsensor_Read_vs_Time_Plot(df_img, temp, tempN, document, pltPath, showPlt)
    #     VRG_TempsensorData.Tempsensor_Read_vs_TestNo_Plot(df_img, temp, tempN, document, pltPath, showPlt)
    #

    # dm1 = 'DVM_Supply_Increase'
    # t1 = 'Voltage_Increase'
    # df[t1] = (df[dm1] + 1) * .02
    #
    # # IMAGE MODE SPECIFIC DATA
    # IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    # for i in IMG:
    #     df_img = VRG_DataFrame.newdataframe(df, 'ImgMode', i)
    #
    #     document.add_heading(i, level=1)
    #     document.add_heading(i + ' SM Voltage Supply Monitor Names vs. Time', level=2)
    #     VRG_AsilData.SM_CHIP_SUPPLY_VOLTAGE_MONITOR_NAMES_vs_Time_Plot(df_img, None, None, document, pltPath, showPlt)

    #
    # cint = 'RegWr00_COARSE_INTEGRATION_TIME_'
    # dataPed = 'RegWr01_DATA_PEDESTAL_'
    # rnc = 'RegWr02_DARK_CONTROL__DARK_CONTROL_ROW_NOISE_CORRECTION_EN'
    # noiseFreq = 'GpibSignalFreq_PSRR'
    # noiseAmp = 'GpibSignalAmplitude_PSRR'
    # pwrSupply = 'VAA [V]'
    # df_img = VRG_DataFrame.newdataframe(df, 'Power', 'Max')
    # document.add_heading('PSSR VAA Statistics')
    # VRG_PowerData.PSRR_Statistics_Table(df_img, None, None, document)
    # document.add_heading('PSSR VAA Measurement Data')
    # VRG_PowerData.PSSR_Measurement_Plot(df_img, 'ImgMode', document, pltPath, showPlt)
    # VRG_PowerData.PSSR_Measurement_Plot(df_img, noiseFreq, document, pltPath, showPlt, lines=False)
    # VRG_PowerData.PSSR_Measurement_Plot(df_img, noiseAmp, document, pltPath, showPlt, lines=False)
    # VRG_PowerData.PSSR_vs_Noise_Frequency_Plot(df_img, 'ImgMode', document, pltPath, showPlt, lines=False, ax_scale='logx')
    # VRG_PowerData.PSSR_vs_Noise_Frequency_Plot(df_img, noiseAmp, document, pltPath, showPlt, lines=False, ax_scale='logx')
    # VRG_PowerData.PSSR_vs_Noise_Amplitude_Plot(df_img, 'ImgMode', document, pltPath, showPlt, lines=False)
    # VRG_PowerData.PSSR_vs_Noise_Amplitude_Plot(df_img, noiseFreq, document, pltPath, showPlt, lines=False)
    #
    # showPlt = False  # Show Plots (T/F)
    # temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    # die = 'Die'  # Group Plots by Die
    # cint = 'RegWr00_COARSE_INTEGRATION_TIME_'
    # dataPed = 'RegWr01_DATA_PEDESTAL_'
    # rnc = 'RegWr02_DARK_CONTROL__DARK_CONTROL_ROW_NOISE_CORRECTION_EN'
    # noiseFreq = 'GpibSignalFreq_PSRR'
    # noiseAmp = 'GpibSignalAmplitude_PSRR'
    # pwrSupply = 'VDD [V]'
    # df_img = VRG_DataFrame.newdataframe(df, 'Power', 'Max')
    #
    # document.add_heading('PSSR VDD Statistics')
    # VRG_PowerData.PSRR_Statistics_Table(df_img, None, None, document)
    # document.add_heading('PSSR VDD Measurement Data')
    # VRG_PowerData.PSSR_Measurement_Plot(df_img, 'ImgMode', document, pltPath, showPlt)
    # VRG_PowerData.PSSR_Measurement_Plot(df_img, noiseFreq, document, pltPath, showPlt, lines=False)
    # VRG_PowerData.PSSR_Measurement_Plot(df_img, noiseAmp, document, pltPath, showPlt, lines=False)
    # VRG_PowerData.PSSR_vs_Noise_Frequency_Plot(df_img, 'ImgMode', document, pltPath, showPlt, lines=False, ax_scale='logx')
    # VRG_PowerData.PSSR_vs_Noise_Frequency_Plot(df_img, noiseAmp, document, pltPath, showPlt, lines=False, ax_scale='logx')
    # VRG_PowerData.PSSR_vs_Noise_Amplitude_Plot(df_img, 'ImgMode', document, pltPath, showPlt, lines=False)
    # VRG_PowerData.PSSR_vs_Noise_Amplitude_Plot(df_img, noiseFreq, document, pltPath, showPlt, lines=False)

    # # IMAGE MODE SPECIFIC DATA
    # IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    # TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    # nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    # for i in IMG:
    #     df_img = VRG_DataFrame.newdataframe(df, 'ImgMode', i)
    #
    #     document.add_heading(i + ' PSSR VDD Measurement Data', level=2)
    #     VRG_PowerData.PSSR_Measurement_Plot(df_img, noiseFreq, document, pltPath, showPlt)
    #     document.add_heading(i + ' PSSR VDD Measurement Data vs. Noise Amplitude', level=2)
    #     VRG_PowerData.PSSR_Measurement_Plot(df_img, noiseAmp, document, pltPath, showPlt)
    #
    #     document.add_heading(i + ' PSSR VDD Data vs. Noise Frequency', level=2)
    #     VRG_PowerData.PSSR_vs_Noise_Frequency_Plot(df_img, None, document, pltPath, showPlt)
    #
    #     document.add_heading(i + ' PSSR VDD Data vs. Noise Amplitude', level=2)
    #     VRG_PowerData.PSSR_vs_Noise_Amplitude_Plot(df_img, None, document, pltPath, showPlt)

    # VRG_PowerData.PSSR_Measurement_Plot(df, 'ImgMode', document, pltPath, showPlt)

    # df_img = VRG_DataFrame.newdataframe(df, 'Clk', 20)

    # document.add_heading('Standby Power & Current vs. Voltage Level')
    # VRG_PowerData.Power_Consumption_Plot(df_img, [die, temp, 'Power', 'Clk'], document, pltPath, showPlt)
    # VRG_PowerData.Current_Consumption_Plot(df_img, [die, temp, 'Power', 'Clk'], document, pltPath, showPlt)

    # document.add_heading('Operating Power & Current vs. Voltage Level')
    # VRG_PowerData.Power_Consumption_Plot(df_img, ['ImgMode', temp, 'Power', 'Clk'], document, pltPath, showPlt)
    # VRG_PowerData.Current_Consumption_Plot(df_img, ['ImgMode', temp, 'Power', 'Clk'], document, pltPath, showPlt)

    # IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    # for i in IMG:
    #     df_img_mode = VRG_DataFrame.newdataframe(df_img, 'ImgMode', i)
    #     document.add_heading('Operating Power & Current vs. Voltage Level')
    #     VRG_PowerData.Power_Consumption_Plot(df_img_mode, ['ImgMode', temp, 'Power', 'Clk'], document, pltPath, showPlt)
    #     VRG_PowerData.Current_Consumption_Plot(df_img_mode, ['ImgMode', temp, 'Power', 'Clk'], document, pltPath, showPlt)

    # digGain = 'RegWr01_GLOBAL_GAIN'
    # nomDigGain = 128
    # digDither = 'RegWr02_DIGITAL_CTRL'
    # ditherEnable = 4360
    # ditherDisable = 4392
    # dataPed = 0
    #
    # IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    # TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    # nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    # for i in IMG:
    #     df_img = VRG_DataFrame.newdataframe(df, 'ImgMode', i)
    #     # df_ditherDisable = VRG_DataFrame.newdataframe(df_img, digDither, ditherDisable)  # dither disable
    #     # df_ditherEnable = VRG_DataFrame.newdataframe(df_img, digDither, ditherEnable)  # dither disable
    #
    #     document.add_heading(i + ' Calculated Digital Gain vs. Power', level=2)
    #     VRG_Calculate.Calc_DigitalGain_Plot(df_img, 'Power', document, pltPath, digGain, nomDigGain, dataPed,
    #                                         showPlt)
    #     document.add_heading(i + ' Calculated Digital Gain', level=2)
    #     VRG_Calculate.Calc_DigitalGain_Plot(df_img, None, document, pltPath, digGain, nomDigGain, dataPed,
    #                                         showPlt)
    # # VRG_General_Data Plots
    # document.add_heading('General Test Data')
    # VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    #
    # # IMAGE MODE SPECIFIC DATA
    # IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    # TEST = np.asarray(df[intTime].unique())
    # TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    # nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    # for i in IMG:
    #     df_img = VRG_DataFrame.newdataframe(df, 'ImgMode', i)
    #     df_img = VRG_DataFrame.newdataframe(df, 'ImgMode', i)
    #     df_nomCint = VRG_DataFrame.newdataframe(df_img, intTime, nomIntTime)
    #     df_nomCint_DigGain = VRG_DataFrame.newdataframe(df_nomCint, digGain, nomDigGain)
    #     df_nomCint_AnaGain = VRG_DataFrame.newdataframe(df_nomCint, anaGain, nomAnaGain)
    #     df_nomDigGain = VRG_DataFrame.newdataframe(df_img, digGain, nomDigGain)
    #     df_nomAnaGain = VRG_DataFrame.newdataframe(df_img, anaGain, nomAnaGain)
    #     df_nomDigGain_AnaGain = VRG_DataFrame.newdataframe(df_nomDigGain, anaGain, nomAnaGain)
    #     for tmp in TEMP:  # Temperature
    #         df_tmp = VRG_DataFrame.newdataframe(df_img, temp, tmp)
    #         document.add_heading(i + ' Image Statistics vs. Nominal Digital & Analog Gain vs. Integration time vs. Temp =' + str(tmp), level=2)
    #         VRG_Stats_Arr.Arr_Mean_Plot(df_nomDigGain_AnaGain, [intTime, temp], document, pltPath, showPlt)
    #         VRG_Stats_Arr.Arr_StdDev_Plot(df_nomDigGain_AnaGain, [intTime, temp], document, pltPath, showPlt)
    #         VRG_Stats_Arr.Arr_TotalNoise_Plot(df_nomDigGain_AnaGain, [intTime, temp], document, pltPath, showPlt)
    #         VRG_Stats_Arr.Arr_FPN_Plot(df_nomDigGain_AnaGain, [intTime, temp], document, pltPath, showPlt)
    #         VRG_Stats_Arr.Arr_Temporal_Plot(df_nomDigGain_AnaGain, [intTime, temp], document, pltPath, showPlt)
    #         VRG_Stats_Arr.Arr_RowStdDev_Plot(df_nomDigGain_AnaGain, [intTime, temp], document, pltPath, showPlt)
    #         VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_nomDigGain_AnaGain, [intTime, temp], document, pltPath, showPlt)
    #         VRG_Stats_Arr.Arr_RowFPN_Plot(df_nomDigGain_AnaGain, [intTime, temp], document, pltPath, showPlt)
    #         VRG_Stats_Arr.Arr_RowTempNoise_Plot(df_nomDigGain_AnaGain, [intTime, temp], document, pltPath, showPlt)
    #         VRG_Stats_Arr.Arr_ColStdDev_Plot(df_nomDigGain_AnaGain, [intTime, temp], document, pltPath, showPlt)
    #         VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_nomDigGain_AnaGain, [intTime, temp], document, pltPath, showPlt)
    #         VRG_Stats_Arr.Arr_ColFPN_Plot(df_nomDigGain_AnaGain, [intTime, temp], document, pltPath, showPlt)
    #         VRG_Stats_Arr.Arr_ColTempNoise_Plot(df_nomDigGain_AnaGain, [intTime, temp], document, pltPath, showPlt)
    #         VRG_Stats_Arr.Arr_Flicker_Plot(df_nomDigGain_AnaGain, [intTime, temp], document, pltPath, showPlt)
    #         VRG_Stats_Arr.Arr_PixelTotalNoise_Plot(df_nomDigGain_AnaGain, [intTime, temp], document, pltPath, showPlt)
    #         VRG_Stats_Arr.Arr_PixelTemporalNoise_Plot(df_nomDigGain_AnaGain, [intTime, temp], document, pltPath, showPlt)
    #         VRG_Stats_Arr.Arr_PixelFPN_Plot(df_nomDigGain_AnaGain, [intTime, temp], document, pltPath, showPlt)
    #         VRG_Stats_Arr.Arr_RowTemporalNoiseRatio_Plot(df_nomDigGain_AnaGain, [intTime, temp], document, pltPath, showPlt)
    #         VRG_Stats_Arr.Arr_ColumnTemporalNoiseRatio_Plot(df_nomDigGain_AnaGain, [intTime, temp], document, pltPath, showPlt)
    #         VRG_Stats_Arr.Arr_RowFPNRatio_Plot(df_nomDigGain_AnaGain, [intTime, temp], document, pltPath, showPlt)
    #         VRG_Stats_Arr.Arr_ColumnFPNRatio_Plot(df_nomDigGain_AnaGain, [intTime, temp], document, pltPath, showPlt)
    #
    #     document.add_heading(i + ' Image Statistics vs. Temp', level=2)
    #     VRG_Stats_Arr.Arr_Mean_Plot(df_img, temp, document, pltPath, showPlt)
    #     VRG_Stats_Arr.Arr_StdDev_Plot(df_img, temp, document, pltPath, showPlt)
    #     VRG_Stats_Arr.Arr_TotalNoise_Plot(df_img, temp, document, pltPath, showPlt)
    #     VRG_Stats_Arr.Arr_FPN_Plot(df_img, temp, document, pltPath, showPlt)
    #     VRG_Stats_Arr.Arr_Temporal_Plot(df_img, temp, document, pltPath, showPlt)
    #     VRG_Stats_Arr.Arr_RowStdDev_Plot(df_img, temp, document, pltPath, showPlt)
    #     VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_img, temp, document, pltPath, showPlt)
    #     VRG_Stats_Arr.Arr_RowFPN_Plot(df_img, temp, document, pltPath, showPlt)
    #     VRG_Stats_Arr.Arr_RowTempNoise_Plot(df_img, temp, document, pltPath, showPlt)
    #     VRG_Stats_Arr.Arr_ColStdDev_Plot(df_img, temp, document, pltPath, showPlt)
    #     VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_img, temp, document, pltPath, showPlt)
    #     VRG_Stats_Arr.Arr_ColFPN_Plot(df_img, temp, document, pltPath, showPlt)
    #     VRG_Stats_Arr.Arr_ColTempNoise_Plot(df_img, temp, document, pltPath, showPlt)
    #     VRG_Stats_Arr.Arr_Flicker_Plot(df_img, temp, document, pltPath, showPlt)
    #     VRG_Stats_Arr.Arr_PixelTotalNoise_Plot(df_img, temp, document, pltPath, showPlt)
    #     VRG_Stats_Arr.Arr_PixelTemporalNoise_Plot(df_img, temp, document, pltPath, showPlt)
    #     VRG_Stats_Arr.Arr_PixelFPN_Plot(df_img, temp, document, pltPath, showPlt)
    #     VRG_Stats_Arr.Arr_RowTemporalNoiseRatio_Plot(df_img, temp, document, pltPath, showPlt)
    #     VRG_Stats_Arr.Arr_ColumnTemporalNoiseRatio_Plot(df_img, temp, document, pltPath, showPlt)
    #     VRG_Stats_Arr.Arr_RowFPNRatio_Plot(df_img, temp, document, pltPath, showPlt)
    #     VRG_Stats_Arr.Arr_ColumnFPNRatio_Plot(df_img, temp, document, pltPath, showPlt)

    # cint = 'RegWr00_COARSE_INTEGRATION_TIME_'
    # dataPed = 'RegWr02_DATA_PEDESTAL_'
    # corrections = 'RegWr01_TEST_RAW_MODE__RAW_DATA'
    #
    # # IMAGE MODE SPECIFIC DATA
    # IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    # TEST = np.asarray(df[corrections].unique())
    # TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    # nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    # for i in IMG:
    #     if i == 'ERS_20fps_T1+T2_Full-Res_14b':
    #         df_img = VRG_DataFrame.newdataframe(df, 'ImgMode', i)
    #         for tst in TEST:  # Test
    #             df_test = VRG_DataFrame.newdataframe(df_img, corrections, tst)
    #             document.add_heading(i + ' Data Pedestal Error vs. Color Planes vs. Raw Mode = ' + str(tst), level=2)
    #
    #             for tmp in TEMP:  # Temperature
    #                 df_tmp = VRG_DataFrame.newdataframe(df_test, temp, tmp)
    #                 if tmp == nomTemp:
    #                     VRG_ImageAnalysis.Add_Image_Analysis_Info(df_tmp, 2, document, showPlt)
    # VRG_PowerData.PowerOnReset_Voltage_Plot(df, None, document, pltPath, showPlt)
    # df.to_csv('C:/Users/fg83rh/Documents/GitHub/VRG/VRG/Reports/Rev2p0/ES_VAL/pordf2csv.csv')  # Save final df with report

    # anaGain = 'DVM_3_09_Analog_Gain'
    # nomAnaGain = 1
    # dataPedestalVal = 168
    # anaGainReg1 = 'RegVal_OCL_T1_GAIN_'
    # anaGainReg2 = 'RegVal_OCL_T1_GAIN2'
    # expBypass = 'RegWr01_LFM2_T1_CTRL'
    # E1_E2 = 32929
    # E1_byp = 33445
    #
    # # IMAGE MODE SPECIFIC DATA
    # IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    # TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    # nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    # for i in IMG:
    #     df_img = VRG_DataFrame.newdataframe(df, 'ImgMode', i)
    #     df_img_minLight = VRG_DataFrame.newdataframe(df_img, 'Light', 500)
    #     df_img_maxLight = VRG_DataFrame.newdataframe(df_img, 'Light', 5000)
    #     df_E1_E2 = VRG_DataFrame.newdataframe(df_img, expBypass, E1_E2)
    #     df_E1_byp = VRG_DataFrame.newdataframe(df_img, expBypass, E1_byp)
    #     df_E1_E2_minLight = VRG_DataFrame.newdataframe(df_img_minLight, expBypass, E1_E2)
    #     df_E1_E2_maxLight = VRG_DataFrame.newdataframe(df_img_maxLight, expBypass, E1_E2)
    #     df_E1_byp_minLight = VRG_DataFrame.newdataframe(df_img_minLight, expBypass, E1_byp)
    #     df_E1_byp_maxLight = VRG_DataFrame.newdataframe(df_img_maxLight, expBypass, E1_byp)
    #     df_tmp.to_csv(
    #         'C:/Users/fg83rh/Documents/GitHub/VRG/VRG/Reports/Rev2p0/ES_VAL/dataframeImages_df2csv.csv')  # Save final df with report
    #
    #     for tmp in TEMP:  # Temperature
    #         df_tmp = VRG_DataFrame.newdataframe(df_E1_byp_minLight, temp, tmp)
    #         if tmp == nomTemp:
    #             print(df_tmp[i0])
    #             print(df_tmp[i1])
    #             print(df_tmp[anaGain])
    #             df_tmp.to_csv('C:/Users/fg83rh/Documents/GitHub/VRG/VRG/Reports/Rev2p0/ES_VAL/dataframeImages_df2csv.csv')  # Save final df with report
    #             df_img_maxLight.to_csv(
    #                 'C:/Users/fg83rh/Documents/GitHub/VRG/VRG/Reports/Rev2p0/ES_VAL/dataframeImages_df2csv.csv')  # Save final df with report

    # document.add_heading(i + ' Image Capture E1 Bypass at Low Lux Level at Temp = ' + str(tmp), level=2)
    # VRG_ImageAnalysis.Add_Image_Analysis_Info(df_tmp, 2, document, showPlt)  # 0.5x ana gain
    # VRG_ImageAnalysis.Add_Image_Analysis_Info(df_tmp, 20, document, showPlt)  # 1x ana gain
    # VRG_ImageAnalysis.Add_Image_Analysis_Info(df_tmp, 56, document, showPlt)  # 2x ana gain
    # VRG_ImageAnalysis.Add_Image_Analysis_Info(df_tmp, 80, document, showPlt)  # 3x ana gain
    # VRG_ImageAnalysis.Add_Image_Analysis_Info(df_tmp, 83, document, showPlt)  # 4x ana gain
    # VRG_ImageAnalysis.Add_Image_Analysis_Info(df_tmp, 95, document, showPlt)  # 8x dig gain

    # eclVal = 'RegWr01_DAC_LD_28_29::SREG_COLAMP_ECL_VALUE'
    # dn = eclVal.replace('::', '__')
    # print(dn)

    # dc1 = 'AdcName'
    # d1 = 'AdcName(col)'
    # df[d1] = df[dc1].str.split('=')[1]
    # print(df[d1])
    #
    # d3 = dc1.split('=')[1]  # get the column number

    # VRG_General_Data.Total_TestTime_Plot(df, temp, document, pltPath, showPlt)
    # VRG_General_Data.EID_vs_Die_Table(df, document)

    # # IMAGE MODE SPECIFIC DATA
    # IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    # TEST = np.asarray(df[test].unique())
    # TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    # nomTemp = min(TEMP, key=lambda x: abs(x - 60))# closest temp to 60C
    # for i in IMG:
    #     df_img = VRG_DataFrame.newdataframe(df, 'ImgMode', i)
    #
    #     for tst in TEST: # Test
    #         df_test = VRG_DataFrame.newdataframe(df_img, test, tst)
    #         for tmp in TEMP:  # Temperature
    #             df_tmp = VRG_DataFrame.newdataframe(df_test, temp, tmp)
    #             if tmp == nomTemp:
    #                 document.add_heading(i + ' Image Capture (' + test + ' = ' + str(tst) + ')', level=2)
    #                 VRG_ImageAnalysis.Add_Image_Analysis_Info(df_tmp, 2, document, showPlt)

    #
    # VRG_ImageUtils.External_Image_Crop(imgPath, 'Step=122of324_Temp=60C_Frm=01.png', document, 34, 0, 64, 20, showPlt) # RRC start
    # VRG_ImageUtils.External_Image_Crop(imgPath, 'Step=122of324_Temp=60C_Frm=01.png', document, 1504, 0, 1536, 20, showPlt)  # RRC mid
    # VRG_ImageUtils.External_Image_Crop(imgPath, 'Step=122of324_Temp=60C_Frm=01.png', document, 3100, 0, 3130, 20, showPlt)  # RRC end
    # VRG_ImageUtils.External_Image_Crop(imgPath, 'Step=122of324_Temp=60C_Frm=01.png', document, 4, 32, 12, 80, showPlt)  # DTR start
    # VRG_ImageUtils.External_Image_Crop(imgPath, 'Step=122of324_Temp=60C_Frm=01.png', document, 4, 2000, 12, 2048, showPlt)  # DTR mid
    # VRG_ImageUtils.External_Image_Crop(imgPath, 'Step=122of324_Temp=60C_Frm=01.png', document, 4, 4088, 12, 4136, showPlt)  # DTR end
    # VRG_ImageUtils.External_Image_Crop(imgPath, 'Step=122of324_Temp=60C_Frm=01.png', document, 3140, 32, 3160, 80, showPlt) # ATR start
    # VRG_ImageUtils.External_Image_Crop(imgPath, 'Step=122of324_Temp=60C_Frm=01.png', document, 3140, 2000, 3160, 2048, showPlt)  # ATR mid
    # VRG_ImageUtils.External_Image_Crop(imgPath, 'Step=122of324_Temp=60C_Frm=01.png', document, 3140, 4088, 3160, 4136, showPlt)  # ATR end
    #
    #

    # d1 = 'FID'
    #
    # EID = df[d1].str.split('_', n=6, expand=True)
    # df['EID_Lot'] = EID[0]
    # df['EID_Wafer'] = EID[1]
    # df['EID_X_Position'] = EID[2]
    # df['EID_Y_Position'] = EID[3]
    # df['EID_C_Feature'] = EID[4]
    # df['EID_Design_Rev'] = EID[5]
    # df['EID_Fab_ID'] = EID[6]
    #
    # print(df['EID_Lot'])
    # print(df['EID_Wafer'])
    # print(df['EID_X_Position'])
    # print(df['EID_Y_Position'])
    # print(df['EID_C_Feature'])
    # print(df['EID_Design_Rev'])
    # print(df['EID_Fab_ID'])
    #
    # df['EID_X_Position'] = df['EID_X_Position'].str.replace('P', '')
    # df['EID_X_Position']= df['EID_X_Position'].str.replace('N', '-')
    # print(df['EID_X_Position'])

    # VRG_OTPMData.OTPM_Auto_Read_Plot(df, None, document, pltPath, showPlt)
    # VRG_OTPMData.OTPM_Manual_Read_Plot(df, None, document, pltPath, showPlt)

    # df_img = VRG_DataFrame.newdataframe(df, 'ImgMode', 'GS+HDR_20fps_Full-Res_14b')
    # df_img.to_csv('C:/Users/fg83rh/Documents/GitHub/VRG/VRG/CSV/Rev2p0/Rev2p0_AS/df2csv_test.csv')  # Save final df with report

    # VRG_ImageUtils.Image_Crop(imgPath,'1606987318.000000003C0460C22255361252410949.PKGSORT.S014F.IP750-99.0.Bin_D.png',document, showPlt)

    # ULcolor = '#ff0000'
    # LLcolor = '#0000ff'
    # cint = 'RegWr00_COARSE_INTEGRATION_TIME_'
    # digGain = 'RegWr01_GLOBAL_GAIN'
    # anaGain = 'DVM_3_09_Analog_Gain'
    # rncCorrection = 'RegWr02_DARK_CONTROL::DARK_CONTROL_ROW_NOISE_CORRECTION_EN'
    #
    # IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    # TEST = np.asarray(df[rncCorrection].unique())
    # TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    # nomTemp = min(TEMP, key=lambda x: abs(x - 60))
    # for i in IMG:
    #     df_img = VRG_DataFrame.newdataframe(df, 'ImgMode', i)
    #
    #     for tst in TEST:
    #         df_test = VRG_DataFrame.newdataframe(df_img, rncCorrection, tst)
    #         VRG_Stats_Arr.Arr_Mean_Plot(df_test, cint, document, pltPath, showPlt)
    #         VRG_Stats_Arr.Arr_Mean_Plot(df_test, anaGain, document, pltPath, showPlt)
    #         VRG_Stats_Arr.Arr_Mean_Plot(df_test, digGain, document, pltPath, showPlt)

    # VRG_ImageUtils.Frame_CRC(imgPath, 'testpattern14bit.raw')

    # intTime = 'RegWr00_COARSE_INTEGRATION_TIME_'
    # nomIntTime = 934
    # digGain = 'RegWr02_GLOBAL_GAIN'
    # nomDigGain = 128
    # dataPed = 'RegWr01_DATA_PEDESTAL_'
    # nomAnaGain = 168
    #
    # IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    # TEST = np.asarray(df[intTime].unique())
    # TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    # nomTemp = min(TEMP, key=lambda x: abs(x - 60))# closest temp to 60C
    # for i in IMG:
    #     df_img = VRG_DataFrame.newdataframe(df, 'ImgMode', i)
    #     VRG_Calculate.Calc_DataPedestal_Error_Plot(df_img, None, document, pltPath, dataPed, showPlt)

    #
    # intTime = 'RegWr00_COARSE_INTEGRATION_TIME_'
    # nomIntTime = 934
    # digGain = 'RegWr01_GLOBAL_GAIN'
    # nomDigGain = 128
    # anaGain = 'DVM_3_09_Analog_Gain'
    # nomAnaGain = 1.11
    #
    #
    # # IMAGE MODE SPECIFIC DATA
    # IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    # TEST = np.asarray(df[intTime].unique())
    # TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    # nomTemp = min(TEMP, key=lambda x: abs(x - 60))# closest temp to 60C
    # for i in IMG:
    #     df_img = VRG_DataFrame.newdataframe(df, 'ImgMode', i)
    #     df_digGainN = VRG_DataFrame.newdataframe(df_img, digGain, nomDigGain)
    #     df_anaGainN = VRG_DataFrame.newdataframe(df_digGainN, anaGain, nomAnaGain)
    #
    #     document.add_heading(i, level=1)
    #     document.add_heading(i + ' Image Statistics vs. Nominal Digital & Analog Gain vs. Integration time', level=2)
    #     VRG_Stats_Arr.Arr_Mean_Plot(df_img, intTime, document, pltPath, showPlt, row=digGain, ax_size=[225, 225], ax_hlines=[600])
    #
    #
    # VRG_ImageAnalysis.Add_Image(df, 0, document, True)
    # VRG_ImageAnalysis.Add_Image(df, 1, document, True)
    # VRG_ImageAnalysis.Add_Image(df, 114, document, True)

    # # IMAGE MODE SPECIFIC DATA
    # IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    # TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    # nomTemp = min(TEMP, key=lambda x: abs(x - 60))
    # for i in IMG:
    #     df_img = VRG_DataFrame.newdataframe(df, 'ImgMode', i)
    #     for tmp in TEMP:  # Temperature
    #         df_tmp = VRG_DataFrame.newdataframe(df_img, temp, tmp)
    #         document.add_heading(i + ' Image Capture', level=2)
    #         VRG_ImageAnalysis.Add_Image(df_tmp, 1, document, showPlt)

    # # IMAGE MODE SPECIFIC DATA
    # IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    # DIE = np.asarray(df[die].unique())
    # TEST = np.asarray(df[test].unique())
    # TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    # nomTemp = min(TEMP, key=lambda x: abs(x - 60))# closest temp to 60C

    # TEMP = np.asarray(df[temp].unique())
    # nomTemp = min(TMP, key=lambda x:abs(x-60))
    #
    # print(nomTemp)
    #
    #
    # VRG_ImageAnalysis.Add_Image_Analysis_Info(df, imgPath, 43, document, True)

    # testPatReg = 'RegWr00_TEST_PATTERN_MODE_'
    #
    # # IMAGE MODE SPECIFIC DATA
    # IM = np.asarray(df['ImgMode'].unique())  # List of unique image
    # TEST = np.asarray(df[testPatReg].unique())  # List of unique reg values
    # for i in IMG:
    #     df_img = VRG_DataFrame.newdataframe(df, 'ImgMode', i)
    #
    #     document.add_heading(i, level=1)
    #     document.add_heading(i + ' Test Pattern Reg Values vs. Die vs. Test Pattern Test', level=2)
    #     VRG_RegisterData.MIPI_CRC_Registers(df, [die, testPatReg], document, pltPath, showPlt)
    #
    #     for t in TEST:
    #         df_test = VRG_DataFrame.newdataframe(df_img, testPatReg, t)
    #
    #         document.add_heading(i + ' Test Pattern Image (' + testPatReg + ' = ' + str(t) + ')', level=2)
    #         VRG_ImageAnalysis.Add_Image(df_test, imgPath, 2, document,
    #                                     showPlt)  # adds 2st image of each data frame (nom)
    #         if t == 1: #Solid Color Test
    #             document.add_heading('Solid Color Test Pattern Reg Values', level=2)
    #             VRG_RegisterData.Reg_vs_Step_Plot(df, None, document, pltPath, 'RegWr01_TEST_DATA_RED_', showPlt)
    #             VRG_RegisterData.Reg_vs_Step_Plot(df, None, document, pltPath, 'RegWr02_TEST_DATA_GREENR_', showPlt)
    #             VRG_RegisterData.Reg_vs_Step_Plot(df, None, document, pltPath, 'RegWr03_TEST_DATA_BLUE_', showPlt)
    #             VRG_RegisterData.Reg_vs_Step_Plot(df, None, document, pltPath, 'RegWr04_TEST_DATA_GREENB_', showPlt)
    #
    #         document.add_heading(i + ' Test Pattern CRC Values (' + testPatReg + ' = ' + str(t) + ')', level=2)
    #         VRG_RegisterData.MIPI_CRC_Registers(df_test, [die, 'Power', testPatReg], document, pltPath, showPlt)
    #
    #         document.add_heading(i + ' Test Pattern Image Statistics(' + testPatReg + ' = ' + str(t) + ')', level=2)
    #         VRG_Stats_Arr.Arr_Mean_Plot(df_test, [die, testPatReg], document, pltPath, showPlt)
    #         VRG_Stats_Arr.Arr_StdDev_Plot(df_test, [die, testPatReg], document, pltPath, showPlt)

    # colMemReg = 'RegWr00_DAC_LD_34_35'
    #
    # # VRG_RegisterData.MIPI_CRC_Registers(df, ['ImgMode', colMemReg], document, pltPath, showPlt)
    #
    #
    # # IMAGE MODE SPECIFIC DATA
    # IM = np.asarray(df['ImgMode'].unique())  # List of unique image
    # CM = np.asarray(df[colMemReg].unique())  # List of unique colmem reg values
    # for i in IMG:
    #     df_img = VRG_DataFrame.newdataframe(df, 'ImgMode', i)
    #     document.add_heading(i, level=1)
    #
    #     for c in CM:
    #         df_cm = VRG_DataFrame.newdataframe(df_img, colMemReg, c)
    #
    #         document.add_heading(i + ' Column Memory Image (' + colMemReg + ' = ' + str(c) + ')', level=2)
    #         VRG_ImageAnalysis.Add_Image(df_cm, imgPath, 1, document, showPlt)
    #
    #         document.add_heading(i + ' Column Memory CRC Values (' + colMemReg + ' = ' + str(c) + ')', level=2)
    #         VRG_RegisterData.MIPI_CRC_Registers(df_cm, [die, 'Power', colMemReg], document, pltPath, showPlt)

    # VRG_PowerData.Booster_Voltage_Plot(df, None, document, pltPath, showPlt)
    # VRG_PowerData.Positive_Booster_Voltage_Plot(df, None, document, pltPath, showPlt)
    # VRG_PowerData.Middle_Booster_Voltage_Plot(df, None, document, pltPath, showPlt)
    # VRG_PowerData.Negative_Booster_Voltage_Plot(df, None, document, pltPath, showPlt)

    # document.add_heading('Booster Voltages vs. Imaging Mode vs. Power')
    # VRG_PowerData.Booster_Voltage_Plot(df, ['ImgMode', 'Power'], document, pltPath, showPlt)
    # document.add_heading('Booster Voltages vs. Imaging Mode vs. Power vs. Temp')
    # VRG_PowerData.Booster_Voltage_Plot(df, ['ImgMode', 'Power', temp], document, pltPath, showPlt)

    # document.add_heading('External Image Analysis')
    # VRG_ImageAnalysis.Add_External_Image_Analysis(imgPath,'1606987318.000000003C0460C22255361252410949.PKGSORT.S014F.IP750-99.0.Bin_D.png',document, showPlt)
    # VRG_ImageAnalysis.Add_External_Image_Analysis(imgPath,'1606987322.000000003C0460C22255361252410949.PKGSORT.S014F.IP750-99.0.Bin_M.png',document, showPlt)
    # VRG_ImageAnalysis.Add_External_Image_Analysis(imgPath,'1606987318.00000000968064824E204DD1F206002D.PKGSORT.S014F.IP750-99.1.Bin_D.png',document, showPlt)
    # VRG_ImageAnalysis.Add_External_Image_Analysis(imgPath,'1606987322.00000000968064824E204DD1F206002D.PKGSORT.S014F.IP750-99.1.Bin_M.png',document, showPlt)

    # VRG_AsilData.SM_Digital_Test_Rows_Plot(df, None, document, pltPath, showPlt)
    # VRG_AsilData.SM_Digital_Test_Rows_Expanded_Plot(df, None, document, pltPath, showPlt)

    # document.add_heading('ASIL Runtime')
    # VRG_AsilData.SM_Runtime_Plot(df, [die, temp], document, pltPath, showPlt)

    # VRG_ImageAnalysis.Add_Image(df, imgPath, 1, document, True)
    # VRG_ImageAnalysis.Add_Image_Info(df, imgPath, 23, document, True)
    # VRG_ImageAnalysis.Add_Image_Info(df, imgPath, 20, document, True)
    # VRG_ImageAnalysis.Add_Image_Info(df, imgPath, 42, document, True)
    # VRG_ImageAnalysis.Add_Image(df, imgPath, 1, document, True)
    # VRG_ImageAnalysis.Add_Image_Info(df, imgPath, 1, document, True)
    # VRG_ImageAnalysis.Add_Image_Analysis(df, imgPath, 1, document, True)

    # VRG_ImageAnalysis.Add_Image_Analysis(df, imgPath, 5, document, True)
    # VRG_ImageAnalysis.Add_Image_Analysis(df, imgPath, 7, document, showPlt)
    # VRG_ImageAnalysis.Add_Image_Analysis(df, imgPath, 20, document, showPlt)
    # VRG_ImageAnalysis.Add_Image_Analysis(df, imgPath, 40, document, showPlt)

    # VRG_PowerData.Current_Consumption_Plot(df, None, document, pltPath, showPlt)
    # VRG_PowerData.Current_Consumption_Table(df, None, None, document)
    # VRG_PowerData.Power_Consumption_Table(df, None, None, document)

    # VRG_Stats_Frame.Reg_vs_Reg_vs_Img_Mean_Plot(df, 'ImgMode', document, pltPath, 'Light', 'RegWr00_COARSE_INTEGRATION_TIME_', showPlt)
    # VRG_Stats_Frame.Reg_vs_Reg_vs_Img_StdDev_Plot(df, 'ImgMode', document, pltPath, 'Light', 'RegWr00_COARSE_INTEGRATION_TIME_', showPlt)
    # VRG_Stats_Frame.Reg_vs_Reg_vs_Img_TotalNoise_Plot(df, 'ImgMode', document, pltPath, 'Light', 'RegWr00_COARSE_INTEGRATION_TIME_', showPlt)

    # IMG = np.asarray(df['ImgMode'].unique()) # List of unique image modes
    # for i in IMG:
    #     df_img = VRG_DataFrame.newdataframe(df, 'ImgMode', i)
    #     df_img_minV = VRG_DataFrame.newdataframe(df_img, 'Power', 'Min')
    #     document.add_heading(i, level=1)
    #     VRG_Stats_Arr.Arr_Mean_Plot(df_img, [die, temp], document, pltPath, showPlt)

def DV_CUSTOM_TEST_2(df, document, imgPath, pltPath):  # Custom Test Code
    showPlt = True  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'
    die = 'Die'

    VRG_General_Data.TemperatureSetPoint_Plot(df, None, document, pltPath, showPlt)
    VRG_General_Data.Data_vs_Step_Plot(df, 'Clk', document, pltPath, 'TemperatureSetPoint', showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        # ImgMode 1 Voltage, Power, and Current
        document.add_heading(i, level=1)
        document.add_heading(i + ' Data', level=2)
        VRG_General_Data.Data_vs_Step_Plot(df_img, 'Clk', document, pltPath, 'TemperatureSetPoint', showPlt)

def DV_CUSTOM_TEST_3(df, document, imgPath, pltPath):  # Custom Test Code
    showPlt = True  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'
    die = 'Die'

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        # ImgMode 1 Voltage, Power, and Current
        document.add_heading(i, level=1)
        document.add_heading(i + ' Data', level=2)

def DV_CUSTOM_TEST_4(df, document, imgPath, pltPath):  # Custom Test Code
    showPlt = True  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'
    die = 'Die'

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        # ImgMode 1 Voltage, Power, and Current
        document.add_heading(i, level=1)
        document.add_heading(i + ' Data', level=2)

def DV_CUSTOM_TEST_5(df, document, imgPath, pltPath):  # Custom Test Code
    showPlt = True  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'
    die = 'Die'

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        # ImgMode 1 Voltage, Power, and Current
        document.add_heading(i, level=1)
        document.add_heading(i + ' Data', level=2)

def DV_CUSTOM_TEST_6(df, document, imgPath, pltPath):  # Custom Test Code
    showPlt = True  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'
    die = 'Die'

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        # ImgMode 1 Voltage, Power, and Current
        document.add_heading(i, level=1)
        document.add_heading(i + ' Data', level=2)

def DV_CUSTOM_TEST_7(df, document, imgPath, pltPath):  # Custom Test Code
    showPlt = True  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'
    die = 'Die'

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        # ImgMode 1 Voltage, Power, and Current
        document.add_heading(i, level=1)
        document.add_heading(i + ' Data', level=2)

def DV_CUSTOM_TEST_8(df, document, imgPath, pltPath):  # Custom Test Code
    showPlt = True  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'
    die = 'Die'

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        # ImgMode 1 Voltage, Power, and Current
        document.add_heading(i, level=1)
        document.add_heading(i + ' Data', level=2)

def DV_CUSTOM_TEST_9(df, document, imgPath, pltPath):  # Custom Test Code
    showPlt = True  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'
    die = 'Die'

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        # ImgMode 1 Voltage, Power, and Current
        document.add_heading(i, level=1)
        document.add_heading(i + ' Data', level=2)

def DV_CUSTOM_TEST_10(df, document, imgPath, pltPath):  # Custom Test Code
    showPlt = True  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'
    die = 'Die'

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        # ImgMode 1 Voltage, Power, and Current
        document.add_heading(i, level=1)
        document.add_heading(i + ' Data', level=2)


'''
1.00 GLOBAL FUNCTIONS
'''
def DV_0_00_ASIC_RAPID_CHECK(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.LightLevel_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    # document.add_heading('Temperature Sensor')
    # VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # Primary Voltage, Power, and Current
    document.add_heading('Standby Power & Current vs. Voltage Level')
    VRG_Power_Data.Supply_Voltage_Plot(df, [die, temp, 'Power'], document, pltPath, showPlt)
    VRG_Power_Data.Standby_Power_Consumption_Plot(df, [die, temp, 'Power'], document, pltPath, showPlt)
    VRG_Power_Data.Standby_Current_Consumption_Plot(df, [die, temp, 'Power'], document, pltPath, showPlt)
    document.add_heading('Standby Power & Current vs. Light')
    VRG_Power_Data.Standby_Power_Consumption_Plot(df, [die, temp, 'Light'], document, pltPath, showPlt)
    VRG_Power_Data.Standby_Current_Consumption_Plot(df, [die, temp, 'Light'], document, pltPath, showPlt)
    document.add_heading('Standby Power & Current vs. Clk')
    VRG_Power_Data.Standby_Power_Consumption_Plot(df, [die, temp, 'Clk'], document, pltPath, showPlt)
    VRG_Power_Data.Standby_Current_Consumption_Plot(df, [die, temp, 'Clk'], document, pltPath, showPlt)

    # Primary Voltage, Power, and Current
    document.add_heading('Operating Power & Current vs. Imaging Mode')
    VRG_Power_Data.Power_Consumption_Plot(df, [die, temp, 'ImgMode'], document, pltPath, showPlt)
    VRG_Power_Data.Current_Consumption_Plot(df, [die, temp, 'ImgMode'], document, pltPath, showPlt)
    document.add_heading('Operating Power & Current vs. Voltage Level')
    VRG_Power_Data.Power_Consumption_Plot(df, [die, temp, 'Power'], document, pltPath, showPlt)
    VRG_Power_Data.Current_Consumption_Plot(df, [die, temp, 'Power'], document, pltPath, showPlt)
    document.add_heading('Operating Power & Current vs. Light')
    VRG_Power_Data.Power_Consumption_Plot(df, [die, temp, 'Light'], document, pltPath, showPlt)
    VRG_Power_Data.Current_Consumption_Plot(df, [die, temp, 'Light'], document, pltPath, showPlt)
    document.add_heading('Operating Power & Current vs. Clk')
    VRG_Power_Data.Power_Consumption_Plot(df, [die, temp, 'Clk'], document, pltPath, showPlt)
    VRG_Power_Data.Current_Consumption_Plot(df, [die, temp, 'Clk'], document, pltPath, showPlt)

    document.add_heading('Functional Safety Results vs. ImgMode')
    VRG_Safety_Data.ASIL_PIN_ENABLES(df, 'ImgMode', document, pltPath, showPlt)
    VRG_Safety_Data.ASIL_CHECK_ENABLES(df, 'ImgMode', document, pltPath, showPlt)
    VRG_Safety_Data.ASIL_STATUS(df, 'ImgMode', document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        # ImgMode 1 Voltage, Power, and Current
        document.add_heading(i, level=1)
        document.add_heading(i + ' Operating Power & Current vs. Voltage Level', level=2)
        VRG_Power_Data.Supply_Voltage_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.Power_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)
        document.add_heading(i + ' Operating Power & Current vs. Light', level=2)
        VRG_Power_Data.Power_Consumption_Plot(df_img, 'Light', document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, 'Light', document, pltPath, showPlt)
        document.add_heading(i + ' Operating Power & Current vs. Clk', level=2)
        VRG_Power_Data.Power_Consumption_Plot(df_img, 'Clk', document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, 'Clk', document, pltPath, showPlt)

def DV_0_01_GLOBAL_FUNCTIONS(df, document, imgPath, pltPath):
    showPlt = True  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'
    die = 'Die'

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        # ImgMode 1
        document.add_heading(i, level=1)

def DV_0_01_FRAME_RATE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    ULcolor = '#ff0000'
    LLcolor = '#0000ff'
    cint = 'RegWr00_COARSE_INTEGRATION_TIME_'
    resetReg = 'RegWr01_MODE_SELECT'
    reg1 = 'FRAME_LENGTH_LINES_'
    reg2 = 'LINE_LENGTH_PCK_'
    reg3 = 'PLL_MULTIPLIER'
    reg4 = 'PRE_PLL_CLK_DIV'
    reg5 = 'VT_SYS_CLK_DIV'
    reg6 = 'VT_PIX_CLK_DIV'
    reg7 = 'OP_SYS_CLK_DIV'
    reg8 = 'OP_WORD_CLK_DIV'

    limit1 = 'LIMIT__Sensor_30FPS'
    limit2 = 'LIMIT__Sensor_45FPS'
    limit3 = 'LIMIT__Sensor_60FPS'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.LightLevel_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    document.add_heading('Calculated FPS vs. Clk', level=2)
    VRG_General_Data.Calc_FPS_Plot(df, ['ImgMode','Clk'], document, pltPath, showPlt, ax_hlines=[(limit1, ULcolor, '--', 2, 1), (limit2, ULcolor, '--', 2, 1), (limit3, ULcolor, '--', 2, 1)])
    document.add_heading('FPS vs. Clk', level=2)
    VRG_General_Data.Sensor_FPS_Plot(df, ['ImgMode','Clk'], document, pltPath, showPlt, ax_hlines=[(limit1, ULcolor, '--', 2, 1), (limit2, ULcolor, '--', 2, 1), (limit3, ULcolor, '--', 2, 1)])

    document.add_heading('Operating Power & Current vs. Imaging Mode')
    VRG_Power_Data.Power_Consumption_Plot(df, [die, temp, 'ImgMode'], document, pltPath, showPlt)
    VRG_Power_Data.Current_Consumption_Plot(df, [die, temp, 'ImgMode'], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        # ImgMode 1 Voltage, Power, and Current
        document.add_heading(i, level=1)
        document.add_heading(i + ' Key Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, cint, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, resetReg, showPlt)

        document.add_heading(i + ' Frame Rate & PLL Related Registers', level=2)
        for x in range(1, 15):
            reg = eval("reg" + str(x))
            VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, reg, showPlt)

        document.add_heading(i + ' Frame Time vs. Clk', level=2)
        VRG_General_Data.FrameTime_Plot(df_img, 'Clk', document, pltPath, showPlt)
        document.add_heading(i + ' Calculated FPS vs. Clk', level=2)
        VRG_General_Data.Calc_FPS_Plot(df_img, 'Clk', document, pltPath, showPlt, ax_hlines=[(limit1, ULcolor, '--', 2, 1),(limit2, ULcolor, '--', 2, 1),(limit3, ULcolor, '--', 2, 1) ])
        document.add_heading(i + ' FPS vs. Clk', level=2)
        VRG_General_Data.Sensor_FPS_Plot(df_img, 'Clk', document, pltPath, showPlt, ax_hlines=[(limit1, ULcolor, '--', 2, 1), (limit2, ULcolor, '--', 2, 1), (limit3, ULcolor, '--', 2, 1)])
        document.add_heading(i + ' Sensor Data Rate vs. Clk', level=2)
        VRG_General_Data.Calc_Sensor_Data_Rate_Plot(df_img, 'Clk', document, pltPath, showPlt)
        document.add_heading(i + ' PLL Clocks vs. Clk', level=2)
        VRG_General_Data.PLL_Clock_Plot(df_img, 'Clk', document, pltPath, showPlt)
        document.add_heading(i + ' I2C Status vs. Clk', level=2)
        VRG_General_Data.I2C_Status_Plot(df_img, 'Clk', document, pltPath, showPlt)

        document.add_heading(i + ' Power & Current vs. Clk', level=2)
        VRG_Power_Data.Power_Consumption_Plot(df_img, 'Clk', document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, 'Clk', document, pltPath, showPlt)

        document.add_heading(i + ' Power & Current vs. Power vs. Clk', level=2)
        VRG_Power_Data.Power_Consumption_Plot(df_img, ['Power', 'Clk'], document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, ['Power', 'Clk'], document, pltPath, showPlt)

def DV_1_00_STANDBY_CURRENT(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.LightLevel_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # Primary Voltage, Power, and Current
    document.add_heading('Standby Power & Current vs. Voltage Level')
    VRG_Power_Data.Supply_Voltage_Plot(df, [die, temp, 'Power'], document, pltPath, showPlt)
    VRG_Power_Data.Power_Consumption_Plot(df, [die, temp, 'Power'], document, pltPath, showPlt)
    VRG_Power_Data.Current_Consumption_Plot(df, [die, temp, 'Power'], document, pltPath, showPlt)
    document.add_heading('Standby Power & Current vs. Light')
    VRG_Power_Data.Power_Consumption_Plot(df, [die, temp, 'Light'], document, pltPath, showPlt)
    VRG_Power_Data.Current_Consumption_Plot(df, [die, temp, 'Light'], document, pltPath, showPlt)
    document.add_heading('Standby Power & Current vs. Clk')
    VRG_Power_Data.Power_Consumption_Plot(df, [die, temp, 'Clk'], document, pltPath, showPlt)
    VRG_Power_Data.Current_Consumption_Plot(df, [die, temp, 'Clk'], document, pltPath, showPlt)

def DV_1_00_OPERATING_CURRENT(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.LightLevel_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_Macro_Data.MetaData_Enable_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # Primary Voltage, Power, and Current
    document.add_heading('Operating Power & Current vs. Voltage Level')
    VRG_Power_Data.Supply_Voltage_Plot(df, [die, temp, 'Power'], document, pltPath, showPlt)
    VRG_Power_Data.Power_Consumption_Plot(df, [die, temp, 'Power'], document, pltPath, showPlt)
    VRG_Power_Data.Current_Consumption_Plot(df, [die, temp, 'Power'], document, pltPath, showPlt)
    document.add_heading('Operating Power & Current vs. Imaging Mode')
    VRG_Power_Data.Power_Consumption_Plot(df, [die, temp, 'ImgMode'], document, pltPath, showPlt)
    VRG_Power_Data.Current_Consumption_Plot(df, [die, temp, 'ImgMode'], document, pltPath, showPlt)
    document.add_heading('Operating Power & Current vs. Light')
    VRG_Power_Data.Power_Consumption_Plot(df, [die, temp, 'Light'], document, pltPath, showPlt)
    VRG_Power_Data.Current_Consumption_Plot(df, [die, temp, 'Light'], document, pltPath, showPlt)
    document.add_heading('Operating Power & Current vs. Clk')
    VRG_Power_Data.Power_Consumption_Plot(df, [die, temp, 'Clk'], document, pltPath, showPlt)
    VRG_Power_Data.Current_Consumption_Plot(df, [die, temp, 'Clk'], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        # ImgMode 1 Voltage, Power, and Current
        document.add_heading(i, level=1)
        document.add_heading(i + ' Operating Power & Current vs. Voltage Level', level=2)
        VRG_Power_Data.Supply_Voltage_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.Power_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)
        document.add_heading(i + ' Operating Power & Current vs. Light', level=2)
        VRG_Power_Data.Power_Consumption_Plot(df_img, 'Light', document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, 'Light', document, pltPath, showPlt)
        document.add_heading(i + ' Operating Power & Current vs. Clk', level=2)
        VRG_Power_Data.Power_Consumption_Plot(df_img, 'Clk', document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, 'Clk', document, pltPath, showPlt)

def DV_1_01_POWER_UP_SEQUENCE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    powerSequence = ['DVM_Min_PowerUp_Test','DVM_Nom_PowerUp_Test', 'DVM_Max_PowerUp_Test']

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # Combined Data
    for powerSeq in powerSequence:
        document.add_heading('Standby Power & Current vs. Power-Up Sequence')
        VRG_Power_Data.Standby_Power_Consumption_Plot(df, [die, temp, powerSeq], document, pltPath, showPlt)
        VRG_Power_Data.Standby_Current_Consumption_Plot(df, [die, temp, powerSeq], document, pltPath, showPlt)
        document.add_heading('Operating Power & Current vs. Power-Up Sequence')
        VRG_Power_Data.Power_Consumption_Plot(df, [die, temp, powerSeq], document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df, [die, temp, powerSeq], document, pltPath, showPlt)
        document.add_heading('Operating Power & Current vs. Imaging Mode vs. Power-Up Sequence')
        VRG_Power_Data.Power_Consumption_Plot(df, ['ImgMode', powerSeq], document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df, ['ImgMode', powerSeq], document, pltPath, showPlt)

        document.add_heading('Combined Data' + ' Img Mean vs Power-Up Sequence')
        VRG_Stats_Arr.Arr_Mean_Plot(df, [die, temp, powerSeq], document, pltPath, showPlt)
        document.add_heading('Combined Data' + ' Img StdDev vs Power-Up Sequence')
        VRG_Stats_Arr.Arr_StdDev_Plot(df, [die, temp, powerSeq], document, pltPath, showPlt)
        document.add_heading('Combined Data' + ' Frame Rate vs Power-Up Sequence')
        VRG_General_Data.Sensor_FPS_Plot(df, [die, temp, powerSeq], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[powerSeq].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        for powerSeq in powerSequence:
            document.add_heading(i, level=1)
            document.add_heading(i + ' Standby Power & Current vs. Power-Up Sequence', level=2)
            VRG_Power_Data.Standby_Power_Consumption_Plot(df_img, [die, temp, powerSeq], document, pltPath, showPlt)
            VRG_Power_Data.Standby_Current_Consumption_Plot(df_img, [die, temp, powerSeq], document, pltPath, showPlt)
            document.add_heading(i + ' Operating Power & Current vs. Power-Up Sequence', level=2)
            VRG_Power_Data.Power_Consumption_Plot(df_img, [die, temp, powerSeq], document, pltPath, showPlt)
            VRG_Power_Data.Current_Consumption_Plot(df_img, [die, temp, powerSeq], document, pltPath, showPlt)

            document.add_heading(i + ' Img Mean vs Power-Up Sequence', level=2)
            VRG_Stats_Arr.Arr_Mean_Plot(df_img, [die, temp, powerSeq], document, pltPath, showPlt)
            document.add_heading(i + ' Img StdDev vs Power-Up Sequence', level=2)
            VRG_Stats_Arr.Arr_StdDev_Plot(df_img, [die, temp, powerSeq], document, pltPath, showPlt)
            document.add_heading(i + ' Frame Rate vs Power-Up Sequence', level=2)
            VRG_General_Data.Sensor_FPS_Plot(df_img, [die, temp, powerSeq], document, pltPath, showPlt)

            # for tst in TEST:  # Powerup sequence
            #     df_test = VRG_Data_Frame.newdataframe(df_img, powerSeq, tst)
            #     for tmp in TEMP:  # Temperature
            #         df_tmp = VRG_Data_Frame.newdataframe(df_test, temp, tmp)
            #         if tmp == nomTemp:
            #             document.add_heading(i + ' Image Capture (' + powerSeq + ' = ' + str(tst) + ')', level=2)
            #             VRG_Image_Analysis.Add_Image(df_tmp, 1, document, showPlt)

def DV_1_01_POWER_UP_SEQUENCE_MIN(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    powerSequence = 'DVM_Min_PowerUp_Test'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # Combined Data
    document.add_heading('Standby Power & Current vs. Power-Up Sequence')
    VRG_Power_Data.Standby_Power_Consumption_Plot(df, [die, temp, powerSequence], document, pltPath, showPlt)
    VRG_Power_Data.Standby_Current_Consumption_Plot(df, [die, temp, powerSequence], document, pltPath, showPlt)
    document.add_heading('Intermediate Current vs. Power-Up Sequence')
    VRG_Power_Data.Intermediate_Current_Samples_Plot(df, [die, temp, powerSequence], document, pltPath, showPlt)
    VRG_Power_Data.Intermediate_Current_Mean_Plot(df, [die, temp, powerSequence], document, pltPath, showPlt)
    VRG_Power_Data.Intermediate_Current_Std_Plot(df, [die, temp, powerSequence], document, pltPath, showPlt)
    document.add_heading('Operating Power & Current vs. Power-Up Sequence')
    VRG_Power_Data.Power_Consumption_Plot(df, [die, temp, powerSequence], document, pltPath, showPlt)
    VRG_Power_Data.Current_Consumption_Plot(df, [die, temp, powerSequence], document, pltPath, showPlt)
    document.add_heading('Operating Power & Current vs. Imaging Mode vs. Power-Up Sequence')
    VRG_Power_Data.Power_Consumption_Plot(df, ['ImgMode', powerSequence], document, pltPath, showPlt)
    VRG_Power_Data.Current_Consumption_Plot(df, ['ImgMode', powerSequence], document, pltPath, showPlt)

    document.add_heading('Img Mean vs Power-Up Sequence')
    VRG_Stats_Arr.Arr_Mean_Plot(df, [die, temp, powerSequence], document, pltPath, showPlt)
    document.add_heading('Img StdDev vs Power-Up Sequence')
    VRG_Stats_Arr.Arr_StdDev_Plot(df, [die, temp, powerSequence], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[powerSequence].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Standby Power & Current vs. Power-Up Sequence', level=2)
        VRG_Power_Data.Standby_Power_Consumption_Plot(df_img, [die, temp, powerSequence], document, pltPath, showPlt)
        VRG_Power_Data.Standby_Current_Consumption_Plot(df_img, [die, temp, powerSequence], document, pltPath, showPlt)
        document.add_heading(i + ' Intermediate Current vs. Power-Up Sequence')
        VRG_Power_Data.Intermediate_Current_Samples_Plot(df_img, [die, temp, powerSequence], document, pltPath, showPlt)
        VRG_Power_Data.Intermediate_Current_Mean_Plot(df_img, [die, temp, powerSequence], document, pltPath, showPlt)
        VRG_Power_Data.Intermediate_Current_Std_Plot(df_img, [die, temp, powerSequence], document, pltPath, showPlt)
        document.add_heading(i + ' Operating Power & Current vs. Power-Up Sequence', level=2)
        VRG_Power_Data.Power_Consumption_Plot(df_img, [die, temp, powerSequence], document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, [die, temp, powerSequence], document, pltPath, showPlt)

        document.add_heading(i + ' Img Mean vs Power-Up Sequence', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, [die, temp, powerSequence], document, pltPath, showPlt)
        document.add_heading(i + ' Img StdDev vs Power-Up Sequence', level=2)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, [die, temp, powerSequence], document, pltPath, showPlt)

        # for tst in TEST:  # Powerup sequence
        #     df_test = VRG_Data_Frame.newdataframe(df_img, powerSequence, tst)
        #     for tmp in TEMP:  # Temperature
        #         df_tmp = VRG_Data_Frame.newdataframe(df_test, temp, tmp)
        #         if tmp == nomTemp:
        #             document.add_heading(i + ' Image Capture (' + powerSequence + ' = ' + str(tst) + ')', level=2)
        #             VRG_Image_Analysis.Add_Image(df_tmp, 1, document, showPlt)

def DV_1_01_POWER_UP_SEQUENCE_NOM(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    powerSequence = 'DVM_Nom_PowerUp_Test'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # Combined Data
    document.add_heading('Standby Power & Current vs. Power-Up Sequence')
    VRG_Power_Data.Standby_Power_Consumption_Plot(df, [die, temp, powerSequence], document, pltPath, showPlt)
    VRG_Power_Data.Standby_Current_Consumption_Plot(df, [die, temp, powerSequence], document, pltPath, showPlt)
    document.add_heading('Intermediate Current vs. Power-Up Sequence')
    VRG_Power_Data.Intermediate_Current_Samples_Plot(df, [die, temp, powerSequence], document, pltPath, showPlt)
    VRG_Power_Data.Intermediate_Current_Mean_Plot(df, [die, temp, powerSequence], document, pltPath, showPlt)
    VRG_Power_Data.Intermediate_Current_Std_Plot(df, [die, temp, powerSequence], document, pltPath, showPlt)
    document.add_heading('Operating Power & Current vs. Power-Up Sequence')
    VRG_Power_Data.Power_Consumption_Plot(df, [die, temp, powerSequence], document, pltPath, showPlt)
    VRG_Power_Data.Current_Consumption_Plot(df, [die, temp, powerSequence], document, pltPath, showPlt)
    document.add_heading('Operating Power & Current vs. Imaging Mode vs. Power-Up Sequence')
    VRG_Power_Data.Power_Consumption_Plot(df, ['ImgMode', powerSequence], document, pltPath, showPlt)
    VRG_Power_Data.Current_Consumption_Plot(df, ['ImgMode', powerSequence], document, pltPath, showPlt)

    document.add_heading('Img Mean vs Power-Up Sequence')
    VRG_Stats_Arr.Arr_Mean_Plot(df, [die, temp, powerSequence], document, pltPath, showPlt)
    document.add_heading('Img StdDev vs Power-Up Sequence')
    VRG_Stats_Arr.Arr_StdDev_Plot(df, [die, temp, powerSequence], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[powerSequence].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Standby Power & Current vs. Power-Up Sequence', level=2)
        VRG_Power_Data.Standby_Power_Consumption_Plot(df_img, [die, temp, powerSequence], document, pltPath, showPlt)
        VRG_Power_Data.Standby_Current_Consumption_Plot(df_img, [die, temp, powerSequence], document, pltPath, showPlt)
        document.add_heading(i + ' Intermediate Current vs. Power-Up Sequence')
        VRG_Power_Data.Intermediate_Current_Samples_Plot(df_img, [die, temp, powerSequence], document, pltPath, showPlt)
        VRG_Power_Data.Intermediate_Current_Mean_Plot(df_img, [die, temp, powerSequence], document, pltPath, showPlt)
        VRG_Power_Data.Intermediate_Current_Std_Plot(df_img, [die, temp, powerSequence], document, pltPath, showPlt)
        document.add_heading(i + ' Operating Power & Current vs. Power-Up Sequence', level=2)
        VRG_Power_Data.Power_Consumption_Plot(df_img, [die, temp, powerSequence], document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, [die, temp, powerSequence], document, pltPath, showPlt)

        document.add_heading(i + ' Img Mean vs Power-Up Sequence', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, [die, temp, powerSequence], document, pltPath, showPlt)
        document.add_heading(i + ' Img StdDev vs Power-Up Sequence', level=2)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, [die, temp, powerSequence], document, pltPath, showPlt)


        # for tst in TEST:  # Powerup sequence
        #     df_test = VRG_Data_Frame.newdataframe(df_img, powerSequence, tst)
        #     for tmp in TEMP:  # Temperature
        #         df_tmp = VRG_Data_Frame.newdataframe(df_test, temp, tmp)
        #         if tmp == nomTemp:
        #             document.add_heading(i + ' Image Capture (' + powerSequence + ' = ' + str(tst) + ')', level=2)
        #             VRG_Image_Analysis.Add_Image(df_tmp, 1, document, showPlt)

def DV_1_01_POWER_UP_SEQUENCE_MAX(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    powerSequence = 'DVM_Max_PowerUp_Test'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # Combined Data
    document.add_heading('Standby Power & Current vs. Power-Up Sequence')
    VRG_Power_Data.Standby_Power_Consumption_Plot(df, [die, temp, powerSequence], document, pltPath, showPlt)
    VRG_Power_Data.Standby_Current_Consumption_Plot(df, [die, temp, powerSequence], document, pltPath, showPlt)
    document.add_heading('Intermediate Current vs. Power-Up Sequence')
    VRG_Power_Data.Intermediate_Current_Samples_Plot(df, [die, temp, powerSequence], document, pltPath, showPlt)
    VRG_Power_Data.Intermediate_Current_Mean_Plot(df, [die, temp, powerSequence], document, pltPath, showPlt)
    VRG_Power_Data.Intermediate_Current_Std_Plot(df, [die, temp, powerSequence], document, pltPath, showPlt)
    document.add_heading('Operating Power & Current vs. Power-Up Sequence')
    VRG_Power_Data.Power_Consumption_Plot(df, [die, temp, powerSequence], document, pltPath, showPlt)
    VRG_Power_Data.Current_Consumption_Plot(df, [die, temp, powerSequence], document, pltPath, showPlt)
    document.add_heading('Operating Power & Current vs. Imaging Mode vs. Power-Up Sequence')
    VRG_Power_Data.Power_Consumption_Plot(df, ['ImgMode', powerSequence], document, pltPath, showPlt)
    VRG_Power_Data.Current_Consumption_Plot(df, ['ImgMode', powerSequence], document, pltPath, showPlt)

    document.add_heading('Img Mean vs Power-Up Sequence')
    VRG_Stats_Arr.Arr_Mean_Plot(df, [die, temp, powerSequence], document, pltPath, showPlt)
    document.add_heading('Img StdDev vs Power-Up Sequence')
    VRG_Stats_Arr.Arr_StdDev_Plot(df, [die, temp, powerSequence], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[powerSequence].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Standby Power & Current vs. Power-Up Sequence', level=2)
        VRG_Power_Data.Standby_Power_Consumption_Plot(df_img, [die, temp, powerSequence], document, pltPath, showPlt)
        VRG_Power_Data.Standby_Current_Consumption_Plot(df_img, [die, temp, powerSequence], document, pltPath, showPlt)
        document.add_heading(i + ' Intermediate Current vs. Power-Up Sequence')
        VRG_Power_Data.Intermediate_Current_Samples_Plot(df_img, [die, temp, powerSequence], document, pltPath, showPlt)
        VRG_Power_Data.Intermediate_Current_Mean_Plot(df_img, [die, temp, powerSequence], document, pltPath, showPlt)
        VRG_Power_Data.Intermediate_Current_Std_Plot(df_img, [die, temp, powerSequence], document, pltPath, showPlt)
        document.add_heading(i + ' Operating Power & Current vs. Power-Up Sequence', level=2)
        VRG_Power_Data.Power_Consumption_Plot(df_img, [die, temp, powerSequence], document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, [die, temp, powerSequence], document, pltPath, showPlt)

        document.add_heading(i + ' Img Mean vs Power-Up Sequence', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, [die, temp, powerSequence], document, pltPath, showPlt)
        document.add_heading(i + ' Img StdDev vs Power-Up Sequence', level=2)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, [die, temp, powerSequence], document, pltPath, showPlt)

        # for tst in TEST:  # Powerup sequence
        #     df_test = VRG_Data_Frame.newdataframe(df_img, powerSequence, tst)
        #     for tmp in TEMP:  # Temperature
        #         df_tmp = VRG_Data_Frame.newdataframe(df_test, temp, tmp)
        #         if tmp == nomTemp:
        #             document.add_heading(i + ' Image Capture (' + powerSequence + ' = ' + str(tst) + ')', level=2)
        #             VRG_Image_Analysis.Add_Image(df_tmp, 1, document, showPlt)

def DV_1_02_POWER_DOWN_SEQUENCE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    powerSequence = 'DVM_Power_Down_Test'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # All Data
    document.add_heading('Standby Power & Current vs. Power-Down Sequence')
    VRG_Power_Data.Standby_Power_Consumption_Plot(df, [die, temp, powerSequence], document, pltPath, showPlt)
    VRG_Power_Data.Standby_Current_Consumption_Plot(df, [die, temp, powerSequence], document, pltPath, showPlt)
    document.add_heading('Intermediate Current vs. Power-Down Sequence')
    VRG_Power_Data.Intermediate_Current_Samples_Plot(df, [die, temp, powerSequence], document, pltPath, showPlt)
    VRG_Power_Data.Intermediate_Current_Mean_Plot(df, [die, temp, powerSequence], document, pltPath, showPlt)
    VRG_Power_Data.Intermediate_Current_Std_Plot(df, [die, temp, powerSequence], document, pltPath, showPlt)
    document.add_heading('Operating Power & Current vs. Power-Down Sequence')
    VRG_Power_Data.Power_Consumption_Plot(df, [die, temp, powerSequence], document, pltPath, showPlt)
    VRG_Power_Data.Current_Consumption_Plot(df, [die, temp, powerSequence], document, pltPath, showPlt)
    document.add_heading('Operating Power & Current vs. Imaging Mode vs. Power-Up Sequence')
    VRG_Power_Data.Power_Consumption_Plot(df, ['ImgMode', powerSequence], document, pltPath, showPlt)
    VRG_Power_Data.Current_Consumption_Plot(df, ['ImgMode', powerSequence], document, pltPath, showPlt)

    document.add_heading('Img Mean vs Power-Down Sequence')
    VRG_Stats_Arr.Arr_Mean_Plot(df, [die, temp, powerSequence], document, pltPath, showPlt)
    document.add_heading('Img StdDev vs Power-Down Sequence')
    VRG_Stats_Arr.Arr_StdDev_Plot(df, [die, temp, powerSequence], document, pltPath, showPlt)


    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[powerSequence].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Standby Power & Current vs. Power-Down Sequence', level=2)
        VRG_Power_Data.Standby_Power_Consumption_Plot(df_img, [die, temp, powerSequence], document, pltPath, showPlt)
        VRG_Power_Data.Standby_Current_Consumption_Plot(df_img, [die, temp, powerSequence], document, pltPath, showPlt)
        document.add_heading(i + ' Intermediate Current vs. Power-Down Sequence')
        VRG_Power_Data.Intermediate_Current_Samples_Plot(df_img, [die, temp, powerSequence], document, pltPath, showPlt)
        VRG_Power_Data.Intermediate_Current_Mean_Plot(df_img, [die, temp, powerSequence], document, pltPath, showPlt)
        VRG_Power_Data.Intermediate_Current_Std_Plot(df_img, [die, temp, powerSequence], document, pltPath, showPlt)
        document.add_heading(i + ' Operating Power & Current vs. Power-Down Sequence', level=2)
        VRG_Power_Data.Power_Consumption_Plot(df_img, [die, temp, powerSequence], document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, [die, temp, powerSequence], document, pltPath, showPlt)

        document.add_heading(i + ' Img Mean vs Power-Down Sequence', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, [die, temp, powerSequence], document, pltPath, showPlt)
        document.add_heading(i + ' Img StdDev vs Power-Down Sequence', level=2)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, [die, temp, powerSequence], document, pltPath, showPlt)


        # for tst in TEST:  # Powerdown sequence
        #     df_test = VRG_Data_Frame.newdataframe(df_img, powerSeq, tst)
        #     for tmp in TEMP:  # Temperature
        #         df_tmp = VRG_Data_Frame.newdataframe(df_test, temp, tmp)
        #         if tmp == nomTemp:
        #             document.add_heading(i + ' Image Capture (' + powerSeq + ' = ' + str(tst) + ')', level=2)
        #             VRG_Image_Analysis.Add_Image(df_tmp, 1, document, showPlt)

def DV_1_03_HARD_RESET(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # Primary Voltage, Power, and Current
    document.add_heading('Power & Current vs. Voltage Level')
    VRG_Power_Data.Power_Consumption_Plot(df, 'Power', document, pltPath, showPlt)
    VRG_Power_Data.Current_Consumption_Plot(df, 'Power', document, pltPath, showPlt)
    VRG_Power_Data.ResetClkOff_Current_Mean_Plot(df, 'Power', document, pltPath, showPlt)
    VRG_Power_Data.ResetClkOff_Current_Std_Plot(df, 'Power', document, pltPath, showPlt)
    VRG_Power_Data.ResetClkOn_Current_Mean_Plot(df, 'Power', document, pltPath, showPlt)
    VRG_Power_Data.ResetClkOn_Current_Std_Plot(df, 'Power', document, pltPath, showPlt)
    VRG_Power_Data.STREAMING_Current_Mean_Plot(df, 'Power', document, pltPath, showPlt)
    VRG_Power_Data.STREAMING_Current_Std_Plot(df, 'Power', document, pltPath, showPlt)

    document.add_heading('Power & Current vs. Voltage Level vs. Imaging Mode')
    VRG_Power_Data.Power_Consumption_Plot(df, ['Power', 'ImgMode'], document, pltPath, showPlt)
    VRG_Power_Data.Current_Consumption_Plot(df, ['Power', 'ImgMode'], document, pltPath, showPlt)
    VRG_Power_Data.ResetClkOff_Current_Mean_Plot(df, ['Power', 'ImgMode'], document, pltPath, showPlt)
    VRG_Power_Data.ResetClkOff_Current_Std_Plot(df, ['Power', 'ImgMode'], document, pltPath, showPlt)
    VRG_Power_Data.ResetClkOn_Current_Mean_Plot(df, ['Power', 'ImgMode'], document, pltPath, showPlt)
    VRG_Power_Data.ResetClkOn_Current_Std_Plot(df, ['Power', 'ImgMode'], document, pltPath, showPlt)
    VRG_Power_Data.STREAMING_Current_Mean_Plot(df, ['Power', 'ImgMode'], document, pltPath, showPlt)
    VRG_Power_Data.STREAMING_Current_Std_Plot(df, ['Power', 'ImgMode'], document, pltPath, showPlt)

    # Validation Template Data
    # Test Data - Evaluate register values of different power domains
    document.add_heading('Pre & Post Hard Reset Register Check')
    VRG_General_Data.DefaultRegCheck_Plot(df, None, document, pltPath, showPlt)

    # Test Data - Ensure sensor is functional after enabling streaming.
    document.add_heading('Post Hard Reset Image Capture')
    VRG_Stats_Arr.Arr_Mean_Plot(df, None, document, pltPath, showPlt)
    VRG_Stats_Arr.Arr_StdDev_Plot(df, None, document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        # ImgMode 1 Voltage, Power, and Current
        document.add_heading(i, level=1)
        document.add_heading(i + ' Power & Current vs. Voltage Level', level=2)
        VRG_Power_Data.Power_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.ResetClkOff_Current_Mean_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.ResetClkOff_Current_Std_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.ResetClkOn_Current_Mean_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.ResetClkOn_Current_Std_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.STREAMING_Current_Mean_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.STREAMING_Current_Std_Plot(df_img, 'Power', document, pltPath, showPlt)

        # Test Data - Evaluate register values of different power domains
        document.add_heading(i + ' Pre & Post Hard Reset Register Check', level=2)
        VRG_General_Data.DefaultRegCheck_Plot(df_img, None, document, pltPath, showPlt)

        # Test Data - Ensure sensor is functional after enabling streaming.
        document.add_heading(i + ' Post Hard Reset Image Statistics', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, None, document, pltPath, showPlt)

        # for tmp in TEMP:  # Temperature
        #     df_tmp = VRG_Data_Frame.newdataframe(df_img, temp, tmp)
        #     if tmp == nomTemp:
        #         document.add_heading(i + ' Image Capture', level=2)
        #         VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 2, document, showPlt)

def DV_1_04_SOFT_RESET(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # Primary Voltage, Power, and Current
    document.add_heading('Power & Current vs. Voltage Level')
    VRG_Power_Data.Power_Consumption_Plot(df, 'Power', document, pltPath, showPlt)
    VRG_Power_Data.Current_Consumption_Plot(df, 'Power', document, pltPath, showPlt)

    # Validation Template Data
    # Test Data - Evaluate register values of different power domains
    document.add_heading('Pre & Post Soft Reset Register Check')
    VRG_General_Data.DefaultRegCheck_Plot(df, None, document, pltPath, showPlt)

    # Test Data - Ensure sensor is functional after enabling streaming.
    document.add_heading('Post Soft Reset Image Capture')
    VRG_Stats_Arr.Arr_Mean_Plot(df, None, document, pltPath, showPlt)
    VRG_Stats_Arr.Arr_StdDev_Plot(df, None, document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        # ImgMode Voltage, Power, and Current
        document.add_heading(i, level=1)
        document.add_heading(i + ' Power & Current vs. Voltage Level', level=2)
        VRG_Power_Data.Power_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)

        # Validation Template Data
        # Test Data - Evaluate register values of different power domains
        document.add_heading(i + ' Pre & Post Soft Reset Register Check', level=2)
        VRG_General_Data.DefaultRegCheck_Plot(df_img, None, document, pltPath, showPlt)

        # Test Data - Ensure sensor is functional after enabling streaming
        document.add_heading(i + ' Post Soft Reset Image Statistics', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, None, document, pltPath, showPlt)

        # for tmp in TEMP:  # Temperature
        #     df_tmp = VRG_Data_Frame.newdataframe(df_img, temp, tmp)
        #     if tmp == nomTemp:
        #         document.add_heading(i + ' Image Capture', level=2)
        #         VRG_Image_Analysis.Add_Image_Analysis(df_tmp, 2, document, showPlt)

def DV_1_05_HARD_STANDBY(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    clkInPin = 'Pin:CLKIN'
    reg1 = 'RegVal_Y_ADDR_START_'
    reg2 = 'RegVal_X_ADDR_START_'
    reg3 = 'RegVal_Y_ADDR_END_'
    reg4 = 'RegVal_X_ADDR_END_'
    reg5 = 'RegVal_COARSE_INTEGRATION_TIME_'
    reg6 = 'RegVal_MODE_SELECT__IMAGE_ORIENTATION'
    reg7 = 'RegVal_DAC_LD_96_97'
    reg8 = 'RegVal_DAC_LD_104_105'
    reg9 = 'RegVal_DAC_LD_110_111'
    reg10 = 'RegVal_DAC_LD_114_115'
    reg11 = 'RegVal_DAC_LD_116_117'
    reg12 = 'RegVal_DAC_LD_118_119'
    reg13 = 'RegVal_DAC_LD_120_121'
    reg14 = 'RegVal_DAC_LD_122_123'
    reg15 = 'RegVal_DAC_LD_124_125'
    reg16 = 'RegVal_DAC_LD_126_127'
    reg17 = 'RegVal_DAC_LD_128_129'
    reg18 = 'RegVal_DAC_LD_130_131'
    reg19 = 'RegVal_DAC_LD_148_149'
    reg20 = 'RegVal_DAC_LD_150_151'
    reg21 = 'RegVal_TEMPVSENS1_SREG_TRIM_V_IPTAT'
    reg22 = 'RegVal_TEMPVSENS1_SREG_TRIM_VBG_REFBUF'
    reg23 = 'RegVal_TEMPVSENS1_SREG_CFG_54_TO_69'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # Primary Voltage, Power, and Current
    # Test Data - Table of measured DC power supply currents when the part is in Hard Standby mode
    document.add_heading('Power & Current vs. Voltage Level')
    VRG_Power_Data.Power_Consumption_Plot(df, 'Power', document, pltPath, showPlt)
    VRG_Power_Data.Current_Consumption_Plot(df, 'Power', document, pltPath, showPlt)

    document.add_heading('Power & Current vs. CLKIN State')
    VRG_Power_Data.Power_Consumption_Plot(df, clkInPin, document, pltPath, showPlt)
    VRG_Power_Data.Current_Consumption_Plot(df, clkInPin, document, pltPath, showPlt)

    # Validation Template Data
    # Test Data - Confirm part is able to exit of hard standby  by looking at the value of the registers
    document.add_heading('Default Reg Values vs. Die vs. CLKIN')
    VRG_Register_Data.Reg_vs_Step_Plot(df, [die, clkInPin], document, pltPath, reg1, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, [die, clkInPin], document, pltPath, reg2, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, [die, clkInPin], document, pltPath, reg3, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, [die, clkInPin], document, pltPath, reg4, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, [die, clkInPin], document, pltPath, reg5, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, [die, clkInPin], document, pltPath, reg6, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, [die, clkInPin], document, pltPath, reg7, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, [die, clkInPin], document, pltPath, reg8, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, [die, clkInPin], document, pltPath, reg9, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, [die, clkInPin], document, pltPath, reg10, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, [die, clkInPin], document, pltPath, reg11, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, [die, clkInPin], document, pltPath, reg12, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, [die, clkInPin], document, pltPath, reg13, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, [die, clkInPin], document, pltPath, reg14, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, [die, clkInPin], document, pltPath, reg15, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, [die, clkInPin], document, pltPath, reg16, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, [die, clkInPin], document, pltPath, reg17, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, [die, clkInPin], document, pltPath, reg18, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, [die, clkInPin], document, pltPath, reg19, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, [die, clkInPin], document, pltPath, reg20, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, [die, clkInPin], document, pltPath, reg21, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, [die, clkInPin], document, pltPath, reg22, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, [die, clkInPin], document, pltPath, reg23, showPlt)
    
    # Test Data - Capture an image to confirm successful initialization into streaming mode.
    document.add_heading('Post Hard Standby Image Capture')
    VRG_Stats_Arr.Arr_Mean_Plot(df, None, document, pltPath, showPlt)
    VRG_Stats_Arr.Arr_StdDev_Plot(df, None, document, pltPath, showPlt)

    document.add_heading('Post Hard Standby Image Capture vs. CLKIN')
    VRG_Stats_Arr.Arr_Mean_Plot(df, clkInPin, document, pltPath, showPlt)
    VRG_Stats_Arr.Arr_StdDev_Plot(df, clkInPin, document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[clkInPin].unique())  # List of unique reg values
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        # ImgMode Voltage, Power, and Current
        document.add_heading(i, level=1)
        document.add_heading(i + ' Power & Current vs. Voltage Level', level=2)
        VRG_Power_Data.Power_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)

        document.add_heading(i + ' Power & Current vs. CLKIN State', level=2)
        VRG_Power_Data.Power_Consumption_Plot(df_img, clkInPin, document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, clkInPin, document, pltPath, showPlt)

        # Validation Template Data
        # Test Data - Confirm part is able to exit of hard standby  by looking at the value of the registers
        document.add_heading(i + ' Default Reg Values vs. Die vs. CLKIN', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, [die, clkInPin], document, pltPath, reg1, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, [die, clkInPin], document, pltPath, reg2, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, [die, clkInPin], document, pltPath, reg3, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, [die, clkInPin], document, pltPath, reg4, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, [die, clkInPin], document, pltPath, reg5, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, [die, clkInPin], document, pltPath, reg6, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, [die, clkInPin], document, pltPath, reg7, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, [die, clkInPin], document, pltPath, reg8, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, [die, clkInPin], document, pltPath, reg9, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, [die, clkInPin], document, pltPath, reg10, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, [die, clkInPin], document, pltPath, reg11, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, [die, clkInPin], document, pltPath, reg12, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, [die, clkInPin], document, pltPath, reg13, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, [die, clkInPin], document, pltPath, reg14, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, [die, clkInPin], document, pltPath, reg15, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, [die, clkInPin], document, pltPath, reg16, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, [die, clkInPin], document, pltPath, reg17, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, [die, clkInPin], document, pltPath, reg18, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, [die, clkInPin], document, pltPath, reg19, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, [die, clkInPin], document, pltPath, reg20, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, [die, clkInPin], document, pltPath, reg21, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, [die, clkInPin], document, pltPath, reg22, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, [die, clkInPin], document, pltPath, reg23, showPlt)


        # Test Data - Capture an image to confirm successful initialization into streaming mode.
        document.add_heading(i + ' Post Hard Standby Image Statistics', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Post Hard Standby Image Statistics vs. CLKIN', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, clkInPin, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, clkInPin, document, pltPath, showPlt)

        # for tst in TEST:
        #     df_test = VRG_Data_Frame.newdataframe(df_img, clkInPin, tst)
        #     for tmp in TEMP:  # Temperature
        #         df_tmp = VRG_Data_Frame.newdataframe(df_test, temp, tmp)
        #         if tmp == nomTemp:
        #             document.add_heading(i + ' Image Capture with CLKIN = ' + str(tst), level=2)
        #             VRG_Image_Analysis.Add_Image_Analysis(df_tmp, 2, document, showPlt)

def DV_1_06_SOFT_STANDBY(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    clkInPin = 'Pin:CLKIN'
    reg1 = 'RegVal_Y_ADDR_START_'
    reg2 = 'RegVal_X_ADDR_START_'
    reg3 = 'RegVal_Y_ADDR_END_'
    reg4 = 'RegVal_X_ADDR_END_'
    reg5 = 'RegVal_COARSE_INTEGRATION_TIME_'
    reg6 = 'RegVal_MODE_SELECT__IMAGE_ORIENTATION'
    reg7 = 'RegVal_DAC_LD_96_97'
    reg8 = 'RegVal_DAC_LD_104_105'
    reg9 = 'RegVal_DAC_LD_110_111'
    reg10 = 'RegVal_DAC_LD_114_115'
    reg11 = 'RegVal_DAC_LD_116_117'
    reg12 = 'RegVal_DAC_LD_118_119'
    reg13 = 'RegVal_DAC_LD_120_121'
    reg14 = 'RegVal_DAC_LD_122_123'
    reg15 = 'RegVal_DAC_LD_124_125'
    reg16 = 'RegVal_DAC_LD_126_127'
    reg17 = 'RegVal_DAC_LD_128_129'
    reg18 = 'RegVal_DAC_LD_130_131'
    reg19 = 'RegVal_DAC_LD_148_149'
    reg20 = 'RegVal_DAC_LD_150_151'
    reg21 = 'RegVal_TEMPVSENS1_SREG_TRIM_V_IPTAT'
    reg22 = 'RegVal_TEMPVSENS1_SREG_TRIM_VBG_REFBUF'
    reg23 = 'RegVal_TEMPVSENS1_SREG_CFG_54_TO_69'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # Primary Voltage, Power, and Current
    # Test Data - a.	Table of measured DC power supply currents when the part is in Hard Standby mode
    document.add_heading('Power & Current vs. Voltage Level')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    VRG_Power_Data.Power_Consumption_Plot(df, 'Power', document, pltPath, showPlt)
    VRG_Power_Data.Current_Consumption_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Power & Current vs. CLKIN State')
    VRG_Power_Data.Power_Consumption_Plot(df, clkInPin, document, pltPath, showPlt)
    VRG_Power_Data.Current_Consumption_Plot(df, clkInPin, document, pltPath, showPlt)

    # Validation Template Data
    # Test Data - Confirm part is able to exit of hard standby  by looking at the value of the registers
    document.add_heading('Default Reg Values vs. Die vs. CLKIN')
    VRG_Register_Data.Reg_vs_Step_Plot(df, [die, clkInPin], document, pltPath, reg1, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, [die, clkInPin], document, pltPath, reg2, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, [die, clkInPin], document, pltPath, reg3, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, [die, clkInPin], document, pltPath, reg4, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, [die, clkInPin], document, pltPath, reg5, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, [die, clkInPin], document, pltPath, reg6, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, [die, clkInPin], document, pltPath, reg7, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, [die, clkInPin], document, pltPath, reg8, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, [die, clkInPin], document, pltPath, reg9, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, [die, clkInPin], document, pltPath, reg10, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, [die, clkInPin], document, pltPath, reg11, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, [die, clkInPin], document, pltPath, reg12, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, [die, clkInPin], document, pltPath, reg13, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, [die, clkInPin], document, pltPath, reg14, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, [die, clkInPin], document, pltPath, reg15, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, [die, clkInPin], document, pltPath, reg16, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, [die, clkInPin], document, pltPath, reg17, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, [die, clkInPin], document, pltPath, reg18, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, [die, clkInPin], document, pltPath, reg19, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, [die, clkInPin], document, pltPath, reg20, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, [die, clkInPin], document, pltPath, reg21, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, [die, clkInPin], document, pltPath, reg22, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, [die, clkInPin], document, pltPath, reg23, showPlt)

    # Test Data - Capture an image to confirm successful initialization into streaming mode.
    document.add_heading('Post Soft Standby Image Capture')
    VRG_Stats_Arr.Arr_Mean_Plot(df, None, document, pltPath, showPlt)  # Img Means
    VRG_Stats_Arr.Arr_StdDev_Plot(df, None, document, pltPath, showPlt)  # Img StdDev

    document.add_heading('Post Soft Standby Image Capture vs. CLKIN')
    VRG_Stats_Arr.Arr_Mean_Plot(df, clkInPin, document, pltPath, showPlt)  # Img Means
    VRG_Stats_Arr.Arr_StdDev_Plot(df, clkInPin, document, pltPath, showPlt)  # Img StdDev

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[clkInPin].unique())  # List of unique reg values
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        # ImgMode Voltage, Power, and Current
        document.add_heading(i, level=1)
        document.add_heading(i + ' Power & Current vs. Voltage Level', level=2)
        VRG_Power_Data.Power_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)

        document.add_heading(i + ' Power & Current vs. CLKIN State', level=2)
        VRG_Power_Data.Power_Consumption_Plot(df_img, clkInPin, document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, clkInPin, document, pltPath, showPlt)

        # Validation Template Data
        # Test Data - Confirm  part is able to exit of hard standby by looking at the value of the registers
        document.add_heading(i + ' Default Reg Values vs. Die vs. CLKIN', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, [die, clkInPin], document, pltPath, reg1, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, [die, clkInPin], document, pltPath, reg2, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, [die, clkInPin], document, pltPath, reg3, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, [die, clkInPin], document, pltPath, reg4, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, [die, clkInPin], document, pltPath, reg5, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, [die, clkInPin], document, pltPath, reg6, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, [die, clkInPin], document, pltPath, reg7, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, [die, clkInPin], document, pltPath, reg8, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, [die, clkInPin], document, pltPath, reg9, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, [die, clkInPin], document, pltPath, reg10, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, [die, clkInPin], document, pltPath, reg11, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, [die, clkInPin], document, pltPath, reg12, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, [die, clkInPin], document, pltPath, reg13, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, [die, clkInPin], document, pltPath, reg14, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, [die, clkInPin], document, pltPath, reg15, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, [die, clkInPin], document, pltPath, reg16, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, [die, clkInPin], document, pltPath, reg17, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, [die, clkInPin], document, pltPath, reg18, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, [die, clkInPin], document, pltPath, reg19, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, [die, clkInPin], document, pltPath, reg20, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, [die, clkInPin], document, pltPath, reg21, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, [die, clkInPin], document, pltPath, reg22, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, [die, clkInPin], document, pltPath, reg23, showPlt)

        # Test Data - Capture an image to confirm successful initialization into streaming mode.
        document.add_heading(i + ' Post Soft Standby Image Statistics', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Post Soft Standby Image Statistics', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, clkInPin, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, clkInPin, document, pltPath, showPlt)

        # for tst in TEST:
        #     df_test = VRG_Data_Frame.newdataframe(df_img, clkInPin, tst)
        #     for tmp in TEMP:  # Temperature
        #         df_tmp = VRG_Data_Frame.newdataframe(df_test, temp, tmp)
        #         if tmp == nomTemp:
        #             document.add_heading(i + ' Image Capture with CLKIN = ' + str(tst), level=2)
        #             VRG_Image_Analysis.Add_Image_Analysis(df_tmp, 2, document, showPlt)

def DV_1_07_DEFAULT_REGISTER_SHORT(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    reg1 = 'RegVal_Y_ADDR_START_'
    reg2 = 'RegVal_X_ADDR_START_'
    reg3 = 'RegVal_Y_ADDR_END_'
    reg4 = 'RegVal_X_ADDR_END_'
    reg5 = 'RegVal_COARSE_INTEGRATION_TIME_'
    reg6 = 'RegVal_MODE_SELECT'
    reg7 = 'RegVal_DAC_LD_0_1'
    reg8 = 'RegVal_DAC_LD_2_3'
    reg9 = 'RegVal_DAC_LD_4_5'
    reg10 = 'RegVal_DAC_LD_16_17'
    reg11 = 'RegVal_TEMPVSENS1_SREG_TRIM0'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # Test Data - 1.	Table of measured vs. expected register values
    document.add_heading('Default Reg Values')
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, reg1, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, reg2, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, reg3, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, reg4, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, reg5, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, reg6, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, reg7, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, reg8, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, reg9, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, reg10, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, reg11, showPlt)

    document.add_heading('Default Reg Values vs. Die')
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, reg1, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, reg2, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, reg3, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, reg4, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, reg5, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, reg6, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, reg7, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, reg8, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, reg9, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, reg10, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, reg11, showPlt)

    # Test Data - 2.	Comparison of values in embedded data rows (if applicable) with I2C.

def DV_1_07_DEFAULT_REGISTER(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    reg1 = 'RegVal_Y_ADDR_START_'
    reg2 = 'RegVal_X_ADDR_START_'
    reg3 = 'RegVal_Y_ADDR_END_'
    reg4 = 'RegVal_X_ADDR_END_'
    reg5 = 'RegVal_COARSE_INTEGRATION_TIME_'
    reg6 = 'RegVal_MODE_SELECT'
    reg7 = 'RegVal_DAC_LD_0_1'
    reg8 = 'RegVal_DAC_LD_2_3'
    reg9 = 'RegVal_DAC_LD_4_5'
    reg10 = 'RegVal_DAC_LD_16_17'
    reg11 = 'RegVal_TEMPVSENS1_SREG_TRIM0'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # Test Data - 1.	Table of measured vs. expected register values
    document.add_heading('Default Reg Values')
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, reg1, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, reg2, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, reg3, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, reg4, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, reg5, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, reg6, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, reg7, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, reg8, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, reg9, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, reg10, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, reg11, showPlt)

    document.add_heading('Default Reg Values vs. Die')
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, reg1, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, reg2, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, reg3, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, reg4, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, reg5, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, reg6, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, reg7, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, reg8, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, reg9, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, reg10, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, reg11, showPlt)

    # Test Data - 2.	Comparison of values in embedded data rows (if applicable) with I2C.

def DV_1_08_OPERATING_MODES(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    test = 'RegWr01_MODE_SELECT__IMAGE_ORIENTATION::IMAGE_ORIENTATION'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # Primary Voltage, Power, and Current
    document.add_heading('Power & Current vs. Voltage Level')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    VRG_Power_Data.Power_Consumption_Plot(df, 'Power', document, pltPath, showPlt)
    VRG_Power_Data.Current_Consumption_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Power & Current vs. Light')
    VRG_Power_Data.Power_Consumption_Plot(df, 'Light', document, pltPath, showPlt)
    VRG_Power_Data.Current_Consumption_Plot(df, 'Light', document, pltPath, showPlt)
    document.add_heading('Power & Current vs. Clk')
    VRG_Power_Data.Power_Consumption_Plot(df, 'Clk', document, pltPath, showPlt)
    VRG_Power_Data.Current_Consumption_Plot(df, 'Clk', document, pltPath, showPlt)
    document.add_heading('Power & Current vs. NormalOp/Flip/Mirror/Flip&Mirror')
    VRG_Power_Data.Power_Consumption_Plot(df, 'RegWr01_READ_MODE', document, pltPath, showPlt)
    VRG_Power_Data.Current_Consumption_Plot(df, 'RegWr01_READ_MODE', document, pltPath, showPlt)

    # Temperature Coefficient for operating current
    document.add_heading('Operating Current Temperature Coefficient')
    VRG_Calculate.Operating_Current_Temperature_Coefficient_Plot(df, 'Power', document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[test].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        # ImgMode Voltage, Power, and Current
        document.add_heading(i, level=1)
        document.add_heading(i + ' Power & Current vs. Voltage Level', level=2)
        VRG_Power_Data.Supply_Voltage_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.Power_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)
        document.add_heading(i + ' Power & Current vs. Light', level=2)
        VRG_Power_Data.Power_Consumption_Plot(df_img, 'Light', document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, 'Light', document, pltPath, showPlt)
        document.add_heading(i + ' Power & Current vs. Clk', level=2)
        VRG_Power_Data.Power_Consumption_Plot(df_img, 'Clk', document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, 'Clk', document, pltPath, showPlt)

        # Temperature Coefficient for operating current
        document.add_heading(i + ' Operating Current Temperature Coefficient', level=2)
        VRG_Calculate.Operating_Current_Temperature_Coefficient_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Image Stats vs. Light', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, 'Light', document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, 'Light', document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowStdDev_Plot(df_img, 'Light', document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_img, 'Light', document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColStdDev_Plot(df_img, 'Light', document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_img, 'Light', document, pltPath, showPlt)

        # for tst in TEST:  # Test
        #     df_test = VRG_Data_Frame.newdataframe(df_img, test, tst)
        #     for tmp in TEMP:  # Temperature
        #         df_tmp = VRG_Data_Frame.newdataframe(df_test, temp, tmp)
        #         if tmp == nomTemp:
        #             document.add_heading(i + ' Image Capture (' + test + ' = ' + str(tst) + ')', level=2)
        #             VRG_Image_Analysis.Add_Image_Analysis(df_tmp, 2, document, showPlt)

def DV_1_09_CONTEXT_SWITCHING_REGISTER(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_1_09_CONTEXT_SWITCHING_RAM_AUTOMATIC(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_1_09_CONTEXT_SWITCHING_RAM_MANUAL(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    ctxSwitch = 'RegWr00_CTX_CONTROL_REG'
    ctx1val = 32768
    ctx2val = 32769
    ctxReg1 = 'RegVal_COARSE_INTEGRATION_TIME_'
    ctxReg2 = 'RegVal_Y_ADDR_START_'
    ctxReg3 = 'RegVal_X_ADDR_START_'
    ctxReg4 = 'RegVal_Y_ADDR_END_'
    ctxReg5 = 'RegVal_X_ADDR_END_'
    ctxReg6 = 'RegVal_OCL_T1_GAIN_'
    ctxReg7 = 'RegVal_OCL_T1_GAIN2'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # Primary Voltage, Power, and Current
    document.add_heading('Power & Current vs. Voltage Level')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    VRG_Power_Data.Power_Consumption_Plot(df, 'Power', document, pltPath, showPlt)
    VRG_Power_Data.Current_Consumption_Plot(df, 'Power', document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[ctxSwitch].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)
        df_img_CTX1 = VRG_Data_Frame.newdataframe(df_img, ctxSwitch, ctx1val)  # Sort only CTX1 data
        df_img_CTX2 = VRG_Data_Frame.newdataframe(df_img, ctxSwitch, ctx2val)  # Sort only CTX2 data

        # ImgMode Voltage, Power, and Current
        document.add_heading(i, level=1)
        document.add_heading(i + ' Light Level Values', level=2)
        VRG_General_Data.LightLevel_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Integration Time', level=2)
        VRG_General_Data.Integration_Time_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Context Switch Reg Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, ctxSwitch, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, ctxSwitch, document, pltPath, ctxReg1, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, ctxSwitch, document, pltPath, ctxReg2, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, ctxSwitch, document, pltPath, ctxReg3, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, ctxSwitch, document, pltPath, ctxReg4, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, ctxSwitch, document, pltPath, ctxReg5, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, ctxSwitch, document, pltPath, ctxReg6, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, ctxSwitch, document, pltPath, ctxReg7, showPlt)

        document.add_heading(i + ' Full-Res Image Stats vs. Light', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, 'Light', document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, 'Light', document, pltPath, showPlt)
        document.add_heading(i + ' CTX1 Full-Res Image Stats vs. Light', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img_CTX1, 'Light', document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img_CTX1, 'Light', document, pltPath, showPlt)
        document.add_heading(i + ' CTX2 Full-Res Image Stats vs. Light', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img_CTX2, 'Light', document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img_CTX2, 'Light', document, pltPath, showPlt)

        document.add_heading(i + ' Region Image Stats vs. Light', level=2)
        VRG_Stats_Frame.Rgn_Mean_Plot(df_img, 'Light', document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_StdDev_Plot(df_img, 'Light', document, pltPath, showPlt)
        document.add_heading(i + ' CTX1 Region Image Stats vs. Light', level=2)
        VRG_Stats_Frame.Rgn_Mean_Plot(df_img_CTX1, 'Light', document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_StdDev_Plot(df_img_CTX1, 'Light', document, pltPath, showPlt)
        document.add_heading(i + ' CTX2 Region Image Stats vs. Light', level=2)
        VRG_Stats_Frame.Rgn_Mean_Plot(df_img_CTX2, 'Light', document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_StdDev_Plot(df_img_CTX2, 'Light', document, pltPath, showPlt)

        document.add_heading(i + ' CTX1 & CTX2 ASIL Image Data', level=2)
        VRG_Safety_Data.SM_Analog_Test_Rows_Plot(df_img, ctxSwitch, document, pltPath, showPlt)
        VRG_Safety_Data.SM_Row_Rom_Address_Columns_Plot(df_img, ctxSwitch, document, pltPath, showPlt)
        VRG_Safety_Data.SM_Row_Rom_SIC_Plot(df_img, ctxSwitch, document, pltPath, showPlt)
        VRG_Safety_Data.SM_Digital_Test_Rows_Plot(df_img, ctxSwitch, document, pltPath, showPlt)

        document.add_heading(i + ' Power & Current vs. Voltage Level', level=2)
        VRG_Power_Data.Supply_Voltage_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.Power_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)

        # for tst in TEST:  # Test
        #     df_test = VRG_Data_Frame.newdataframe(df_img, ctxSwitch, tst)
        #     for tmp in TEMP:  # Temperature
        #         df_tmp = VRG_Data_Frame.newdataframe(df_test, temp, tmp)
        #         if tmp == nomTemp:
        #             document.add_heading(i + ' Image Capture (' + ctxSwitch + ' = ' + str(tst) + ')', level=2)
        #             VRG_Image_Analysis.Add_Image_Analysis(df_tmp, 2, document, showPlt)
        #             VRG_Image_Analysis.Add_Image_Analysis(df_tmp, 5, document, showPlt)
        #             VRG_Image_Analysis.Add_Image_Analysis(df_tmp, 8, document, showPlt)

        document.add_heading(i + ' CTX1 & CTX2 ASIL Image Data', level=2)
        document.add_heading(i + ' Analog Test Rows', level=2)
        VRG_Safety_Data.SM_Analog_Test_Rows_Plot(df_img, ctxSwitch, document, pltPath, showPlt)
        VRG_Safety_Data.SM_Analog_Test_Rows_Expanded_Plot(df_img, ctxSwitch, document, pltPath, showPlt)
        document.add_heading(i + ' RRC Data Values', level=2)
        VRG_Safety_Data.SM_Row_Rom_Address_Columns_Plot(df_img, ctxSwitch, document, pltPath, showPlt)
        VRG_Safety_Data.SM_Row_Rom_Address_Columns_Expanded_Plot(df_img, ctxSwitch, document, pltPath, showPlt)
        document.add_heading(i + ' RRC Signal Integrity Values', level=2)
        VRG_Safety_Data.SM_Row_Rom_SIC_Plot(df_img, ctxSwitch, document, pltPath, showPlt)
        VRG_Safety_Data.SM_Row_Rom_SIC_Expanded_Plot(df_img, ctxSwitch, document, pltPath, showPlt)
        document.add_heading(i + ' Digital Test Rows', level=2)
        VRG_Safety_Data.SM_Digital_Test_Rows_Plot(df_img, ctxSwitch, document, pltPath, showPlt)
        VRG_Safety_Data.SM_Digital_Test_Rows_Expanded_Plot(df_img, ctxSwitch, document, pltPath, showPlt)

    document.add_heading('ASIL Runtime vs. Context Switching vs. Image Mode', level=2)
    VRG_Safety_Data.SM_Runtime_Plot(df, ['ImgMode', ctxSwitch], document, pltPath, showPlt)

def DV_1_09_CONTEXT_SWITCHING_RAM_CUSTOMER(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    ctxSwitch = 'RegWr00_CTX_CONTROL_REG'
    ctx1val = 32768
    ctx2val = 32769
    ctxReg1 = 'RegVal_COARSE_INTEGRATION_TIME_'
    ctxReg2 = 'RegVal_LFM2_T1_E1_C'
    ctxReg3 = 'RegVal_LFM2_T1_E2_OFFSET'
    ctxReg4 = 'RegVal_LFM2_T1_E2_GAIN_CTRL_GS'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # Primary Voltage, Power, and Current
    document.add_heading('Power & Current vs. Voltage Level')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    VRG_Power_Data.Power_Consumption_Plot(df, 'Power', document, pltPath, showPlt)
    VRG_Power_Data.Current_Consumption_Plot(df, 'Power', document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[ctxSwitch].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)
        df_img_CTX1 = VRG_Data_Frame.newdataframe(df_img, ctxSwitch, ctx1val)  # Sort only CTX1 data
        df_img_CTX2 = VRG_Data_Frame.newdataframe(df_img, ctxSwitch, ctx2val)  # Sort only CTX2 data

        # ImgMode Voltage, Power, and Current
        document.add_heading(i, level=1)
        document.add_heading(i + ' Light Level Values')
        VRG_General_Data.LightLevel_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Integration Time', level=2)
        VRG_General_Data.Integration_Time_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Context Switch Reg Values')
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, ctxSwitch, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, ctxSwitch, document, pltPath, ctxReg1, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, ctxSwitch, document, pltPath, ctxReg2, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, ctxSwitch, document, pltPath, ctxReg3, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, ctxSwitch, document, pltPath, ctxReg4, showPlt)

        document.add_heading(i + ' CTX1 Context Switch Reg Values')
        VRG_Register_Data.Reg_vs_Step_Plot(df_img_CTX1, None, document, pltPath, ctxReg1, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img_CTX1, None, document, pltPath, ctxReg2, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img_CTX1, None, document, pltPath, ctxReg3, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img_CTX1, None, document, pltPath, ctxReg4, showPlt)

        document.add_heading(i + ' CTX2 Context Switch Reg Values')
        VRG_Register_Data.Reg_vs_Step_Plot(df_img_CTX2, None, document, pltPath, ctxReg1, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img_CTX2, None, document, pltPath, ctxReg2, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img_CTX2, None, document, pltPath, ctxReg3, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img_CTX2, None, document, pltPath, ctxReg4, showPlt)

        document.add_heading(i + ' Power & Current vs. Voltage Level', level=2)
        VRG_Power_Data.Supply_Voltage_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.Power_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)

        document.add_heading(i + ' Full-Res Image Stats vs. CTX #', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, ctxSwitch, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, ctxSwitch, document, pltPath, showPlt)
        document.add_heading(i + ' Full-Res Image Stats vs. Light', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, 'Light', document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, 'Light', document, pltPath, showPlt)
        document.add_heading(i + ' CTX1 Full-Res Image Stats vs. Light', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img_CTX1, 'Light', document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img_CTX1, 'Light', document, pltPath, showPlt)
        document.add_heading(i + ' CTX2 Full-Res Image Stats vs. Light', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img_CTX2, 'Light', document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img_CTX2, 'Light', document, pltPath, showPlt)

        # document.add_heading(i + ' Region Image Stats vs. Light', level=2)
        # VRG_Stats_Frame.Rgn_Mean_Plot(df_img, 'Light', document, pltPath, showPlt)
        # VRG_Stats_Frame.Rgn_StdDev_Plot(df_img, 'Light', document, pltPath, showPlt)
        # document.add_heading(i + ' CTX1 Region Image Stats vs. Light', level=2)
        # VRG_Stats_Frame.Rgn_Mean_Plot(df_img_CTX1, 'Light', document, pltPath, showPlt)
        # VRG_Stats_Frame.Rgn_StdDev_Plot(df_img_CTX1, 'Light', document, pltPath, showPlt)
        # document.add_heading(i + ' CTX2 Region Image Stats vs. Light', level=2)
        # VRG_Stats_Frame.Rgn_Mean_Plot(df_img_CTX2, 'Light', document, pltPath, showPlt)
        # VRG_Stats_Frame.Rgn_StdDev_Plot(df_img_CTX2, 'Light', document, pltPath, showPlt)

        # for tst in TEST:  # Test
        #     df_test = VRG_Data_Frame.newdataframe(df_img, ctxSwitch, tst)
        #     for tmp in TEMP:  # Temperature
        #         df_tmp = VRG_Data_Frame.newdataframe(df_test, temp, tmp)
        #         if tmp == nomTemp:
        #             document.add_heading(i + ' Image Capture (' + ctxSwitch + ' = ' + str(tst) + ')', level=2)
        #             VRG_Image_Analysis.Add_Image_Analysis(df_tmp, 2, document, showPlt)
        #             VRG_Image_Analysis.Add_Image_Analysis(df_tmp, 5, document, showPlt)
        #             VRG_Image_Analysis.Add_Image_Analysis(df_tmp, 8, document, showPlt)
        #             VRG_Image_Analysis.Add_Image_Analysis(df_tmp, 11, document, showPlt)
        #             VRG_Image_Analysis.Add_Image_Analysis(df_tmp, 14, document, showPlt)

        document.add_heading(i + ' CTX1 & CTX2 Analog Test Rows', level=2)
        VRG_Safety_Data.SM_Analog_Test_Rows_Plot(df_img, ctxSwitch, document, pltPath, showPlt)
        VRG_Safety_Data.SM_Analog_Test_Rows_Expanded_Plot(df_img, ctxSwitch, document, pltPath, showPlt)
        document.add_heading(i + ' CTX1 & CTX2 RRC Data Values', level=2)
        VRG_Safety_Data.SM_Row_Rom_Address_Columns_Plot(df_img, ctxSwitch, document, pltPath, showPlt)
        VRG_Safety_Data.SM_Row_Rom_Address_Columns_Expanded_Plot(df_img, ctxSwitch, document, pltPath, showPlt)
        document.add_heading(i + ' CTX1 & CTX2 RRC Signal Integrity Values', level=2)
        VRG_Safety_Data.SM_Row_Rom_SIC_Plot(df_img, ctxSwitch, document, pltPath, showPlt)
        VRG_Safety_Data.SM_Row_Rom_SIC_Expanded_Plot(df_img, ctxSwitch, document, pltPath, showPlt)
        document.add_heading(i + ' CTX1 & CTX2 Digital Test Rows', level=2)
        VRG_Safety_Data.SM_Digital_Test_Rows_Plot(df_img, ctxSwitch, document, pltPath, showPlt)
        VRG_Safety_Data.SM_Digital_Test_Rows_Expanded_Plot(df_img, ctxSwitch, document, pltPath, showPlt)

    document.add_heading('ASIL Runtime vs. Context Switching vs. Image Mode', level=2)
    VRG_Safety_Data.SM_Runtime_Plot(df, ['ImgMode', ctxSwitch], document, pltPath, showPlt)

def DV_1_10_DYNAMIC_GAIN_AND_EXPOSURE_CHANGES(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    test = 'DVM_3_09_Analog_Gain'
    cint = 'RegWr00_COARSE_INTEGRATION_TIME_'
    minCint = 5
    nomCint = 934
    maxCint = 1540

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[test].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)
        df_mincint = VRG_Data_Frame.newdataframe(df_img, cint, minCint)
        df_nomcint = VRG_Data_Frame.newdataframe(df_img, cint, nomCint)
        df_maxcint = VRG_Data_Frame.newdataframe(df_img, cint, maxCint)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Light Level Values', level=2)
        VRG_General_Data.LightLevel_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Analog Gain vs. Integration Time', level=2)
        VRG_Stats_Frame.Reg_vs_Reg_vs_Img_Mean_Plot(df_img, None, document, pltPath, cint, test, showPlt)
        VRG_Stats_Frame.Reg_vs_Reg_vs_Img_StdDev_Plot(df_img, None, document, pltPath, cint, test, showPlt)

        document.add_heading(i + ' Analog Gain vs. Integration Time vs. Light', level=2)
        VRG_Stats_Frame.Reg_vs_Reg_vs_Img_Mean_Plot(df_img, 'Light', document, pltPath, test, cint, showPlt)

        document.add_heading(i + ' Analog Gain vs. Nominal Integration Time vs. Light', level=2)
        VRG_Stats_Frame.Reg_vs_Img_Mean_Plot(df_mincint, 'Light', document, pltPath, test, showPlt)
        document.add_heading(i + ' Analog Gain vs. Nominal Integration Time vs. Light', level=2)
        VRG_Stats_Frame.Reg_vs_Img_Mean_Plot(df_nomcint, 'Light', document, pltPath, test, showPlt)
        document.add_heading(i + ' Analog Gain vs. Nominal Integration Time vs. Light', level=2)
        VRG_Stats_Frame.Reg_vs_Img_Mean_Plot(df_maxcint, 'Light', document, pltPath, test, showPlt)

        # for tmp in TEMP:  # Temperature
        #     df_tmp = VRG_Data_Frame.newdataframe(df_img, temp, tmp)
        #     if tmp == nomTemp:
        #         document.add_heading(i + ' Image Capture (' + temp + ' = ' + str(tmp) + ')', level=2)
        #         VRG_Image_Analysis.Add_Image_Info(df_tmp, 5, document, showPlt)  # .5x
        #         VRG_Image_Analysis.Add_Image_Info(df_tmp, 14, document, showPlt)  # 1.11x
        #         VRG_Image_Analysis.Add_Image_Info(df_tmp, 23, document, showPlt)  # 2x
        #         VRG_Image_Analysis.Add_Image_Info(df_tmp, 32, document, showPlt)  # 4x
        #         VRG_Image_Analysis.Add_Image_Info(df_tmp, 41, document, showPlt)  # 8x

        document.add_heading(i + ' ASIL Analog Test Rows', level=2)
        VRG_Safety_Data.SM_Analog_Test_Rows_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Safety_Data.SM_Analog_Test_Rows_Expanded_Plot(df_img, 'Power', document, pltPath, showPlt)
        document.add_heading(i + ' ASIL Row Rom Columns', level=2)
        VRG_Safety_Data.SM_Row_Rom_Address_Columns_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Safety_Data.SM_Row_Rom_Address_Columns_Expanded_Plot(df_img, 'Power', document, pltPath, showPlt)
        document.add_heading(i + ' ASIL RRC SIC Columns', level=2)
        VRG_Safety_Data.SM_Row_Rom_SIC_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Safety_Data.SM_Row_Rom_SIC_Expanded_Plot(df_img, 'Power', document, pltPath, showPlt)
        document.add_heading(i + ' ASIL Digital Test Rows', level=2)
        VRG_Safety_Data.SM_Digital_Test_Rows_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Safety_Data.SM_Digital_Test_Rows_Expanded_Plot(df_img, 'Power', document, pltPath, showPlt)

        VRG_Image_Utils.Image_Crop(df_img, 2, document, 34, 0, 64, 20, showPlt)  # RRC start
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 1504, 0, 1536, 20, showPlt)  # RRC mid
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 3100, 0, 3130, 20, showPlt)  # RRC end
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 4, 32, 12, 80, showPlt)  # DTR start
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 4, 2000, 12, 2048, showPlt)  # DTR mid
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 4, 4088, 12, 4136, showPlt)  # DTR end
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 3140, 32, 3160, 80, showPlt)  # ATR start
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 3140, 2000, 3160, 2048, showPlt)  # ATR mid
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 3140, 4088, 3160, 4136, showPlt)  # ATR end

    document.add_heading('ASIL Runtime vs. Imaging Mode', level=2)
    VRG_Safety_Data.SM_Runtime_Plot(df, 'ImgMode', document, pltPath, showPlt)

def DV_1_10_DYNAMIC_EXPOSURE_CHANGES(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    test = 'DVM_3_09_Analog_Gain'
    cint = 'RegWr00_COARSE_INTEGRATION_TIME_'
    minCint = 5
    nomCint = 934
    maxCint = 1540

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[test].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)
        df_mincint = VRG_Data_Frame.newdataframe(df_img, cint, minCint)
        df_nomcint = VRG_Data_Frame.newdataframe(df_img, cint, nomCint)
        df_maxcint = VRG_Data_Frame.newdataframe(df_img, cint, maxCint)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Light Level Values', level=2)
        VRG_General_Data.LightLevel_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Analog Gain vs. Integration Time', level=2)
        VRG_Stats_Frame.Reg_vs_Reg_vs_Img_Mean_Plot(df_img, None, document, pltPath, cint, test, showPlt)
        VRG_Stats_Frame.Reg_vs_Reg_vs_Img_StdDev_Plot(df_img, None, document, pltPath, cint, test, showPlt)

        document.add_heading(i + ' Analog Gain vs. Integration Time vs. Light', level=2)
        VRG_Stats_Frame.Reg_vs_Reg_vs_Img_Mean_Plot(df_img, 'Light', document, pltPath, test, cint, showPlt)

        document.add_heading(i + ' Analog Gain vs. Nominal Integration Time vs. Light', level=2)
        VRG_Stats_Frame.Reg_vs_Img_Mean_Plot(df_mincint, 'Light', document, pltPath, test, showPlt)
        document.add_heading(i + ' Analog Gain vs. Nominal Integration Time vs. Light', level=2)
        VRG_Stats_Frame.Reg_vs_Img_Mean_Plot(df_nomcint, 'Light', document, pltPath, test, showPlt)
        document.add_heading(i + ' Analog Gain vs. Nominal Integration Time vs. Light', level=2)
        VRG_Stats_Frame.Reg_vs_Img_Mean_Plot(df_maxcint, 'Light', document, pltPath, test, showPlt)

        # for tmp in TEMP:  # Temperature
        #     df_tmp = VRG_Data_Frame.newdataframe(df_img, temp, tmp)
        #     if tmp == nomTemp:
        #         document.add_heading(i + ' Image Capture (' + temp + ' = ' + str(tmp) + ')', level=2)
        #         VRG_Image_Analysis.Add_Image_Info(df_tmp, 5, document, showPlt)  # .5x
        #         VRG_Image_Analysis.Add_Image_Info(df_tmp, 14, document, showPlt)  # 1.11x
        #         VRG_Image_Analysis.Add_Image_Info(df_tmp, 23, document, showPlt)  # 2x
        #         VRG_Image_Analysis.Add_Image_Info(df_tmp, 32, document, showPlt)  # 4x
        #         VRG_Image_Analysis.Add_Image_Info(df_tmp, 41, document, showPlt)  # 8x

        document.add_heading(i + ' ASIL Analog Test Rows', level=2)
        VRG_Safety_Data.SM_Analog_Test_Rows_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Safety_Data.SM_Analog_Test_Rows_Expanded_Plot(df_img, 'Power', document, pltPath, showPlt)
        document.add_heading(i + ' ASIL Row Rom Columns', level=2)
        VRG_Safety_Data.SM_Row_Rom_Address_Columns_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Safety_Data.SM_Row_Rom_Address_Columns_Expanded_Plot(df_img, 'Power', document, pltPath, showPlt)
        document.add_heading(i + ' ASIL RRC SIC Columns', level=2)
        VRG_Safety_Data.SM_Row_Rom_SIC_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Safety_Data.SM_Row_Rom_SIC_Expanded_Plot(df_img, 'Power', document, pltPath, showPlt)
        document.add_heading(i + ' ASIL Digital Test Rows', level=2)
        VRG_Safety_Data.SM_Digital_Test_Rows_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Safety_Data.SM_Digital_Test_Rows_Expanded_Plot(df_img, 'Power', document, pltPath, showPlt)

        VRG_Image_Utils.Image_Crop(df_img, 2, document, 34, 0, 64, 20, showPlt)  # RRC start
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 1504, 0, 1536, 20, showPlt)  # RRC mid
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 3100, 0, 3130, 20, showPlt)  # RRC end
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 4, 32, 12, 80, showPlt)  # DTR start
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 4, 2000, 12, 2048, showPlt)  # DTR mid
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 4, 4088, 12, 4136, showPlt)  # DTR end
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 3140, 32, 3160, 80, showPlt)  # ATR start
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 3140, 2000, 3160, 2048, showPlt)  # ATR mid
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 3140, 4088, 3160, 4136, showPlt)  # ATR end

    document.add_heading('ASIL Runtime vs. Imaging Mode', level=2)
    VRG_Safety_Data.SM_Runtime_Plot(df, 'ImgMode', document, pltPath, showPlt)

def DV_1_11_IMAGE_PERFORMANCE_IN_STREAMING(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    intTime = 'RegWr00_COARSE_INTEGRATION_TIME_'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameGrabber_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Image Statistics', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_TotalNoise_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_FPN_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_Temporal_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowStdDev_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowFPN_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTempNoise_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColStdDev_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColFPN_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTempNoise_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_Flicker_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelTotalNoise_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelTemporalNoise_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelFPN_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTemporalNoiseRatio_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColumnTemporalNoiseRatio_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowFPNRatio_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColumnFPNRatio_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Image Statistics vs. Integration Time ', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_TotalNoise_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_FPN_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_Temporal_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowStdDev_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowFPN_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTempNoise_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColStdDev_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColFPN_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTempNoise_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_Flicker_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelTotalNoise_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelTemporalNoise_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelFPN_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTemporalNoiseRatio_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColumnTemporalNoiseRatio_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowFPNRatio_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColumnFPNRatio_Plot(df_img, intTime, document, pltPath, showPlt)

        # for tmp in TEMP:  # Temperature
        #     df_tmp = VRG_Data_Frame.newdataframe(df_img, temp, tmp)
        #     if tmp == nomTemp:
        #         document.add_heading(i + ' Image Capture', level=2)
        #         VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 3, document, showPlt)  # 20ms, minV
        #         VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 3, document, showPlt)  # 20ms, maxV

        document.add_heading(i + ' ASIL Analog Test Rows', level=2)
        VRG_Safety_Data.SM_Analog_Test_Rows_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Safety_Data.SM_Analog_Test_Rows_Expanded_Plot(df_img, 'Power', document, pltPath, showPlt)
        document.add_heading(i + ' ASIL Row Rom Columns', level=2)
        VRG_Safety_Data.SM_Row_Rom_Address_Columns_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Safety_Data.SM_Row_Rom_Address_Columns_Expanded_Plot(df_img, 'Power', document, pltPath, showPlt)
        document.add_heading(i + ' ASIL RRC SIC Columns', level=2)
        VRG_Safety_Data.SM_Row_Rom_SIC_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Safety_Data.SM_Row_Rom_SIC_Expanded_Plot(df_img, 'Power', document, pltPath, showPlt)
        document.add_heading(i + ' ASIL Digital Test Rows', level=2)
        VRG_Safety_Data.SM_Digital_Test_Rows_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Safety_Data.SM_Digital_Test_Rows_Expanded_Plot(df_img, 'Power', document, pltPath, showPlt)


'''
2.00 TEST MODES
'''

def DV_2_01_POR_BYPASS(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_2_02_TRIM_CALCULATE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # Test Data - 1.	Table of measured vs. expected register values
    document.add_heading('Trim Calculate Results vs. Die vs. Power vs. Temperature')
    VRG_Power_Data.Trim_Calculate_Plot(df, [die, 'Power', temp], document, pltPath, showPlt)

def DV_2_02_REFERENCE_CURRENT(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    trimReg1 = 'RegVal_DAC_LD_0_1'
    trimReg2 = 'RegVal_DAC_LD_2_3'
    trimReg3 = 'RegVal_DAC_LD_4_5'
    trimReg4 = 'RegVal_DAC_LD_16_17'
    trimReg5 = 'RegVal_TEMPVSENS1_SREG_TRIM0'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # Test Data - 1.	Table of measured vs. expected register values
    document.add_heading('Trim Reg Values')
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, trimReg1, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, trimReg2, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, trimReg3, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, trimReg4, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, trimReg5, showPlt)

    document.add_heading('Current Trim Reference vs. Die vs. Power')
    VRG_Power_Data.Current_Trim_Reference_Plot(df, [die, 'Power'], document, pltPath, showPlt)

    document.add_heading('Current Trim Reference vs. Die vs. Temperature vs. Power')
    VRG_Power_Data.Current_Trim_Reference_Plot(df, [die, temp, 'Power'], document, pltPath, showPlt)

def DV_2_02_REFERENCE_VOLTAGE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    trimReg1 = 'RegVal_DAC_LD_0_1'
    trimReg2 = 'RegVal_DAC_LD_2_3'
    trimReg3 = 'RegVal_DAC_LD_4_5'
    trimReg4 = 'RegVal_DAC_LD_16_17'
    trimReg5 = 'RegVal_TEMPVSENS1_SREG_TRIM0'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # Test Data - 1.	Table of measured vs. expected register values
    document.add_heading('Trim Reg Values')
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, trimReg1, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, trimReg2, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, trimReg3, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, trimReg4, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, trimReg5, showPlt)

    document.add_heading('Voltage Trim Reference vs. Die vs. Power')
    VRG_Power_Data.Voltage_Trim_Reference_Plot(df, [die, 'Power'], document, pltPath, showPlt)

    document.add_heading('Current Trim Reference vs. Die vs. Temperature vs. Power')
    VRG_Power_Data.Voltage_Trim_Reference_Plot(df, [die, temp, 'Power'], document, pltPath, showPlt)

def DV_2_02_REFERENCE_CURRENT_VS_TRIM(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    trimReg1 = 'RegVal_DAC_LD_0_1'
    trimReg2 = 'RegVal_DAC_LD_2_3'
    trimReg3 = 'RegVal_DAC_LD_4_5'
    trimReg4 = 'RegVal_DAC_LD_16_17'
    trimReg5 = 'RegVal_TEMPVSENS1_SREG_TRIM0'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # Test Data - 1.	Table of measured vs. expected register values
    document.add_heading('Trim Reg Values')
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, trimReg1, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, trimReg2, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, trimReg3, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, trimReg4, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, trimReg5, showPlt)

    document.add_heading('Current Trim Reference vs. Die vs. Power')
    VRG_Power_Data.Current_Trim_Reference_Plot(df, [die, 'Power'], document, pltPath, showPlt)

    document.add_heading('Current Trim Reference vs. Die vs. Temperature vs. Power')
    VRG_Power_Data.Current_Trim_Reference_Plot(df, [die, temp, 'Power'], document, pltPath, showPlt)

def DV_2_02_REFERENCE_VOLTAGE_VS_TRIM(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    trimReg1 = 'RegVal_DAC_LD_0_1'
    trimReg2 = 'RegVal_DAC_LD_2_3'
    trimReg3 = 'RegVal_DAC_LD_4_5'
    trimReg4 = 'RegVal_DAC_LD_16_17'
    trimReg5 = 'RegVal_TEMPVSENS1_SREG_TRIM0'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # Test Data - 1.	Table of measured vs. expected register values
    document.add_heading('Trim Reg Values')
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, trimReg1, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, trimReg2, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, trimReg3, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, trimReg4, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, trimReg5, showPlt)

    document.add_heading('Voltage Trim Reference vs. Die vs. Power')
    VRG_Power_Data.Voltage_Trim_Reference_Plot(df, [die, 'Power'], document, pltPath, showPlt)

    document.add_heading('Current Trim Reference vs. Die vs. Temperature vs. Power')
    VRG_Power_Data.Voltage_Trim_Reference_Plot(df, [die, temp, 'Power'], document, pltPath, showPlt)

def DV_2_03_ADC_TEST_MODE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_2_04_ASC_TEST_MODE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_2_05_PLL_BYPASS(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    pllByp = 'RegWr00_DIGITAL_TEST'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    document.add_heading('PLL Bypass Reg Values')
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, pllByp, showPlt)

    document.add_heading('PLL Clocks vs. Bypass ')
    VRG_General_Data.PLL_Clock_Plot(df, pllByp, document, pltPath, showPlt)
    VRG_General_Data.I2C_Status_Plot(df, pllByp, document, pltPath, showPlt)

    document.add_heading('PLL Clocks vs. Bypass vs. Clk')
    VRG_General_Data.PLL_Clock_Plot(df, [pllByp, 'Clk'], document, pltPath, showPlt)
    VRG_General_Data.I2C_Status_Plot(df, [pllByp, 'Clk'], document, pltPath, showPlt)

    document.add_heading('PLL Clocks vs. Bypass vs. Clk vs. Voltage')
    VRG_General_Data.PLL_Clock_Plot(df, [pllByp, 'Clk', 'Power'], document, pltPath, showPlt)
    VRG_General_Data.I2C_Status_Plot(df, [pllByp, 'Clk', 'Power'], document, pltPath, showPlt)

    document.add_heading('PLL Clocks vs. Die vs. Clk')
    VRG_General_Data.PLL_Clock_Plot(df, [die, 'Clk'], document, pltPath, showPlt)
    VRG_General_Data.I2C_Status_Plot(df, [die, 'Clk'], document, pltPath, showPlt)

    document.add_heading('PLL Clocks vs. Die vs. Clk vs. Temp')
    VRG_General_Data.PLL_Clock_Plot(df, [die, 'Clk', temp], document, pltPath, showPlt)
    VRG_General_Data.I2C_Status_Plot(df, [die, 'Clk', temp], document, pltPath, showPlt)

    document.add_heading('Power & Current vs. Bypass')
    VRG_Power_Data.Power_Consumption_Plot(df, 'Power', document, pltPath, showPlt)
    VRG_Power_Data.Current_Consumption_Plot(df, 'Power', document, pltPath, showPlt)

    document.add_heading('Power & Current vs. Voltage Level')
    VRG_Power_Data.Power_Consumption_Plot(df, 'Power', document, pltPath, showPlt)
    VRG_Power_Data.Current_Consumption_Plot(df, 'Power', document, pltPath, showPlt)

def DV_2_06_NAND_TREE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_2_07_MEMORY_BIST(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_2_08_SCAN_CHAIN(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_2_08_BOUNDRY_SCAN_CHAIN(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_2_09_INPUT_OUTPUT_LEAKAGE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_2_11_COLUMN_MEMORY(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    colMemReg = 'RegWr00_DAC_LD_34_35'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    document.add_heading('Column Memory Reg Values')
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, colMemReg, showPlt)

    document.add_heading('Column Memory CRC Values vs. Die vs. Column Memory Test')
    VRG_Register_Data.MIPI_CRC_Register_Plot(df, ['ImgMode', colMemReg], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image
    TEST = np.asarray(df[colMemReg].unique())  # List of unique colmem reg values
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Column Memory CRC Values  vs. Column Memory Test', level=2)
        VRG_Register_Data.MIPI_CRC_Register_Plot(df, colMemReg, document, pltPath, showPlt)

        document.add_heading(i + ' Column Memory CRC Values vs. Die vs. Column Memory Test', level=2)
        VRG_Register_Data.MIPI_CRC_Register_Plot(df, [die, colMemReg], document, pltPath, showPlt)

        document.add_heading(i + ' Column Memory CRC Values vs. Power vs. Column Memory Test', level=2)
        VRG_Register_Data.MIPI_CRC_Register_Plot(df, ['Power', colMemReg], document, pltPath, showPlt)

        for tst in TEST:  # Test
            df_test = VRG_Data_Frame.newdataframe(df_img, colMemReg, tst)
            # for tmp in TEMP:  # Temperature
            #     df_tmp = VRG_Data_Frame.newdataframe(df_test, temp, tmp)
            #     if tmp == nomTemp:
            #         document.add_heading(i + ' Column Memory Image (' + colMemReg + ' = ' + str(tst) + ')', level=2)
            #         VRG_Image_Analysis.Add_Image(df_tmp, 2, document, showPlt)  # each colmem, nomV, 60C, imgmode

            document.add_heading(i + ' Column Memory Image Statistics(' + colMemReg + ' = ' + str(tst) + ')', level=2)
            VRG_Stats_Arr.Arr_Mean_Plot(df_test, [die, colMemReg], document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_StdDev_Plot(df_test, [die, colMemReg], document, pltPath, showPlt)

            document.add_heading(i + ' Column Memory CRC Values (' + colMemReg + ' = ' + str(tst) + ')', level=2)
            VRG_Register_Data.MIPI_CRC_Register_Plot(df_test, colMemReg, document, pltPath, showPlt)

            document.add_heading(
                i + ' Column Memory CRC Values vs. Die vs. Power (' + colMemReg + ' = ' + str(tst) + ')', level=2)
            VRG_Register_Data.MIPI_CRC_Register_Plot(df_test, [die, 'Power', colMemReg], document, pltPath, showPlt)

def DV_2_12_DIGITAL_TEST_PATTERNS_LEGACY(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    testPatReg = 'RegWr00_TEST_PATTERN_MODE_'
    solidColor = 1

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    document.add_heading('Test Pattern Reg Values')
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, testPatReg, showPlt)

    document.add_heading('Test Pattern Reg Values vs. Die vs. Test Pattern Test')
    VRG_Register_Data.MIPI_CRC_Register_Plot(df, ['ImgMode', testPatReg], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image
    TEST = np.asarray(df[testPatReg].unique())  # List of unique reg values
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Test Pattern CRC Values vs.  vs. Test Pattern Test', level=2)
        VRG_Register_Data.MIPI_CRC_Register_Plot(df, testPatReg, document, pltPath, showPlt)

        document.add_heading(i + ' Test Pattern CRC Values vs. Die vs. Test Pattern Test', level=2)
        VRG_Register_Data.MIPI_CRC_Register_Plot(df, [die, testPatReg], document, pltPath, showPlt)

        document.add_heading(i + ' Test Pattern CRC Values vs. Power vs. Test Pattern Test', level=2)
        VRG_Register_Data.MIPI_CRC_Register_Plot(df, ['Power', testPatReg], document, pltPath, showPlt)

        for tst in TEST:
            df_test = VRG_Data_Frame.newdataframe(df_img, testPatReg, tst)

            # for tmp in TEMP:  # Temperature
            #     df_tmp = VRG_Data_Frame.newdataframe(df_test, temp, tmp)
            #     if tmp == nomTemp:
            #         document.add_heading(i + ' Test Pattern Image (' + testPatReg + ' = ' + str(tst) + ')', level=2)
            #         VRG_Image_Analysis.Add_Image(df_tmp, 2, document, showPlt)  # each testpattern, nomV, 60C, imgmode

            document.add_heading(i + ' Test Pattern Image Statistics(' + testPatReg + ' = ' + str(tst) + ')', level=2)
            VRG_Stats_Arr.Arr_Mean_Plot(df_test, [die, testPatReg], document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_StdDev_Plot(df_test, [die, testPatReg], document, pltPath, showPlt)

            if tst == solidColor:
                document.add_heading('Test Pattern Reg Values', level=2)
                VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, testPatReg, showPlt)

            document.add_heading(i + ' Test Pattern CRC Values (' + testPatReg + ' = ' + str(tst) + ')', level=2)
            VRG_Register_Data.MIPI_CRC_Register_Plot(df_test, testPatReg, document, pltPath, showPlt)

            document.add_heading(
                i + ' Test Pattern CRC Values vs. Power vs. Die (' + testPatReg + ' = ' + str(tst) + ')', level=2)
            VRG_Register_Data.MIPI_CRC_Register_Plot(df_test, [die, 'Power', testPatReg], document, pltPath, showPlt)

def DV_2_12_DIGITAL_TEST_PATTERNS_TPG(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_2_13_PFA_PROCEDURES_DOCUMENT_VALIDATION(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_2_14_ALTERNATING_COLUMN_MODE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die


'''
3.00 SENSOR CORE
'''

def DV_3_00_LINEARITY_IMAGE_ANALYSIS(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    cint = 'RegWr00_COARSE_INTEGRATION_TIME_'
    df_minInteg = VRG_Data_Frame.newdataframe(df, 'RegWr00_COARSE_INTEGRATION_TIME_', 5)
    df_maxInteg = VRG_Data_Frame.newdataframe(df, 'RegWr00_COARSE_INTEGRATION_TIME_', 1540)

    # VRG_General_Data Plots
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    document.add_heading('Img Stats vs. ImgMode vs. IntegTime vs. Light')
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_Mean_Plot(df, 'ImgMode', document, pltPath, 'Light', cint, showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_StdDev_Plot(df, 'ImgMode', document, pltPath, 'Light', cint, showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_TotalNoise_Plot(df, 'ImgMode', document, pltPath, 'Light', cint, showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_FPN_Plot(df, 'ImgMode', document, pltPath, 'Light', cint, showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_Temporal_Plot(df, 'ImgMode', document, pltPath, 'Light', cint, showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_ColTotalNoise_Plot(df, 'ImgMode', document, pltPath, 'Light', cint, showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_RowTotalNoise_Plot(df, 'ImgMode', document, pltPath, 'Light', cint, showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_ColFPN_Plot(df, 'ImgMode', document, pltPath, 'Light', cint, showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_RowFPN_Plot(df, 'ImgMode', document, pltPath, 'Light', cint, showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_ColTempNoise_Plot(df, 'ImgMode', document, pltPath, 'Light', cint, showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_RowTempNoise_Plot(df, 'ImgMode', document, pltPath, 'Light', cint, showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_PixelTotalNoise_Plot(df, 'ImgMode', document, pltPath, 'Light', cint, showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_PixelFPN_Plot(df, 'ImgMode', document, pltPath, 'Light', cint, showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_PixelTemporalNoise_Plot(df, 'ImgMode', document, pltPath, 'Light', cint, showPlt)

    document.add_heading('Minimum IntegTime Img Stats vs. ImgMode vs. Light')
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_Mean_Plot(df_minInteg, 'ImgMode', document, pltPath, 'Light', 'Power', showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_StdDev_Plot(df_minInteg, 'ImgMode', document, pltPath, 'Light', 'Power', showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_TotalNoise_Plot(df_minInteg, 'ImgMode', document, pltPath, 'Light', 'Power',
                                                      showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_FPN_Plot(df_minInteg, 'ImgMode', document, pltPath, 'Light', 'Power', showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_Temporal_Plot(df_minInteg, 'ImgMode', document, pltPath, 'Light', 'Power',
                                                    showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_ColTotalNoise_Plot(df_minInteg, 'ImgMode', document, pltPath, 'Light', 'Power',
                                                         showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_RowTotalNoise_Plot(df_minInteg, 'ImgMode', document, pltPath, 'Light', 'Power',
                                                         showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_ColFPN_Plot(df_minInteg, 'ImgMode', document, pltPath, 'Light', 'Power', showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_RowFPN_Plot(df_minInteg, 'ImgMode', document, pltPath, 'Light', 'Power', showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_ColTempNoise_Plot(df_minInteg, 'ImgMode', document, pltPath, 'Light', 'Power',
                                                        showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_RowTempNoise_Plot(df_minInteg, 'ImgMode', document, pltPath, 'Light', 'Power',
                                                        showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_PixelTotalNoise_Plot(df_minInteg, 'ImgMode', document, pltPath, 'Light', 'Power',
                                                           showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_PixelFPN_Plot(df_minInteg, 'ImgMode', document, pltPath, 'Light', 'Power',
                                                    showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_PixelTemporalNoise_Plot(df_minInteg, 'ImgMode', document, pltPath, 'Light',
                                                              'Power', showPlt)

    document.add_heading('Maximum IntegTime Img Stats vs. ImgMode vs. Light')
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_Mean_Plot(df_maxInteg, 'ImgMode', document, pltPath, 'Light', 'Power', showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_StdDev_Plot(df_maxInteg, 'ImgMode', document, pltPath, 'Light', 'Power', showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_TotalNoise_Plot(df_maxInteg, 'ImgMode', document, pltPath, 'Light', 'Power',
                                                      showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_FPN_Plot(df_maxInteg, 'ImgMode', document, pltPath, 'Light', 'Power', showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_Temporal_Plot(df_maxInteg, 'ImgMode', document, pltPath, 'Light', 'Power',
                                                    showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_ColTotalNoise_Plot(df_maxInteg, 'ImgMode', document, pltPath, 'Light', 'Power',
                                                         showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_RowTotalNoise_Plot(df_maxInteg, 'ImgMode', document, pltPath, 'Light', 'Power',
                                                         showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_ColFPN_Plot(df_maxInteg, 'ImgMode', document, pltPath, 'Light', 'Power', showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_RowFPN_Plot(df_maxInteg, 'ImgMode', document, pltPath, 'Light', 'Power', showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_ColTempNoise_Plot(df_maxInteg, 'ImgMode', document, pltPath, 'Light', 'Power',
                                                        showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_RowTempNoise_Plot(df_maxInteg, 'ImgMode', document, pltPath, 'Light', 'Power',
                                                        showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_PixelTotalNoise_Plot(df_maxInteg, 'ImgMode', document, pltPath, 'Light', 'Power',
                                                           showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_PixelFPN_Plot(df_maxInteg, 'ImgMode', document, pltPath, 'Light', 'Power',
                                                    showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_PixelTemporalNoise_Plot(df_maxInteg, 'ImgMode', document, pltPath, 'Light',
                                                              'Power', showPlt)

    document.add_heading('Power & Current vs. Voltage Level')
    VRG_Power_Data.Power_Consumption_Plot(df, 'Power', document, pltPath, showPlt)
    VRG_Power_Data.Current_Consumption_Plot(df, 'Power', document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)
        df_img_minLight = VRG_Data_Frame.newdataframe(df_img, 'Light', 0)
        df_img_nomLight = VRG_Data_Frame.newdataframe(df_img, 'Light', 20000)
        df_img_maxLight = VRG_Data_Frame.newdataframe(df_img, 'Light', 65535)
        df_img_minInteg = VRG_Data_Frame.newdataframe(df_img, cint, 5)
        df_img_nomInteg = VRG_Data_Frame.newdataframe(df_img, cint, 934)
        df_img_maxInteg = VRG_Data_Frame.newdataframe(df_img, cint, 1540)

        document.add_heading(i + ' Img Stats', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, 'Light', document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, cint, document, pltPath, showPlt)
        document.add_heading(i + ' Img Stats @ Min IntegrationTime', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img_minInteg, 'Light', document, pltPath, showPlt)
        document.add_heading(i + ' Img Stats @ Max IntegrationTime', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img_maxInteg, 'Light', document, pltPath, showPlt)

        document.add_heading(i + 'Power & Current vs. Voltage Level', level=2)
        VRG_Power_Data.Power_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)

def DV_3_01_DARK_IMAGE_ANALYSIS(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    intTime = 'RegWr00_COARSE_INTEGRATION_TIME_'
    nomIntTime = 934
    digGain = 'RegWr01_GLOBAL_GAIN'
    nomDigGain = 128
    anaGain = 'DVM_3_09_Analog_Gain'
    nomAnaGain = 1.11

    # VRG_General_Data Plots
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[intTime].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)
        df_nomCint = VRG_Data_Frame.newdataframe(df_img, intTime, nomIntTime)
        df_nomCint_DigGain = VRG_Data_Frame.newdataframe(df_nomCint, digGain, nomDigGain)
        df_nomCint_AnaGain = VRG_Data_Frame.newdataframe(df_nomCint, anaGain, nomAnaGain)
        df_nomDigGain = VRG_Data_Frame.newdataframe(df_img, digGain, nomDigGain)
        df_nomAnaGain = VRG_Data_Frame.newdataframe(df_img, anaGain, nomAnaGain)
        df_nomDigGain_AnaGain = VRG_Data_Frame.newdataframe(df_nomDigGain, anaGain, nomAnaGain)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Light Level Values', level=1)
        VRG_General_Data.LightLevel_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Key Register Values', level=1)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, intTime, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, digGain, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, anaGain, showPlt)

        document.add_heading(i + ' Image Statistics vs. Nominal Digital & Analog Gain vs. Integration time', level=1)
        VRG_Stats_Arr.Arr_Mean_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_TotalNoise_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_FPN_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_Temporal_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowStdDev_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowFPN_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTempNoise_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColStdDev_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColFPN_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTempNoise_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_Flicker_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelTotalNoise_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelTemporalNoise_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelFPN_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTemporalNoiseRatio_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColumnTemporalNoiseRatio_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowFPNRatio_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColumnFPNRatio_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)

        document.add_heading(i + ' Image Statistics vs. Nominal Integration Time & Analog Gain vs. Digital Gain',
                             level=1)
        VRG_Stats_Arr.Arr_Mean_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_TotalNoise_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_FPN_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_Temporal_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowStdDev_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowFPN_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTempNoise_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColStdDev_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColFPN_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTempNoise_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_Flicker_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelTotalNoise_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelTemporalNoise_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelFPN_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTemporalNoiseRatio_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColumnTemporalNoiseRatio_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowFPNRatio_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColumnFPNRatio_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)

        document.add_heading(i + ' Image Statistics vs. Nominal Integration Time & Digital Gain vs. Analog Gain',
                             level=1)
        VRG_Stats_Arr.Arr_Mean_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_TotalNoise_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_FPN_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_Temporal_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowStdDev_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowFPN_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTempNoise_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColStdDev_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColFPN_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTempNoise_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_Flicker_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelTotalNoise_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelTemporalNoise_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelFPN_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTemporalNoiseRatio_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColumnTemporalNoiseRatio_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowFPNRatio_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColumnFPNRatio_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)

        document.add_heading(i + ' Image Statistics vs. Integration Time ', level=1)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_TotalNoise_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_FPN_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_Temporal_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowStdDev_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowFPN_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTempNoise_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColStdDev_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColFPN_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTempNoise_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_Flicker_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelTotalNoise_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelTemporalNoise_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelFPN_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTemporalNoiseRatio_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColumnTemporalNoiseRatio_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowFPNRatio_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColumnFPNRatio_Plot(df_img, intTime, document, pltPath, showPlt)

        document.add_heading(i + ' Image Statistics vs. Digital & Analog Gain vs. Integration time', level=1)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_TotalNoise_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_FPN_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_Temporal_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowStdDev_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowFPN_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTempNoise_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColStdDev_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColFPN_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTempNoise_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_Flicker_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelTotalNoise_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelTemporalNoise_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelFPN_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTemporalNoiseRatio_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColumnTemporalNoiseRatio_Plot(df_img, [intTime, digGain, anaGain], document, pltPath,
                                                          showPlt)
        VRG_Stats_Arr.Arr_RowFPNRatio_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColumnFPNRatio_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)

        document.add_heading(i + ' Image Statistics vs. Die', level=1)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_TotalNoise_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_FPN_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_Temporal_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowStdDev_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowFPN_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTempNoise_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColStdDev_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColFPN_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTempNoise_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_Flicker_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelTotalNoise_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelTemporalNoise_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelFPN_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTemporalNoiseRatio_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColumnTemporalNoiseRatio_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowFPNRatio_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColumnFPNRatio_Plot(df_img, die, document, pltPath, showPlt)
        # my_plots = [
        #     VRG_Stats_Arr.Arr_Mean_Plot,
        #
        # ]
        # for plot in my_plots:
        #     plot((df_img, die, document, pltPath, showPlt)

        for tst in TEST:  # Test
            df_test = VRG_Data_Frame.newdataframe(df_img, intTime, tst)
            for tmp in TEMP:  # Temperature
                df_tmp = VRG_Data_Frame.newdataframe(df_test, temp, tmp)
                if tmp == nomTemp:
                    document.add_heading(
                        i + ' Image Capture (' + intTime + ' = ' + str(tst) + ') at Temperature = ' + str(tmp), level=2)
                    VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 40, document,
                                                               showPlt)  # 128 dig gain, 1.11x ana gain

        document.add_heading(i + ' ASIL Image Data', level=2)
        VRG_Safety_Data.SM_Analog_Test_Rows_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Safety_Data.SM_Row_Rom_Address_Columns_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Safety_Data.SM_Row_Rom_SIC_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Safety_Data.SM_Digital_Test_Rows_Plot(df_img, 'Power', document, pltPath, showPlt)

        VRG_Image_Utils.Image_Crop(df_img, 2, document, 34, 0, 64, 20, showPlt)  # RRC start
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 1504, 0, 1536, 20, showPlt)  # RRC mid
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 3100, 0, 3130, 20, showPlt)  # RRC end
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 4, 32, 12, 80, showPlt)  # DTR start
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 4, 2000, 12, 2048, showPlt)  # DTR mid
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 4, 4088, 12, 4136, showPlt)  # DTR end
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 3140, 32, 3160, 80, showPlt)  # ATR start
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 3140, 2000, 3160, 2048, showPlt)  # ATR mid
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 3140, 4088, 3160, 4136, showPlt)  # ATR end

        document.add_heading(i + 'Power & Current vs. Voltage Level', level=2)
        VRG_Power_Data.Power_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)

def DV_3_02_LOW_MIDLEVEL_IMAGE_ANALYSIS(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    intTime = 'RegWr00_COARSE_INTEGRATION_TIME_'
    nomIntTime = 934
    digGain = 'RegWr01_GLOBAL_GAIN'
    nomDigGain = 128
    anaGain = 'DVM_3_09_Analog_Gain'
    nomAnaGain = 1.11

    # VRG_General_Data Plots
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[intTime].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)
        df_nomCint = VRG_Data_Frame.newdataframe(df_img, intTime, nomIntTime)
        df_nomCint_DigGain = VRG_Data_Frame.newdataframe(df_nomCint, digGain, nomDigGain)
        df_nomCint_AnaGain = VRG_Data_Frame.newdataframe(df_nomCint, anaGain, nomAnaGain)
        df_nomDigGain = VRG_Data_Frame.newdataframe(df_img, digGain, nomDigGain)
        df_nomAnaGain = VRG_Data_Frame.newdataframe(df_img, anaGain, nomAnaGain)
        df_nomDigGain_AnaGain = VRG_Data_Frame.newdataframe(df_nomDigGain, anaGain, nomAnaGain)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Light Level Values', level=2)
        VRG_General_Data.LightLevel_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Key Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, intTime, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, digGain, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, anaGain, showPlt)

        document.add_heading(i + ' Image Statistics vs. Nominal Digital & Analog Gain vs. Integration time', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_TotalNoise_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_FPN_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_Temporal_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowStdDev_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowFPN_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTempNoise_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColStdDev_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColFPN_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTempNoise_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_Flicker_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelTotalNoise_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelTemporalNoise_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelFPN_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTemporalNoiseRatio_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColumnTemporalNoiseRatio_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowFPNRatio_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColumnFPNRatio_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)

        document.add_heading(i + ' Image Statistics vs. Nominal Integration Time & Analog Gain vs. Digital Gain',
                             level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_TotalNoise_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_FPN_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_Temporal_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowStdDev_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowFPN_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTempNoise_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColStdDev_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColFPN_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTempNoise_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_Flicker_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelTotalNoise_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelTemporalNoise_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelFPN_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTemporalNoiseRatio_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColumnTemporalNoiseRatio_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowFPNRatio_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColumnFPNRatio_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)

        document.add_heading(i + ' Image Statistics vs. Nominal Integration Time & Digital Gain vs. Analog Gain',
                             level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_TotalNoise_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_FPN_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_Temporal_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowStdDev_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowFPN_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTempNoise_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColStdDev_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColFPN_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTempNoise_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_Flicker_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelTotalNoise_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelTemporalNoise_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelFPN_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTemporalNoiseRatio_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColumnTemporalNoiseRatio_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowFPNRatio_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColumnFPNRatio_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)

        document.add_heading(i + ' Image Statistics vs. Integration Time ', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_TotalNoise_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_FPN_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_Temporal_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowStdDev_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowFPN_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTempNoise_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColStdDev_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColFPN_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTempNoise_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_Flicker_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelTotalNoise_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelTemporalNoise_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelFPN_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTemporalNoiseRatio_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColumnTemporalNoiseRatio_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowFPNRatio_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColumnFPNRatio_Plot(df_img, intTime, document, pltPath, showPlt)

        document.add_heading(i + ' Image Statistics vs. Digital & Analog Gain vs. Integration time', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_TotalNoise_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_FPN_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_Temporal_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowStdDev_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowFPN_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTempNoise_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColStdDev_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColFPN_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTempNoise_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_Flicker_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelTotalNoise_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelTemporalNoise_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelFPN_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTemporalNoiseRatio_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColumnTemporalNoiseRatio_Plot(df_img, [intTime, digGain, anaGain], document, pltPath,
                                                          showPlt)
        VRG_Stats_Arr.Arr_RowFPNRatio_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColumnFPNRatio_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)

        document.add_heading(i + ' Image Statistics vs. Die', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_TotalNoise_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_FPN_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_Temporal_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowStdDev_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowFPN_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTempNoise_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColStdDev_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColFPN_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTempNoise_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_Flicker_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelTotalNoise_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelTemporalNoise_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelFPN_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTemporalNoiseRatio_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColumnTemporalNoiseRatio_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowFPNRatio_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColumnFPNRatio_Plot(df_img, die, document, pltPath, showPlt)

        document.add_heading(i + ' Image Statistics vs. Die', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, temp, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, temp, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_TotalNoise_Plot(df_img, temp, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_FPN_Plot(df_img, temp, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_Temporal_Plot(df_img, temp, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowStdDev_Plot(df_img, temp, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_img, temp, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowFPN_Plot(df_img, temp, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTempNoise_Plot(df_img, temp, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColStdDev_Plot(df_img, temp, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_img, temp, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColFPN_Plot(df_img, temp, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTempNoise_Plot(df_img, temp, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_Flicker_Plot(df_img, temp, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelTotalNoise_Plot(df_img, temp, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelTemporalNoise_Plot(df_img, temp, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelFPN_Plot(df_img, temp, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTemporalNoiseRatio_Plot(df_img, temp, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColumnTemporalNoiseRatio_Plot(df_img, temp, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowFPNRatio_Plot(df_img, temp, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColumnFPNRatio_Plot(df_img, temp, document, pltPath, showPlt)

        # for tst in TEST:  # Test
        #     df_test = VRG_Data_Frame.newdataframe(df_img, intTime, tst)
        #     for tmp in TEMP:  # Temperature
        #         df_tmp = VRG_Data_Frame.newdataframe(df_test, temp, tmp)
        #         if tmp == nomTemp:
        #             document.add_heading(
        #                 i + ' Image Capture (' + intTime + ' = ' + str(tst) + ') at Temperature = ' + str(tmp), level=2)
        #             VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 40, document,
        #                                                        showPlt)  # 128 dig gain, 1.11x ana gain

        document.add_heading(i + ' ASIL Image Data', level=2)
        VRG_Safety_Data.SM_Analog_Test_Rows_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Safety_Data.SM_Row_Rom_Address_Columns_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Safety_Data.SM_Row_Rom_SIC_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Safety_Data.SM_Digital_Test_Rows_Plot(df_img, 'Power', document, pltPath, showPlt)

        VRG_Image_Utils.Image_Crop(df_img, 2, document, 34, 0, 64, 20, showPlt)  # RRC start
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 1504, 0, 1536, 20, showPlt)  # RRC mid
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 3100, 0, 3130, 20, showPlt)  # RRC end
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 4, 32, 12, 80, showPlt)  # DTR start
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 4, 2000, 12, 2048, showPlt)  # DTR mid
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 4, 4088, 12, 4136, showPlt)  # DTR end
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 3140, 32, 3160, 80, showPlt)  # ATR start
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 3140, 2000, 3160, 2048, showPlt)  # ATR mid
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 3140, 4088, 3160, 4136, showPlt)  # ATR end

        document.add_heading(i + 'Power & Current vs. Voltage Level', level=2)
        VRG_Power_Data.Power_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)

def DV_3_03_SATURATED_IMAGE_ANALYSIS(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    intTime = 'RegWr00_COARSE_INTEGRATION_TIME_'
    nomIntTime = 934
    digGain = 'RegWr01_GLOBAL_GAIN'
    nomDigGain = 128
    anaGain = 'DVM_3_09_Analog_Gain'
    nomAnaGain = 1.11

    # VRG_General_Data Plots
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[intTime].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)
        df_nomCint = VRG_Data_Frame.newdataframe(df_img, intTime, nomIntTime)
        df_nomCint_DigGain = VRG_Data_Frame.newdataframe(df_nomCint, digGain, nomDigGain)
        df_nomCint_AnaGain = VRG_Data_Frame.newdataframe(df_nomCint, anaGain, nomAnaGain)
        df_nomDigGain = VRG_Data_Frame.newdataframe(df_img, digGain, nomDigGain)
        df_nomAnaGain = VRG_Data_Frame.newdataframe(df_img, anaGain, nomAnaGain)
        df_nomDigGain_AnaGain = VRG_Data_Frame.newdataframe(df_nomDigGain, anaGain, nomAnaGain)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Light Level Values', level=2)
        VRG_General_Data.LightLevel_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Key Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, intTime, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, digGain, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, anaGain, showPlt)

        document.add_heading(i + ' Image Statistics vs. Nominal Digital & Analog Gain vs. Integration time', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_TotalNoise_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_FPN_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_Temporal_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowStdDev_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowFPN_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTempNoise_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColStdDev_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColFPN_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTempNoise_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_Flicker_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelTotalNoise_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelTemporalNoise_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelFPN_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTemporalNoiseRatio_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColumnTemporalNoiseRatio_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowFPNRatio_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColumnFPNRatio_Plot(df_nomDigGain_AnaGain, intTime, document, pltPath, showPlt)

        document.add_heading(i + ' Image Statistics vs. Nominal Integration Time & Analog Gain vs. Digital Gain',
                             level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_TotalNoise_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_FPN_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_Temporal_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowStdDev_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowFPN_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTempNoise_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColStdDev_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColFPN_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTempNoise_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_Flicker_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelTotalNoise_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelTemporalNoise_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelFPN_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTemporalNoiseRatio_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColumnTemporalNoiseRatio_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowFPNRatio_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColumnFPNRatio_Plot(df_nomCint_AnaGain, digGain, document, pltPath, showPlt)

        document.add_heading(i + ' Image Statistics vs. Nominal Integration Time & Digital Gain vs. Analog Gain',
                             level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_TotalNoise_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_FPN_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_Temporal_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowStdDev_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowFPN_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTempNoise_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColStdDev_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColFPN_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTempNoise_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_Flicker_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelTotalNoise_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelTemporalNoise_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelFPN_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTemporalNoiseRatio_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColumnTemporalNoiseRatio_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowFPNRatio_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColumnFPNRatio_Plot(df_nomCint_DigGain, anaGain, document, pltPath, showPlt)

        document.add_heading(i + ' Image Statistics vs. Integration Time ', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_TotalNoise_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_FPN_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_Temporal_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowStdDev_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowFPN_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTempNoise_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColStdDev_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColFPN_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTempNoise_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_Flicker_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelTotalNoise_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelTemporalNoise_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelFPN_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTemporalNoiseRatio_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColumnTemporalNoiseRatio_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowFPNRatio_Plot(df_img, intTime, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColumnFPNRatio_Plot(df_img, intTime, document, pltPath, showPlt)

        document.add_heading(i + ' Image Statistics vs. Digital & Analog Gain vs. Integration time', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_TotalNoise_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_FPN_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_Temporal_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowStdDev_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowFPN_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTempNoise_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColStdDev_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColFPN_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTempNoise_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_Flicker_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelTotalNoise_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelTemporalNoise_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelFPN_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTemporalNoiseRatio_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColumnTemporalNoiseRatio_Plot(df_img, [intTime, digGain, anaGain], document, pltPath,
                                                          showPlt)
        VRG_Stats_Arr.Arr_RowFPNRatio_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColumnFPNRatio_Plot(df_img, [intTime, digGain, anaGain], document, pltPath, showPlt)

        document.add_heading(i + ' Image Statistics vs. Die', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_TotalNoise_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_FPN_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_Temporal_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowStdDev_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowFPN_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTempNoise_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColStdDev_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColFPN_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTempNoise_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_Flicker_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelTotalNoise_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelTemporalNoise_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelFPN_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTemporalNoiseRatio_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColumnTemporalNoiseRatio_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowFPNRatio_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColumnFPNRatio_Plot(df_img, die, document, pltPath, showPlt)

        # for tst in TEST:  # Test
        #     df_test = VRG_Data_Frame.newdataframe(df_img, intTime, tst)
        #     for tmp in TEMP:  # Temperature
        #         df_tmp = VRG_Data_Frame.newdataframe(df_test, temp, tmp)
        #         if tmp == nomTemp:
        #             document.add_heading(
        #                 i + ' Image Capture (' + intTime + ' = ' + str(tst) + ') at Temperature = ' + str(tmp), level=2)
        #             VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 40, document,
        #                                                        showPlt)  # 128 dig gain, 1.11x ana gain

        document.add_heading(i + ' ASIL Image Data', level=2)
        VRG_Safety_Data.SM_Analog_Test_Rows_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Safety_Data.SM_Row_Rom_Address_Columns_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Safety_Data.SM_Row_Rom_SIC_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Safety_Data.SM_Digital_Test_Rows_Plot(df_img, 'Power', document, pltPath, showPlt)

        VRG_Image_Utils.Image_Crop(df_img, 2, document, 34, 0, 64, 20, showPlt)  # RRC start
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 1504, 0, 1536, 20, showPlt)  # RRC mid
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 3100, 0, 3130, 20, showPlt)  # RRC end
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 4, 32, 12, 80, showPlt)  # DTR start
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 4, 2000, 12, 2048, showPlt)  # DTR mid
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 4, 4088, 12, 4136, showPlt)  # DTR end
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 3140, 32, 3160, 80, showPlt)  # ATR start
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 3140, 2000, 3160, 2048, showPlt)  # ATR mid
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 3140, 4088, 3160, 4136, showPlt)  # ATR end

        document.add_heading(i + 'Power & Current vs. Voltage Level', level=2)
        VRG_Power_Data.Power_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)

def DV_3_04_PIXOUT_AND_ROW_DRIVER_ANALYSIS(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

    # VRG_General_Data Plots
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i + ' RRC LDO Columns vs. Temp vs. Power ', level=2)
        VRG_Safety_Data.SM_Row_Rom_SIC_Expanded_Plot(df_img, [temp, 'Power'], document, pltPath, showPlt)

        document.add_heading(i + ' RRC LDO Columns vs. Die vs. Power ', level=2)
        VRG_Safety_Data.SM_Row_Rom_SIC_Expanded_Plot(df_img, [die, 'Power'], document, pltPath, showPlt)

        document.add_heading(i + ' RRC LDO Columns vs. Light vs. Power ', level=2)
        VRG_Safety_Data.SM_Row_Rom_SIC_Expanded_Plot(df_img, ['Light', 'Power'], document, pltPath, showPlt)

def DV_3_04_PIXOUT_ANALYSIS(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

    # VRG_General_Data Plots
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i + ' RRC LDO Columns vs. Temp vs. Power ', level=2)
        VRG_Safety_Data.SM_Row_Rom_SIC_Expanded_Plot(df_img, [temp, 'Power'], document, pltPath, showPlt)

        document.add_heading(i + ' RRC LDO Columns vs. Die vs. Power ', level=2)
        VRG_Safety_Data.SM_Row_Rom_SIC_Expanded_Plot(df_img, [die, 'Power'], document, pltPath, showPlt)

        document.add_heading(i + ' RRC LDO Columns vs. Light vs. Power ', level=2)
        VRG_Safety_Data.SM_Row_Rom_SIC_Expanded_Plot(df_img, ['Light', 'Power'], document, pltPath, showPlt)

def DV_3_05_OFFSET_DAC(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_3_06_DATA_PEDESTAL(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

    intTime = 'RegWr00_COARSE_INTEGRATION_TIME_'
    nomIntTime = 934
    digGain = 'RegWr02_GLOBAL_GAIN'
    nomDigGain = 128
    dataPed = 'RegWr01_DATA_PEDESTAL_'
    nomAnaGain = 168

    # VRG_General_Data Plots
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[intTime].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)
        df_nomCint = VRG_Data_Frame.newdataframe(df_img, intTime, nomIntTime)
        df_nomCint_DigGain = VRG_Data_Frame.newdataframe(df_nomCint, digGain, nomDigGain)
        df_nomDigGain = VRG_Data_Frame.newdataframe(df_img, digGain, nomDigGain)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Light Level Values', level=2)
        VRG_General_Data.LightLevel_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Data Pedestal Reg Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, dataPed, showPlt)

        document.add_heading(i + ' Key Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, intTime, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, digGain, showPlt)

        document.add_heading(i + ' Image Mean & StdDev vs. Data Pedestal', level=2)
        VRG_Stats_Frame.Reg_vs_Img_Mean_Plot(df_nomDigGain, None, document, pltPath, dataPed, showPlt)  # looks good
        VRG_Stats_Frame.Reg_vs_Img_Mean_Plot(df_nomDigGain, intTime, document, pltPath, dataPed, showPlt)  # looks good
        document.add_heading(i + ' Data Pedestal Error vs. Color Planes', level=2)
        VRG_Calculate.Calc_DataPedestal_Error_Plot(df_nomDigGain, None, document, pltPath, dataPed, showPlt)

        for tst in TEST:  # Test
            df_test = VRG_Data_Frame.newdataframe(df_nomDigGain, intTime, tst)
            document.add_heading(i + ' with Integration Time = ' + str(tst), level=2)
            document.add_heading(i + ' Image Stats vs. Data Pedestal vs. Integration Time = ' + str(tst), level=2)
            VRG_Stats_Arr.Arr_Mean_Plot(df_test, dataPed, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_StdDev_Plot(df_test, dataPed, document, pltPath, showPlt)
            document.add_heading(i + ' Image Stats vs. Data Pedestal vs. Integration Time = ' + str(tst), level=2)
            VRG_Stats_Frame.Reg_vs_Img_Mean_Plot(df_test, temp, document, pltPath, dataPed, showPlt)
            VRG_Stats_Frame.Reg_vs_Img_StdDev_Plot(df_test, temp, document, pltPath, dataPed, showPlt)
            document.add_heading(i + ' Data Pedestal Error vs. Color Planes vs. Integration Time = ' + str(tst),
                                 level=2)
            VRG_Calculate.Calc_DataPedestal_Error_Plot(df_test, None, document, pltPath, dataPed, showPlt)

            for tmp in TEMP:  # Temperature
                df_tmp = VRG_Data_Frame.newdataframe(df_test, temp, tmp)
                document.add_heading(
                    i + ' Image Stats vs. Data Pedestal vs. Integration Time vs. Nominal DigGain at Temp = ' + str(tmp),
                    level=2)
                VRG_Stats_Arr.Arr_Mean_Plot(df_tmp, dataPed, document, pltPath, showPlt)
                VRG_Stats_Arr.Arr_StdDev_Plot(df_tmp, dataPed, document, pltPath, showPlt)
                VRG_Stats_Frame.Reg_vs_Img_Mean_Plot(df_tmp, None, document, pltPath, dataPed, showPlt)
                VRG_Stats_Frame.Reg_vs_Img_StdDev_Plot(df_tmp, None, document, pltPath, dataPed, showPlt)
                document.add_heading(i + ' Data Pedestal Error vs. Color Planes at Temp = ' + str(tmp), level=2)
                VRG_Calculate.Calc_DataPedestal_Error_Plot(df_tmp, None, document, pltPath, dataPed, showPlt)

        document.add_heading(i + 'Power & Current vs. Voltage Level', level=2)
        VRG_Power_Data.Power_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)

def DV_3_07_ADC(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

    # VRG_General_Data Plots
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameGrabber_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    document.add_heading('ADC Column # Tested')
    VRG_General_Data.AdcName_Plot(df, None, document, pltPath, showPlt)
    document.add_heading('ADC Test Ramp Data')
    VRG_General_Data.VoltRampStart_Plot(df, None, document, pltPath, showPlt)
    VRG_General_Data.VoltRampStop_Plot(df, None, document, pltPath, showPlt)
    VRG_General_Data.VoltRampStep_Plot(df, None, document, pltPath, showPlt)
    VRG_General_Data.VoltRampLinesPerStep_Plot(df, None, document, pltPath, showPlt)

    document.add_heading('ADC Missing Code Count')
    VRG_General_Data.Data_vs_Step_Plot(df, 'ImgMode', document, pltPath, 'MissingCodeCount', showPlt)
    document.add_heading('Max Differential Non-Linearity')
    VRG_General_Data.Data_vs_Step_Plot(df, 'ImgMode', document, pltPath, 'MaxDNL', showPlt)
    document.add_heading('Max Integral Non-Linearity')
    VRG_General_Data.Data_vs_Step_Plot(df, 'ImgMode', document, pltPath, 'MaxINL', showPlt)
    document.add_heading('Mid-level Column FPN')
    VRG_General_Data.Data_vs_Step_Plot(df, 'ImgMode', document, pltPath, 'MidLevelColumnFPN', showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i + ' ADC Test Data')
        document.add_heading(i + ' ADC Missing Code Count', level=2)
        VRG_General_Data.Data_vs_Step_Plot(df_img, None, document, pltPath, 'MissingCodeCount', showPlt)
        document.add_heading(i + ' Max Differential Non-Linearity', level=2)
        VRG_General_Data.Data_vs_Step_Plot(df_img, None, document, pltPath, 'MaxDNL', showPlt)
        document.add_heading(i + ' Max Integral Non-Linearity', level=2)
        VRG_General_Data.Data_vs_Step_Plot(df_img, None, document, pltPath, 'MaxINL', showPlt)
        document.add_heading(i + ' Mid-level Column FPN', level=2)
        VRG_General_Data.Data_vs_Step_Plot(df_img, None, document, pltPath, 'MidLevelColumnFPN', showPlt)

    keyword = 'AdcResp'
    for imgName in os.listdir(imgPath):
        if keyword in imgName:
            document.add_heading('ADC Response Plot', level=1)
            VRG_Image_Analysis.Add_External_Image(imgPath, imgName, document, showPlt)

    keyword = 'CuHist'
    for imgName in os.listdir(imgPath):
        if keyword in imgName:
            document.add_heading('Cumulative Histogram Plot', level=1)
            VRG_Image_Analysis.Add_External_Image(imgPath, imgName, document, showPlt)

    keyword = 'Dnl'
    for imgName in os.listdir(imgPath):
        if keyword in imgName:
            document.add_heading('Differential Non-Linearity (DNL)', level=1)
            VRG_Image_Analysis.Add_External_Image(imgPath, imgName, document, showPlt)

    keyword = 'Inl'
    for imgName in os.listdir(imgPath):
        if keyword in imgName:
            document.add_heading('Integral Non-Linearity (INL)', level=1)
            VRG_Image_Analysis.Add_External_Image(imgPath, imgName, document, showPlt)

def DV_3_07_ADC_E1(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

    # VRG_General_Data Plots
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameGrabber_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    document.add_heading('ADC Column # Tested')
    VRG_General_Data.AdcName_Plot(df, None, document, pltPath, showPlt)
    document.add_heading('ADC Test Ramp Data')
    VRG_General_Data.VoltRampStart_Plot(df, None, document, pltPath, showPlt)
    VRG_General_Data.VoltRampStop_Plot(df, None, document, pltPath, showPlt)
    VRG_General_Data.VoltRampStep_Plot(df, None, document, pltPath, showPlt)
    VRG_General_Data.VoltRampLinesPerStep_Plot(df, None, document, pltPath, showPlt)

    document.add_heading('ADC Missing Code Count')
    VRG_General_Data.Data_vs_Step_Plot(df, 'ImgMode', document, pltPath, 'MissingCodeCount', showPlt)
    document.add_heading('Max Differential Non-Linearity')
    VRG_General_Data.Data_vs_Step_Plot(df, 'ImgMode', document, pltPath, 'MaxDNL', showPlt)
    document.add_heading('Max Integral Non-Linearity')
    VRG_General_Data.Data_vs_Step_Plot(df, 'ImgMode', document, pltPath, 'MaxINL', showPlt)
    document.add_heading('Mid-level Column FPN')
    VRG_General_Data.Data_vs_Step_Plot(df, 'ImgMode', document, pltPath, 'MidLevelColumnFPN', showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i + ' ADC Test Data')
        document.add_heading(i + ' ADC Missing Code Count', level=2)
        VRG_General_Data.Data_vs_Step_Plot(df_img, None, document, pltPath, 'MissingCodeCount', showPlt)
        document.add_heading(i + ' Max Differential Non-Linearity', level=2)
        VRG_General_Data.Data_vs_Step_Plot(df_img, None, document, pltPath, 'MaxDNL', showPlt)
        document.add_heading(i + ' Max Integral Non-Linearity', level=2)
        VRG_General_Data.Data_vs_Step_Plot(df_img, None, document, pltPath, 'MaxINL', showPlt)
        document.add_heading(i + ' Mid-level Column FPN', level=2)
        VRG_General_Data.Data_vs_Step_Plot(df_img, None, document, pltPath, 'MidLevelColumnFPN', showPlt)

    keyword = 'AdcResp'
    for imgName in os.listdir(imgPath):
        if keyword in imgName:
            document.add_heading('ADC Response Plot', level=1)
            VRG_Image_Analysis.Add_External_Image(imgPath, imgName, document, showPlt)

    keyword = 'CuHist'
    for imgName in os.listdir(imgPath):
        if keyword in imgName:
            document.add_heading('Cumulative Histogram Plot', level=1)
            VRG_Image_Analysis.Add_External_Image(imgPath, imgName, document, showPlt)

    keyword = 'Dnl'
    for imgName in os.listdir(imgPath):
        if keyword in imgName:
            document.add_heading('Differential Non-Linearity (DNL)', level=1)
            VRG_Image_Analysis.Add_External_Image(imgPath, imgName, document, showPlt)

    keyword = 'Inl'
    for imgName in os.listdir(imgPath):
        if keyword in imgName:
            document.add_heading('Integral Non-Linearity (INL)', level=1)
            VRG_Image_Analysis.Add_External_Image(imgPath, imgName, document, showPlt)

def DV_3_07_ADC_E2(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

    # VRG_General_Data Plots
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameGrabber_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    document.add_heading('ADC Column # Tested')
    VRG_General_Data.AdcName_Plot(df, None, document, pltPath, showPlt)
    document.add_heading('ADC Test Ramp Data')
    VRG_General_Data.VoltRampStart_Plot(df, None, document, pltPath, showPlt)
    VRG_General_Data.VoltRampStop_Plot(df, None, document, pltPath, showPlt)
    VRG_General_Data.VoltRampStep_Plot(df, None, document, pltPath, showPlt)
    VRG_General_Data.VoltRampLinesPerStep_Plot(df, None, document, pltPath, showPlt)

    document.add_heading('ADC Missing Code Count')
    VRG_General_Data.Data_vs_Step_Plot(df, 'ImgMode', document, pltPath, 'MissingCodeCount', showPlt)
    document.add_heading('Max Differential Non-Linearity')
    VRG_General_Data.Data_vs_Step_Plot(df, 'ImgMode', document, pltPath, 'MaxDNL', showPlt)
    document.add_heading('Max Integral Non-Linearity')
    VRG_General_Data.Data_vs_Step_Plot(df, 'ImgMode', document, pltPath, 'MaxINL', showPlt)
    document.add_heading('Mid-level Column FPN')
    VRG_General_Data.Data_vs_Step_Plot(df, 'ImgMode', document, pltPath, 'MidLevelColumnFPN', showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i + ' ADC Test Data')
        document.add_heading(i + ' ADC Missing Code Count', level=2)
        VRG_General_Data.Data_vs_Step_Plot(df_img, None, document, pltPath, 'MissingCodeCount', showPlt)
        document.add_heading(i + ' Max Differential Non-Linearity', level=2)
        VRG_General_Data.Data_vs_Step_Plot(df_img, None, document, pltPath, 'MaxDNL', showPlt)
        document.add_heading(i + ' Max Integral Non-Linearity', level=2)
        VRG_General_Data.Data_vs_Step_Plot(df_img, None, document, pltPath, 'MaxINL', showPlt)
        document.add_heading(i + ' Mid-level Column FPN', level=2)
        VRG_General_Data.Data_vs_Step_Plot(df_img, None, document, pltPath, 'MidLevelColumnFPN', showPlt)

    keyword = 'AdcResp'
    for imgName in os.listdir(imgPath):
        if keyword in imgName:
            document.add_heading('ADC Response Plot', level=1)
            VRG_Image_Analysis.Add_External_Image(imgPath, imgName, document, showPlt)

    keyword = 'CuHist'
    for imgName in os.listdir(imgPath):
        if keyword in imgName:
            document.add_heading('Cumulative Histogram Plot', level=1)
            VRG_Image_Analysis.Add_External_Image(imgPath, imgName, document, showPlt)

    keyword = 'Dnl'
    for imgName in os.listdir(imgPath):
        if keyword in imgName:
            document.add_heading('Differential Non-Linearity (DNL)', level=1)
            VRG_Image_Analysis.Add_External_Image(imgPath, imgName, document, showPlt)

    keyword = 'Inl'
    for imgName in os.listdir(imgPath):
        if keyword in imgName:
            document.add_heading('Integral Non-Linearity (INL)', level=1)
            VRG_Image_Analysis.Add_External_Image(imgPath, imgName, document, showPlt)

def DV_3_07_ADC_E3(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

    # VRG_General_Data Plots
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameGrabber_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    document.add_heading('ADC Column # Tested')
    VRG_General_Data.AdcName_Plot(df, None, document, pltPath, showPlt)
    document.add_heading('ADC Test Ramp Data')
    VRG_General_Data.VoltRampStart_Plot(df, None, document, pltPath, showPlt)
    VRG_General_Data.VoltRampStop_Plot(df, None, document, pltPath, showPlt)
    VRG_General_Data.VoltRampStep_Plot(df, None, document, pltPath, showPlt)
    VRG_General_Data.VoltRampLinesPerStep_Plot(df, None, document, pltPath, showPlt)

    document.add_heading('ADC Missing Code Count')
    VRG_General_Data.Data_vs_Step_Plot(df, 'ImgMode', document, pltPath, 'MissingCodeCount', showPlt)
    document.add_heading('Max Differential Non-Linearity')
    VRG_General_Data.Data_vs_Step_Plot(df, 'ImgMode', document, pltPath, 'MaxDNL', showPlt)
    document.add_heading('Max Integral Non-Linearity')
    VRG_General_Data.Data_vs_Step_Plot(df, 'ImgMode', document, pltPath, 'MaxINL', showPlt)
    document.add_heading('Mid-level Column FPN')
    VRG_General_Data.Data_vs_Step_Plot(df, 'ImgMode', document, pltPath, 'MidLevelColumnFPN', showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i + ' ADC Test Data')
        document.add_heading(i + ' ADC Missing Code Count', level=2)
        VRG_General_Data.Data_vs_Step_Plot(df_img, None, document, pltPath, 'MissingCodeCount', showPlt)
        document.add_heading(i + ' Max Differential Non-Linearity', level=2)
        VRG_General_Data.Data_vs_Step_Plot(df_img, None, document, pltPath, 'MaxDNL', showPlt)
        document.add_heading(i + ' Max Integral Non-Linearity', level=2)
        VRG_General_Data.Data_vs_Step_Plot(df_img, None, document, pltPath, 'MaxINL', showPlt)
        document.add_heading(i + ' Mid-level Column FPN', level=2)
        VRG_General_Data.Data_vs_Step_Plot(df_img, None, document, pltPath, 'MidLevelColumnFPN', showPlt)

    keyword = 'AdcResp'
    for imgName in os.listdir(imgPath):
        if keyword in imgName:
            document.add_heading('ADC Response Plot', level=1)
            VRG_Image_Analysis.Add_External_Image(imgPath, imgName, document, showPlt)

    keyword = 'CuHist'
    for imgName in os.listdir(imgPath):
        if keyword in imgName:
            document.add_heading('Cumulative Histogram Plot', level=1)
            VRG_Image_Analysis.Add_External_Image(imgPath, imgName, document, showPlt)

    keyword = 'Dnl'
    for imgName in os.listdir(imgPath):
        if keyword in imgName:
            document.add_heading('Differential Non-Linearity (DNL)', level=1)
            VRG_Image_Analysis.Add_External_Image(imgPath, imgName, document, showPlt)

    keyword = 'Inl'
    for imgName in os.listdir(imgPath):
        if keyword in imgName:
            document.add_heading('Integral Non-Linearity (INL)', level=1)
            VRG_Image_Analysis.Add_External_Image(imgPath, imgName, document, showPlt)

def DV_3_07_ADC_T2(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

    # VRG_General_Data Plots
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameGrabber_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    document.add_heading('ADC Column # Tested')
    VRG_General_Data.AdcName_Plot(df, None, document, pltPath, showPlt)
    document.add_heading('ADC Test Ramp Data')
    VRG_General_Data.VoltRampStart_Plot(df, None, document, pltPath, showPlt)
    VRG_General_Data.VoltRampStop_Plot(df, None, document, pltPath, showPlt)
    VRG_General_Data.VoltRampStep_Plot(df, None, document, pltPath, showPlt)
    VRG_General_Data.VoltRampLinesPerStep_Plot(df, None, document, pltPath, showPlt)

    document.add_heading('ADC Missing Code Count')
    VRG_General_Data.Data_vs_Step_Plot(df, 'ImgMode', document, pltPath, 'MissingCodeCount', showPlt)
    document.add_heading('Max Differential Non-Linearity')
    VRG_General_Data.Data_vs_Step_Plot(df, 'ImgMode', document, pltPath, 'MaxDNL', showPlt)
    document.add_heading('Max Integral Non-Linearity')
    VRG_General_Data.Data_vs_Step_Plot(df, 'ImgMode', document, pltPath, 'MaxINL', showPlt)
    document.add_heading('Mid-level Column FPN')
    VRG_General_Data.Data_vs_Step_Plot(df, 'ImgMode', document, pltPath, 'MidLevelColumnFPN', showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i + ' ADC Test Data')
        document.add_heading(i + ' ADC Missing Code Count', level=2)
        VRG_General_Data.Data_vs_Step_Plot(df_img, None, document, pltPath, 'MissingCodeCount', showPlt)
        document.add_heading(i + ' Max Differential Non-Linearity', level=2)
        VRG_General_Data.Data_vs_Step_Plot(df_img, None, document, pltPath, 'MaxDNL', showPlt)
        document.add_heading(i + ' Max Integral Non-Linearity', level=2)
        VRG_General_Data.Data_vs_Step_Plot(df_img, None, document, pltPath, 'MaxINL', showPlt)
        document.add_heading(i + ' Mid-level Column FPN', level=2)
        VRG_General_Data.Data_vs_Step_Plot(df_img, None, document, pltPath, 'MidLevelColumnFPN', showPlt)

    keyword = 'AdcResp'
    for imgName in os.listdir(imgPath):
        if keyword in imgName:
            document.add_heading('ADC Response Plot', level=1)
            VRG_Image_Analysis.Add_External_Image(imgPath, imgName, document, showPlt)

    keyword = 'CuHist'
    for imgName in os.listdir(imgPath):
        if keyword in imgName:
            document.add_heading('Cumulative Histogram Plot', level=1)
            VRG_Image_Analysis.Add_External_Image(imgPath, imgName, document, showPlt)

    keyword = 'Dnl'
    for imgName in os.listdir(imgPath):
        if keyword in imgName:
            document.add_heading('Differential Non-Linearity (DNL)', level=1)
            VRG_Image_Analysis.Add_External_Image(imgPath, imgName, document, showPlt)

    keyword = 'Inl'
    for imgName in os.listdir(imgPath):
        if keyword in imgName:
            document.add_heading('Integral Non-Linearity (INL)', level=1)
            VRG_Image_Analysis.Add_External_Image(imgPath, imgName, document, showPlt)

def DV_3_08_DIGITAL_GAIN(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    digGain = 'RegWr01_GLOBAL_GAIN'
    nomDigGain = 128
    digDither = 'RegWr02_DIGITAL_CTRL'
    ditherEnable = 4360
    ditherDisable = 4392
    dataPed = 168

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)
        df_ditherDisable = VRG_Data_Frame.newdataframe(df_img, digDither, ditherDisable)  # dither disable
        df_ditherEnable = VRG_Data_Frame.newdataframe(df_img, digDither, ditherEnable)  # dither disable

        document.add_heading(i, level=1)
        document.add_heading(i + ' Digital Gain Reg Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, digGain, showPlt)
        document.add_heading(i + ' Digital Test (Dither) Reg Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, digDither, showPlt)

        document.add_heading(i + ' Calculated Digital Gain vs. Dither Enable', level=2)
        VRG_Calculate.Calc_DigitalGain_Plot(df_ditherDisable, None, document, pltPath, digGain, nomDigGain, dataPed,
                                            showPlt)  # pass gain reg and 1x val
        document.add_heading(i + ' Calculated Digital Gain vs. Dither Disable', level=2)
        VRG_Calculate.Calc_DigitalGain_Plot(df_ditherEnable, None, document, pltPath, digGain, nomDigGain, dataPed,
                                            showPlt)  # pass gain reg and 1x val

        document.add_heading(i + ' Digital Gain Mean & StdDev, Dither Disabled', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_ditherDisable, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_ditherDisable, digGain, document, pltPath, showPlt)

        document.add_heading(i + ' Digital Gain Mean & StdDev, Dither Enabled', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_ditherEnable, digGain, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_ditherEnable, digGain, document, pltPath, showPlt)

        document.add_heading(i + ' Mean & StdDev vs Global_Gain vs. Dither', level=2)
        VRG_Stats_Frame.Reg_vs_Img_Mean_Plot(df_img, digDither, document, pltPath, digGain, showPlt)
        VRG_Stats_Frame.Reg_vs_Img_StdDev_Plot(df_img, digDither, document, pltPath, digGain, showPlt)

        document.add_heading(i + ' Row StdDev & TotalNoise vs. Global Gain vs. Digital Dither', level=2)
        VRG_Stats_Frame.Reg_vs_Img_RowStdDev_Plot(df_img, digDither, document, pltPath, digGain, showPlt)
        VRG_Stats_Frame.Reg_vs_Img_RowTotalNoise_Plot(df_img, digDither, document, pltPath, digGain, showPlt)

        document.add_heading(i + ' Col StdDev & TotalNoise vs. Global Gain vs. Digital Dither', level=2)
        VRG_Stats_Frame.Reg_vs_Img_ColStdDev_Plot(df_img, digDither, document, pltPath, digGain, showPlt)
        VRG_Stats_Frame.Reg_vs_Img_ColTotalNoise_Plot(df_img, digDither, document, pltPath, digGain, showPlt)

        # for tmp in TEMP:  # Temperature
        #     df_tmp = VRG_Data_Frame.newdataframe(df_ditherDisable, temp, tmp)
        #     if tmp == nomTemp:
        #         document.add_heading(i + ' Image Capture (Temp = ' + str(tmp) + ')', level=2)
        #         VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 2, document, showPlt)  # 0 dig gain
        #         # VRG_ImageAnalysis.Add_Image_Analysis_Info(df_tmp, 4, document, showPlt)  # 1 dig gain
        #         # VRG_ImageAnalysis.Add_Image_Analysis_Info(df_tmp, 6, document, showPlt)  # 2 dig gain
        #         # VRG_ImageAnalysis.Add_Image_Analysis_Info(df_tmp, 8, document, showPlt)  # 4 dig gain
        #         # VRG_ImageAnalysis.Add_Image_Analysis_Info(df_tmp, 10, document, showPlt)  # 8 dig gain
        #         # VRG_ImageAnalysis.Add_Image_Analysis_Info(df_tmp, 12, document, showPlt)  # 16 dig gain
        #         # VRG_ImageAnalysis.Add_Image_Analysis_Info(df_tmp, 14, document, showPlt)  # 32 dig gain
        #         # VRG_ImageAnalysis.Add_Image_Analysis_Info(df_tmp, 16, document, showPlt)  # 64 dig gain
        #         VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 18, document, showPlt)  # 128 dig gain
        #         # VRG_ImageAnalysis.Add_Image_Analysis_Info(df_tmp, 20, document, showPlt)  # 256 dig gain
        #         VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 22, document, showPlt)  # 512 dig gain
        #         # VRG_ImageAnalysis.Add_Image_Analysis_Info(df_tmp, 24, document, showPlt)  # 768 dig gain
        #         VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 26, document, showPlt)  # 1024 dig gain
        #         # VRG_ImageAnalysis.Add_Image_Analysis_Info(df_tmp, 28, document, showPlt)  # 1280 dig gain
        #         # VRG_ImageAnalysis.Add_Image_Analysis_Info(df_tmp, 30, document, showPlt)  # 1536 dig gain
        #         # VRG_ImageAnalysis.Add_Image_Analysis_Info(df_tmp, 32, document, showPlt)  # 1792 dig gain
        #         VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 34, document, showPlt)  # 2047 dig gain

        document.add_heading(i + ' Power & Current vs. Voltage Level', level=2)
        VRG_Power_Data.Power_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)

def DV_3_08_DIGITAL_GAIN_PRE_HDR(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_3_08_DIGITAL_GAIN_TPG_PRE_HDR(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_3_08_DIGITAL_GAIN_POST_HDR(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_3_08_DIGITAL_GAIN_TPG_POST_HDR(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_3_09_ANALOG_GAIN(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    anaGain = 'DVM_3_09_Analog_Gain'
    nomAnaGain = 1
    dataPedestalVal = 168
    anaGainReg1 = 'RegVal_OCL_T1_GAIN_'
    anaGainReg2 = 'RegVal_OCL_T1_GAIN2'
    expBypass = 'RegWr01_LFM2_T1_CTRL'
    E1_E2 = 32929
    E1_byp = 33445
    minLight = 500
    maxLight = 20000

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)
        df_img_minLight = VRG_Data_Frame.newdataframe(df_img, 'Light', minLight)
        df_img_maxLight = VRG_Data_Frame.newdataframe(df_img, 'Light', maxLight)
        df_E1_E2 = VRG_Data_Frame.newdataframe(df_img, expBypass, E1_E2)
        df_E1_byp = VRG_Data_Frame.newdataframe(df_img, expBypass, E1_byp)
        df_E1_E2_minLight = VRG_Data_Frame.newdataframe(df_img_minLight, expBypass, E1_E2)
        df_E1_E2_maxLight = VRG_Data_Frame.newdataframe(df_img_maxLight, expBypass, E1_E2)
        df_E1_byp_minLight = VRG_Data_Frame.newdataframe(df_img_minLight, expBypass, E1_byp)
        df_E1_byp_maxLight = VRG_Data_Frame.newdataframe(df_img_maxLight, expBypass, E1_byp)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Analog Gain Reg Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, anaGain, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, anaGainReg1, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, anaGainReg2, showPlt)

        document.add_heading(i + ' Exposure Bypass Reg Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, expBypass, showPlt)

        document.add_heading(i + ' Calculated Analog Gain @ Low Light', level=2)
        VRG_Calculate.Calc_AnalogGain_Plot(df_img_minLight, None, document, pltPath, anaGain, nomAnaGain,
                                           dataPedestalVal, showPlt)
        document.add_heading(i + ' Calculated Analog Gain % Error @ Low Light', level=2)
        VRG_Calculate.Calc_AnalogGain_Error_Plot(df_img_minLight, None, document, pltPath, anaGain, nomAnaGain,
                                                 dataPedestalVal, showPlt)
        document.add_heading(i + ' Calculated Analog Gain @ Mid Light', level=2)
        VRG_Calculate.Calc_AnalogGain_Plot(df_img_maxLight, None, document, pltPath, anaGain, nomAnaGain,
                                           dataPedestalVal, showPlt)
        document.add_heading(i + ' Calculated Analog Gain % Error @ Mid Light', level=2)
        VRG_Calculate.Calc_AnalogGain_Error_Plot(df_img_maxLight, None, document, pltPath, anaGain, nomAnaGain,
                                                 dataPedestalVal, showPlt)

        document.add_heading(i + ' Img Means & StdDev vs. Gain Registers @ Low Light', level=2)
        VRG_Stats_Frame.Reg_vs_Reg_vs_Img_Mean_Plot(df_img_minLight, None, document, pltPath, anaGainReg1, anaGainReg2,
                                                    showPlt)
        VRG_Stats_Frame.Reg_vs_Reg_vs_Img_StdDev_Plot(df_img_minLight, None, document, pltPath, anaGainReg1,
                                                      anaGainReg2, showPlt)
        document.add_heading(i + ' Img Means & StdDev vs. Gain Registers @ Mid Light', level=2)
        VRG_Stats_Frame.Reg_vs_Reg_vs_Img_Mean_Plot(df_img_maxLight, None, document, pltPath, anaGainReg1, anaGainReg2,
                                                    showPlt)
        VRG_Stats_Frame.Reg_vs_Reg_vs_Img_StdDev_Plot(df_img_maxLight, None, document, pltPath, anaGainReg1,
                                                      anaGainReg2, showPlt)

        document.add_heading(i + ' Img Means & StdDev vs. Analog Gain @ Low Light', level=2)
        VRG_Stats_Frame.Reg_vs_Img_Mean_Plot(df_img_minLight, None, document, pltPath, anaGain, showPlt)
        VRG_Stats_Frame.Reg_vs_Img_StdDev_Plot(df_img_minLight, None, document, pltPath, anaGain, showPlt)
        document.add_heading(i + ' Img Means & StdDev vs. Analog Gain @ Mid Light', level=2)
        VRG_Stats_Frame.Reg_vs_Img_Mean_Plot(df_img_maxLight, None, document, pltPath, anaGain, showPlt)
        VRG_Stats_Frame.Reg_vs_Img_StdDev_Plot(df_img_maxLight, None, document, pltPath, anaGain, showPlt)

        document.add_heading(i + ' Img Means & StdDev vs. Analog Gain @ Low Light vs. E1 + E2', level=2)
        VRG_Stats_Frame.Reg_vs_Img_Mean_Plot(df_E1_E2_minLight, None, document, pltPath, anaGain, showPlt)
        VRG_Stats_Frame.Reg_vs_Img_StdDev_Plot(df_E1_E2_minLight, None, document, pltPath, anaGain, showPlt)
        document.add_heading(i + ' Img Means & StdDev vs. Analog Gain @ Mid Light vs. E1 + E2', level=2)
        VRG_Stats_Frame.Reg_vs_Img_Mean_Plot(df_E1_E2_maxLight, None, document, pltPath, anaGain, showPlt)
        VRG_Stats_Frame.Reg_vs_Img_StdDev_Plot(df_E1_E2_maxLight, None, document, pltPath, anaGain, showPlt)

        document.add_heading(i + ' Img Means & StdDev vs. Analog Gain @ Low Light vs. E1 Bypass', level=2)
        VRG_Stats_Frame.Reg_vs_Img_Mean_Plot(df_E1_byp_minLight, None, document, pltPath, anaGain, showPlt)
        VRG_Stats_Frame.Reg_vs_Img_StdDev_Plot(df_E1_byp_minLight, None, document, pltPath, anaGain, showPlt)
        document.add_heading(i + ' Img Means & StdDev vs. Analog Gain @ Mid Light vs. E1 Bypass', level=2)
        VRG_Stats_Frame.Reg_vs_Img_Mean_Plot(df_E1_byp_maxLight, None, document, pltPath, anaGain, showPlt)
        VRG_Stats_Frame.Reg_vs_Img_StdDev_Plot(df_E1_byp_maxLight, None, document, pltPath, anaGain, showPlt)

        document.add_heading(i + ' Row StdDev & TotalNoise vs. Analog Gain @ Low Light', level=2)
        VRG_Stats_Frame.Reg_vs_Img_RowStdDev_Plot(df_img_minLight, None, document, pltPath, anaGain, showPlt)
        VRG_Stats_Frame.Reg_vs_Img_RowTotalNoise_Plot(df_img_minLight, None, document, pltPath, anaGain, showPlt)
        document.add_heading(i + ' Col StdDev & TotalNoise vs. Analog Gain @ Low Light', level=2)
        VRG_Stats_Frame.Reg_vs_Img_ColStdDev_Plot(df_img_minLight, None, document, pltPath, anaGain, showPlt)
        VRG_Stats_Frame.Reg_vs_Img_ColTotalNoise_Plot(df_img_minLight, None, document, pltPath, anaGain, showPlt)
        document.add_heading(i + ' Row StdDev & TotalNoise vs. Analog Gain @ Mid Light', level=2)
        VRG_Stats_Frame.Reg_vs_Img_RowStdDev_Plot(df_img_maxLight, None, document, pltPath, anaGain, showPlt)
        VRG_Stats_Frame.Reg_vs_Img_RowTotalNoise_Plot(df_img_maxLight, None, document, pltPath, anaGain, showPlt)
        document.add_heading(i + ' Col StdDev & TotalNoise vs. Analog Gain @ Mid Light', level=2)
        VRG_Stats_Frame.Reg_vs_Img_ColStdDev_Plot(df_img_maxLight, None, document, pltPath, anaGain, showPlt)
        VRG_Stats_Frame.Reg_vs_Img_ColTotalNoise_Plot(df_img_maxLight, None, document, pltPath, anaGain, showPlt)

        # for tmp in TEMP:  # Temperature
        #     df_tmp = VRG_Data_Frame.newdataframe(df_E1_byp_minLight, temp, tmp)
        #     if tmp == nomTemp:
        #         document.add_heading(i + ' Image Capture E1 Bypass at Low Lux Level at Temp = ' + str(tmp), level=2)
        #         VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 2, document, showPlt)  # 0.5x ana gain
        #         VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 20, document, showPlt)  # 1x ana gain
        #         VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 56, document, showPlt)  # 2x ana gain
        #         VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 80, document, showPlt)  # 3x ana gain
        #         VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 83, document, showPlt)  # 4x ana gain
        #         VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 95, document, showPlt)  # 8x dig gain

        document.add_heading(i + ' Power & Current vs. Voltage Level', level=2)
        VRG_Power_Data.Power_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)

def DV_3_10_BLACK_LEVEL_OPERATION(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_3_11_OFFSET_CORRECTION(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    ULcolor = '#ff0000'
    LLcolor = '#0000ff'
    cint = 'RegWr00_COARSE_INTEGRATION_TIME_'
    dataPed = 'RegWr02_DATA_PEDESTAL_'
    corrections = 'RegWr01_TEST_RAW_MODE__RAW_DATA'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[corrections].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Light Level Values', level=2)
        VRG_General_Data.LightLevel_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Key Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, cint, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, dataPed, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, corrections, showPlt)

        document.add_heading(i + ' Data Pedestal Error vs. Color Planes vs. Raw Mode', level=2)
        VRG_Calculate.Calc_DataPedestal_Error_Plot(df_img, corrections, document, pltPath, dataPed, showPlt)
        document.add_heading(i + ' Data Pedestal Error vs. Color Planes vs. Raw Mode vs. Integration Time', level=2)
        VRG_Calculate.Calc_DataPedestal_Error_Plot(df_img, [corrections, cint], document, pltPath, dataPed, showPlt)

        document.add_heading(i + ' Image Stats vs. Correction Enable/Disable', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, corrections, document, pltPath, showPlt,
                                      ax_hlines=[(dataPed, ULcolor, '--', 3, 1)])
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, corrections, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_TotalNoise_Plot(df_img, corrections, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_FPN_Plot(df_img, corrections, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_Temporal_Plot(df_img, corrections, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowStdDev_Plot(df_img, corrections, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_img, corrections, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowFPN_Plot(df_img, corrections, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTempNoise_Plot(df_img, corrections, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColStdDev_Plot(df_img, corrections, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_img, corrections, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColFPN_Plot(df_img, corrections, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTempNoise_Plot(df_img, corrections, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_Flicker_Plot(df_img, corrections, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelTotalNoise_Plot(df_img, corrections, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelTemporalNoise_Plot(df_img, corrections, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelFPN_Plot(df_img, corrections, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTemporalNoiseRatio_Plot(df_img, corrections, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColumnTemporalNoiseRatio_Plot(df_img, corrections, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowFPNRatio_Plot(df_img, corrections, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColumnFPNRatio_Plot(df_img, corrections, document, pltPath, showPlt)

        for tst in TEST:  # Test
            df_test = VRG_Data_Frame.newdataframe(df_img, corrections, tst)
            document.add_heading(i + ' Data Pedestal Error vs. Color Planes vs. Raw Mode = ' + str(tst), level=2)
            VRG_Calculate.Calc_DataPedestal_Error_Plot(df_test, [corrections, cint], document, pltPath, dataPed,
                                                       showPlt)

            # for tmp in TEMP:  # Temperature
            #     df_tmp = VRG_Data_Frame.newdataframe(df_test, temp, tmp)
            #     if tmp == nomTemp:
            #         document.add_heading(i + ' vs. Raw Mode = ' + str(tst) + ' Image Capture (Temp = ' + str(tmp) + ')',
            #                              level=2)
            #         VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 2, document, showPlt)  # low integration
            #         VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 5, document, showPlt)  # high integration

        document.add_heading(i + 'Power & Current vs. Voltage Level', level=2)
        VRG_Power_Data.Power_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)

def DV_3_12_FINE_DIGITAL_CORRECTION(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_3_13_COLUMN_FPN_CORRECTION(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_3_14_ANALOG_ROW_WISE_CORRECTION(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_3_15_DIGITAL_ROW_WISE_CORRECTION(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    ULcolor = '#ff0000'
    LLcolor = '#0000ff'
    cint = 'RegWr00_COARSE_INTEGRATION_TIME_'
    rncCorrection = 'RegWr01_DARK_CONTROL__DARK_CONTROL_ROW_NOISE_CORRECTION_EN'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[rncCorrection].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Light Level Values', level=2)
        VRG_General_Data.LightLevel_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Key Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, cint, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, rncCorrection, showPlt)

        document.add_heading(i + ' Image Stats vs. Correction Enable/Disable', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, rncCorrection, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, rncCorrection, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_TotalNoise_Plot(df_img, rncCorrection, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_FPN_Plot(df_img, rncCorrection, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_Temporal_Plot(df_img, rncCorrection, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowStdDev_Plot(df_img, rncCorrection, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_img, rncCorrection, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowFPN_Plot(df_img, rncCorrection, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTempNoise_Plot(df_img, rncCorrection, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColStdDev_Plot(df_img, rncCorrection, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_img, rncCorrection, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColFPN_Plot(df_img, rncCorrection, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTempNoise_Plot(df_img, rncCorrection, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_Flicker_Plot(df_img, rncCorrection, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelTotalNoise_Plot(df_img, rncCorrection, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelTemporalNoise_Plot(df_img, rncCorrection, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelFPN_Plot(df_img, rncCorrection, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTemporalNoiseRatio_Plot(df_img, rncCorrection, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColumnTemporalNoiseRatio_Plot(df_img, rncCorrection, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowFPNRatio_Plot(df_img, rncCorrection, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColumnFPNRatio_Plot(df_img, rncCorrection, document, pltPath, showPlt)

        for tst in TEST:
            df_test = VRG_Data_Frame.newdataframe(df_img, rncCorrection, tst)
            document.add_heading(i + ' Image Stats vs. Integration Time vs. Raw Mode = ' + str(tst), level=2)
            VRG_Stats_Arr.Arr_Mean_Plot(df_test, cint, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_StdDev_Plot(df_test, cint, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_TotalNoise_Plot(df_test, cint, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_FPN_Plot(df_test, cint, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_Temporal_Plot(df_test, cint, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_RowStdDev_Plot(df_test, cint, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_test, cint, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_RowFPN_Plot(df_test, cint, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_RowTempNoise_Plot(df_test, cint, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_ColStdDev_Plot(df_test, cint, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_test, cint, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_ColFPN_Plot(df_test, cint, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_ColTempNoise_Plot(df_test, cint, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_Flicker_Plot(df_test, cint, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_PixelTotalNoise_Plot(df_test, cint, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_PixelTemporalNoise_Plot(df_test, cint, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_PixelFPN_Plot(df_test, cint, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_RowTemporalNoiseRatio_Plot(df_test, cint, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_ColumnTemporalNoiseRatio_Plot(df_test, cint, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_RowFPNRatio_Plot(df_test, cint, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_ColumnFPNRatio_Plot(df_test, cint, document, pltPath, showPlt)

            document.add_heading(i + ' Image Stats vs. Temperature vs. Raw Mode = ' + str(tst), level=2)
            VRG_Stats_Arr.Arr_Mean_Plot(df_test, temp, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_StdDev_Plot(df_test, temp, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_TotalNoise_Plot(df_test, temp, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_FPN_Plot(df_test, temp, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_Temporal_Plot(df_test, temp, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_RowStdDev_Plot(df_test, temp, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_test, temp, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_RowFPN_Plot(df_test, temp, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_RowTempNoise_Plot(df_test, temp, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_ColStdDev_Plot(df_test, temp, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_test, temp, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_ColFPN_Plot(df_test, temp, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_ColTempNoise_Plot(df_test, temp, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_Flicker_Plot(df_test, temp, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_PixelTotalNoise_Plot(df_test, temp, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_PixelTemporalNoise_Plot(df_test, temp, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_PixelFPN_Plot(df_test, temp, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_RowTemporalNoiseRatio_Plot(df_test, temp, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_ColumnTemporalNoiseRatio_Plot(df_test, temp, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_RowFPNRatio_Plot(df_test, temp, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_ColumnFPNRatio_Plot(df_test, temp, document, pltPath, showPlt)

            # for tmp in TEMP:  # Temperature
            #     df_tmp = VRG_Data_Frame.newdataframe(df_test, temp, tmp)
            #     if tmp == nomTemp:
            #         document.add_heading(i + ' Image Capture (Temp = ' + str(tmp) + ') with Raw Mode = ' + str(tst),
            #                              level=2)
            #         VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 41, document,
            #                                                    showPlt)  # low integration low light
            #         VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 44, document,
            #                                                    showPlt)  # low integration brt light
            #         VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 47, document,
            #                                                    showPlt)  # high integration low light
            #         VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 50, document,
            #                                                    showPlt)  # high integration brt light

        document.add_heading(i + 'Power & Current vs. Voltage Level', level=2)
        VRG_Power_Data.Power_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)

def DV_3_16_COLUMN_BALANCE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_3_17_AUTOMATIC_GAIN_SELECTION(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_3_18_DARK_CURRENT_AND_DELTA_DARK_OPERATION(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    minLight = 0
    maxLight = 65535
    ULcolor = '#ff0000'
    LLcolor = '#0000ff'
    cint = 'RegWr00_COARSE_INTEGRATION_TIME_'
    anaGain = 'DVM_3_09_Analog_Gain'
    dataPed = 'RegWr01_DATA_PEDESTAL_'
    deltaDk = 'RegWr02_DELTA_DK_CONTROL'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[deltaDk].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)
        df_minLight = VRG_Data_Frame.newdataframe(df_img, 'Light', minLight)
        df_maxLight = VRG_Data_Frame.newdataframe(df_img, 'Light', maxLight)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Light Level Values', level=2)
        VRG_General_Data.LightLevel_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Key Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, cint, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, anaGain, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, dataPed, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, deltaDk, showPlt)

        document.add_heading(i + ' Image Stats vs. Delta Dark Enable/Disable', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, deltaDk, document, pltPath, showPlt,
                                      ax_hlines=[(dataPed, ULcolor, '--', 3, 1)])
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, deltaDk, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_TotalNoise_Plot(df_img, deltaDk, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_FPN_Plot(df_img, deltaDk, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_Temporal_Plot(df_img, deltaDk, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowStdDev_Plot(df_img, deltaDk, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_img, deltaDk, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowFPN_Plot(df_img, deltaDk, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTempNoise_Plot(df_img, deltaDk, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColStdDev_Plot(df_img, deltaDk, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_img, deltaDk, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColFPN_Plot(df_img, deltaDk, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTempNoise_Plot(df_img, deltaDk, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_Flicker_Plot(df_img, deltaDk, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelTotalNoise_Plot(df_img, deltaDk, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelTemporalNoise_Plot(df_img, deltaDk, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelFPN_Plot(df_img, deltaDk, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTemporalNoiseRatio_Plot(df_img, deltaDk, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColumnTemporalNoiseRatio_Plot(df_img, deltaDk, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowFPNRatio_Plot(df_img, deltaDk, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColumnFPNRatio_Plot(df_img, deltaDk, document, pltPath, showPlt)

        document.add_heading(i + ' Dark Image Stats vs. Delta Dark Enable/Disable', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_minLight, deltaDk, document, pltPath, showPlt,
                                      ax_hlines=[(dataPed, ULcolor, '--', 3, 1)])
        VRG_Stats_Arr.Arr_StdDev_Plot(df_minLight, deltaDk, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_TotalNoise_Plot(df_minLight, deltaDk, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_FPN_Plot(df_minLight, deltaDk, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_Temporal_Plot(df_minLight, deltaDk, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowStdDev_Plot(df_minLight, deltaDk, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_minLight, deltaDk, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowFPN_Plot(df_minLight, deltaDk, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTempNoise_Plot(df_minLight, deltaDk, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColStdDev_Plot(df_minLight, deltaDk, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_minLight, deltaDk, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColFPN_Plot(df_minLight, deltaDk, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTempNoise_Plot(df_minLight, deltaDk, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_Flicker_Plot(df_minLight, deltaDk, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelTotalNoise_Plot(df_minLight, deltaDk, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelTemporalNoise_Plot(df_minLight, deltaDk, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelFPN_Plot(df_minLight, deltaDk, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTemporalNoiseRatio_Plot(df_minLight, deltaDk, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColumnTemporalNoiseRatio_Plot(df_minLight, deltaDk, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowFPNRatio_Plot(df_minLight, deltaDk, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColumnFPNRatio_Plot(df_minLight, deltaDk, document, pltPath, showPlt)

        for tst in TEST:  # Test
            df_test_minLight = VRG_Data_Frame.newdataframe(df_minLight, deltaDk, tst)
            df_test_maxLight = VRG_Data_Frame.newdataframe(df_maxLight, deltaDk, tst)

            document.add_heading(i + ' Dark Image Stats vs. Delta Dark = ' + str(tst), level=2)
            VRG_Stats_Arr.Arr_Mean_Plot(df_test_minLight, deltaDk, document, pltPath, showPlt,
                                          ax_hlines=[(dataPed, ULcolor, '--', 3, 1)])
            VRG_Stats_Arr.Arr_StdDev_Plot(df_test_minLight, deltaDk, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_TotalNoise_Plot(df_test_minLight, deltaDk, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_FPN_Plot(df_test_minLight, deltaDk, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_Temporal_Plot(df_test_minLight, deltaDk, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_RowStdDev_Plot(df_test_minLight, deltaDk, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_test_minLight, deltaDk, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_RowFPN_Plot(df_test_minLight, deltaDk, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_RowTempNoise_Plot(df_test_minLight, deltaDk, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_ColStdDev_Plot(df_test_minLight, deltaDk, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_test_minLight, deltaDk, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_ColFPN_Plot(df_test_minLight, deltaDk, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_ColTempNoise_Plot(df_test_minLight, deltaDk, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_Flicker_Plot(df_test_minLight, deltaDk, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_PixelTotalNoise_Plot(df_test_minLight, deltaDk, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_PixelTemporalNoise_Plot(df_test_minLight, deltaDk, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_PixelFPN_Plot(df_test_minLight, deltaDk, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_RowTemporalNoiseRatio_Plot(df_test_minLight, deltaDk, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_ColumnTemporalNoiseRatio_Plot(df_test_minLight, deltaDk, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_RowFPNRatio_Plot(df_test_minLight, deltaDk, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_ColumnFPNRatio_Plot(df_test_minLight, deltaDk, document, pltPath, showPlt)

            document.add_heading(i + ' Saturated Image Stats vs. Delta Dark = ' + str(tst), level=2)
            VRG_Stats_Arr.Arr_Mean_Plot(df_test_maxLight, deltaDk, document, pltPath, showPlt,
                                          ax_hlines=[(dataPed, ULcolor, '--', 3, 1)])
            VRG_Stats_Arr.Arr_StdDev_Plot(df_test_maxLight, deltaDk, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_TotalNoise_Plot(df_test_maxLight, deltaDk, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_FPN_Plot(df_test_maxLight, deltaDk, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_Temporal_Plot(df_test_maxLight, deltaDk, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_RowStdDev_Plot(df_test_maxLight, deltaDk, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_test_maxLight, deltaDk, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_RowFPN_Plot(df_test_maxLight, deltaDk, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_RowTempNoise_Plot(df_test_maxLight, deltaDk, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_ColStdDev_Plot(df_test_maxLight, deltaDk, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_test_maxLight, deltaDk, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_ColFPN_Plot(df_test_maxLight, deltaDk, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_ColTempNoise_Plot(df_test_maxLight, deltaDk, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_Flicker_Plot(df_test_maxLight, deltaDk, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_PixelTotalNoise_Plot(df_test_maxLight, deltaDk, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_PixelTemporalNoise_Plot(df_test_maxLight, deltaDk, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_PixelFPN_Plot(df_test_maxLight, deltaDk, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_RowTemporalNoiseRatio_Plot(df_test_maxLight, deltaDk, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_ColumnTemporalNoiseRatio_Plot(df_test_maxLight, deltaDk, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_RowFPNRatio_Plot(df_test_maxLight, deltaDk, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_ColumnFPNRatio_Plot(df_test_maxLight, deltaDk, document, pltPath, showPlt)

            for tmp in TEMP:  # Temperature
                df_tmp_minLight = VRG_Data_Frame.newdataframe(df_test_minLight, temp, tmp)
                df_tmp_maxLight = VRG_Data_Frame.newdataframe(df_test_maxLight, temp, tmp)
                if tmp == nomTemp:
                    document.add_heading(
                        i + 'Dark Image Capture vs. Delta Dk = ' + str(tst) + ' (Temp = ' + str(tmp) + ')', level=2)
                    VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp_minLight, 11, document, showPlt)  # low integration
                    VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp_minLight, 14, document, showPlt)  # nom integration
                    VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp_minLight, 17, document,
                                                               showPlt)  # high integration
                    document.add_heading(
                        i + 'Saturated Image Capture vs. Delta Dk = ' + str(tst) + ' (Temp = ' + str(tmp) + ')',
                        level=2)
                    VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp_maxLight, 11, document, showPlt)  # low integration
                    VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp_maxLight, 14, document, showPlt)  # nom integration
                    VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp_maxLight, 17, document,
                                                               showPlt)  # high integration

        document.add_heading(i + 'Power & Current vs. Voltage Level', level=2)
        VRG_Power_Data.Power_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)

def DV_3_19_ANTI_ECLIPSE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    ULcolor = '#ff0000'
    LLcolor = '#0000ff'
    cint = 'RegWr00_COARSE_INTEGRATION_TIME_'
    eclVal = 'RegWr01_DAC_LD_28_29__SREG_COLAMP_ECL_VALUE'
    clampVal = 'RegWr02_DAC_LD_28_29__SREG_COLAMP_CLAMP_VALUE'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[eclVal].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Light Level Values', level=2)
        VRG_General_Data.LightLevel_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Key Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, cint, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, eclVal, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, clampVal, showPlt)

        for tst in TEST:  # Test
            df_test = VRG_Data_Frame.newdataframe(df_img, eclVal, tst)
            document.add_heading(i + 'Image Stats vs. Column Amp ECL = ' + str(tst), level=2)
            VRG_Stats_Arr.Arr_Mean_Plot(df_test, clampVal, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_StdDev_Plot(df_test, clampVal, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_RowStdDev_Plot(df_test, clampVal, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_test, clampVal, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_ColStdDev_Plot(df_test, clampVal, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_test, clampVal, document, pltPath, showPlt)

        document.add_heading(i + 'Power & Current vs. Voltage Level', level=2)
        VRG_Power_Data.Power_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)

def DV_3_20_ROW_COLUMN_BANDING(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_3_21_FUSE_BASED_DEFECT_CORRECTION(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_3_22_HORIZONTAL_MIRROR(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    ULcolor = '#ff0000'
    LLcolor = '#0000ff'
    cint = 'RegWr00_COARSE_INTEGRATION_TIME_'
    vFlip_hMirror = 'RegWr01_READ_MODE'
    bin_skip = 'RegWr02_DARK_CONTROL__DARK_CONTROL_SKIP_N_BIN_CTRL'
    vbLines = 'RegWr03_MIPI_DT_VC_CONFIG__ENABLE_VB_LINES'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[vFlip_hMirror].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Light Level Values', level=2)
        VRG_General_Data.LightLevel_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Key Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, cint, showPlt)
        document.add_heading(i + ' Horizontal Mirror Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, vFlip_hMirror, showPlt)
        document.add_heading(i + ' Column Binning & Row Skipping Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, bin_skip, showPlt)
        document.add_heading(i + ' Vertical Blanking Line Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, vbLines, showPlt)

        document.add_heading(i + ' Image Stats vs. Horizontal Mirror', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, vFlip_hMirror, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, vFlip_hMirror, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowStdDev_Plot(df_img, vFlip_hMirror, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_img, vFlip_hMirror, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColStdDev_Plot(df_img, vFlip_hMirror, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_img, vFlip_hMirror, document, pltPath, showPlt)

        for tst in TEST:  # Test
            df_test = VRG_Data_Frame.newdataframe(df_img, vFlip_hMirror, tst)
            document.add_heading(i + 'Image Stats vs. Horizontal Mirror = ' + str(
                tst) + ' vs. Column Bin & Row Skipping', level=2)
            VRG_Stats_Arr.Arr_Mean_Plot(df_test, bin_skip, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_StdDev_Plot(df_test, bin_skip, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_RowStdDev_Plot(df_test, bin_skip, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_test, bin_skip, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_ColStdDev_Plot(df_test, bin_skip, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_test, bin_skip, document, pltPath, showPlt)

            for tmp in TEMP:  # Temperature
                df_tmp = VRG_Data_Frame.newdataframe(df_test, temp, tmp)
                if tmp == nomTemp:
                    document.add_heading(
                        i + 'Image Capture vs. Horizontal Mirror = ' + str(tst) + ' (Temp = ' + str(
                            tmp) + ')', level=2)
                    VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 2, document, showPlt)  # low integration
                    VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 5, document, showPlt)  # nom integration
                    VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 8, document, showPlt)  # high integration

        document.add_heading(i + 'Power & Current vs. Voltage Level', level=2)
        VRG_Power_Data.Power_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)

def DV_3_22_VERTICAL_FLIP(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    ULcolor = '#ff0000'
    LLcolor = '#0000ff'
    cint = 'RegWr00_COARSE_INTEGRATION_TIME_'
    vFlip_hMirror = 'RegWr01_READ_MODE'
    bin_skip = 'RegWr02_DARK_CONTROL__DARK_CONTROL_SKIP_N_BIN_CTRL'
    vbLines = 'RegWr03_MIPI_DT_VC_CONFIG__ENABLE_VB_LINES'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[vFlip_hMirror].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Light Level Values', level=2)
        VRG_General_Data.LightLevel_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Key Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, cint, showPlt)
        document.add_heading(i + ' Vertical Flip Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, vFlip_hMirror, showPlt)
        document.add_heading(i + ' Column Binning & Row Skipping Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, bin_skip, showPlt)
        document.add_heading(i + ' Vertical Blanking Line Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, vbLines, showPlt)

        document.add_heading(i + ' Image Stats vs. Vertical Flip', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, vFlip_hMirror, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, vFlip_hMirror, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowStdDev_Plot(df_img, vFlip_hMirror, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_img, vFlip_hMirror, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColStdDev_Plot(df_img, vFlip_hMirror, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_img, vFlip_hMirror, document, pltPath, showPlt)

        for tst in TEST:  # Test
            df_test = VRG_Data_Frame.newdataframe(df_img, vFlip_hMirror, tst)
            document.add_heading(i + 'Image Stats vs. Vertical Flip = ' + str(
                tst) + ' vs. Column Bin & Row Skipping', level=2)
            VRG_Stats_Arr.Arr_Mean_Plot(df_test, bin_skip, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_StdDev_Plot(df_test, bin_skip, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_RowStdDev_Plot(df_test, bin_skip, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_test, bin_skip, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_ColStdDev_Plot(df_test, bin_skip, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_test, bin_skip, document, pltPath, showPlt)

            for tmp in TEMP:  # Temperature
                df_tmp = VRG_Data_Frame.newdataframe(df_test, temp, tmp)
                if tmp == nomTemp:
                    document.add_heading(
                        i + 'Image Capture vs. Vertical Flip = ' + str(tst) + ' (Temp = ' + str(
                            tmp) + ')', level=2)
                    VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 2, document, showPlt)  # low integration
                    VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 5, document, showPlt)  # nom integration
                    VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 8, document, showPlt)  # high integration

        document.add_heading(i + 'Power & Current vs. Voltage Level', level=2)
        VRG_Power_Data.Power_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)

def DV_3_22_HORIZONTAL_MIRROR_AND_VERTICAL_FLIP(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    ULcolor = '#ff0000'
    LLcolor = '#0000ff'
    cint = 'RegWr00_COARSE_INTEGRATION_TIME_'
    vFlip_hMirror = 'RegWr01_READ_MODE'
    bin_skip = 'RegWr02_DARK_CONTROL__DARK_CONTROL_SKIP_N_BIN_CTRL'
    vbLines = 'RegWr03_MIPI_DT_VC_CONFIG__ENABLE_VB_LINES'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[vFlip_hMirror].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Light Level Values', level=2)
        VRG_General_Data.LightLevel_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Key Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, cint, showPlt)
        document.add_heading(i + ' Horizontal Mirror & Vertical Flip Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, vFlip_hMirror, showPlt)
        document.add_heading(i + ' Column Binning & Row Skipping Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, bin_skip, showPlt)
        document.add_heading(i + ' Vertical Blanking Line Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, vbLines, showPlt)

        document.add_heading(i + ' Image Stats vs. Horizontal Mirror & Vertical Flip', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, vFlip_hMirror, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, vFlip_hMirror, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowStdDev_Plot(df_img, vFlip_hMirror, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_img, vFlip_hMirror, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColStdDev_Plot(df_img, vFlip_hMirror, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_img, vFlip_hMirror, document, pltPath, showPlt)

        for tst in TEST:  # Test
            df_test = VRG_Data_Frame.newdataframe(df_img, vFlip_hMirror, tst)
            document.add_heading(i + 'Image Stats vs. Horizontal Mirror & Vertical Flip = ' + str(
                tst) + ' vs. Column Bin & Row Skipping', level=2)
            VRG_Stats_Arr.Arr_Mean_Plot(df_test, bin_skip, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_StdDev_Plot(df_test, bin_skip, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_RowStdDev_Plot(df_test, bin_skip, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_test, bin_skip, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_ColStdDev_Plot(df_test, bin_skip, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_test, bin_skip, document, pltPath, showPlt)

            for tmp in TEMP:  # Temperature
                df_tmp = VRG_Data_Frame.newdataframe(df_test, temp, tmp)
                if tmp == nomTemp:
                    document.add_heading(
                        i + 'Image Capture vs. Horizontal Mirror & Vertical Flip = ' + str(tst) + ' (Temp = ' + str(
                            tmp) + ')', level=2)
                    VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 2, document, showPlt)  # low integration
                    VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 5, document, showPlt)  # nom integration
                    VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 8, document, showPlt)  # high integration

        document.add_heading(i + 'Power & Current vs. Voltage Level', level=2)
        VRG_Power_Data.Power_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)

def DV_3_24_VALIDATE_PIXEL_ARRAY_ARCHITECTURE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    ULcolor = '#ff0000'
    LLcolor = '#0000ff'
    cint = 'RegWr00_COARSE_INTEGRATION_TIME_'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Light Level Values', level=2)
        VRG_General_Data.LightLevel_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Key Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, cint, showPlt)

        document.add_heading(i + ' Image Size Specifications', level=2)
        VRG_General_Data.FrameWidth_Plot(df_img, [die, temp], document, pltPath, showPlt)
        VRG_General_Data.FrameHeight_Plot(df_img, [die, temp], document, pltPath, showPlt)

        document.add_heading(i + ' Full Resolution Image', level=2)
        VRG_Image_Analysis.Add_Image(df_img, 2, document, showPlt)
        document.add_heading(i + ' Full Resolution Image 200x200 Top Left of Frame', level=2)
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 0, 0, 200, 200, showPlt)  # 200 x 200 top frame
        document.add_heading(i + ' Full Resolution Image 200x200 Top Right of Frame', level=2)
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 0, 3960, 200, 4160, showPlt)  # 200 x 200 top frame
        document.add_heading(i + ' Full Resolution Image 200x200 Bottom Left of Frame', level=2)
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 2964, 0, 3164, 200, showPlt)  # 200 x 200 btm frame
        document.add_heading(i + ' Full Resolution Image 200x200 Bottom Right of Frame', level=2)
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 2964, 3960, 3164, 4160, showPlt)  # 200 x 200 btm frame

        document.add_heading(i + ' RRC Start', level=2)
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 34, 0, 64, 20, showPlt)  # RRC start
        document.add_heading(i + ' RRC Middle', level=2)
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 1504, 0, 1536, 20, showPlt)  # RRC mid
        document.add_heading(i + ' RRC End', level=2)
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 3100, 0, 3130, 20, showPlt)  # RRC end
        document.add_heading(i + ' DTR Start', level=2)
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 4, 32, 12, 80, showPlt)  # DTR start
        document.add_heading(i + ' DTR Middle', level=2)
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 4, 2000, 12, 2048, showPlt)  # DTR mid
        document.add_heading(i + ' DTR End', level=2)
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 4, 4088, 12, 4136, showPlt)  # DTR end
        document.add_heading(i + ' ATR Start', level=2)
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 3140, 32, 3160, 80, showPlt)  # ATR start
        document.add_heading(i + ' ATR Middle', level=2)
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 3140, 2000, 3160, 2048, showPlt)  # ATR mid
        document.add_heading(i + ' ATR End', level=2)
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 3140, 4088, 3160, 4136, showPlt)  # ATR end

def DV_3_25_PSRR(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)

def DV_3_25_PSRR_VAA(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    cint = 'RegWr00_COARSE_INTEGRATION_TIME_'
    dataPed = 'RegWr01_DATA_PEDESTAL_'
    rnc = 'RegWr02_DARK_CONTROL__DARK_CONTROL_ROW_NOISE_CORRECTION_EN'
    noiseFreq = 'GpibSignalFreq_PSRR'
    noiseAmp = 'GpibSignalAmplitude_PSRR'
    pwrSupply = 'VAA [V]'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    document.add_heading('Key Register Values')
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, cint, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, dataPed, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, rnc, showPlt)

    document.add_heading('PSSR VAA Settings & Data vs. Imaging Mode')
    VRG_Power_Data.PSSR_Input_Signal_Voltage_Plot(df, 'ImgMode', document, pltPath, showPlt)
    VRG_Power_Data.PSSR_Input_Signal_Voltage_vs_Supply_Plot(df, 'ImgMode', document, pltPath, pwrSupply, showPlt)
    VRG_Power_Data.PSSR_Sigma_Plot(df, 'ImgMode', document, pltPath, showPlt)
    VRG_Power_Data.PSSR_Noise_Signal_Frequency_Plot(df, 'ImgMode', document, pltPath, showPlt, ax_scale='logy')
    VRG_Power_Data.PSSR_Noise_Signal_Amplitude_Plot(df, 'ImgMode', document, pltPath, showPlt)
    VRG_Power_Data.PSSR_Noise_Signal_Offset_Plot(df, 'ImgMode', document, pltPath, showPlt)
    VRG_Power_Data.PSSR_Noise_Signal_Type_Plot(df, 'ImgMode', document, pltPath, showPlt)

    document.add_heading('PSSR VAA Measurement Data vs. Imaging Mode')
    VRG_Power_Data.PSSR_Measurement_Plot(df, 'ImgMode', document, pltPath, showPlt)
    VRG_Power_Data.PSSR_vs_Noise_Frequency_Plot(df, 'ImgMode', document, pltPath, showPlt, lines=False, ax_scale='logx')
    VRG_Power_Data.PSSR_vs_Noise_Amplitude_Plot(df, 'ImgMode', document, pltPath, showPlt, lines=False)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Light Level Values', level=2)
        VRG_General_Data.LightLevel_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Key Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, cint, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, dataPed, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, rnc, showPlt)

        document.add_heading(i + ' PSSR Input Signal Voltages', level=2)
        VRG_Power_Data.PSSR_Input_Signal_Voltage_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.PSSR_Input_Signal_Voltage_vs_Supply_Plot(df_img, 'Power', document, pltPath, pwrSupply, showPlt)
        document.add_heading(i + ' PSSR Sigma Measurements', level=2)
        VRG_Power_Data.PSSR_Sigma_Plot(df_img, 'Power', document, pltPath, showPlt)
        document.add_heading(i + ' PSSR Noise Signal Settings', level=2)
        VRG_Power_Data.PSSR_Noise_Signal_Frequency_Plot(df_img, None, document, pltPath, showPlt, ax_scale='logy')
        VRG_Power_Data.PSSR_Noise_Signal_Amplitude_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Power_Data.PSSR_Noise_Signal_Offset_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Power_Data.PSSR_Noise_Signal_Type_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' PSSR VAA Statistics')
        VRG_Power_Data.PSRR_Statistics_Table(df_img, None, None, document)

        document.add_heading(i + ' PSSR VAA Measurement Data', level=2)
        VRG_Power_Data.PSSR_Measurement_Plot(df_img, None, document, pltPath, showPlt)
        document.add_heading(i + ' PSSR VAA Measurement Data vs. Power', level=2)
        VRG_Power_Data.PSSR_Measurement_Plot(df_img, 'Power', document, pltPath, showPlt)
        document.add_heading(i + ' PSSR VAA Measurement Data vs. Noise Frequency', level=2)
        VRG_Power_Data.PSSR_Measurement_Plot(df_img, noiseFreq, document, pltPath, showPlt, lines=False)
        document.add_heading(i + ' PSSR VAA Measurement Data vs. Noise Amplitude', level=2)
        VRG_Power_Data.PSSR_Measurement_Plot(df_img, noiseAmp, document, pltPath, showPlt, lines=False)
        document.add_heading(i + ' PSSR VAA Measurement Data vs. Row Noise Correction', level=2)
        VRG_Power_Data.PSSR_Measurement_Plot(df_img, rnc, document, pltPath, showPlt, lines=False)

        document.add_heading(i + ' PSSR VAA Data vs. Noise Frequency', level=2)
        VRG_Power_Data.PSSR_vs_Noise_Frequency_Plot(df_img, None, document, pltPath, showPlt, lines=False,
                                                    ax_scale='logx')
        document.add_heading(i + ' PSSR VAA Data vs. Noise Frequency vs. Power', level=2)
        VRG_Power_Data.PSSR_vs_Noise_Frequency_Plot(df_img, 'Power', document, pltPath, showPlt, lines=False,
                                                    ax_scale='logx')
        document.add_heading(i + ' PSSR VAA Data vs. Noise Frequency vs. Noise Amplitude', level=2)
        VRG_Power_Data.PSSR_vs_Noise_Frequency_Plot(df_img, noiseAmp, document, pltPath, showPlt, lines=False,
                                                    ax_scale='logx')
        document.add_heading(i + ' PSSR VAA Data vs. Noise Frequency vs. Power', level=2)
        VRG_Power_Data.PSSR_vs_Noise_Frequency_Plot(df_img, rnc, document, pltPath, showPlt, lines=False,
                                                    ax_scale='logx')

        document.add_heading(i + ' PSSR VAA Data vs. Noise Amplitude', level=2)
        VRG_Power_Data.PSSR_vs_Noise_Amplitude_Plot(df_img, None, document, pltPath, showPlt, lines=False)
        document.add_heading(i + ' PSSR VAA Data vs. Noise Amplitude vs. Power', level=2)
        VRG_Power_Data.PSSR_vs_Noise_Amplitude_Plot(df_img, 'Power', document, pltPath, showPlt, lines=False)
        document.add_heading(i + ' PSSR VAA Data vs. Noise Amplitude vs. Noise Frequency', level=2)
        VRG_Power_Data.PSSR_vs_Noise_Amplitude_Plot(df_img, noiseFreq, document, pltPath, showPlt, lines=False)
        document.add_heading(i + ' PSSR VAA Data vs. Noise Amplitude vs. Row Noise Correction', level=2)
        VRG_Power_Data.PSSR_vs_Noise_Amplitude_Plot(df_img, rnc, document, pltPath, showPlt, lines=False)

def DV_3_25_PSRR_VAAPIX(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    cint = 'RegWr00_COARSE_INTEGRATION_TIME_'
    dataPed = 'RegWr01_DATA_PEDESTAL_'
    rnc = 'RegWr02_DARK_CONTROL__DARK_CONTROL_ROW_NOISE_CORRECTION_EN'
    noiseFreq = 'GpibSignalFreq_PSRR'
    noiseAmp = 'GpibSignalAmplitude_PSRR'
    pwrSupply = 'VAA [V]'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    document.add_heading('Key Register Values')
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, cint, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, dataPed, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, rnc, showPlt)

    document.add_heading('PSSR VAA Settings & Data vs. Imaging Mode')
    VRG_Power_Data.PSSR_Input_Signal_Voltage_Plot(df, 'ImgMode', document, pltPath, showPlt)
    VRG_Power_Data.PSSR_Input_Signal_Voltage_vs_Supply_Plot(df, 'ImgMode', document, pltPath, pwrSupply, showPlt)
    VRG_Power_Data.PSSR_Sigma_Plot(df, 'ImgMode', document, pltPath, showPlt)
    VRG_Power_Data.PSSR_Noise_Signal_Frequency_Plot(df, 'ImgMode', document, pltPath, showPlt, ax_scale='logy')
    VRG_Power_Data.PSSR_Noise_Signal_Amplitude_Plot(df, 'ImgMode', document, pltPath, showPlt)
    VRG_Power_Data.PSSR_Noise_Signal_Offset_Plot(df, 'ImgMode', document, pltPath, showPlt)
    VRG_Power_Data.PSSR_Noise_Signal_Type_Plot(df, 'ImgMode', document, pltPath, showPlt)

    document.add_heading('PSSR VAA Measurement Data vs. Imaging Mode')
    VRG_Power_Data.PSSR_Measurement_Plot(df, 'ImgMode', document, pltPath, showPlt)
    VRG_Power_Data.PSSR_vs_Noise_Frequency_Plot(df, 'ImgMode', document, pltPath, showPlt, lines=False, ax_scale='logx')
    VRG_Power_Data.PSSR_vs_Noise_Amplitude_Plot(df, 'ImgMode', document, pltPath, showPlt, lines=False)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Light Level Values', level=2)
        VRG_General_Data.LightLevel_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Key Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, cint, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, dataPed, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, rnc, showPlt)

        document.add_heading(i + ' PSSR Input Signal Voltages', level=2)
        VRG_Power_Data.PSSR_Input_Signal_Voltage_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.PSSR_Input_Signal_Voltage_vs_Supply_Plot(df_img, 'Power', document, pltPath, pwrSupply, showPlt)
        document.add_heading(i + ' PSSR Sigma Measurements', level=2)
        VRG_Power_Data.PSSR_Sigma_Plot(df_img, 'Power', document, pltPath, showPlt)
        document.add_heading(i + ' PSSR Noise Signal Settings', level=2)
        VRG_Power_Data.PSSR_Noise_Signal_Frequency_Plot(df_img, None, document, pltPath, showPlt, ax_scale='logy')
        VRG_Power_Data.PSSR_Noise_Signal_Amplitude_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Power_Data.PSSR_Noise_Signal_Offset_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Power_Data.PSSR_Noise_Signal_Type_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' PSSR VAA Statistics')
        VRG_Power_Data.PSRR_Statistics_Table(df_img, None, None, document)

        document.add_heading(i + ' PSSR VAA Measurement Data', level=2)
        VRG_Power_Data.PSSR_Measurement_Plot(df_img, None, document, pltPath, showPlt)
        document.add_heading(i + ' PSSR VAA Measurement Data vs. Power', level=2)
        VRG_Power_Data.PSSR_Measurement_Plot(df_img, 'Power', document, pltPath, showPlt)
        document.add_heading(i + ' PSSR VAA Measurement Data vs. Noise Frequency', level=2)
        VRG_Power_Data.PSSR_Measurement_Plot(df_img, noiseFreq, document, pltPath, showPlt, lines=False)
        document.add_heading(i + ' PSSR VAA Measurement Data vs. Noise Amplitude', level=2)
        VRG_Power_Data.PSSR_Measurement_Plot(df_img, noiseAmp, document, pltPath, showPlt, lines=False)
        document.add_heading(i + ' PSSR VAA Measurement Data vs. Row Noise Correction', level=2)
        VRG_Power_Data.PSSR_Measurement_Plot(df_img, rnc, document, pltPath, showPlt, lines=False)

        document.add_heading(i + ' PSSR VAA Data vs. Noise Frequency', level=2)
        VRG_Power_Data.PSSR_vs_Noise_Frequency_Plot(df_img, None, document, pltPath, showPlt, lines=False,
                                                    ax_scale='logx')
        document.add_heading(i + ' PSSR VAA Data vs. Noise Frequency vs. Power', level=2)
        VRG_Power_Data.PSSR_vs_Noise_Frequency_Plot(df_img, 'Power', document, pltPath, showPlt, lines=False,
                                                    ax_scale='logx')
        document.add_heading(i + ' PSSR VAA Data vs. Noise Frequency vs. Noise Amplitude', level=2)
        VRG_Power_Data.PSSR_vs_Noise_Frequency_Plot(df_img, noiseAmp, document, pltPath, showPlt, lines=False,
                                                    ax_scale='logx')
        document.add_heading(i + ' PSSR VAA Data vs. Noise Frequency vs. Power', level=2)
        VRG_Power_Data.PSSR_vs_Noise_Frequency_Plot(df_img, rnc, document, pltPath, showPlt, lines=False,
                                                    ax_scale='logx')

        document.add_heading(i + ' PSSR VAA Data vs. Noise Amplitude', level=2)
        VRG_Power_Data.PSSR_vs_Noise_Amplitude_Plot(df_img, None, document, pltPath, showPlt, lines=False)
        document.add_heading(i + ' PSSR VAA Data vs. Noise Amplitude vs. Power', level=2)
        VRG_Power_Data.PSSR_vs_Noise_Amplitude_Plot(df_img, 'Power', document, pltPath, showPlt, lines=False)
        document.add_heading(i + ' PSSR VAA Data vs. Noise Amplitude vs. Noise Frequency', level=2)
        VRG_Power_Data.PSSR_vs_Noise_Amplitude_Plot(df_img, noiseFreq, document, pltPath, showPlt, lines=False)
        document.add_heading(i + ' PSSR VAA Data vs. Noise Amplitude vs. Row Noise Correction', level=2)
        VRG_Power_Data.PSSR_vs_Noise_Amplitude_Plot(df_img, rnc, document, pltPath, showPlt, lines=False)

def DV_3_25_PSRR_VAA2V8(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    cint = 'RegWr00_COARSE_INTEGRATION_TIME_'
    dataPed = 'RegWr01_DATA_PEDESTAL_'
    rnc = 'RegWr02_DARK_CONTROL__DARK_CONTROL_ROW_NOISE_CORRECTION_EN'
    noiseFreq = 'GpibSignalFreq_PSRR'
    noiseAmp = 'GpibSignalAmplitude_PSRR'
    pwrSupply = 'VAA [V]'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    document.add_heading('Key Register Values')
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, cint, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, dataPed, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, rnc, showPlt)

    document.add_heading('PSSR VAA Settings & Data vs. Imaging Mode')
    VRG_Power_Data.PSSR_Input_Signal_Voltage_Plot(df, 'ImgMode', document, pltPath, showPlt)
    VRG_Power_Data.PSSR_Input_Signal_Voltage_vs_Supply_Plot(df, 'ImgMode', document, pltPath, pwrSupply, showPlt)
    VRG_Power_Data.PSSR_Sigma_Plot(df, 'ImgMode', document, pltPath, showPlt)
    VRG_Power_Data.PSSR_Noise_Signal_Frequency_Plot(df, 'ImgMode', document, pltPath, showPlt, ax_scale='logy')
    VRG_Power_Data.PSSR_Noise_Signal_Amplitude_Plot(df, 'ImgMode', document, pltPath, showPlt)
    VRG_Power_Data.PSSR_Noise_Signal_Offset_Plot(df, 'ImgMode', document, pltPath, showPlt)
    VRG_Power_Data.PSSR_Noise_Signal_Type_Plot(df, 'ImgMode', document, pltPath, showPlt)

    document.add_heading('PSSR VAA Measurement Data vs. Imaging Mode')
    VRG_Power_Data.PSSR_Measurement_Plot(df, 'ImgMode', document, pltPath, showPlt)
    VRG_Power_Data.PSSR_vs_Noise_Frequency_Plot(df, 'ImgMode', document, pltPath, showPlt, lines=False, ax_scale='logx')
    VRG_Power_Data.PSSR_vs_Noise_Amplitude_Plot(df, 'ImgMode', document, pltPath, showPlt, lines=False)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Light Level Values', level=2)
        VRG_General_Data.LightLevel_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Key Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, cint, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, dataPed, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, rnc, showPlt)

        document.add_heading(i + ' PSSR Input Signal Voltages', level=2)
        VRG_Power_Data.PSSR_Input_Signal_Voltage_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.PSSR_Input_Signal_Voltage_vs_Supply_Plot(df_img, 'Power', document, pltPath, pwrSupply, showPlt)
        document.add_heading(i + ' PSSR Sigma Measurements', level=2)
        VRG_Power_Data.PSSR_Sigma_Plot(df_img, 'Power', document, pltPath, showPlt)
        document.add_heading(i + ' PSSR Noise Signal Settings', level=2)
        VRG_Power_Data.PSSR_Noise_Signal_Frequency_Plot(df_img, None, document, pltPath, showPlt, ax_scale='logy')
        VRG_Power_Data.PSSR_Noise_Signal_Amplitude_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Power_Data.PSSR_Noise_Signal_Offset_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Power_Data.PSSR_Noise_Signal_Type_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' PSSR VAA Statistics')
        VRG_Power_Data.PSRR_Statistics_Table(df_img, None, None, document)

        document.add_heading(i + ' PSSR VAA Measurement Data', level=2)
        VRG_Power_Data.PSSR_Measurement_Plot(df_img, None, document, pltPath, showPlt)
        document.add_heading(i + ' PSSR VAA Measurement Data vs. Power', level=2)
        VRG_Power_Data.PSSR_Measurement_Plot(df_img, 'Power', document, pltPath, showPlt)
        document.add_heading(i + ' PSSR VAA Measurement Data vs. Noise Frequency', level=2)
        VRG_Power_Data.PSSR_Measurement_Plot(df_img, noiseFreq, document, pltPath, showPlt, lines=False)
        document.add_heading(i + ' PSSR VAA Measurement Data vs. Noise Amplitude', level=2)
        VRG_Power_Data.PSSR_Measurement_Plot(df_img, noiseAmp, document, pltPath, showPlt, lines=False)
        document.add_heading(i + ' PSSR VAA Measurement Data vs. Row Noise Correction', level=2)
        VRG_Power_Data.PSSR_Measurement_Plot(df_img, rnc, document, pltPath, showPlt, lines=False)

        document.add_heading(i + ' PSSR VAA Data vs. Noise Frequency', level=2)
        VRG_Power_Data.PSSR_vs_Noise_Frequency_Plot(df_img, None, document, pltPath, showPlt, lines=False,
                                                    ax_scale='logx')
        document.add_heading(i + ' PSSR VAA Data vs. Noise Frequency vs. Power', level=2)
        VRG_Power_Data.PSSR_vs_Noise_Frequency_Plot(df_img, 'Power', document, pltPath, showPlt, lines=False,
                                                    ax_scale='logx')
        document.add_heading(i + ' PSSR VAA Data vs. Noise Frequency vs. Noise Amplitude', level=2)
        VRG_Power_Data.PSSR_vs_Noise_Frequency_Plot(df_img, noiseAmp, document, pltPath, showPlt, lines=False,
                                                    ax_scale='logx')
        document.add_heading(i + ' PSSR VAA Data vs. Noise Frequency vs. Power', level=2)
        VRG_Power_Data.PSSR_vs_Noise_Frequency_Plot(df_img, rnc, document, pltPath, showPlt, lines=False,
                                                    ax_scale='logx')

        document.add_heading(i + ' PSSR VAA Data vs. Noise Amplitude', level=2)
        VRG_Power_Data.PSSR_vs_Noise_Amplitude_Plot(df_img, None, document, pltPath, showPlt, lines=False)
        document.add_heading(i + ' PSSR VAA Data vs. Noise Amplitude vs. Power', level=2)
        VRG_Power_Data.PSSR_vs_Noise_Amplitude_Plot(df_img, 'Power', document, pltPath, showPlt, lines=False)
        document.add_heading(i + ' PSSR VAA Data vs. Noise Amplitude vs. Noise Frequency', level=2)
        VRG_Power_Data.PSSR_vs_Noise_Amplitude_Plot(df_img, noiseFreq, document, pltPath, showPlt, lines=False)
        document.add_heading(i + ' PSSR VAA Data vs. Noise Amplitude vs. Row Noise Correction', level=2)
        VRG_Power_Data.PSSR_vs_Noise_Amplitude_Plot(df_img, rnc, document, pltPath, showPlt, lines=False)

def DV_3_25_PSRR_VAA1V8(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    cint = 'RegWr00_COARSE_INTEGRATION_TIME_'
    dataPed = 'RegWr01_DATA_PEDESTAL_'
    rnc = 'RegWr02_DARK_CONTROL__DARK_CONTROL_ROW_NOISE_CORRECTION_EN'
    noiseFreq = 'GpibSignalFreq_PSRR'
    noiseAmp = 'GpibSignalAmplitude_PSRR'
    pwrSupply = 'VAA [V]'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    document.add_heading('Key Register Values')
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, cint, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, dataPed, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, rnc, showPlt)

    document.add_heading('PSSR VAA Settings & Data vs. Imaging Mode')
    VRG_Power_Data.PSSR_Input_Signal_Voltage_Plot(df, 'ImgMode', document, pltPath, showPlt)
    VRG_Power_Data.PSSR_Input_Signal_Voltage_vs_Supply_Plot(df, 'ImgMode', document, pltPath, pwrSupply, showPlt)
    VRG_Power_Data.PSSR_Sigma_Plot(df, 'ImgMode', document, pltPath, showPlt)
    VRG_Power_Data.PSSR_Noise_Signal_Frequency_Plot(df, 'ImgMode', document, pltPath, showPlt, ax_scale='logy')
    VRG_Power_Data.PSSR_Noise_Signal_Amplitude_Plot(df, 'ImgMode', document, pltPath, showPlt)
    VRG_Power_Data.PSSR_Noise_Signal_Offset_Plot(df, 'ImgMode', document, pltPath, showPlt)
    VRG_Power_Data.PSSR_Noise_Signal_Type_Plot(df, 'ImgMode', document, pltPath, showPlt)

    document.add_heading('PSSR VAA Measurement Data vs. Imaging Mode')
    VRG_Power_Data.PSSR_Measurement_Plot(df, 'ImgMode', document, pltPath, showPlt)
    VRG_Power_Data.PSSR_vs_Noise_Frequency_Plot(df, 'ImgMode', document, pltPath, showPlt, lines=False, ax_scale='logx')
    VRG_Power_Data.PSSR_vs_Noise_Amplitude_Plot(df, 'ImgMode', document, pltPath, showPlt, lines=False)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Light Level Values', level=2)
        VRG_General_Data.LightLevel_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Key Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, cint, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, dataPed, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, rnc, showPlt)

        document.add_heading(i + ' PSSR Input Signal Voltages', level=2)
        VRG_Power_Data.PSSR_Input_Signal_Voltage_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.PSSR_Input_Signal_Voltage_vs_Supply_Plot(df_img, 'Power', document, pltPath, pwrSupply, showPlt)
        document.add_heading(i + ' PSSR Sigma Measurements', level=2)
        VRG_Power_Data.PSSR_Sigma_Plot(df_img, 'Power', document, pltPath, showPlt)
        document.add_heading(i + ' PSSR Noise Signal Settings', level=2)
        VRG_Power_Data.PSSR_Noise_Signal_Frequency_Plot(df_img, None, document, pltPath, showPlt, ax_scale='logy')
        VRG_Power_Data.PSSR_Noise_Signal_Amplitude_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Power_Data.PSSR_Noise_Signal_Offset_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Power_Data.PSSR_Noise_Signal_Type_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' PSSR VAA Statistics')
        VRG_Power_Data.PSRR_Statistics_Table(df_img, None, None, document)

        document.add_heading(i + ' PSSR VAA Measurement Data', level=2)
        VRG_Power_Data.PSSR_Measurement_Plot(df_img, None, document, pltPath, showPlt)
        document.add_heading(i + ' PSSR VAA Measurement Data vs. Power', level=2)
        VRG_Power_Data.PSSR_Measurement_Plot(df_img, 'Power', document, pltPath, showPlt)
        document.add_heading(i + ' PSSR VAA Measurement Data vs. Noise Frequency', level=2)
        VRG_Power_Data.PSSR_Measurement_Plot(df_img, noiseFreq, document, pltPath, showPlt, lines=False)
        document.add_heading(i + ' PSSR VAA Measurement Data vs. Noise Amplitude', level=2)
        VRG_Power_Data.PSSR_Measurement_Plot(df_img, noiseAmp, document, pltPath, showPlt, lines=False)
        document.add_heading(i + ' PSSR VAA Measurement Data vs. Row Noise Correction', level=2)
        VRG_Power_Data.PSSR_Measurement_Plot(df_img, rnc, document, pltPath, showPlt, lines=False)

        document.add_heading(i + ' PSSR VAA Data vs. Noise Frequency', level=2)
        VRG_Power_Data.PSSR_vs_Noise_Frequency_Plot(df_img, None, document, pltPath, showPlt, lines=False,
                                                    ax_scale='logx')
        document.add_heading(i + ' PSSR VAA Data vs. Noise Frequency vs. Power', level=2)
        VRG_Power_Data.PSSR_vs_Noise_Frequency_Plot(df_img, 'Power', document, pltPath, showPlt, lines=False,
                                                    ax_scale='logx')
        document.add_heading(i + ' PSSR VAA Data vs. Noise Frequency vs. Noise Amplitude', level=2)
        VRG_Power_Data.PSSR_vs_Noise_Frequency_Plot(df_img, noiseAmp, document, pltPath, showPlt, lines=False,
                                                    ax_scale='logx')
        document.add_heading(i + ' PSSR VAA Data vs. Noise Frequency vs. Power', level=2)
        VRG_Power_Data.PSSR_vs_Noise_Frequency_Plot(df_img, rnc, document, pltPath, showPlt, lines=False,
                                                    ax_scale='logx')

        document.add_heading(i + ' PSSR VAA Data vs. Noise Amplitude', level=2)
        VRG_Power_Data.PSSR_vs_Noise_Amplitude_Plot(df_img, None, document, pltPath, showPlt, lines=False)
        document.add_heading(i + ' PSSR VAA Data vs. Noise Amplitude vs. Power', level=2)
        VRG_Power_Data.PSSR_vs_Noise_Amplitude_Plot(df_img, 'Power', document, pltPath, showPlt, lines=False)
        document.add_heading(i + ' PSSR VAA Data vs. Noise Amplitude vs. Noise Frequency', level=2)
        VRG_Power_Data.PSSR_vs_Noise_Amplitude_Plot(df_img, noiseFreq, document, pltPath, showPlt, lines=False)
        document.add_heading(i + ' PSSR VAA Data vs. Noise Amplitude vs. Row Noise Correction', level=2)
        VRG_Power_Data.PSSR_vs_Noise_Amplitude_Plot(df_img, rnc, document, pltPath, showPlt, lines=False)

def DV_3_25_PSRR_VDD(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    cint = 'RegWr00_COARSE_INTEGRATION_TIME_'
    dataPed = 'RegWr01_DATA_PEDESTAL_'
    rnc = 'RegWr02_DARK_CONTROL__DARK_CONTROL_ROW_NOISE_CORRECTION_EN'
    noiseFreq = 'GpibSignalFreq_PSRR'
    noiseAmp = 'GpibSignalAmplitude_PSRR'
    pwrSupply = 'VDD [V]'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    document.add_heading('Key Register Values')
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, cint, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, dataPed, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, rnc, showPlt)

    document.add_heading('PSSR VDD Settings & Data vs. Imaging Mode')
    VRG_Power_Data.PSSR_Input_Signal_Voltage_Plot(df, 'ImgMode', document, pltPath, showPlt)
    VRG_Power_Data.PSSR_Input_Signal_Voltage_vs_Supply_Plot(df, 'ImgMode', document, pltPath, pwrSupply, showPlt)
    VRG_Power_Data.PSSR_Sigma_Plot(df, 'ImgMode', document, pltPath, showPlt)
    VRG_Power_Data.PSSR_Noise_Signal_Frequency_Plot(df, 'ImgMode', document, pltPath, showPlt, ax_scale='logy')
    VRG_Power_Data.PSSR_Noise_Signal_Amplitude_Plot(df, 'ImgMode', document, pltPath, showPlt)
    VRG_Power_Data.PSSR_Noise_Signal_Offset_Plot(df, 'ImgMode', document, pltPath, showPlt)
    VRG_Power_Data.PSSR_Noise_Signal_Type_Plot(df, 'ImgMode', document, pltPath, showPlt)

    document.add_heading('PSSR VDD Measurement Data vs. Imaging Mode')
    VRG_Power_Data.PSSR_Measurement_Plot(df, 'ImgMode', document, pltPath, showPlt)
    VRG_Power_Data.PSSR_vs_Noise_Frequency_Plot(df, 'ImgMode', document, pltPath, showPlt, lines=False, ax_scale='logx')
    VRG_Power_Data.PSSR_vs_Noise_Amplitude_Plot(df, 'ImgMode', document, pltPath, showPlt, lines=False)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Light Level Values', level=2)
        VRG_General_Data.LightLevel_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Key Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, cint, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, dataPed, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, rnc, showPlt)

        document.add_heading(i + ' PSSR Input Signal Voltages', level=2)
        VRG_Power_Data.PSSR_Input_Signal_Voltage_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.PSSR_Input_Signal_Voltage_vs_Supply_Plot(df_img, 'Power', document, pltPath, pwrSupply, showPlt)
        document.add_heading(i + ' PSSR Sigma Measurements', level=2)
        VRG_Power_Data.PSSR_Sigma_Plot(df_img, 'Power', document, pltPath, showPlt)
        document.add_heading(i + ' PSSR Noise Signal Settings', level=2)
        VRG_Power_Data.PSSR_Noise_Signal_Frequency_Plot(df_img, None, document, pltPath, showPlt, ax_scale='logy')
        VRG_Power_Data.PSSR_Noise_Signal_Amplitude_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Power_Data.PSSR_Noise_Signal_Offset_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Power_Data.PSSR_Noise_Signal_Type_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' PSSR VDD Statistics')
        VRG_Power_Data.PSRR_Statistics_Table(df_img, None, None, document)

        document.add_heading(i + ' PSSR VDD Measurement Data', level=2)
        VRG_Power_Data.PSSR_Measurement_Plot(df_img, None, document, pltPath, showPlt)
        document.add_heading(i + ' PSSR VDD Measurement Data vs. Power', level=2)
        VRG_Power_Data.PSSR_Measurement_Plot(df_img, 'Power', document, pltPath, showPlt)
        document.add_heading(i + ' PSSR VDD Measurement Data vs. Noise Frequency', level=2)
        VRG_Power_Data.PSSR_Measurement_Plot(df_img, noiseFreq, document, pltPath, showPlt, lines=False)
        document.add_heading(i + ' PSSR VDD Measurement Data vs. Noise Amplitude', level=2)
        VRG_Power_Data.PSSR_Measurement_Plot(df_img, noiseAmp, document, pltPath, showPlt, lines=False)
        document.add_heading(i + ' PSSR VDD Measurement Data vs. Row Noise Correction', level=2)
        VRG_Power_Data.PSSR_Measurement_Plot(df_img, rnc, document, pltPath, showPlt, lines=False)

        document.add_heading(i + ' PSSR VDD Data vs. Noise Frequency', level=2)
        VRG_Power_Data.PSSR_vs_Noise_Frequency_Plot(df_img, None, document, pltPath, showPlt, lines=False,
                                                    ax_scale='logx')
        document.add_heading(i + ' PSSR VDD Data vs. Noise Frequency vs. Power', level=2)
        VRG_Power_Data.PSSR_vs_Noise_Frequency_Plot(df_img, 'Power', document, pltPath, showPlt, lines=False,
                                                    ax_scale='logx')
        document.add_heading(i + ' PSSR VDD Data vs. Noise Frequency vs. Noise Amplitude', level=2)
        VRG_Power_Data.PSSR_vs_Noise_Frequency_Plot(df_img, noiseAmp, document, pltPath, showPlt, lines=False,
                                                    ax_scale='logx')
        document.add_heading(i + ' PSSR VDD Data vs. Noise Frequency vs. Power', level=2)
        VRG_Power_Data.PSSR_vs_Noise_Frequency_Plot(df_img, rnc, document, pltPath, showPlt, lines=False,
                                                    ax_scale='logx')

        document.add_heading(i + ' PSSR VDD Data vs. Noise Amplitude', level=2)
        VRG_Power_Data.PSSR_vs_Noise_Amplitude_Plot(df_img, None, document, pltPath, showPlt, lines=False)
        document.add_heading(i + ' PSSR VDD Data vs. Noise Amplitude vs. Power', level=2)
        VRG_Power_Data.PSSR_vs_Noise_Amplitude_Plot(df_img, 'Power', document, pltPath, showPlt, lines=False)
        document.add_heading(i + ' PSSR VDD Data vs. Noise Amplitude vs. Noise Frequency', level=2)
        VRG_Power_Data.PSSR_vs_Noise_Amplitude_Plot(df_img, noiseFreq, document, pltPath, showPlt, lines=False)
        document.add_heading(i + ' PSSR VDD Data vs. Noise Amplitude vs. Row Noise Correction', level=2)
        VRG_Power_Data.PSSR_vs_Noise_Amplitude_Plot(df_img, rnc, document, pltPath, showPlt, lines=False)

def DV_3_26_CONTINUOUS_TRIGGER_MODE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    ULcolor = '#ff0000'
    LLcolor = '#0000ff'
    cint = 'RegWr00_COARSE_INTEGRATION_TIME_'
    reg1 = 'RegWr01_MODE_SELECT'
    reg2 = 'RegWr02_GPIO_CONTROL1'
    reg3 = 'RegWr03_GPIO_CONTROL2'
    frmCnt = 'RegVal_FRAME_COUNT_'
    gpio0 = 'Pin:GPIO0'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Light Level Values', level=2)
        VRG_General_Data.LightLevel_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Key Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, cint, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, reg1, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, reg2, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, reg3, showPlt)

        document.add_heading(i + ' Trigger Pin Level', level=2)
        VRG_Pins_Data.Pin_Plot(df_img, None, document, pltPath, gpio0, showPlt)

        document.add_heading(i + ' Frame Time', level=2)
        VRG_General_Data.FrameTime_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' PLL Clocks', level=2)
        VRG_General_Data.PLL_Clock_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' I2C Status', level=2)
        VRG_General_Data.I2C_Status_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Image Size Specifications', level=2)
        VRG_General_Data.FrameWidth_Plot(df_img, [die, temp], document, pltPath, showPlt)
        VRG_General_Data.FrameHeight_Plot(df_img, [die, temp], document, pltPath, showPlt)

        document.add_heading(i + ' Image Statistics vs. Die vs. Temperature', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, [die, temp], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, [die, temp], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowStdDev_Plot(df_img, [die, temp], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_img, [die, temp], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColStdDev_Plot(df_img, [die, temp], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_img, [die, temp], document, pltPath, showPlt)

        document.add_heading(i + 'Power & Current vs. Voltage Level', level=2)
        VRG_Power_Data.Power_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)

def DV_3_26_PULSE_TRIGGER_MODE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    ULcolor = '#ff0000'
    LLcolor = '#0000ff'
    cint = 'RegWr00_COARSE_INTEGRATION_TIME_'
    reg1 = 'RegWr01_MODE_SELECT'
    reg2 = 'RegWr02_GPIO_CONTROL1'
    reg3 = 'RegWr03_GPIO_CONTROL2'
    frmCnt = 'RegVal_FRAME_COUNT_'
    gpio0 = 'Pin:GPIO0'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Light Level Values', level=2)
        VRG_General_Data.LightLevel_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Key Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, cint, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, reg1, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, reg2, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, reg3, showPlt)

        document.add_heading(i + ' Trigger Pin Level', level=2)
        VRG_Pins_Data.Pin_Plot(df_img, None, document, pltPath, gpio0, showPlt)

        document.add_heading(i + ' Frame Time', level=2)
        VRG_General_Data.FrameTime_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' PLL Clocks', level=2)
        VRG_General_Data.PLL_Clock_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' I2C Status', level=2)
        VRG_General_Data.I2C_Status_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Image Size Specifications', level=2)
        VRG_General_Data.FrameWidth_Plot(df_img, [die, temp], document, pltPath, showPlt)
        VRG_General_Data.FrameHeight_Plot(df_img, [die, temp], document, pltPath, showPlt)

        document.add_heading(i + ' Image Statistics vs. Die vs. Temperature', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, [die, temp], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, [die, temp], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowStdDev_Plot(df_img, [die, temp], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_img, [die, temp], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColStdDev_Plot(df_img, [die, temp], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_img, [die, temp], document, pltPath, showPlt)

        document.add_heading(i + 'Power & Current vs. Voltage Level', level=2)
        VRG_Power_Data.Power_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)

def DV_3_26_SHUTTER_SYNC_TRIGGER_MODE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    ULcolor = '#ff0000'
    LLcolor = '#0000ff'
    reg1 = 'RegWr00_LINE_LENGTH_PCK_'
    reg2 = 'RegWr01_GPIO_CONTROL1'
    reg3 = 'RegWr02_GPIO_SELECT'
    reg4 = 'RegWr03_GPIO_CONTROL2'
    reg5 = 'RegWr04_MODE_SELECT'
    reg6 = 'RegWr05_GRR_CONTROL1'
    reg7 = 'RegWr06_MODE_SELECT'
    frmCnt = 'RegVal_FRAME_COUNT_'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Light Level Values', level=2)
        VRG_General_Data.LightLevel_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Key Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, reg1, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, reg2, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, reg3, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, reg4, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, reg5, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, reg6, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, reg7, showPlt)

        document.add_heading(i + ' Frame Count', level=2)
        VRG_General_Data.FrameCount_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Frame Count Register', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, frmCnt, showPlt)

        document.add_heading(i + ' Integration Time', level=2)
        VRG_General_Data.Integration_Time_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Image Size Specifications', level=2)
        VRG_General_Data.FrameWidth_Plot(df_img, [die, temp], document, pltPath, showPlt)
        VRG_General_Data.FrameHeight_Plot(df_img, [die, temp], document, pltPath, showPlt)

        document.add_heading(i + ' Image Statistics vs. Die vs. Temperature', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, [die, temp], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, [die, temp], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_TotalNoise_Plot(df_img, [die, temp], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_FPN_Plot(df_img, [die, temp], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowStdDev_Plot(df_img, [die, temp], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_img, [die, temp], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowFPN_Plot(df_img, [die, temp], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColStdDev_Plot(df_img, [die, temp], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_img, [die, temp], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColFPN_Plot(df_img, [die, temp], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelTotalNoise_Plot(df_img, [die, temp], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_PixelFPN_Plot(df_img, [die, temp], document, pltPath, showPlt)

        document.add_heading(i + 'Power & Current vs. Voltage Level', level=2)
        VRG_Power_Data.Power_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)

    document.add_heading('ASIL Runtime vs. Imaging Modes', level=2)
    VRG_Safety_Data.SM_Runtime_Plot(df, 'ImgMode', document, pltPath, showPlt)

def DV_3_27_GLOBAL_RESET_RELEASE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_3_28_FLOATING_NODE_CHECK(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_3_29_COLUMN_BINNING_AND_ROW_SKIPPING(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    ULcolor = '#ff0000'
    LLcolor = '#0000ff'
    cint = 'RegWr00_COARSE_INTEGRATION_TIME_'
    bin_skip = 'DARK_CONTROL'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[bin_skip].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Light Level Values', level=2)
        VRG_General_Data.LightLevel_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Key Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, cint, showPlt)
        document.add_heading(i + ' Column Binning & Row Skipping Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, bin_skip, showPlt)

        document.add_heading(i + ' Image Stats vs. Column Binning & Row Skipping (Dark_Control)', level=2)
        VRG_Stats_Frame.Rgn_Mean_Plot(df_img, bin_skip, document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_StdDev_Plot(df_img, bin_skip, document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_TotalNoise_Plot(df_img, bin_skip, document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_FPN_Plot(df_img, bin_skip, document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_RowTotalNoise_Plot(df_img, bin_skip, document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_RowFPN_Plot(df_img, bin_skip, document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_ColTotalNoise_Plot(df_img, bin_skip, document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_ColFPN_Plot(df_img, bin_skip, document, pltPath, showPlt)

        for tst in TEST:  # Test
            df_test = VRG_Data_Frame.newdataframe(df_img, bin_skip, tst)
            document.add_heading(i + 'Image Stats vs. Column Binning & Row Skipping (Dark_Control = ' + str(tst) + ')',
                                 level=2)
            VRG_Stats_Frame.Rgn_Mean_Plot(df_test, bin_skip, document, pltPath, showPlt)
            VRG_Stats_Frame.Rgn_StdDev_Plot(df_test, bin_skip, document, pltPath, showPlt)
            VRG_Stats_Frame.Rgn_TotalNoise_Plot(df_test, bin_skip, document, pltPath, showPlt)
            VRG_Stats_Frame.Rgn_FPN_Plot(df_test, bin_skip, document, pltPath, showPlt)
            VRG_Stats_Frame.Rgn_RowTotalNoise_Plot(df_test, bin_skip, document, pltPath, showPlt)
            VRG_Stats_Frame.Rgn_RowFPN_Plot(df_test, bin_skip, document, pltPath, showPlt)
            VRG_Stats_Frame.Rgn_ColTotalNoise_Plot(df_test, bin_skip, document, pltPath, showPlt)
            VRG_Stats_Frame.Rgn_ColFPN_Plot(df_test, bin_skip, document, pltPath, showPlt)

            for tmp in TEMP:  # Temperature
                df_tmp = VRG_Data_Frame.newdataframe(df_test, temp, tmp)
                if tmp == nomTemp:
                    document.add_heading(
                        i + 'Image Capture vs. Column Binning & Row Skipping (Dark_Control = ' + str(
                            tst) + ') at (Temp = ' + str(tmp) + ')', level=2)
                    VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 2, document, showPlt)

        document.add_heading(i + ' Analog Test Rows vs. Column Binning & Row Skipping', level=2)
        VRG_Safety_Data.SM_Analog_Test_Rows_Plot(df_img, bin_skip, document, pltPath, showPlt)
        document.add_heading(i + ' RRC Data Values vs. Column Binning & Row Skipping', level=2)
        VRG_Safety_Data.SM_Row_Rom_Address_Columns_Plot(df_img, bin_skip, document, pltPath, showPlt)
        document.add_heading(i + ' RRC Signal Integrity Values vs. Column Binning & Row Skipping', level=2)
        VRG_Safety_Data.SM_Row_Rom_SIC_Plot(df_img, bin_skip, document, pltPath, showPlt)
        document.add_heading(i + ' Digital Test Rows vs. Column Binning & Row Skipping', level=2)
        VRG_Safety_Data.SM_Digital_Test_Rows_Plot(df_img, bin_skip, document, pltPath, showPlt)

        document.add_heading(i + 'Power & Current vs. Voltage Level', level=2)
        VRG_Power_Data.Power_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)

    document.add_heading('ASIL Runtime vs. Imaging Modes vs. Column Binning & Row Skipping', level=2)
    VRG_Safety_Data.SM_Runtime_Plot(df, ['ImgMode', bin_skip], document, pltPath, showPlt)

def DV_3_29_SKIPPING_SUB_SAMPLING(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    ULcolor = '#ff0000'
    LLcolor = '#0000ff'
    cint = 'RegWr00_COARSE_INTEGRATION_TIME_'
    bin_skip = 'DARK_CONTROL'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[bin_skip].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Light Level Values', level=2)
        VRG_General_Data.LightLevel_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Key Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, cint, showPlt)
        document.add_heading(i + ' Row Skipping Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, bin_skip, showPlt)

        document.add_heading(i + ' Image Stats vs. Row Skipping (Dark_Control)', level=2)
        VRG_Stats_Frame.Rgn_Mean_Plot(df_img, bin_skip, document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_StdDev_Plot(df_img, bin_skip, document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_TotalNoise_Plot(df_img, bin_skip, document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_FPN_Plot(df_img, bin_skip, document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_RowTotalNoise_Plot(df_img, bin_skip, document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_RowFPN_Plot(df_img, bin_skip, document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_ColTotalNoise_Plot(df_img, bin_skip, document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_ColFPN_Plot(df_img, bin_skip, document, pltPath, showPlt)

        for tst in TEST:  # Test
            df_test = VRG_Data_Frame.newdataframe(df_img, bin_skip, tst)
            document.add_heading(i + 'Image Stats vs. Row Skipping (Dark_Control = ' + str(tst) + ')',
                                 level=2)
            VRG_Stats_Frame.Rgn_Mean_Plot(df_test, bin_skip, document, pltPath, showPlt)
            VRG_Stats_Frame.Rgn_StdDev_Plot(df_test, bin_skip, document, pltPath, showPlt)
            VRG_Stats_Frame.Rgn_TotalNoise_Plot(df_test, bin_skip, document, pltPath, showPlt)
            VRG_Stats_Frame.Rgn_FPN_Plot(df_test, bin_skip, document, pltPath, showPlt)
            VRG_Stats_Frame.Rgn_RowTotalNoise_Plot(df_test, bin_skip, document, pltPath, showPlt)
            VRG_Stats_Frame.Rgn_RowFPN_Plot(df_test, bin_skip, document, pltPath, showPlt)
            VRG_Stats_Frame.Rgn_ColTotalNoise_Plot(df_test, bin_skip, document, pltPath, showPlt)
            VRG_Stats_Frame.Rgn_ColFPN_Plot(df_test, bin_skip, document, pltPath, showPlt)

            for tmp in TEMP:  # Temperature
                df_tmp = VRG_Data_Frame.newdataframe(df_test, temp, tmp)
                if tmp == nomTemp:
                    document.add_heading(
                        i + 'Image Capture vs. Row Skipping (Dark_Control = ' + str(tst) + ') at (Temp = ' + str(
                            tmp) + ')', level=2)
                    VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 2, document, showPlt)

        document.add_heading(i + ' Analog Test Rows', level=2)
        VRG_Safety_Data.SM_Analog_Test_Rows_Plot(df_img, bin_skip, document, pltPath, showPlt)
        document.add_heading(i + ' RRC Data Values', level=2)
        VRG_Safety_Data.SM_Row_Rom_Address_Columns_Plot(df_img, bin_skip, document, pltPath, showPlt)
        document.add_heading(i + ' RRC Signal Integrity Values', level=2)
        VRG_Safety_Data.SM_Row_Rom_SIC_Plot(df_img, bin_skip, document, pltPath, showPlt)
        document.add_heading(i + ' Digital Test Rows', level=2)
        VRG_Safety_Data.SM_Digital_Test_Rows_Plot(df_img, bin_skip, document, pltPath, showPlt)

        document.add_heading(i + 'Power & Current vs. Voltage Level', level=2)
        VRG_Power_Data.Power_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)

    document.add_heading('ASIL Runtime vs. Imaging Modes', level=2)
    VRG_Safety_Data.SM_Runtime_Plot(df, 'ImgMode', document, pltPath, showPlt)

def DV_3_30_ANALOG_BINNING(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    ULcolor = '#ff0000'
    LLcolor = '#0000ff'
    cint = 'RegWr00_COARSE_INTEGRATION_TIME_'
    bin_skip = 'DARK_CONTROL'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[bin_skip].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Light Level Values', level=2)
        VRG_General_Data.LightLevel_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Key Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, cint, showPlt)
        document.add_heading(i + ' Column Binning Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, bin_skip, showPlt)

        document.add_heading(i + ' Image Stats vs. Column Binning(Dark_Control)', level=2)
        VRG_Stats_Frame.Rgn_Mean_Plot(df_img, bin_skip, document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_StdDev_Plot(df_img, bin_skip, document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_TotalNoise_Plot(df_img, bin_skip, document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_FPN_Plot(df_img, bin_skip, document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_RowTotalNoise_Plot(df_img, bin_skip, document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_RowFPN_Plot(df_img, bin_skip, document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_ColTotalNoise_Plot(df_img, bin_skip, document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_ColFPN_Plot(df_img, bin_skip, document, pltPath, showPlt)

        for tst in TEST:  # Test
            df_test = VRG_Data_Frame.newdataframe(df_img, bin_skip, tst)
            document.add_heading(i + 'Image Stats vs. Column Binning (Dark_Control = ' + str(tst) + ')',
                                 level=2)
            VRG_Stats_Frame.Rgn_Mean_Plot(df_test, bin_skip, document, pltPath, showPlt)
            VRG_Stats_Frame.Rgn_StdDev_Plot(df_test, bin_skip, document, pltPath, showPlt)
            VRG_Stats_Frame.Rgn_TotalNoise_Plot(df_test, bin_skip, document, pltPath, showPlt)
            VRG_Stats_Frame.Rgn_FPN_Plot(df_test, bin_skip, document, pltPath, showPlt)
            VRG_Stats_Frame.Rgn_RowTotalNoise_Plot(df_test, bin_skip, document, pltPath, showPlt)
            VRG_Stats_Frame.Rgn_RowFPN_Plot(df_test, bin_skip, document, pltPath, showPlt)
            VRG_Stats_Frame.Rgn_ColTotalNoise_Plot(df_test, bin_skip, document, pltPath, showPlt)
            VRG_Stats_Frame.Rgn_ColFPN_Plot(df_test, bin_skip, document, pltPath, showPlt)

            for tmp in TEMP:  # Temperature
                df_tmp = VRG_Data_Frame.newdataframe(df_test, temp, tmp)
                if tmp == nomTemp:
                    document.add_heading(
                        i + 'Image Capture vs. Column Binning (Dark_Control = ' + str(
                            tst) + + ') at (Temp = ' + str(tmp) + ')', level=2)
                    VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 2, document, showPlt)

        document.add_heading(i + ' Analog Test Rows', level=2)
        VRG_Safety_Data.SM_Analog_Test_Rows_Plot(df_img, bin_skip, document, pltPath, showPlt)
        document.add_heading(i + ' RRC Data Values', level=2)
        VRG_Safety_Data.SM_Row_Rom_Address_Columns_Plot(df_img, bin_skip, document, pltPath, showPlt)
        document.add_heading(i + ' RRC Signal Integrity Values', level=2)
        VRG_Safety_Data.SM_Row_Rom_SIC_Plot(df_img, bin_skip, document, pltPath, showPlt)
        document.add_heading(i + ' Digital Test Rows', level=2)
        VRG_Safety_Data.SM_Digital_Test_Rows_Plot(df_img, bin_skip, document, pltPath, showPlt)

        document.add_heading(i + 'Power & Current vs. Voltage Level', level=2)
        VRG_Power_Data.Power_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)

    document.add_heading('ASIL Runtime vs. Imaging Modes', level=2)
    VRG_Safety_Data.SM_Runtime_Plot(df, 'ImgMode', document, pltPath, showPlt)

def DV_3_31_SCALAR(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_3_32_DYNAMIC_POWER_MODE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_3_33_SLAVE_MODE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    slaveAddr = 'DVM_3_33_Slave_Address'
    shipAddr = 'SENSOR_SHIP_ADDRESS'
    i2cStatus = 'I2C Status'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, None, document, pltPath, showPlt)  # Temperature for each val test
    VRG_General_Data.Clk_Frequency_Plot(df, None, document, pltPath, showPlt)  # Plot each frequency for each test
    VRG_General_Data.TestTime_Plot(df, None, document, pltPath, showPlt)  # Time to run each val test
    VRG_General_Data.RunNumber_Plot(df, None, document, pltPath, showPlt)  # Val test run number
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)

    document.add_heading('I2CIDS Registers vs. Test', level=2)
    VRG_Register_Data.I2CIDS_Register_Plot(df, None, document, pltPath, showPlt)
    document.add_heading('PLL Clocks vs. Test', level=2)
    VRG_General_Data.PLL_Clock_Plot(df, None, document, pltPath, showPlt)
    document.add_heading('PLL Clocks vs. Slave Address', level=2)
    VRG_General_Data.Reg_vs_PLL_Clock_Plot(df, None, document, pltPath, slaveAddr, showPlt)

    document.add_heading('All Imaging Modes')
    document.add_heading('SADDR Pin Levels', level=2)
    VRG_Pins_Data.SADDR_Plot_3_Pins(df, ['Power', temp], document, pltPath, showPlt)
    VRG_Macro_Data.Macro_vs_Step_Plot(df, 'Power', document, pltPath, slaveAddr, showPlt)
    document.add_heading('Slave Addresses', level=2)
    VRG_Register_Data.Reg_vs_Step_Plot(df, ['Power', temp], document, pltPath, shipAddr, showPlt)
    document.add_heading('SADDR vs Slave Addresses', level=2)
    VRG_Macro_Data.Reg_vs_Macro_Plot(df, 'Power', document, pltPath, shipAddr, slaveAddr, showPlt)
    document.add_heading(i2cStatus, level=2)
    VRG_General_Data.I2C_Status_Plot(df, ['Power', temp], document, pltPath, showPlt)
    document.add_heading('I2C Status vs SADDR', level=2)
    VRG_Macro_Data.Reg_vs_Macro_Plot(df, ['Power', temp], document, pltPath, i2cStatus, slaveAddr,
                                     showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' SADDR Pin Levels', level=2)
        VRG_Pins_Data.SADDR_Plot_3_Pins(df_img, ['Power', temp], document, pltPath, showPlt)
        VRG_Macro_Data.Macro_vs_Step_Plot(df_img, 'Power', document, pltPath, slaveAddr, showPlt)
        document.add_heading(i + ' Slave Addresses', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, ['Power', temp], document, pltPath, shipAddr, showPlt)
        document.add_heading(i + ' SADDR vs Slave Addresses', level=2)
        VRG_Macro_Data.Reg_vs_Macro_Plot(df_img, ['Power', temp], document, pltPath, shipAddr, slaveAddr, showPlt)
        document.add_heading(i + ' I2C Status', level=2)
        VRG_General_Data.I2C_Status_Plot(df_img, ['Power', temp], document, pltPath, showPlt)
        document.add_heading(i + ' I2C Status vs SADDR', level=2)
        VRG_Macro_Data.Reg_vs_Macro_Plot(df_img, ['Power', temp], document, pltPath, i2cStatus, slaveAddr,
                                         showPlt)

def DV_3_34_COLUMN_SHUFFLE_MODE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    ULcolor = '#ff0000'
    LLcolor = '#0000ff'
    cint = 'RegWr00_COARSE_INTEGRATION_TIME_'
    crmControl = 'RegWr01_CRM_CONTROL'
    hMirror = 'RegWr02_READ_MODE__READ_MODE_HORIZ_MIRROR'
    vFlip = 'RegWr03_READ_MODE__READ_MODE_VERT_FLIP'
    normalOp = 0

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[crmControl].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)
        df_img_normalOp = VRG_Data_Frame.newdataframe(df_img, hMirror, normalOp)
        df_normalOp = VRG_Data_Frame.newdataframe(df_img_normalOp, vFlip, normalOp)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Light Level Values', level=2)
        VRG_General_Data.LightLevel_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Key Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, cint, showPlt)
        document.add_heading(i + ' CRM Control Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, crmControl, showPlt)
        document.add_heading(i + ' Horizontal Mirror Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, hMirror, showPlt)
        document.add_heading(i + ' Vertical Flip Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, vFlip, showPlt)

        document.add_heading(i + ' Image Stats vs. CRM Control', level=2)
        VRG_Stats_Frame.Rgn_Mean_Plot(df_img, crmControl, document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_StdDev_Plot(df_img, crmControl, document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_TotalNoise_Plot(df_img, crmControl, document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_FPN_Plot(df_img, crmControl, document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_RowTotalNoise_Plot(df_img, crmControl, document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_RowFPN_Plot(df_img, crmControl, document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_ColTotalNoise_Plot(df_img, crmControl, document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_ColFPN_Plot(df_img, crmControl, document, pltPath, showPlt)

        for tst in TEST:  # Test
            df_test = VRG_Data_Frame.newdataframe(df_img, crmControl, tst)
            document.add_heading(i + 'Image Stats vs. CRM Control = ' + str(tst) + ') vs. Flip and Mirror', level=2)
            VRG_Stats_Frame.Rgn_Mean_Plot(df_test, [hMirror, vFlip], document, pltPath, showPlt)
            VRG_Stats_Frame.Rgn_StdDev_Plot(df_test, [hMirror, vFlip], document, pltPath, showPlt)
            VRG_Stats_Frame.Rgn_TotalNoise_Plot(df_test, [hMirror, vFlip], document, pltPath, showPlt)
            VRG_Stats_Frame.Rgn_FPN_Plot(df_test, [hMirror, vFlip], document, pltPath, showPlt)
            VRG_Stats_Frame.Rgn_RowTotalNoise_Plot(df_test, [hMirror, vFlip], document, pltPath, showPlt)
            VRG_Stats_Frame.Rgn_RowFPN_Plot(df_test, [hMirror, vFlip], document, pltPath, showPlt)
            VRG_Stats_Frame.Rgn_ColTotalNoise_Plot(df_test, [hMirror, vFlip], document, pltPath, showPlt)
            VRG_Stats_Frame.Rgn_ColFPN_Plot(df_test, [hMirror, vFlip], document, pltPath, showPlt)

        for tmp in TEMP:  # Temperature
            df_tmp = VRG_Data_Frame.newdataframe(df_img, temp, tmp)
            if tmp == nomTemp:
                document.add_heading(i + 'Image Capture vs. CRM Control at (Temp = ' + str(tmp) + ')', level=2)
                VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 2, document, showPlt)
                VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 5, document, showPlt)
                VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 8, document, showPlt)
                VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 11, document, showPlt)
                VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 14, document, showPlt)

        document.add_heading(i + ' Analog Test Rows vs. CRM Control', level=2)
        VRG_Safety_Data.SM_Analog_Test_Rows_Plot(df_img, crmControl, document, pltPath, showPlt)
        document.add_heading(i + ' RRC Data Values vs. CRM Control', level=2)
        VRG_Safety_Data.SM_Row_Rom_Address_Columns_Plot(df_img, crmControl, document, pltPath, showPlt)
        document.add_heading(i + ' RRC Signal Integrity Values vs. CRM Control', level=2)
        VRG_Safety_Data.SM_Row_Rom_SIC_Plot(df_img, crmControl, document, pltPath, showPlt)
        document.add_heading(i + ' Digital Test Rows vs. CRM Control', level=2)
        VRG_Safety_Data.SM_Digital_Test_Rows_Plot(df_img, crmControl, document, pltPath, showPlt)

        document.add_heading(i + 'Power & Current vs. Voltage Level', level=2)
        VRG_Power_Data.Power_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)

    document.add_heading('ASIL Runtime vs. Imaging Modes', level=2)
    VRG_Safety_Data.SM_Runtime_Plot(df, 'ImgMode', document, pltPath, showPlt)

def DV_3_35_HORIZONTAL_SHADING_CORRECTION(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_3_36_GLOBAL_GRADIENT_REMOVAL(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_3_37_DIGITAL_CROP_WINDOWING(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    ULcolor = '#ff0000'
    LLcolor = '#0000ff'
    cint = 'RegWr00_COARSE_INTEGRATION_TIME_'
    imgSizeMacro = 'Macro5'
    reg1 = 'RegVal_Y_ADDR_START_'
    reg2 = 'RegVal_X_ADDR_START_'
    reg3 = 'RegVal_Y_ADDR_END_'
    reg4 = 'RegVal_X_ADDR_END_'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[imgSizeMacro].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i + ' Image Size Registers', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, reg1, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, reg2, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, reg3, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, reg4, showPlt)
        document.add_heading(i + ' Image Sizes', level=2)
        VRG_General_Data.FrameWidth_Plot(df_img, None, document, pltPath, showPlt)
        VRG_General_Data.FrameHeight_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Actual Image Sizes vs. Calculated Image Size', level=2)
        VRG_Calculate.Calc_FrameSize_Plot(df_img, None, document, pltPath, reg2, reg4, reg1, reg3, showPlt)

        document.add_heading(i + ' Image Stats', level=2)
        VRG_Stats_Frame.Rgn_Mean_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_StdDev_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_TotalNoise_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_FPN_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_RowTotalNoise_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_RowFPN_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_ColTotalNoise_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_ColFPN_Plot(df_img, None, document, pltPath, showPlt)

        for tst in TEST:  # Test
            df_test = VRG_Data_Frame.newdataframe(df_img, imgSizeMacro, tst)
            document.add_heading(i + ' Image Stats vs. Image Size = ' + str(tst) + ')', level=2)
            VRG_Register_Data.Reg_vs_Step_Plot(df_test, None, document, pltPath, reg1, showPlt)
            VRG_Register_Data.Reg_vs_Step_Plot(df_test, None, document, pltPath, reg2, showPlt)
            VRG_Register_Data.Reg_vs_Step_Plot(df_test, None, document, pltPath, reg3, showPlt)
            VRG_Register_Data.Reg_vs_Step_Plot(df_test, None, document, pltPath, reg4, showPlt)

            document.add_heading(i + ' Frame Width & Height for Expected Image Size = ' + str(tst) + ')', level=2)
            VRG_General_Data.FrameWidth_Plot(df_test, None, document, pltPath, showPlt)
            VRG_General_Data.FrameHeight_Plot(df_test, None, document, pltPath, showPlt)

            document.add_heading(i + ' Actual Image Sizes vs. Calculated Image Size = ' + str(tst) + ')', level=2)
            VRG_Calculate.Calc_FrameSize_Plot(df_test, None, document, pltPath, reg2, reg4, reg1, reg3, showPlt)

            document.add_heading(i + ' Image Stats vs. Expected Image Size = ' + str(tst) + ')', level=2)
            VRG_Stats_Frame.Rgn_Mean_Plot(df_test, None, document, pltPath, showPlt)
            VRG_Stats_Frame.Rgn_StdDev_Plot(df_test, None, document, pltPath, showPlt)
            VRG_Stats_Frame.Rgn_TotalNoise_Plot(df_test, None, document, pltPath, showPlt)
            VRG_Stats_Frame.Rgn_FPN_Plot(df_test, None, document, pltPath, showPlt)
            VRG_Stats_Frame.Rgn_RowTotalNoise_Plot(df_test, None, document, pltPath, showPlt)
            VRG_Stats_Frame.Rgn_RowFPN_Plot(df_test, None, document, pltPath, showPlt)
            VRG_Stats_Frame.Rgn_ColTotalNoise_Plot(df_test, None, document, pltPath, showPlt)
            VRG_Stats_Frame.Rgn_ColFPN_Plot(df_test, None, document, pltPath, showPlt)

            document.add_heading(i + ' Analog Test Rows vs. Expected Image Size = ' + str(tst) + ')', level=2)
            VRG_Safety_Data.SM_Analog_Test_Rows_Plot(df_test, None, document, pltPath, showPlt)
            document.add_heading(i + ' RRC Data Values vs. Expected Image Size = ' + str(tst) + ')', level=2)
            VRG_Safety_Data.SM_Row_Rom_Address_Columns_Plot(df_test, None, document, pltPath, showPlt)
            document.add_heading(i + ' RRC Signal Integrity Values vs. Expected Image Size = ' + str(tst) + ')',
                                 level=2)
            VRG_Safety_Data.SM_Row_Rom_SIC_Plot(df_test, None, document, pltPath, showPlt)
            document.add_heading(i + ' Digital Test Rows vs. Expected Image Size = ' + str(tst) + ')', level=2)
            VRG_Safety_Data.SM_Digital_Test_Rows_Plot(df_test, None, document, pltPath, showPlt)

        document.add_heading(i + 'Power & Current vs. Voltage Level', level=2)
        VRG_Power_Data.Power_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)

    document.add_heading('ASIL Runtime vs. Imaging Modes', level=2)
    VRG_Safety_Data.SM_Runtime_Plot(df, 'ImgMode', document, pltPath, showPlt)

def DV_3_39_HDR_MULTIPLE_EXPOSURE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    cint = 'RegWr00_COARSE_INTEGRATION_TIME_'
    bypassReg = 'RegWr01_LFM2_T1_CTRL'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[bypassReg].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Light Level Values', level=2)
        VRG_General_Data.LightLevel_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Key Registers', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, cint, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, bypassReg, showPlt)

        document.add_heading(i + ' Image Stats vs. Integration Time', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, cint, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, cint, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowStdDev_Plot(df_img, cint, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_img, cint, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColStdDev_Plot(df_img, cint, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_img, cint, document, pltPath, showPlt)

        document.add_heading(i + ' Image Stats vs. Exposure Bypass vs Integration Time', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, [bypassReg, cint], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, [bypassReg, cint], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowStdDev_Plot(df_img, [bypassReg, cint], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_img, [bypassReg, cint], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColStdDev_Plot(df_img, [bypassReg, cint], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_img, [bypassReg, cint], document, pltPath, showPlt)

        document.add_heading(i + ' Image Stats vs. Light Level vs Integration Time', level=2)
        VRG_Stats_Frame.Reg_vs_Img_Mean_Plot(df_img, cint, document, pltPath, 'Light', showPlt)
        VRG_Stats_Frame.Reg_vs_Img_StdDev_Plot(df_img, cint, document, pltPath, 'Light', showPlt)
        VRG_Stats_Frame.Reg_vs_Img_RowStdDev_Plot(df_img, cint, document, pltPath, 'Light', showPlt)
        VRG_Stats_Frame.Reg_vs_Img_RowTotalNoise_Plot(df_img, cint, document, pltPath, 'Light', showPlt)
        VRG_Stats_Frame.Reg_vs_Img_ColStdDev_Plot(df_img, cint, document, pltPath, 'Light', showPlt)
        VRG_Stats_Frame.Reg_vs_Img_ColTotalNoise_Plot(df_img, cint, document, pltPath, 'Light', showPlt)

        for tst in TEST:  # Test
            df_test = VRG_Data_Frame.newdataframe(df_img, bypassReg, tst)

            document.add_heading(i + ' Image Stats vs. Exposure Bypass = ' + str(tst) + ')', level=2)
            VRG_Stats_Arr.Arr_Mean_Plot(df_test, cint, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_StdDev_Plot(df_test, cint, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_RowStdDev_Plot(df_test, cint, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_test, cint, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_ColStdDev_Plot(df_test, cint, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_test, cint, document, pltPath, showPlt)

            document.add_heading(i + ' Image Stats vs. Light Level vs. Exposure Bypass = ' + str(tst) + ')', level=2)
            VRG_Stats_Frame.Reg_vs_Img_Mean_Plot(df_test, cint, document, pltPath, 'Light', showPlt)
            VRG_Stats_Frame.Reg_vs_Img_StdDev_Plot(df_test, cint, document, pltPath, 'Light', showPlt)
            VRG_Stats_Frame.Reg_vs_Img_RowStdDev_Plot(df_test, cint, document, pltPath, 'Light', showPlt)
            VRG_Stats_Frame.Reg_vs_Img_RowTotalNoise_Plot(df_test, cint, document, pltPath, 'Light', showPlt)
            VRG_Stats_Frame.Reg_vs_Img_ColStdDev_Plot(df_test, cint, document, pltPath, 'Light', showPlt)
            VRG_Stats_Frame.Reg_vs_Img_ColTotalNoise_Plot(df_test, cint, document, pltPath, 'Light', showPlt)

            for tmp in TEMP:  # Temperature
                df_tmp = VRG_Data_Frame.newdataframe(df_img, temp, tmp)
                if tmp == nomTemp:
                    document.add_heading(
                        i + 'Image Capture vs. Exposure Bypass =  at ' + str(tst) + ')' + ' at (Temp = ' + str(
                            tmp) + ')', level=2)
                    VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 14, document, showPlt)
                    VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 17, document, showPlt)
                    VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 20, document, showPlt)
                    VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 23, document, showPlt)

        document.add_heading(i + 'Power & Current vs. Voltage Level', level=2)
        VRG_Power_Data.Power_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)

    document.add_heading('ASIL Runtime vs. Imaging Mode', level=2)
    VRG_Safety_Data.SM_Runtime_Plot(df, 'ImgMode', document, pltPath, showPlt)

def DV_3_39_SE_MULTIPLE_EXPOSURE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    cint = 'RegWr00_COARSE_INTEGRATION_TIME_'
    bypassReg = 'RegWr01_LFM2_T1_CTRL'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[bypassReg].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Light Level Values', level=2)
        VRG_General_Data.LightLevel_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Key Registers', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, cint, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, bypassReg, showPlt)

        document.add_heading(i + ' Image Stats vs. Integration Time', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, cint, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, cint, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowStdDev_Plot(df_img, cint, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_img, cint, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColStdDev_Plot(df_img, cint, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_img, cint, document, pltPath, showPlt)

        document.add_heading(i + ' Image Stats vs. Exposure Bypass vs Integration Time', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, [bypassReg, cint], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, [bypassReg, cint], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowStdDev_Plot(df_img, [bypassReg, cint], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_img, [bypassReg, cint], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColStdDev_Plot(df_img, [bypassReg, cint], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_img, [bypassReg, cint], document, pltPath, showPlt)

        document.add_heading(i + ' Image Stats vs. Light Level vs Integration Time', level=2)
        VRG_Stats_Frame.Reg_vs_Img_Mean_Plot(df_img, cint, document, pltPath, 'Light', showPlt)
        VRG_Stats_Frame.Reg_vs_Img_StdDev_Plot(df_img, cint, document, pltPath, 'Light', showPlt)
        VRG_Stats_Frame.Reg_vs_Img_RowStdDev_Plot(df_img, cint, document, pltPath, 'Light', showPlt)
        VRG_Stats_Frame.Reg_vs_Img_RowTotalNoise_Plot(df_img, cint, document, pltPath, 'Light', showPlt)
        VRG_Stats_Frame.Reg_vs_Img_ColStdDev_Plot(df_img, cint, document, pltPath, 'Light', showPlt)
        VRG_Stats_Frame.Reg_vs_Img_ColTotalNoise_Plot(df_img, cint, document, pltPath, 'Light', showPlt)

        for tst in TEST:  # Test
            df_test = VRG_Data_Frame.newdataframe(df_img, bypassReg, tst)

            document.add_heading(i + ' Image Stats vs. Exposure Bypass = ' + str(tst) + ')', level=2)
            VRG_Stats_Arr.Arr_Mean_Plot(df_test, cint, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_StdDev_Plot(df_test, cint, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_RowStdDev_Plot(df_test, cint, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_test, cint, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_ColStdDev_Plot(df_test, cint, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_test, cint, document, pltPath, showPlt)

            document.add_heading(i + ' Image Stats vs. Light Level vs. Exposure Bypass = ' + str(tst) + ')', level=2)
            VRG_Stats_Frame.Reg_vs_Img_Mean_Plot(df_test, cint, document, pltPath, 'Light', showPlt)
            VRG_Stats_Frame.Reg_vs_Img_StdDev_Plot(df_test, cint, document, pltPath, 'Light', showPlt)
            VRG_Stats_Frame.Reg_vs_Img_RowStdDev_Plot(df_test, cint, document, pltPath, 'Light', showPlt)
            VRG_Stats_Frame.Reg_vs_Img_RowTotalNoise_Plot(df_test, cint, document, pltPath, 'Light', showPlt)
            VRG_Stats_Frame.Reg_vs_Img_ColStdDev_Plot(df_test, cint, document, pltPath, 'Light', showPlt)
            VRG_Stats_Frame.Reg_vs_Img_ColTotalNoise_Plot(df_test, cint, document, pltPath, 'Light', showPlt)

            for tmp in TEMP:  # Temperature
                df_tmp = VRG_Data_Frame.newdataframe(df_img, temp, tmp)
                if tmp == nomTemp:
                    document.add_heading(
                        i + 'Image Capture vs. Exposure Bypass =  at ' + str(tst) + ')' + ' at (Temp = ' + str(
                            tmp) + ')', level=2)
                    VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 14, document, showPlt)
                    VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 17, document, showPlt)
                    VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 20, document, showPlt)
                    VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 23, document, showPlt)

        document.add_heading(i + 'Power & Current vs. Voltage Level', level=2)
        VRG_Power_Data.Power_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)

    document.add_heading('ASIL Runtime vs. Imaging Mode', level=2)
    VRG_Safety_Data.SM_Runtime_Plot(df, 'ImgMode', document, pltPath, showPlt)

def DV_3_40_IHDR_INTERLACED_HDR(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_3_41_LINE_INTERLEAVED_HDR_AMBARELLA_READOUT_MODE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_3_41_DUAL_OUTPUT_MODE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_3_42_HDR_COMPANDING(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_3_43_GLOBAL_SHUTTER(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_3_44_LED_FLICKER_MITIGATION(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_3_45_EXPOSURE_TEST(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    cint = 'RegWr00_COARSE_INTEGRATION_TIME_'
    cintTime = 'Integration_Time (ms)'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Light Level Values', level=2)
        VRG_General_Data.LightLevel_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Integration Time Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, cint, showPlt)

        document.add_heading(i + ' Integration Time', level=2)
        VRG_General_Data.Integration_Time_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Integration Time vs. Integration Register Value', level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, cintTime, cint, showPlt)

        document.add_heading(i + ' Image Stats', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowStdDev_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColStdDev_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Image Stats vs. Light Level vs Integration Time', level=2)
        VRG_Stats_Frame.Reg_vs_Img_Mean_Plot(df_img, 'Light', document, pltPath, cint, showPlt)
        VRG_Stats_Frame.Reg_vs_Img_StdDev_Plot(df_img, 'Light', document, pltPath, cint, showPlt)
        VRG_Stats_Frame.Reg_vs_Img_RowStdDev_Plot(df_img, 'Light', document, pltPath, cint, showPlt)
        VRG_Stats_Frame.Reg_vs_Img_RowTotalNoise_Plot(df_img, 'Light', document, pltPath, cint, showPlt)
        VRG_Stats_Frame.Reg_vs_Img_ColStdDev_Plot(df_img, 'Light', document, pltPath, cint, showPlt)
        VRG_Stats_Frame.Reg_vs_Img_ColTotalNoise_Plot(df_img, 'Light', document, pltPath, cint, showPlt)

        for tmp in TEMP:  # Temperature
            df_tmp = VRG_Data_Frame.newdataframe(df_img, temp, tmp)
            if tmp == nomTemp:
                document.add_heading(i + 'Image Capture vs. Integration Time at (Temp = ' + str(tmp) + ')', level=2)
                VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 2, document, showPlt)
                VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 179, document, showPlt)
                VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 299, document, showPlt)

        document.add_heading(i + ' Analog Test Rows', level=2)
        VRG_Safety_Data.SM_Analog_Test_Rows_Plot(df_img, 'Power', document, pltPath, showPlt)
        document.add_heading(i + ' RRC Data Values', level=2)
        VRG_Safety_Data.SM_Row_Rom_Address_Columns_Plot(df_img, 'Power', document, pltPath, showPlt)
        document.add_heading(i + ' RRC Signal Integrity Values', level=2)
        VRG_Safety_Data.SM_Row_Rom_SIC_Plot(df_img, 'Power', document, pltPath, showPlt)
        document.add_heading(i + ' Digital Test Rows', level=2)
        VRG_Safety_Data.SM_Digital_Test_Rows_Plot(df_img, 'Power', document, pltPath, showPlt)

        document.add_heading(i + 'Power & Current vs. Voltage Level', level=2)
        VRG_Power_Data.Power_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)

    document.add_heading('ASIL Runtime vs. Imaging Mode', level=2)
    VRG_Safety_Data.SM_Runtime_Plot(df, 'ImgMode', document, pltPath, showPlt)

def DV_3_45_EXPOSURE_TEST_T1(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    cint = 'RegWr00_COARSE_INTEGRATION_TIME_'
    cintTime = 'Integration_Time (ms)'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Light Level Values', level=2)
        VRG_General_Data.LightLevel_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Integration Time Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, cint, showPlt)

        document.add_heading(i + ' Integration Time', level=2)
        VRG_General_Data.Integration_Time_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Integration Time vs. Integration Register Value', level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, cintTime, cint, showPlt)

        document.add_heading(i + ' Image Stats', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowStdDev_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColStdDev_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Image Stats vs. Light Level vs Integration Time', level=2)
        VRG_Stats_Frame.Reg_vs_Img_Mean_Plot(df_img, 'Light', document, pltPath, cint, showPlt)
        VRG_Stats_Frame.Reg_vs_Img_StdDev_Plot(df_img, 'Light', document, pltPath, cint, showPlt)
        VRG_Stats_Frame.Reg_vs_Img_RowStdDev_Plot(df_img, 'Light', document, pltPath, cint, showPlt)
        VRG_Stats_Frame.Reg_vs_Img_RowTotalNoise_Plot(df_img, 'Light', document, pltPath, cint, showPlt)
        VRG_Stats_Frame.Reg_vs_Img_ColStdDev_Plot(df_img, 'Light', document, pltPath, cint, showPlt)
        VRG_Stats_Frame.Reg_vs_Img_ColTotalNoise_Plot(df_img, 'Light', document, pltPath, cint, showPlt)

        for tmp in TEMP:  # Temperature
            df_tmp = VRG_Data_Frame.newdataframe(df_img, temp, tmp)
            if tmp == nomTemp:
                document.add_heading(i + 'Image Capture vs. Integration Time at (Temp = ' + str(tmp) + ')', level=2)
                VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 2, document, showPlt)
                VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 179, document, showPlt)
                VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 299, document, showPlt)

        document.add_heading(i + ' Analog Test Rows', level=2)
        VRG_Safety_Data.SM_Analog_Test_Rows_Plot(df_img, 'Power', document, pltPath, showPlt)
        document.add_heading(i + ' RRC Data Values', level=2)
        VRG_Safety_Data.SM_Row_Rom_Address_Columns_Plot(df_img, 'Power', document, pltPath, showPlt)
        document.add_heading(i + ' RRC Signal Integrity Values', level=2)
        VRG_Safety_Data.SM_Row_Rom_SIC_Plot(df_img, 'Power', document, pltPath, showPlt)
        document.add_heading(i + ' Digital Test Rows', level=2)
        VRG_Safety_Data.SM_Digital_Test_Rows_Plot(df_img, 'Power', document, pltPath, showPlt)

        document.add_heading(i + 'Power & Current vs. Voltage Level', level=2)
        VRG_Power_Data.Power_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)

    document.add_heading('ASIL Runtime vs. Imaging Mode', level=2)
    VRG_Safety_Data.SM_Runtime_Plot(df, 'ImgMode', document, pltPath, showPlt)

def DV_3_45_EXPOSURE_TEST_EXPOSURE_RATIO(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    cint = 'RegWr00_COARSE_INTEGRATION_TIME_'
    cintTime = 'Integration_Time (ms)'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Light Level Values', level=2)
        VRG_General_Data.LightLevel_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Integration Time Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, cint, showPlt)

        document.add_heading(i + ' Integration Time', level=2)
        VRG_General_Data.Integration_Time_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Integration Time vs. Integration Register Value', level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, cintTime, cint, showPlt)

        document.add_heading(i + ' Image Stats', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowStdDev_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColStdDev_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Image Stats vs. Light Level vs Integration Time', level=2)
        VRG_Stats_Frame.Reg_vs_Img_Mean_Plot(df_img, 'Light', document, pltPath, cint, showPlt)
        VRG_Stats_Frame.Reg_vs_Img_StdDev_Plot(df_img, 'Light', document, pltPath, cint, showPlt)
        VRG_Stats_Frame.Reg_vs_Img_RowStdDev_Plot(df_img, 'Light', document, pltPath, cint, showPlt)
        VRG_Stats_Frame.Reg_vs_Img_RowTotalNoise_Plot(df_img, 'Light', document, pltPath, cint, showPlt)
        VRG_Stats_Frame.Reg_vs_Img_ColStdDev_Plot(df_img, 'Light', document, pltPath, cint, showPlt)
        VRG_Stats_Frame.Reg_vs_Img_ColTotalNoise_Plot(df_img, 'Light', document, pltPath, cint, showPlt)

        for tmp in TEMP:  # Temperature
            df_tmp = VRG_Data_Frame.newdataframe(df_img, temp, tmp)
            if tmp == nomTemp:
                document.add_heading(i + 'Image Capture vs. Integration Time at (Temp = ' + str(tmp) + ')', level=2)
                VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 2, document, showPlt)
                VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 179, document, showPlt)
                VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 299, document, showPlt)

        document.add_heading(i + ' Analog Test Rows', level=2)
        VRG_Safety_Data.SM_Analog_Test_Rows_Plot(df_img, 'Power', document, pltPath, showPlt)
        document.add_heading(i + ' RRC Data Values', level=2)
        VRG_Safety_Data.SM_Row_Rom_Address_Columns_Plot(df_img, 'Power', document, pltPath, showPlt)
        document.add_heading(i + ' RRC Signal Integrity Values', level=2)
        VRG_Safety_Data.SM_Row_Rom_SIC_Plot(df_img, 'Power', document, pltPath, showPlt)
        document.add_heading(i + ' Digital Test Rows', level=2)
        VRG_Safety_Data.SM_Digital_Test_Rows_Plot(df_img, 'Power', document, pltPath, showPlt)

        document.add_heading(i + 'Power & Current vs. Voltage Level', level=2)
        VRG_Power_Data.Power_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)

    document.add_heading('ASIL Runtime vs. Imaging Mode', level=2)
    VRG_Safety_Data.SM_Runtime_Plot(df, 'ImgMode', document, pltPath, showPlt)

def DV_3_45_EXPOSURE_TEST_T2(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    cint = 'RegWr00_COARSE_INTEGRATION_TIME_'
    cintTime = 'Integration_Time (ms)'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Light Level Values', level=2)
        VRG_General_Data.LightLevel_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Integration Time Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, cint, showPlt)

        document.add_heading(i + ' Integration Time', level=2)
        VRG_General_Data.Integration_Time_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Integration Time vs. Integration Register Value', level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, cintTime, cint, showPlt)

        document.add_heading(i + ' Image Stats', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowStdDev_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColStdDev_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Image Stats vs. Light Level vs Integration Time', level=2)
        VRG_Stats_Frame.Reg_vs_Img_Mean_Plot(df_img, 'Light', document, pltPath, cint, showPlt)
        VRG_Stats_Frame.Reg_vs_Img_StdDev_Plot(df_img, 'Light', document, pltPath, cint, showPlt)
        VRG_Stats_Frame.Reg_vs_Img_RowStdDev_Plot(df_img, 'Light', document, pltPath, cint, showPlt)
        VRG_Stats_Frame.Reg_vs_Img_RowTotalNoise_Plot(df_img, 'Light', document, pltPath, cint, showPlt)
        VRG_Stats_Frame.Reg_vs_Img_ColStdDev_Plot(df_img, 'Light', document, pltPath, cint, showPlt)
        VRG_Stats_Frame.Reg_vs_Img_ColTotalNoise_Plot(df_img, 'Light', document, pltPath, cint, showPlt)

        for tmp in TEMP:  # Temperature
            df_tmp = VRG_Data_Frame.newdataframe(df_img, temp, tmp)
            if tmp == nomTemp:
                document.add_heading(i + 'Image Capture vs. Integration Time at (Temp = ' + str(tmp) + ')', level=2)
                VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 2, document, showPlt)
                VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 179, document, showPlt)
                VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 299, document, showPlt)

        document.add_heading(i + ' Analog Test Rows', level=2)
        VRG_Safety_Data.SM_Analog_Test_Rows_Plot(df_img, 'Power', document, pltPath, showPlt)
        document.add_heading(i + ' RRC Data Values', level=2)
        VRG_Safety_Data.SM_Row_Rom_Address_Columns_Plot(df_img, 'Power', document, pltPath, showPlt)
        document.add_heading(i + ' RRC Signal Integrity Values', level=2)
        VRG_Safety_Data.SM_Row_Rom_SIC_Plot(df_img, 'Power', document, pltPath, showPlt)
        document.add_heading(i + ' Digital Test Rows', level=2)
        VRG_Safety_Data.SM_Digital_Test_Rows_Plot(df_img, 'Power', document, pltPath, showPlt)

        document.add_heading(i + 'Power & Current vs. Voltage Level', level=2)
        VRG_Power_Data.Power_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)

    document.add_heading('ASIL Runtime vs. Imaging Mode', level=2)
    VRG_Safety_Data.SM_Runtime_Plot(df, 'ImgMode', document, pltPath, showPlt)

def DV_3_46_LAG_CORRECTION(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_3_47_LOW_POWER_MODE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_3_50_SMART_ROI(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_3_50_EIGHT_ROI(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    cint = 'RegWr00_COARSE_INTEGRATION_TIME_'
    imgType = 'Macro5'
    roiMacro = 'Macro6'
    reg1 = 'RegVal_Y_ADDR_START_'
    reg2 = 'RegVal_X_ADDR_START_'
    reg3 = 'RegVal_Y_ADDR_END_'
    reg4 = 'RegVal_X_ADDR_END_'
    reg5 = 'RegVal_ROI0_X_ADDR_START'
    reg6 = 'RegVal_ROI0_X_ADDR_END'
    reg7 = 'RegVal_ROI0_Y_ADDR_START'
    reg8 = 'RegVal_ROI0_Y_ADDR_END'
    reg9 = 'RegVal_ROI1_X_ADDR_START'
    reg10 = 'RegVal_ROI1_X_ADDR_END'
    reg11 = 'RegVal_ROI1_Y_ADDR_START'
    reg12 = 'RegVal_ROI1_Y_ADDR_END'
    reg13 = 'RegVal_ROI2_X_ADDR_START'
    reg14 = 'RegVal_ROI2_X_ADDR_END'
    reg15 = 'RegVal_ROI2_Y_ADDR_START'
    reg16 = 'RegVal_ROI2_Y_ADDR_END'
    reg17 = 'RegVal_ROI3_X_ADDR_START'
    reg18 = 'RegVal_ROI3_X_ADDR_END'
    reg19 = 'RegVal_ROI3_Y_ADDR_START'
    reg20 = 'RegVal_ROI3_Y_ADDR_END'
    reg21 = 'RegVal_ROI4_X_ADDR_START'
    reg22 = 'RegVal_ROI4_X_ADDR_END'
    reg23 = 'RegVal_ROI4_Y_ADDR_START'
    reg24 = 'RegVal_ROI4_Y_ADDR_END'
    reg25 = 'RegVal_ROI5_X_ADDR_START'
    reg26 = 'RegVal_ROI5_X_ADDR_END'
    reg27 = 'RegVal_ROI5_Y_ADDR_START'
    reg28 = 'RegVal_ROI5_Y_ADDR_END'
    reg29 = 'RegVal_ROI6_X_ADDR_START'
    reg30 = 'RegVal_ROI6_X_ADDR_END'
    reg31 = 'RegVal_ROI6_Y_ADDR_START'
    reg32 = 'RegVal_ROI6_Y_ADDR_END'
    reg33 = 'RegVal_ROI7_X_ADDR_START'
    reg34 = 'RegVal_ROI7_X_ADDR_END'
    reg35 = 'RegVal_ROI7_Y_ADDR_START'
    reg36 = 'RegVal_ROI7_Y_ADDR_END'
    reg37 = 'RegWr02_DIGITAL_CTRL__ROI8_MIN_MAX_EN'
    reg38 = 'RegWr03_DUMMY_PIXEL_VALUE'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[imgType].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i + ' Image Size Registers', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, reg1, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, reg2, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, reg3, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, reg4, showPlt)

        document.add_heading(i + ' 8ROI Registers', level=2)
        for x in range(5, 38):
            reg = eval("reg" + str(x))
            VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, reg, showPlt)

        document.add_heading(i + ' Image Sizes', level=2)
        VRG_General_Data.FrameWidth_Plot(df_img, None, document, pltPath, showPlt)
        VRG_General_Data.FrameHeight_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Actual Image Sizes vs. Calculated Image Size', level=2)
        VRG_Calculate.Calc_FrameSize_Plot(df_img, None, document, pltPath, reg2, reg4, reg1, reg3, showPlt)

        document.add_heading(i + ' Image Stats', level=2)
        VRG_Stats_Frame.Rgn_Mean_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_StdDev_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_TotalNoise_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_FPN_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_RowTotalNoise_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_RowFPN_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_ColTotalNoise_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_ColFPN_Plot(df_img, None, document, pltPath, showPlt)

        for tst in TEST:  # Test
            df_test = VRG_Data_Frame.newdataframe(df_img, imgType, tst)

            document.add_heading(i + ' Image Stats vs. Image Type = ' + str(tst) + ')', level=2)
            VRG_Register_Data.Reg_vs_Step_Plot(df_test, roiMacro, document, pltPath, reg1, showPlt)
            VRG_Register_Data.Reg_vs_Step_Plot(df_test, roiMacro, document, pltPath, reg2, showPlt)
            VRG_Register_Data.Reg_vs_Step_Plot(df_test, roiMacro, document, pltPath, reg3, showPlt)
            VRG_Register_Data.Reg_vs_Step_Plot(df_test, roiMacro, document, pltPath, reg4, showPlt)

            document.add_heading(i + ' 8ROI Registers', level=2)
            for x in range(5, 35):
                reg = eval("reg" + str(x))
                VRG_Register_Data.Reg_vs_Step_Plot(df_test, roiMacro, document, pltPath, reg, showPlt)

            document.add_heading(i + ' Frame Width & Height for Expected Image Type = ' + str(tst) + ')', level=2)
            VRG_General_Data.FrameWidth_Plot(df_test, roiMacro, document, pltPath, showPlt)
            VRG_General_Data.FrameHeight_Plot(df_test, roiMacro, document, pltPath, showPlt)

            document.add_heading(i + ' Actual Image Sizes vs. Calculated Image Size = ' + str(tst) + ')', level=2)
            VRG_Calculate.Calc_FrameSize_Plot(df_test, roiMacro, document, pltPath, reg2, reg4, reg1, reg3, showPlt)

            document.add_heading(i + ' ROI Image Stats vs. Image Type = ' + str(tst) + ')', level=2)
            VRG_Stats_Frame.Rgn_Mean_Plot(df_test, roiMacro, document, pltPath, showPlt)
            VRG_Stats_Frame.Rgn_StdDev_Plot(df_test, roiMacro, document, pltPath, showPlt)
            VRG_Stats_Frame.Rgn_TotalNoise_Plot(df_test, roiMacro, document, pltPath, showPlt)
            VRG_Stats_Frame.Rgn_FPN_Plot(df_test, roiMacro, document, pltPath, showPlt)
            VRG_Stats_Frame.Rgn_RowTotalNoise_Plot(df_test, roiMacro, document, pltPath, showPlt)
            VRG_Stats_Frame.Rgn_RowFPN_Plot(df_test, roiMacro, document, pltPath, showPlt)
            VRG_Stats_Frame.Rgn_ColTotalNoise_Plot(df_test, roiMacro, document, pltPath, showPlt)
            VRG_Stats_Frame.Rgn_ColFPN_Plot(df_test, roiMacro, document, pltPath, showPlt)

            for tmp in TEMP:  # Temperature
                df_tmp = VRG_Data_Frame.newdataframe(df_img, temp, tmp)
                if tmp == nomTemp:
                    document.add_heading(
                        i + 'Image Capture vs. Image Type = ' + str(tst) + ' at (Temp = ' + str(tmp) + ')', level=2)
                    VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 5, document, showPlt)
                    VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 17, document, showPlt)
                    VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 23, document, showPlt)
                    VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 34, document, showPlt)
                    VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 40, document, showPlt)
                    VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 52, document, showPlt)
                    VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 70, document, showPlt)

            document.add_heading(i + ' Analog Test Rows vs. Image Type = ' + str(tst) + ')', level=2)
            VRG_Safety_Data.SM_Analog_Test_Rows_Plot(df_test, roiMacro, document, pltPath, showPlt)
            document.add_heading(i + ' RRC Data Values vs. Image Type = ' + str(tst) + ')', level=2)
            VRG_Safety_Data.SM_Row_Rom_Address_Columns_Plot(df_test, roiMacro, document, pltPath, showPlt)
            document.add_heading(i + ' RRC Signal Integrity Values vs. Image Type = ' + str(tst) + ')', level=2)
            VRG_Safety_Data.SM_Row_Rom_SIC_Plot(df_test, roiMacro, document, pltPath, showPlt)
            document.add_heading(i + ' Digital Test Rows vs. Image Type = ' + str(tst) + ')', level=2)
            VRG_Safety_Data.SM_Digital_Test_Rows_Plot(df_test, roiMacro, document, pltPath, showPlt)

        document.add_heading(i + 'Power & Current vs. Voltage Level', level=2)
        VRG_Power_Data.Power_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)

    document.add_heading('ASIL Runtime vs. Imaging Modes', level=2)
    VRG_Safety_Data.SM_Runtime_Plot(df, 'ImgMode', document, pltPath, showPlt)

'''
4.00 AUTO FEATURE TESTS
'''

def DV_4_01_DYNAMIC_DEFECT_PIXEL_CORRECTION(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    cint = 'RegWr00_COARSE_INTEGRATION_TIME_'
    cintTime = 'Integration_Time (ms)'
    reg2DDC = 'RegWr01_T4_PIX_DEF_ID'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df['Light'].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Light Level Values', level=2)
        VRG_General_Data.LightLevel_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Integration Time Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, cint, showPlt)

        document.add_heading(i + ' 2DDC Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, reg2DDC, showPlt)

        document.add_heading(i + ' Pixel Defect Specification Thresholds', level=2)
        VRG_General_Data.ODS_Threshold_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Pixel Defect Count Values', level=2)
        VRG_General_Data.ODS_Data_Plot(df_img, None, document, pltPath, showPlt)

        VRG_Stats_Frame.Rgn_Mean_Plot(df_img, reg2DDC, document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_StdDev_Plot(df_img, reg2DDC, document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_TotalNoise_Plot(df_img, reg2DDC, document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_FPN_Plot(df_img, reg2DDC, document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_RowTotalNoise_Plot(df_img, reg2DDC, document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_RowFPN_Plot(df_img, reg2DDC, document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_ColTotalNoise_Plot(df_img, reg2DDC, document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_ColFPN_Plot(df_img, reg2DDC, document, pltPath, showPlt)

        for tst in TEST:  # Test
            df_test = VRG_Data_Frame.newdataframe(df_img, 'Light', tst)
            document.add_heading(i + ' Image Stats vs. Light Level vs. 2DDC', level=2)
            VRG_Stats_Frame.Rgn_Mean_Plot(df_test, reg2DDC, document, pltPath, showPlt)
            VRG_Stats_Frame.Rgn_StdDev_Plot(df_test, reg2DDC, document, pltPath, showPlt)
            VRG_Stats_Frame.Rgn_TotalNoise_Plot(df_test, reg2DDC, document, pltPath, showPlt)
            VRG_Stats_Frame.Rgn_FPN_Plot(df_test, reg2DDC, document, pltPath, showPlt)
            VRG_Stats_Frame.Rgn_RowTotalNoise_Plot(df_test, reg2DDC, document, pltPath, showPlt)
            VRG_Stats_Frame.Rgn_RowFPN_Plot(df_test, reg2DDC, document, pltPath, showPlt)
            VRG_Stats_Frame.Rgn_ColTotalNoise_Plot(df_test, reg2DDC, document, pltPath, showPlt)
            VRG_Stats_Frame.Rgn_ColFPN_Plot(df_test, reg2DDC, document, pltPath, showPlt)

            for tmp in TEMP:  # Temperature
                df_tmp = VRG_Data_Frame.newdataframe(df_img, temp, tmp)
                if tmp == nomTemp:
                    document.add_heading(i + 'Image Capture vs. 2DDC = ' + str(tst) + ' at (Temp = ' + str(tmp) + ')',
                                         level=2)
                    VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 2, document, showPlt)
                    VRG_Image_Analysis.Add_Image_Analysis_Info(df_tmp, 8, document, showPlt)

        document.add_heading(i + ' Analog Test Rows vs. 2DDC', level=2)
        VRG_Safety_Data.SM_Analog_Test_Rows_Plot(df_img, reg2DDC, document, pltPath, showPlt)
        document.add_heading(i + ' RRC Data Values vs. 2DDC', level=2)
        VRG_Safety_Data.SM_Row_Rom_Address_Columns_Plot(df_img, reg2DDC, document, pltPath, showPlt)
        document.add_heading(i + ' RRC Signal Integrity Values vs. 2DDC', level=2)
        VRG_Safety_Data.SM_Row_Rom_SIC_Plot(df_img, reg2DDC, document, pltPath, showPlt)
        document.add_heading(i + ' Digital Test Rows vs. 2DDC', level=2)
        VRG_Safety_Data.SM_Digital_Test_Rows_Plot(df_img, reg2DDC, document, pltPath, showPlt)

        document.add_heading(i + 'Power & Current vs. Voltage Level', level=2)
        VRG_Power_Data.Power_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)

    document.add_heading('ASIL Runtime vs. Imaging Mode', level=2)
    VRG_Safety_Data.SM_Runtime_Plot(df, 'ImgMode', document, pltPath, showPlt)

def DV_4_02_LENS_SHADING_CORRECTION(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_4_03_DYNAMIC_CLUSTER_CORRECTION(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_4_04_FLASH_SUPPORT(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_4_05_DYNAMIC_SEQUENCER(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_4_06_COLOR_CORRECTION_MATRIX(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_4_07_AUTO_EXPOSURE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_4_08_ADACD(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_4_09_MOTION_COMPENSATION(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die


'''
5.00 SUBSYSTEM AND IO INTERFACES
'''

def DV_5_01_POR(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    document.add_heading('Power On Reset Vtrig Falling & Rising')
    VRG_Power_Data.PowerOnReset_Voltage_Plot(df, None, document, pltPath, showPlt)

    document.add_heading('Power On Reset Vtrig Falling & Rising vs. Die')
    VRG_Power_Data.PowerOnReset_Voltage_Plot(df, die, document, pltPath, showPlt)

    document.add_heading('Power On Reset Vtrig Falling & Rising vs. ImageMode')
    VRG_Power_Data.PowerOnReset_Voltage_Plot(df, 'ImgMode', document, pltPath, showPlt)

    document.add_heading('Power On Reset Vtrig Falling & Rising vs. Power')
    VRG_Power_Data.PowerOnReset_Voltage_Plot(df, 'Power', document, pltPath, showPlt)

    document.add_heading('Power On Reset Vtrig Falling & Rising vs. Die vs. Power')
    VRG_Power_Data.PowerOnReset_Voltage_Plot(df, [die, 'Power'], document, pltPath, showPlt)

    document.add_heading('Power On Reset Vtrig Falling & Rising vs. Die vs. Clk')
    VRG_Power_Data.PowerOnReset_Voltage_Plot(df, [die, 'Clk'], document, pltPath, showPlt)

    document.add_heading('Power On Reset Vtrig Falling & Rising vs. Die vs. Temperature')
    VRG_Power_Data.PowerOnReset_Voltage_Plot(df, [die, temp], document, pltPath, showPlt)

    document.add_heading('Image Stats Post Power On Reset Vtrig Falling & Rising vs. Imaging Mode')
    VRG_Stats_Arr.Arr_Mean_Plot(df, 'ImgMode', document, pltPath, showPlt)
    VRG_Stats_Arr.Arr_StdDev_Plot(df, 'ImgMode', document, pltPath, showPlt)
    VRG_Stats_Arr.Arr_TotalNoise_Plot(df, 'ImgMode', document, pltPath, showPlt)
    VRG_Stats_Arr.Arr_FPN_Plot(df, 'ImgMode', document, pltPath, showPlt)
    VRG_Stats_Arr.Arr_Temporal_Plot(df, 'ImgMode', document, pltPath, showPlt)
    VRG_Stats_Arr.Arr_RowStdDev_Plot(df, 'ImgMode', document, pltPath, showPlt)
    VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df, 'ImgMode', document, pltPath, showPlt)
    VRG_Stats_Arr.Arr_RowFPN_Plot(df, 'ImgMode', document, pltPath, showPlt)
    VRG_Stats_Arr.Arr_RowTempNoise_Plot(df, 'ImgMode', document, pltPath, showPlt)
    VRG_Stats_Arr.Arr_ColStdDev_Plot(df, 'ImgMode', document, pltPath, showPlt)
    VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df, 'ImgMode', document, pltPath, showPlt)
    VRG_Stats_Arr.Arr_ColFPN_Plot(df, 'ImgMode', document, pltPath, showPlt)
    VRG_Stats_Arr.Arr_ColTempNoise_Plot(df, 'ImgMode', document, pltPath, showPlt)
    VRG_Stats_Arr.Arr_Flicker_Plot(df, 'ImgMode', document, pltPath, showPlt)
    VRG_Stats_Arr.Arr_PixelTotalNoise_Plot(df, 'ImgMode', document, pltPath, showPlt)
    VRG_Stats_Arr.Arr_PixelTemporalNoise_Plot(df, 'ImgMode', document, pltPath, showPlt)
    VRG_Stats_Arr.Arr_PixelFPN_Plot(df, 'ImgMode', document, pltPath, showPlt)
    VRG_Stats_Arr.Arr_RowTemporalNoiseRatio_Plot(df, 'ImgMode', document, pltPath, showPlt)
    VRG_Stats_Arr.Arr_ColumnTemporalNoiseRatio_Plot(df, 'ImgMode', document, pltPath, showPlt)
    VRG_Stats_Arr.Arr_RowFPNRatio_Plot(df, 'ImgMode', document, pltPath, showPlt)
    VRG_Stats_Arr.Arr_ColumnFPNRatio_Plot(df, 'ImgMode', document, pltPath, showPlt)

def DV_5_02_OTPM(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    otpmStatus = 'OTPM_STATUS'
    eccBypass = 'RegWr00_OTPM_EXPR__ECC_BYPASS'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    document.add_heading('Streaming Register vs. Test Step', level=2)
    VRG_Register_Data.Streaming_Register_Plot(df, None, document, pltPath, showPlt)

    document.add_heading('OTPM Error Correction (ECC)')
    document.add_heading('OTPM ECC Bypass Register Values vs. Test Step', level=2)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, eccBypass, showPlt)
    document.add_heading('OTPM Status Register vs. Die vs. Clk vs. Power vs. Temp', level=2)
    VRG_Register_Data.Reg_vs_Step_Plot(df, [die, 'Clk','Power', temp], document, pltPath, otpmStatus, showPlt)
    document.add_heading('OTPM Status Register vs. ECC Bypass', level=2)
    VRG_Register_Data.Reg_vs_Step_Plot(df, eccBypass, document, pltPath, otpmStatus, showPlt)

    document.add_heading('OTPM Auto Write')
    document.add_heading('OTPM Auto Write EID Registers vs. Die vs. Clk vs. Power vs. Temp', level=2)
    VRG_Register_Data.FUSE_ID_Register_Plot(df, [die, 'Clk', 'Power', temp], document, pltPath, showPlt)
    document.add_heading('OTPM Status Auto Write Data vs. Power vs temp', level=2)
    VRG_OTPM_Data.OTPM_Manual_Read_Status_Plot(df, ['Power', temp], document, pltPath, showPlt)

    document.add_heading('OTPM Initial Check')
    document.add_heading('OTPM Initial Check vs. Die vs. Clk vs. Power vs. Temp', level=2)
    VRG_OTPM_Data.OTPM_Initial_Check_Plot(df, [die, 'Clk', 'Power', temp], document, pltPath, showPlt)

    document.add_heading('OTPM Auto Read')
    document.add_heading('OTPM Auto Read Data vs. Die vs. Clk vs. Power vs. Temp', level=2)
    VRG_OTPM_Data.OTPM_Auto_Read_Plot(df, [die, 'Clk', 'Power', temp], document, pltPath, showPlt)
    document.add_heading('OTPM Status Auto Read Data vs. Power vs temp', level=2)
    VRG_OTPM_Data.OTPM_Auto_Read_Status_Plot(df, [die, 'Clk', 'Power', temp], document, pltPath, showPlt)

    document.add_heading('OTPM Manual Read')
    document.add_heading('OTPM Manual Read Data vs. Die vs. Clk vs. Power vs. Temp', level=2)
    VRG_OTPM_Data.OTPM_Manual_Read_Plot(df, [die, 'Clk', 'Power', temp], document, pltPath, showPlt)
    document.add_heading('OTPM Status Manual Read Data vs. Power vs temp', level=2)
    VRG_OTPM_Data.OTPM_Manual_Read_Status_Plot(df, [die, 'Clk', 'Power', temp], document, pltPath, showPlt)


def DV_5_03_FIFO_AND_WATERMARK(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_5_04_PIN_FUNCTIONALITY_AND_IO_PAD_TEST(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_5_05_STREAMING_AND_BLANKING(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_5_06_ITU_R_BTU_656(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_5_07_DUAL_CAMERA_OPERATION(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_5_08_FUSE_ID_AND_CUSTOMER_REVISION(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    reg1 = 'RegVal_CHIP_VERSION_REG'
    reg2 = 'RegVal_REVISION_NUMBER'
    reg3 = 'RegVal_CUSTOMER_REV'
    reg4 = 'RegVal_FUSE_ID1'
    reg5 = 'RegVal_FUSE_ID2'
    reg6 = 'RegVal_FUSE_ID3'
    reg7 = 'RegVal_FUSE_ID4'
    reg8 = 'RegVal_FUSE_ID5'
    reg9 = 'RegVal_FUSE_ID6'
    reg10 = 'RegVal_FUSE_ID7'
    reg11 = 'RegVal_FUSE_ID8'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    document.add_heading('Chip Version Register Values', level=2)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, reg1, showPlt)

    document.add_heading('Revision Number Register Values', level=2)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, reg2, showPlt)

    document.add_heading('Customer Revision Register Values', level=2)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, reg3, showPlt)

    document.add_heading('Fuse ID Attribute Values', level=2)
    VRG_OTPM_Data.EID_Attribute_Plot(df, die, document, pltPath, showPlt)

    document.add_heading('Fuse ID Register Values', level=2)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, reg4, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, reg5, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, reg6, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, reg7, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, reg8, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, reg9, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, reg10, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, reg11, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i + ' Chip Version Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, die, document, pltPath, reg1, showPlt)

        document.add_heading(i + ' Revision Number Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, die, document, pltPath, reg2, showPlt)

        document.add_heading(i + ' Customer Revision Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, die, document, pltPath, reg3, showPlt)

        document.add_heading(i + ' Fuse ID Attribute Values', level=2)
        VRG_OTPM_Data.EID_Attribute_Plot(df_img, die, document, pltPath, showPlt)

        document.add_heading(i + ' Fuse ID Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, die, document, pltPath, reg4, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, die, document, pltPath, reg5, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, die, document, pltPath, reg6, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, die, document, pltPath, reg7, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, die, document, pltPath, reg8, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, die, document, pltPath, reg9, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, die, document, pltPath, reg10, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, die, document, pltPath, reg11, showPlt)

def DV_5_09_MIPI(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_5_10_VOICE_COIL_MOTOR_VCM_DRIVER(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_5_11_VOLTAGE_REGULATOR(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_5_11_BOOSTER_OUTPUT_MEASURE_VS_TRIM(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_5_11_BOOSTER_OUTPUT_MEASURE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

    # VRG_General_Data Plots
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    document.add_heading('All Booster Voltages vs. Power ')
    VRG_Power_Data.Booster_Voltage_Plot(df, ['ImgMode', 'Power'], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i + ' All Booster Voltages vs. Power ', level=2)
        VRG_Power_Data.Booster_Voltage_Plot(df_img, 'Power', document, pltPath, showPlt)

        document.add_heading(i + ' Positive Booster Voltages vs. Power ', level=2)
        VRG_Power_Data.Positive_Booster_Voltage_Plot(df_img, 'Power', document, pltPath, showPlt)

        document.add_heading(i + ' Middle Booster Voltages vs. Power ', level=2)
        VRG_Power_Data.Middle_Booster_Voltage_Plot(df_img, 'Power', document, pltPath, showPlt)

        document.add_heading(i + ' Low Booster Voltages vs. Power ', level=2)
        VRG_Power_Data.Negative_Booster_Voltage_Plot(df_img, 'Power', document, pltPath, showPlt)

        document.add_heading(i + ' All Booster Voltages vs. Power vs. Temp', level=2)
        VRG_Power_Data.Booster_Voltage_Plot(df_img, [temp, 'Power'], document, pltPath, showPlt)

        document.add_heading(i + ' Positive Booster Voltages vs. Power vs. Temp', level=2)
        VRG_Power_Data.Positive_Booster_Voltage_Plot(df_img, [temp, 'Power'], document, pltPath, showPlt)

        document.add_heading(i + ' Middle Booster Voltages vs. Power vs. Temp', level=2)
        VRG_Power_Data.Middle_Booster_Voltage_Plot(df_img, [temp, 'Power'], document, pltPath, showPlt)

        document.add_heading(i + ' Low Booster Voltages vs. Power vs. Temp', level=2)
        VRG_Power_Data.Negative_Booster_Voltage_Plot(df_img, [temp, 'Power'], document, pltPath, showPlt)

def DV_5_11_LDO_OUTPUT_MEASURE_VS_TRIM(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_5_11_LDO_OUTPUT_MEASURE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

    # VRG_General_Data Plots
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    document.add_heading('All LDO Voltages vs. Power ')
    VRG_Power_Data.LDO_Voltage_Plot(df, ['ImgMode', 'Power'], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i + ' All LDO Voltages vs. Power ', level=2)
        VRG_Power_Data.LDO_Voltage_Plot(df_img, 'Power', document, pltPath, showPlt)

        document.add_heading(i + ' High LDO Voltages vs. Power ', level=2)
        VRG_Power_Data.High_LDO_Voltage_Plot(df_img, 'Power', document, pltPath, showPlt)

        document.add_heading(i + ' Middle LDO Voltages vs. Power ', level=2)
        VRG_Power_Data.Middle_LDO_Voltage_Plot(df_img, 'Power', document, pltPath, showPlt)

        document.add_heading(i + ' Low LDO Voltages vs. Power ', level=2)
        VRG_Power_Data.Low_LDO_Voltage_Plot(df_img, 'Power', document, pltPath, showPlt)

        document.add_heading(i + ' All LDO Voltages vs. Power vs. Temp', level=2)
        VRG_Power_Data.LDO_Voltage_Plot(df_img, [temp, 'Power'], document, pltPath, showPlt)

        document.add_heading(i + ' High LDO Voltages vs. Power vs. Temp', level=2)
        VRG_Power_Data.High_LDO_Voltage_Plot(df_img, [temp, 'Power'], document, pltPath, showPlt)

        document.add_heading(i + ' Middle LDO Voltages vs. Power vs. Temp', level=2)
        VRG_Power_Data.Middle_LDO_Voltage_Plot(df_img, [temp, 'Power'], document, pltPath, showPlt)

        document.add_heading(i + ' Low LDO Voltages vs. Power vs. Temp', level=2)
        VRG_Power_Data.Low_LDO_Voltage_Plot(df_img, [temp, 'Power'], document, pltPath, showPlt)

def DV_5_12_I2C_CCI_CAMERA_CONTROL_INTERFACE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    cintWrt = 'RegWr00_COARSE_INTEGRATION_TIME_'
    cintRD = 'RegVal_COARSE_INTEGRATION_TIME_'
    i2cSpeed = 'DVM_5_12_I2C_Speed'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    document.add_heading('Integration Time Register Values Written vs. Read vs. I2C Speed', level=2)
    VRG_Register_Data.Reg_vs_Reg_Plot(df, i2cSpeed, document, pltPath, cintWrt, cintRD, showPlt)

    document.add_heading('I2C Status vs. I2C Speed', level=2)
    VRG_General_Data.I2C_Status_Plot(df, i2cSpeed, document, pltPath, showPlt)

    document.add_heading('I2C Speed', level=2)
    VRG_General_Data.I2C_Speed_Plot(df, None, document, pltPath, showPlt)
    document.add_heading('I2C Speed vs. Clk', level=2)
    VRG_General_Data.I2C_Speed_Plot(df, 'Clk', document, pltPath, showPlt)
    document.add_heading('I2C Speed vs. Power', level=2)
    VRG_General_Data.I2C_Speed_Plot(df, 'Power', document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Light Level Values', level=2)
        VRG_General_Data.LightLevel_Plot(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' Integration Time Register Values Written vs. Read vs. I2C Speed', level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, i2cSpeed, document, pltPath, cintWrt, cintRD, showPlt)

        document.add_heading(i + ' I2C Status vs. I2C Speed', level=2)
        VRG_General_Data.I2C_Status_Plot(df_img, i2cSpeed, document, pltPath, showPlt)

        document.add_heading(i + ' I2C Speed', level=2)
        VRG_General_Data.I2C_Speed_Plot(df_img, None, document, pltPath, showPlt)
        document.add_heading(i + ' I2C Speed vs. Clk', level=2)
        VRG_General_Data.I2C_Speed_Plot(df_img, 'Clk', document, pltPath, showPlt)
        document.add_heading(i + ' I2C Speed vs. Power', level=2)
        VRG_General_Data.I2C_Speed_Plot(df_img, 'Power', document, pltPath, showPlt)

        document.add_heading(i + ' PLL Clocks vs. Clk', level=2)
        VRG_General_Data.PLL_Clock_Plot(df_img, 'Clk', document, pltPath, showPlt)

        document.add_heading(i + ' Frame Time vs. Clk', level=2)
        VRG_General_Data.FrameTime_Plot(df_img, 'Clk', document, pltPath, showPlt)

        document.add_heading(i + ' Image Statistics vs. I2C Speed vs. Integration Time', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, [i2cSpeed, cintWrt], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, [i2cSpeed, cintWrt], document, pltPath, showPlt)

def DV_5_14_HISPI_SLVS(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_5_16_STEREO_MODE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_5_17_TEMPERATURE_SENSOR(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    STBY = 2136  # value of reset register in standby
    STRM = 2140  # value of reset register in standby
    tempH = 125  # High temp
    tempN = 60  # Nom temp
    tempL = -40  # Low temp
    df_stby = VRG_Data_Frame.newdataframe(df, 'RegWr00_MODE_SELECT', STBY)
    df_strm = VRG_Data_Frame.newdataframe(df, 'RegWr00_MODE_SELECT', STRM)

    ## Tempsensor Data
    # document.add_heading('Temperature Sensor Data Average')
    # VRG_TempsensorData.Tempsensor_Read_Average_Plot(df, temp, document, pltPath, showPlt)
    # 
    # document.add_heading('Thermal Impedance vs. Temp')
    # VRG_TempsensorData.Thermal_Impedance_Plot(df, temp, document, pltPath, showPlt)
    # 
    # document.add_heading('Temperature Sensor Data at ' + str(tempL))
    # VRG_TempsensorData.Tempsensor_Read_vs_Time_Plot(df, temp, tempL, document, pltPath, showPlt)
    # VRG_TempsensorData.Tempsensor_Read_vs_TestNo_Plot(df, temp, tempL, document, pltPath, showPlt)
    # 
    # document.add_heading('Temperature Sensor Data at ' + str(tempN))
    # VRG_TempsensorData.Tempsensor_Read_vs_Time_Plot(df, temp, tempN, document, pltPath, showPlt)
    # VRG_TempsensorData.Tempsensor_Read_vs_TestNo_Plot(df, temp, tempN, document, pltPath, showPlt)
    # 
    # document.add_heading('Temperature Sensor Data at ' + str(tempH))
    # VRG_TempsensorData.Tempsensor_Read_vs_Time_Plot(df, temp, tempH, document, pltPath, showPlt)
    # VRG_TempsensorData.Tempsensor_Read_vs_TestNo_Plot(df, temp, tempH, document, pltPath, showPlt)
    # 
    # document.add_heading('Temperature Sensor Data vs. Standby')
    # VRG_TempsensorData.Tempsensor_Read_vs_Time_Plot(df, 'RegWr00_MODE_SELECT', STBY, document, pltPath, showPlt)
    # document.add_heading('Temperature Sensor Data vs. Time vs. Standby vs. High Temp')
    # VRG_TempsensorData.Tempsensor_Read_vs_Time_Plot(df_stby, temp, tempH, document, pltPath, showPlt)
    # document.add_heading('Temperature Sensor Data vs. Time vs. Standby vs. Nom Temp')
    # VRG_TempsensorData.Tempsensor_Read_vs_Time_Plot(df_stby, temp, tempN, document, pltPath, showPlt)
    # document.add_heading('Temperature Sensor Data vs. Time vs. Standby vs. Low Temp')
    # VRG_TempsensorData.Tempsensor_Read_vs_Time_Plot(df_stby, temp, tempL, document, pltPath, showPlt)
    ## document.add_heading('Temperature Sensor Data vs. Test vs. Standby vs. High Temp')
    ## VRG_TempsensorData.Tempsensor_Read_vs_TestNo_Plot(df_stby, temp, tempH, document, pltPath, showPlt)
    ## document.add_heading('Temperature Sensor Data vs. Test vs. Standby vs. Nom Temp')
    ## VRG_TempsensorData.Tempsensor_Read_vs_TestNo_Plot(df_stby, temp, tempN, document, pltPath, showPlt)
    ## document.add_heading('Temperature Sensor Data vs. Test vs. Standby vs. Low Temp')
    ## VRG_TempsensorData.Tempsensor_Read_vs_TestNo_Plot(df_stby, temp, tempL, document, pltPath, showPlt)

    # document.add_heading('Temperature Sensor Data vs. Streaming')
    # VRG_TempsensorData.Tempsensor_Read_vs_Time_Plot(df, 'RegWr00_MODE_SELECT', STRM, document, pltPath, showPlt)
    # document.add_heading('Temperature Sensor Data vs. Time vs. Streaming vs. High Temp')
    # VRG_TempsensorData.Tempsensor_Read_vs_Time_Plot(df_strm, temp, tempH, document, pltPath, showPlt)
    # document.add_heading('Temperature Sensor Data vs. Time vs. Streaming vs. Nom Temp')
    # VRG_TempsensorData.Tempsensor_Read_vs_Time_Plot(df_strm, temp, tempN, document, pltPath, showPlt)
    # document.add_heading('Temperature Sensor Data vs. Time vs. Streaming vs. Low Temp')
    # VRG_TempsensorData.Tempsensor_Read_vs_Time_Plot(df_strm, temp, tempL, document, pltPath, showPlt)
    ## document.add_heading('Temperature Sensor Data vs. Test vs. Streaming vs. High Temp')
    ## VRG_TempsensorData.Tempsensor_Read_vs_TestNo_Plot(df_strm, temp, tempH, document, pltPath, showPlt)
    ## document.add_heading('Temperature Sensor Data vs. Test vs. Streaming vs. Nom Temp')
    ## VRG_TempsensorData.Tempsensor_Read_vs_TestNo_Plot(df_strm, temp, tempN, document, pltPath, showPlt)
    ## document.add_heading('Temperature Sensor Data vs. Test vs. Streaming vs. Low Temp')
    ## VRG_TempsensorData.Tempsensor_Read_vs_TestNo_Plot(df_strm, temp, tempL, document, pltPath, showPlt)

    document.add_heading('Temperature Sensor Register')
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'RegVal_TEMPVSENS1_A0_HI', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'RegVal_TEMPVSENS1_A0_LO', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'RegVal_TEMPVSENS1_A1_HI', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'RegVal_TEMPVSENS1_A1_LO', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'RegVal_TEMPVSENS1_A2_HI', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'RegVal_TEMPVSENS1_A2_LO', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'RegVal_TEMPVSENS1_A3_HI', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'RegVal_TEMPVSENS1_A3_LO', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'RegVal_TEMPVSENS1_M1_HI', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'RegVal_TEMPVSENS1_M1_LO', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'RegVal_TEMPVSENS1_C1_HI', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'RegVal_TEMPVSENS1_C1_LO', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'RegVal_TEMPVSENS1_M2_HI', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'RegVal_TEMPVSENS1_M2_LO', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'RegVal_TEMPVSENS1_C2_HI', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'RegVal_TEMPVSENS1_C2_LO', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'RegVal_TEMPVSENS1_VALUE_55', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'RegVal_TEMPVSENS1_SREG_TRIM0', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'RegVal_TEMPVSENS1_TMG_CTRL_K0', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'RegVal_TEMPVSENS1_EN_CTRL', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'RegVal_TEMPVSENS1_TMG_CTRL_EX', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'RegVal_TEMPVSENS0_BOOST_SAMP_CTRL', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'RegVal_TEMPVSENS1_AUTO_VREF4_PULSE', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'RegVal_TEMPVSENS1_PEDESTAL_VREF16', showPlt)

    # Tempsensor Verify
    document.add_heading('Temperature Sensor Verify')
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'M1_REG', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'M2_REG', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'C1_REG', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'C2_REG', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'C055_REG', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'M_Coeff', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'C_Coeff', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'Coeff_2_21', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'Coeff_2_20', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'M1', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'M2', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'C1', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'C2', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'C055', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'R0x20B2', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'R0x3E9A', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'CTemp_N40_to_54_R0x20B2', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'KTemp_N40_to_54_R0x20B2', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'CTemp_N40_to_54_R0x3E9A', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'KTemp_N40_to_54_R0x3E9A', showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)
        df_img_stby = VRG_Data_Frame.newdataframe(df_img, 'RegWr00_MODE_SELECT', STBY)
        df_img_strm = VRG_Data_Frame.newdataframe(df_img, 'RegWr00_MODE_SELECT', STRM)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Temperature Sensor Data Average')
        VRG_Tempsensor_Data.Tempsensor_Read_Average_Plot(df_img, temp, document, pltPath, showPlt)

        document.add_heading(i + ' Thermal Impedance vs. Temp')
        VRG_Tempsensor_Data.Thermal_Impedance_Plot(df_img, temp, document, pltPath, showPlt)

        document.add_heading(i + ' Temperature Sensor Data vs. All Temperatures')
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img, None, None, document, pltPath, showPlt)
        VRG_Tempsensor_Data.Tempsensor_Read_vs_TestNo_Plot(df_img, None, None, document, pltPath, showPlt)

        document.add_heading('Temperature Sensor Data at ' + str(tempL))
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img, temp, tempL, document, pltPath, showPlt)
        VRG_Tempsensor_Data.Tempsensor_Read_vs_TestNo_Plot(df_img, temp, tempL, document, pltPath, showPlt)

        document.add_heading('Temperature Sensor Data at ' + str(tempN))
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img, temp, tempN, document, pltPath, showPlt)
        VRG_Tempsensor_Data.Tempsensor_Read_vs_TestNo_Plot(df_img, temp, tempN, document, pltPath, showPlt)

        document.add_heading('Temperature Sensor Data at ' + str(tempH))
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img, temp, tempH, document, pltPath, showPlt)
        VRG_Tempsensor_Data.Tempsensor_Read_vs_TestNo_Plot(df_img, temp, tempH, document, pltPath, showPlt)

        document.add_heading(i + ' Temperature Sensor Data vs. Standby')
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img, 'RegWr00_MODE_SELECT', STBY, document, pltPath,
                                                         showPlt)

        document.add_heading(i + ' Temperature Sensor Data vs. Time vs. Standby vs. High Temp')
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_stby, temp, tempH, document, pltPath, showPlt)
        document.add_heading(i + ' Temperature Sensor Data vs. Time vs. Standby vs. Nom Temp')
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_stby, temp, tempN, document, pltPath, showPlt)
        document.add_heading(i + ' Temperature Sensor Data vs. Time vs. Standby vs. Low Temp')
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_stby, temp, tempL, document, pltPath, showPlt)

        # document.add_heading(i + ' Temperature Sensor Data vs. Test vs. Standby vs. High Temp')
        # VRG_TempsensorData.Tempsensor_Read_vs_TestNo_Plot(df_img_stby, temp, tempH, document, pltPath, showPlt)
        # document.add_heading(i + ' Temperature Sensor Data vs. Test vs. Standby vs. Nom Temp')
        # VRG_TempsensorData.Tempsensor_Read_vs_TestNo_Plot(df_img_stby, temp, tempN, document, pltPath, showPlt)
        # document.add_heading(i + ' Temperature Sensor Data vs. Test vs. Standby vs. Low Temp')
        # VRG_TempsensorData.Tempsensor_Read_vs_TestNo_Plot(df_img_stby, temp, tempL, document, pltPath, showPlt)

        document.add_heading(i + ' Temperature Sensor Data vs. Streaming')
        VRG_Tempsensor_Data.Tempsensor_Read_vs_TestNo_Plot(df_img, 'RegWr00_MODE_SELECT', STRM, document, pltPath,
                                                           showPlt)
        document.add_heading(i + ' Temperature Sensor Data vs. Time vs. Streaming vs. High Temp')
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_strm, temp, tempH, document, pltPath, showPlt)
        document.add_heading(i + ' Temperature Sensor Data vs. Time vs. Streaming vs. Nom Temp')
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_strm, temp, tempN, document, pltPath, showPlt)
        document.add_heading(i + ' Temperature Sensor Data vs. Time vs. Streaming vs. Low Temp')
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_strm, temp, tempL, document, pltPath, showPlt)

        # document.add_heading(i + ' Temperature Sensor Data vs. Test vs. Streaming vs. High Temp')
        # VRG_TempsensorData.Tempsensor_Read_vs_TestNo_Plot(df_img_strm, temp, tempH, document, pltPath, showPlt)
        # document.add_heading(i + ' Temperature Sensor Data vs. Test vs. Streaming vs. Nom Temp')
        # VRG_TempsensorData.Tempsensor_Read_vs_TestNo_Plot(df_img_strm, temp, tempN, document, pltPath, showPlt)
        # document.add_heading(i + ' Temperature Sensor Data vs. Test vs. Streaming vs. Low Temp')
        # VRG_TempsensorData.Tempsensor_Read_vs_TestNo_Plot(df_img_strm, temp, tempL, document, pltPath, showPlt)

def DV_5_17_TEMPERATURE_SENSOR_IP_TEMPSENSOR(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    STBY = 2136  # value of reset register in standby
    STRM = 2140  # value of reset register in standby
    tempH = 125  # High temp
    tempN = 60  # Nom temp
    tempL = -40  # Low temp
    df_stby = VRG_Data_Frame.newdataframe(df, 'RegWr00_MODE_SELECT', STBY)
    df_strm = VRG_Data_Frame.newdataframe(df, 'RegWr00_MODE_SELECT', STRM)

    ## Tempsensor Data
    # document.add_heading('Temperature Sensor Data Average')
    # VRG_TempsensorData.Tempsensor_Read_Average_Plot(df, temp, document, pltPath, showPlt)
    #
    # document.add_heading('Thermal Impedance vs. Temp')
    # VRG_TempsensorData.Thermal_Impedance_Plot(df, temp, document, pltPath, showPlt)
    #
    # document.add_heading('Temperature Sensor Data at ' + str(tempL))
    # VRG_TempsensorData.Tempsensor_Read_vs_Time_Plot(df, temp, tempL, document, pltPath, showPlt)
    # VRG_TempsensorData.Tempsensor_Read_vs_TestNo_Plot(df, temp, tempL, document, pltPath, showPlt)
    #
    # document.add_heading('Temperature Sensor Data at ' + str(tempN))
    # VRG_TempsensorData.Tempsensor_Read_vs_Time_Plot(df, temp, tempN, document, pltPath, showPlt)
    # VRG_TempsensorData.Tempsensor_Read_vs_TestNo_Plot(df, temp, tempN, document, pltPath, showPlt)
    #
    # document.add_heading('Temperature Sensor Data at ' + str(tempH))
    # VRG_TempsensorData.Tempsensor_Read_vs_Time_Plot(df, temp, tempH, document, pltPath, showPlt)
    # VRG_TempsensorData.Tempsensor_Read_vs_TestNo_Plot(df, temp, tempH, document, pltPath, showPlt)
    #
    # document.add_heading('Temperature Sensor Data vs. Standby')
    # VRG_TempsensorData.Tempsensor_Read_vs_Time_Plot(df, 'RegWr00_MODE_SELECT', STBY, document, pltPath, showPlt)
    # document.add_heading('Temperature Sensor Data vs. Time vs. Standby vs. High Temp')
    # VRG_TempsensorData.Tempsensor_Read_vs_Time_Plot(df_stby, temp, tempH, document, pltPath, showPlt)
    # document.add_heading('Temperature Sensor Data vs. Time vs. Standby vs. Nom Temp')
    # VRG_TempsensorData.Tempsensor_Read_vs_Time_Plot(df_stby, temp, tempN, document, pltPath, showPlt)
    # document.add_heading('Temperature Sensor Data vs. Time vs. Standby vs. Low Temp')
    # VRG_TempsensorData.Tempsensor_Read_vs_Time_Plot(df_stby, temp, tempL, document, pltPath, showPlt)
    ## document.add_heading('Temperature Sensor Data vs. Test vs. Standby vs. High Temp')
    ## VRG_TempsensorData.Tempsensor_Read_vs_TestNo_Plot(df_stby, temp, tempH, document, pltPath, showPlt)
    ## document.add_heading('Temperature Sensor Data vs. Test vs. Standby vs. Nom Temp')
    ## VRG_TempsensorData.Tempsensor_Read_vs_TestNo_Plot(df_stby, temp, tempN, document, pltPath, showPlt)
    ## document.add_heading('Temperature Sensor Data vs. Test vs. Standby vs. Low Temp')
    ## VRG_TempsensorData.Tempsensor_Read_vs_TestNo_Plot(df_stby, temp, tempL, document, pltPath, showPlt)

    # document.add_heading('Temperature Sensor Data vs. Streaming')
    # VRG_TempsensorData.Tempsensor_Read_vs_Time_Plot(df, 'RegWr00_MODE_SELECT', STRM, document, pltPath, showPlt)
    # document.add_heading('Temperature Sensor Data vs. Time vs. Streaming vs. High Temp')
    # VRG_TempsensorData.Tempsensor_Read_vs_Time_Plot(df_strm, temp, tempH, document, pltPath, showPlt)
    # document.add_heading('Temperature Sensor Data vs. Time vs. Streaming vs. Nom Temp')
    # VRG_TempsensorData.Tempsensor_Read_vs_Time_Plot(df_strm, temp, tempN, document, pltPath, showPlt)
    # document.add_heading('Temperature Sensor Data vs. Time vs. Streaming vs. Low Temp')
    # VRG_TempsensorData.Tempsensor_Read_vs_Time_Plot(df_strm, temp, tempL, document, pltPath, showPlt)
    ## document.add_heading('Temperature Sensor Data vs. Test vs. Streaming vs. High Temp')
    ## VRG_TempsensorData.Tempsensor_Read_vs_TestNo_Plot(df_strm, temp, tempH, document, pltPath, showPlt)
    ## document.add_heading('Temperature Sensor Data vs. Test vs. Streaming vs. Nom Temp')
    ## VRG_TempsensorData.Tempsensor_Read_vs_TestNo_Plot(df_strm, temp, tempN, document, pltPath, showPlt)
    ## document.add_heading('Temperature Sensor Data vs. Test vs. Streaming vs. Low Temp')
    ## VRG_TempsensorData.Tempsensor_Read_vs_TestNo_Plot(df_strm, temp, tempL, document, pltPath, showPlt)

    document.add_heading('Temperature Sensor Register')
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'RegVal_TEMPVSENS1_A0_HI', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'RegVal_TEMPVSENS1_A0_LO', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'RegVal_TEMPVSENS1_A1_HI', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'RegVal_TEMPVSENS1_A1_LO', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'RegVal_TEMPVSENS1_A2_HI', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'RegVal_TEMPVSENS1_A2_LO', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'RegVal_TEMPVSENS1_A3_HI', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'RegVal_TEMPVSENS1_A3_LO', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'RegVal_TEMPVSENS1_M1_HI', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'RegVal_TEMPVSENS1_M1_LO', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'RegVal_TEMPVSENS1_C1_HI', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'RegVal_TEMPVSENS1_C1_LO', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'RegVal_TEMPVSENS1_M2_HI', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'RegVal_TEMPVSENS1_M2_LO', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'RegVal_TEMPVSENS1_C2_HI', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'RegVal_TEMPVSENS1_C2_LO', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'RegVal_TEMPVSENS1_VALUE_55', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'RegVal_TEMPVSENS1_SREG_TRIM0', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'RegVal_TEMPVSENS1_TMG_CTRL_K0', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'RegVal_TEMPVSENS1_EN_CTRL', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'RegVal_TEMPVSENS1_TMG_CTRL_EX', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'RegVal_TEMPVSENS0_BOOST_SAMP_CTRL', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'RegVal_TEMPVSENS1_AUTO_VREF4_PULSE', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'RegVal_TEMPVSENS1_PEDESTAL_VREF16', showPlt)

    # Tempsensor Verify
    document.add_heading('Temperature Sensor Verify')
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'M1_REG', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'M2_REG', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'C1_REG', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'C2_REG', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'C055_REG', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'M_Coeff', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'C_Coeff', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'Coeff_2_21', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'Coeff_2_20', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'M1', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'M2', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'C1', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'C2', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'C055', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'R0x20B2', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'R0x3E9A', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'CTemp_N40_to_54_R0x20B2', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'KTemp_N40_to_54_R0x20B2', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'CTemp_N40_to_54_R0x3E9A', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, 'KTemp_N40_to_54_R0x3E9A', showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)
        df_img_stby = VRG_Data_Frame.newdataframe(df_img, 'RegWr00_MODE_SELECT', STBY)
        df_img_strm = VRG_Data_Frame.newdataframe(df_img, 'RegWr00_MODE_SELECT', STRM)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Temperature Sensor Data Average')
        VRG_Tempsensor_Data.Tempsensor_Read_Average_Plot(df_img, temp, document, pltPath, showPlt)

        document.add_heading(i + ' Thermal Impedance vs. Temp')
        VRG_Tempsensor_Data.Thermal_Impedance_Plot(df_img, temp, document, pltPath, showPlt)

        document.add_heading(i + ' Temperature Sensor Data vs. All Temperatures')
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img, None, None, document, pltPath, showPlt)
        VRG_Tempsensor_Data.Tempsensor_Read_vs_TestNo_Plot(df_img, None, None, document, pltPath, showPlt)

        document.add_heading('Temperature Sensor Data at ' + str(tempL))
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img, temp, tempL, document, pltPath, showPlt)
        VRG_Tempsensor_Data.Tempsensor_Read_vs_TestNo_Plot(df_img, temp, tempL, document, pltPath, showPlt)

        document.add_heading('Temperature Sensor Data at ' + str(tempN))
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img, temp, tempN, document, pltPath, showPlt)
        VRG_Tempsensor_Data.Tempsensor_Read_vs_TestNo_Plot(df_img, temp, tempN, document, pltPath, showPlt)

        document.add_heading('Temperature Sensor Data at ' + str(tempH))
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img, temp, tempH, document, pltPath, showPlt)
        VRG_Tempsensor_Data.Tempsensor_Read_vs_TestNo_Plot(df_img, temp, tempH, document, pltPath, showPlt)

        document.add_heading(i + ' Temperature Sensor Data vs. Standby')
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img, 'RegWr00_MODE_SELECT', STBY, document, pltPath,
                                                         showPlt)

        document.add_heading(i + ' Temperature Sensor Data vs. Time vs. Standby vs. High Temp')
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_stby, temp, tempH, document, pltPath, showPlt)
        document.add_heading(i + ' Temperature Sensor Data vs. Time vs. Standby vs. Nom Temp')
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_stby, temp, tempN, document, pltPath, showPlt)
        document.add_heading(i + ' Temperature Sensor Data vs. Time vs. Standby vs. Low Temp')
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_stby, temp, tempL, document, pltPath, showPlt)

        # document.add_heading(i + ' Temperature Sensor Data vs. Test vs. Standby vs. High Temp')
        # VRG_TempsensorData.Tempsensor_Read_vs_TestNo_Plot(df_img_stby, temp, tempH, document, pltPath, showPlt)
        # document.add_heading(i + ' Temperature Sensor Data vs. Test vs. Standby vs. Nom Temp')
        # VRG_TempsensorData.Tempsensor_Read_vs_TestNo_Plot(df_img_stby, temp, tempN, document, pltPath, showPlt)
        # document.add_heading(i + ' Temperature Sensor Data vs. Test vs. Standby vs. Low Temp')
        # VRG_TempsensorData.Tempsensor_Read_vs_TestNo_Plot(df_img_stby, temp, tempL, document, pltPath, showPlt)

        document.add_heading(i + ' Temperature Sensor Data vs. Streaming')
        VRG_Tempsensor_Data.Tempsensor_Read_vs_TestNo_Plot(df_img, 'RegWr00_MODE_SELECT', STRM, document, pltPath,
                                                           showPlt)
        document.add_heading(i + ' Temperature Sensor Data vs. Time vs. Streaming vs. High Temp')
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_strm, temp, tempH, document, pltPath, showPlt)
        document.add_heading(i + ' Temperature Sensor Data vs. Time vs. Streaming vs. Nom Temp')
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_strm, temp, tempN, document, pltPath, showPlt)
        document.add_heading(i + ' Temperature Sensor Data vs. Time vs. Streaming vs. Low Temp')
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_strm, temp, tempL, document, pltPath, showPlt)

        # document.add_heading(i + ' Temperature Sensor Data vs. Test vs. Streaming vs. High Temp')
        # VRG_TempsensorData.Tempsensor_Read_vs_TestNo_Plot(df_img_strm, temp, tempH, document, pltPath, showPlt)
        # document.add_heading(i + ' Temperature Sensor Data vs. Test vs. Streaming vs. Nom Temp')
        # VRG_TempsensorData.Tempsensor_Read_vs_TestNo_Plot(df_img_strm, temp, tempN, document, pltPath, showPlt)
        # document.add_heading(i + ' Temperature Sensor Data vs. Test vs. Streaming vs. Low Temp')
        # VRG_TempsensorData.Tempsensor_Read_vs_TestNo_Plot(df_img_strm, temp, tempL, document, pltPath, showPlt)

def DV_5_17_TEMPERATURE_SENSOR_DIODE_1(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_5_17_TEMPERATURE_SENSOR_DIODE_2(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_5_17_TEMPERATURE_SENSOR_DIODE_SEQUENCE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_5_17_TEMPERATURE_SENSOR_SAFETY_PTAT_MODE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_5_17_TEMPERATURE_SENSOR_SAFETY_CONSTANT_MODE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_5_17_TEMPERATURE_SENSOR_SAFETY_SEQUENCE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_5_17_TEMPERATURE_SENSOR_SCHMOO(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    resetReg = 'RegWr02_MODE_SELECT'
    STBY = 2136  # value of reset register in standby
    STRM = 2140  # value of reset register in standby
    tempH = 125  # High temp
    tempN = 60  # Nom temp
    tempL = -40  # Low temp

    document.add_heading('Temperature Sensor Register')
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, 'RegVal_TEMPVSENS1_A0_HI', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, 'RegVal_TEMPVSENS1_A0_LO', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, 'RegVal_TEMPVSENS1_A1_HI', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, 'RegVal_TEMPVSENS1_A1_LO', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, 'RegVal_TEMPVSENS1_A2_HI', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, 'RegVal_TEMPVSENS1_A2_LO', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, 'RegVal_TEMPVSENS1_A3_HI', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, 'RegVal_TEMPVSENS1_A3_LO', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, 'RegVal_TEMPVSENS1_M1_HI', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, 'RegVal_TEMPVSENS1_M1_LO', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, 'RegVal_TEMPVSENS1_C1_HI', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, 'RegVal_TEMPVSENS1_C1_LO', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, 'RegVal_TEMPVSENS1_M2_HI', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, 'RegVal_TEMPVSENS1_M2_LO', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, 'RegVal_TEMPVSENS1_C2_HI', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, 'RegVal_TEMPVSENS1_C2_LO', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, 'RegVal_TEMPVSENS1_VALUE_55', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, 'RegVal_TEMPVSENS1_SREG_TRIM0', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, 'RegVal_TEMPVSENS1_TMG_CTRL_K0', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, 'RegVal_TEMPVSENS1_EN_CTRL', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, 'RegVal_TEMPVSENS1_TMG_CTRL_EX', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, 'RegVal_TEMPVSENS0_BOOST_SAMP_CTRL', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, 'RegVal_TEMPVSENS1_AUTO_VREF4_PULSE', showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, 'RegVal_TEMPVSENS1_PEDESTAL_VREF16', showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)
        df_img_stby = VRG_Data_Frame.newdataframe(df_img, resetReg, STBY)
        df_img_strm = VRG_Data_Frame.newdataframe(df_img, resetReg, STRM)

        df_img_smplcntL_stby = VRG_Data_Frame.newdataframe(df_img_stby, 'RegVal_TEMPVSENS1_TMG_CTRL_K0', 512)
        df_img_smplcntH_stby = VRG_Data_Frame.newdataframe(df_img_stby, 'RegVal_TEMPVSENS1_TMG_CTRL_K0', 57856)
        df_img_adcL_stby = VRG_Data_Frame.newdataframe(df_img_stby, 'RegVal_TEMPVSENS1_EN_CTRL', 16384)
        df_img_adcH_stby = VRG_Data_Frame.newdataframe(df_img_stby, 'RegVal_TEMPVSENS1_EN_CTRL', 20480)
        df_img_smpladcL_stby = VRG_Data_Frame.newdataframe(df_img_smplcntL_stby, 'RegVal_TEMPVSENS1_EN_CTRL', 16384)
        df_img_smpladcH_stby = VRG_Data_Frame.newdataframe(df_img_smplcntH_stby, 'RegVal_TEMPVSENS1_EN_CTRL', 20480)

        df_img_smplcntL_strm = VRG_Data_Frame.newdataframe(df_img_strm, 'RegVal_TEMPVSENS1_TMG_CTRL_K0', 512)
        df_img_smplcntH_strm = VRG_Data_Frame.newdataframe(df_img_strm, 'RegVal_TEMPVSENS1_TMG_CTRL_K0', 57856)
        df_img_adcL_strm = VRG_Data_Frame.newdataframe(df_img_strm, 'RegVal_TEMPVSENS1_EN_CTRL', 16384)
        df_img_adcH_strm = VRG_Data_Frame.newdataframe(df_img_strm, 'RegVal_TEMPVSENS1_EN_CTRL', 20480)
        df_img_smpladcL_strm = VRG_Data_Frame.newdataframe(df_img_smplcntL_strm, 'RegVal_TEMPVSENS1_EN_CTRL', 16384)
        df_img_smpladcH_strm = VRG_Data_Frame.newdataframe(df_img_smplcntH_strm, 'RegVal_TEMPVSENS1_EN_CTRL', 20480)

        df_img_vref16L_stby = VRG_Data_Frame.newdataframe(df_img_stby, 'RegVal_TEMPVSENS1_PEDESTAL_VREF16', 0)
        df_img_vref16H_stby = VRG_Data_Frame.newdataframe(df_img_stby, 'RegVal_TEMPVSENS1_PEDESTAL_VREF16', 134)
        df_img_vref16L_strm = VRG_Data_Frame.newdataframe(df_img_strm, 'RegVal_TEMPVSENS1_PEDESTAL_VREF16', 0)
        df_img_vref16H_strm = VRG_Data_Frame.newdataframe(df_img_strm, 'RegVal_TEMPVSENS1_PEDESTAL_VREF16', 134)

        df_img_vref4L_stby = VRG_Data_Frame.newdataframe(df_img_stby, 'RegVal_TEMPVSENS1_AUTO_VREF4_PULSE', 0)
        df_img_vref4H_stby = VRG_Data_Frame.newdataframe(df_img_stby, 'RegVal_TEMPVSENS1_AUTO_VREF4_PULSE', 1280)
        df_img_vref4L_strm = VRG_Data_Frame.newdataframe(df_img_strm, 'RegVal_TEMPVSENS1_AUTO_VREF4_PULSE', 0)
        df_img_vref4H_strm = VRG_Data_Frame.newdataframe(df_img_strm, 'RegVal_TEMPVSENS1_AUTO_VREF4_PULSE', 1280)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Temperature Sensor Data Average')
        VRG_Tempsensor_Data.Tempsensor_Read_Average_Plot(df_img, [die, temp], document, pltPath, showPlt)

        document.add_heading(i + ' Thermal Impedance vs. Temp')
        VRG_Tempsensor_Data.Thermal_Impedance_Plot(df_img, temp, document, pltPath, showPlt)

        # document.add_heading(i + ' Tempsensor Data vs. Standby')
        # VRG_TempsensorData.Tempsensor_Read_vs_Time_Plot(df, resetReg, STBY, document, pltPath, showPlt)
        #
        # document.add_heading(i + ' Tempsensor Data vs. Time vs. Standby vs. Sample Count vs. High Temp')
        # # VRG_TempsensorData.Tempsensor_Read_vs_Time_Plot(df_stby, temp, tempH, document, pltPath, showPlt)
        # document.add_heading(i + ' Tempsensor Data vs. Time vs. Standby vs. Sample Count vs. Nom Temp')
        # VRG_TempsensorData.Tempsensor_Read_vs_Time_Plot(df_stby, temp, tempN, document, pltPath, showPlt)
        # document.add_heading(i + ' Tempsensor Data vs. Time vs. Standby vs. Sample Count vs. Low Temp')
        # VRG_TempsensorData.Tempsensor_Read_vs_Time_Plot(df_stby, temp, tempL, document, pltPath, showPlt)

        document.add_heading(i + ' Tempsensor Data vs. Time vs. Standby vs. ADC Bit-Depth vs. High Temp')
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_adcH_stby, temp, tempH, document, pltPath, showPlt)
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_adcL_stby, temp, tempH, document, pltPath, showPlt)
        document.add_heading(i + ' Tempsensor Data vs. Time vs. Standby vs. ADC Bit-Depth Count vs. Nom Temp')
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_adcH_stby, temp, tempN, document, pltPath, showPlt)
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_adcL_stby, temp, tempN, document, pltPath, showPlt)
        document.add_heading(i + ' Tempsensor Data vs. Time vs. Standby vs. ADC Bit-Depth Count vs. Low Temp')
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_adcH_stby, temp, tempL, document, pltPath, showPlt)
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_adcL_stby, temp, tempL, document, pltPath, showPlt)

        document.add_heading(
            i + ' Tempsensor Data vs. Time vs. Standby vs. Sample Count vs. ADC Bit-Depth vs. High Temp')
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_smpladcH_stby, temp, tempH, document, pltPath, showPlt)
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_smpladcL_stby, temp, tempH, document, pltPath, showPlt)
        document.add_heading(
            i + ' Tempsensor Data vs. Time vs. Standby vs. Sample Count vs. ADC Bit-Depth Count vs. Nom Temp')
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_smpladcH_stby, temp, tempN, document, pltPath, showPlt)
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_smpladcL_stby, temp, tempN, document, pltPath, showPlt)
        document.add_heading(
            i + ' Tempsensor Data vs. Time vs. Standby vs. Sample Count vs. ADC Bit-Depth Count vs. Low Temp')
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_smpladcH_stby, temp, tempL, document, pltPath, showPlt)
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_smpladcL_stby, temp, tempL, document, pltPath, showPlt)

        document.add_heading(i + ' Tempsensor Data vs. Time vs. Standby vs. VREF4 Pulse vs. High Temp')
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_vref4H_stby, temp, tempH, document, pltPath, showPlt)
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_vref4L_stby, temp, tempH, document, pltPath, showPlt)
        document.add_heading(i + ' Tempsensor Data vs. Time vs. Standby vs. VREF4 Pulse vs. Nom Temp')
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_vref4H_stby, temp, tempN, document, pltPath, showPlt)
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_vref4L_stby, temp, tempN, document, pltPath, showPlt)
        document.add_heading(i + ' Tempsensor Data vs. Time vs. Standby vs. VREF4 Pulse vs. Low Temp')
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_vref4H_stby, temp, tempL, document, pltPath, showPlt)
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_vref4L_stby, temp, tempL, document, pltPath, showPlt)

        document.add_heading(i + ' Tempsensor Data vs. Time vs. Standby vs. VREF16 vs. High Temp')
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_vref16H_stby, temp, tempH, document, pltPath, showPlt)
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_vref16L_stby, temp, tempH, document, pltPath, showPlt)
        document.add_heading(i + ' Tempsensor Data vs. Time vs. Standby vs. VREF16 vs. Nom Temp')
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_vref16H_stby, temp, tempN, document, pltPath, showPlt)
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_vref16L_stby, temp, tempN, document, pltPath, showPlt)
        document.add_heading(i + ' Tempsensor Data vs. Time vs. Standby vs. VREF16 vs. Low Temp')
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_vref16H_stby, temp, tempL, document, pltPath, showPlt)
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_vref16L_stby, temp, tempL, document, pltPath, showPlt)

        # document.add_heading(i + ' Temperature Sensor Data vs. Streaming')
        # VRG_TempsensorData.Tempsensor_Read_vs_Time_Plot(df, resetReg, STRM, document, pltPath, showPlt)
        #
        # document.add_heading(i + ' Tempsensor Data vs. Time vs. Streaming vs. Sample Count vs. High Temp')
        # # VRG_TempsensorData.Tempsensor_Read_vs_Time_Plot(df_strm, temp, tempH, document, pltPath, showPlt)
        # document.add_heading(i + ' Tempsensor Data vs. Time vs. Streaming vs. Sample Count  vs. Nom Temp')
        # VRG_TempsensorData.Tempsensor_Read_vs_Time_Plot(df_strm, temp, tempN, document, pltPath, showPlt)
        # document.add_heading(i + ' Tempsensor Data  vs. Time vs. Streaming vs. Sample Count vs. Low Temp')
        # VRG_TempsensorData.Tempsensor_Read_vs_Time_Plot(df_strm, temp, tempL, document, pltPath, showPlt)

        document.add_heading(i + ' Tempsensor Data vs. Time vs. Streaming vs. ADC Bit-Depth vs. High Temp')
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_adcH_strm, temp, tempH, document, pltPath, showPlt)
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_adcL_strm, temp, tempH, document, pltPath, showPlt)
        document.add_heading(i + ' Tempsensor Data vs. Time vs. Streaming vs. ADC Bit-Depth Count vs. Nom Temp')
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_adcH_strm, temp, tempN, document, pltPath, showPlt)
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_adcL_strm, temp, tempN, document, pltPath, showPlt)
        document.add_heading(i + ' Tempsensor Data vs. Time vs. Streaming vs. ADC Bit-Depth Count vs. Low Temp')
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_adcH_strm, temp, tempL, document, pltPath, showPlt)
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_adcL_strm, temp, tempL, document, pltPath, showPlt)

        document.add_heading(
            i + ' Tempsensor Data vs. Time vs. Streaming vs. Sample Count vs. ADC Bit-Depth vs. High Temp')
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_smpladcH_strm, temp, tempH, document, pltPath, showPlt)
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_smpladcL_strm, temp, tempH, document, pltPath, showPlt)
        document.add_heading(
            i + ' Tempsensor Data vs. Time vs. Streaming vs. Sample Count vs. ADC Bit-Depth Count vs. Nom Temp')
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_smpladcH_strm, temp, tempN, document, pltPath, showPlt)
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_smpladcL_strm, temp, tempN, document, pltPath, showPlt)
        document.add_heading(
            i + ' Tempsensor Data vs. Time vs. Streaming vs. Sample Count vs. ADC Bit-Depth Count vs. Low Temp')
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_smpladcH_strm, temp, tempL, document, pltPath, showPlt)
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_smpladcL_strm, temp, tempL, document, pltPath, showPlt)

        document.add_heading(i + ' Tempsensor Data vs. Time vs. Streaming vs. VREF4 Pulse vs. High Temp')
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_vref4H_strm, temp, tempH, document, pltPath, showPlt)
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_vref4L_strm, temp, tempH, document, pltPath, showPlt)
        document.add_heading(i + ' Tempsensor Data vs. Time vs. Streaming vs. VREF4 Pulse vs. Nom Temp')
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_vref4H_strm, temp, tempN, document, pltPath, showPlt)
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_vref4L_strm, temp, tempN, document, pltPath, showPlt)
        document.add_heading(i + ' Tempsensor Data vs. Time vs. Streaming vs. VREF4 Pulse vs. Low Temp')
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_vref4H_strm, temp, tempL, document, pltPath, showPlt)
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_vref4L_strm, temp, tempL, document, pltPath, showPlt)

        document.add_heading(i + ' Tempsensor Data vs. Time vs. Streaming vs. VREF16 vs. High Temp')
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_vref16H_strm, temp, tempH, document, pltPath, showPlt)
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_vref16L_strm, temp, tempH, document, pltPath, showPlt)
        document.add_heading(i + ' Tempsensor Data vs. Time vs. Streaming vs. VREF16 vs. Nom Temp')
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_vref16H_strm, temp, tempN, document, pltPath, showPlt)
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_vref16L_strm, temp, tempN, document, pltPath, showPlt)
        document.add_heading(i + ' Tempsensor Data vs. Time vs. Streaming vs. VREF16 vs. Low Temp')
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_vref16H_strm, temp, tempL, document, pltPath, showPlt)
        VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df_img_vref16L_strm, temp, tempL, document, pltPath, showPlt)

def DV_5_18_PLL(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

    reg1 = 'RegVal_PLL_MULTIPLIER'
    reg2 = 'RegVal_PRE_PLL_CLK_DIV'
    reg3 = 'RegVal_VT_SYS_CLK_DIV'
    reg4 = 'RegVal_VT_PIX_CLK_DIV'
    reg5 = 'RegVal_OP_SYS_CLK_DIV'
    reg6 = 'RegVal_OP_WORD_CLK_DIV'
    reg7 = 'RegVal_PLL_MULTIPLIER_ASIC'
    reg8 = 'RegVal_PRE_PLL_CLK_DIV_ASIC'
    reg9 = 'RegVal_VT_SYS_CLK_DIV_ASIC'
    reg10 = 'RegVal_VT_PIX_CLK_DIV_ASIC'
    reg11 = 'RegVal_OP_SYS_CLK_DIV_ASIC'
    reg12 = 'RegVal_OP_WORD_CLK_DIV_ASIC'
    reg13 = 'RegVal_PLL_CONTROL_ASIC'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    document.add_heading('PLL Clocks vs. Clk', level=2)
    VRG_General_Data.PLL_Clock_Plot(df, 'Clk', document, pltPath, showPlt)

    document.add_heading('Frame Time vs. Clk', level=2)
    VRG_General_Data.FrameTime_Plot(df, 'Clk', document, pltPath, showPlt)

    document.add_heading('I2C Status vs. Clk', level=2)
    VRG_General_Data.I2C_Status_Plot(df, 'Clk', document, pltPath, showPlt)

    document.add_heading('Default Reg Values vs. Clk')
    VRG_Register_Data.Reg_vs_Step_Plot(df, 'Clk', document, pltPath, reg1, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, 'Clk', document, pltPath, reg2, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, 'Clk', document, pltPath, reg3, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, 'Clk', document, pltPath, reg4, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, 'Clk', document, pltPath, reg5, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, 'Clk', document, pltPath, reg6, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, 'Clk', document, pltPath, reg7, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, 'Clk', document, pltPath, reg8, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, 'Clk', document, pltPath, reg9, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, 'Clk', document, pltPath, reg10, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, 'Clk', document, pltPath, reg11, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, 'Clk', document, pltPath, reg12, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, 'Clk', document, pltPath, reg13, showPlt)

    document.add_heading('Frame Capture Pass/Fail vs. Clk')
    VRG_General_Data.FrameCapture_Plot(df, 'Clk', document, pltPath, showPlt)

    document.add_heading('Frame Grab Attempts vs. Clk')
    VRG_General_Data.GrabAttempts_Plot(df, 'Clk', document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' PLL Clocks vs. Clk', level=2)
        VRG_General_Data.PLL_Clock_Plot(df_img, 'Clk', document, pltPath, showPlt)

        document.add_heading(i + ' Frame Time vs. Clk', level=2)
        VRG_General_Data.FrameTime_Plot(df_img, 'Clk', document, pltPath, showPlt)

        document.add_heading(i + ' I2C Status vs. Clk', level=2)
        VRG_General_Data.I2C_Status_Plot(df_img, 'Clk', document, pltPath, showPlt)

        document.add_heading(i + ' PLL Reg Values')
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, 'Clk', document, pltPath, reg1, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, 'Clk', document, pltPath, reg2, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, 'Clk', document, pltPath, reg3, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, 'Clk', document, pltPath, reg4, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, 'Clk', document, pltPath, reg5, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, 'Clk', document, pltPath, reg6, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, 'Clk', document, pltPath, reg7, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, 'Clk', document, pltPath, reg8, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, 'Clk', document, pltPath, reg9, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, 'Clk', document, pltPath, reg10, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, 'Clk', document, pltPath, reg11, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, 'Clk', document, pltPath, reg12, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, 'Clk', document, pltPath, reg13, showPlt)

        document.add_heading(i + ' Frame Capture Pass/Fail vs. Clk')
        VRG_General_Data.FrameCapture_Plot(df_img, 'Clk', document, pltPath, showPlt)

        document.add_heading(i + ' Frame Grab Attempts vs. Clk')
        VRG_General_Data.GrabAttempts_Plot(df_img, 'Clk', document, pltPath, showPlt)

def DV_5_19_NTSC(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_5_20_THREE_WIRE_SERIAL_INTERFACE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_5_21_OUTPUT_DATA_COMPRESSION(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_5_22_EMBEDDED_DATA_AND_STATISTICS_ROWS(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_5_22_EMBEDDED_DATA_ROWS(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_5_22_EMBEDDED_STATISTICS_ROWS(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_5_23_I2C_FEATURE_LOCK(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    cint = 'RegWr00_COARSE_INTEGRATION_TIME_'
    lockControl = 'RegWr01_LOCK_CONTROL'
    flipMirror = 'RegWr02_READ_MODE'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Light Level Values', level=2)
        VRG_General_Data.LightLevel_Plot(df_img, None, document, pltPath, showPlt)
        document.add_heading(i + ' Lock Conrol Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, lockControl, showPlt)
        document.add_heading(i + ' Integration Time Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, cint, showPlt)
        document.add_heading(i + ' Horizontal Mirror & Vertical Flip Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, flipMirror, showPlt)
        document.add_heading(i + ' Horizontal Mirror & Vertical Flip Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, lockControl, document, pltPath, flipMirror, showPlt)

        document.add_heading(i + ' Frame Capture Pass/Fail vs. Lock Control')
        VRG_General_Data.FrameCapture_Plot(df_img, lockControl, document, pltPath, showPlt)

        document.add_heading(i + ' Frame Capture Pass/Fail vs. Lock Control vs. Flip & Mirror')
        VRG_General_Data.FrameCapture_Plot(df_img, [lockControl, flipMirror], document, pltPath, showPlt)

        document.add_heading(i + ' Frame Grab Attempts vs. Lock Control')
        VRG_General_Data.GrabAttempts_Plot(df_img, lockControl, document, pltPath, showPlt)

        document.add_heading(i + ' Frame Size Information vs. Lock Control')
        VRG_General_Data.FrameWidth_Plot(df_img, lockControl, document, pltPath, showPlt)
        VRG_General_Data.FrameHeight_Plot(df_img, lockControl, document, pltPath, showPlt)
        VRG_General_Data.FrameBitDepth_Plot(df_img, lockControl, document, pltPath, showPlt)
        VRG_General_Data.DroppedFrames_Plot(df_img, lockControl, document, pltPath, showPlt)

        document.add_heading(i + ' Frame Size Information vs. Lock Control vs. Flip and Mirror')
        VRG_General_Data.FrameWidth_Plot(df_img, [lockControl, flipMirror], document, pltPath, showPlt)
        VRG_General_Data.FrameHeight_Plot(df_img, [lockControl, flipMirror], document, pltPath, showPlt)
        VRG_General_Data.FrameBitDepth_Plot(df_img, [lockControl, flipMirror], document, pltPath, showPlt)
        VRG_General_Data.DroppedFrames_Plot(df_img, [lockControl, flipMirror], document, pltPath, showPlt)

        document.add_heading(i + ' Image Stats vs. Lock Control', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, lockControl, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, lockControl, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowStdDev_Plot(df_img, lockControl, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_img, lockControl, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColStdDev_Plot(df_img, lockControl, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_img, lockControl, document, pltPath, showPlt)

        document.add_heading(i + ' Image Stats vs. Lock Control vs. Flip and Mirror', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, [lockControl, flipMirror], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, [lockControl, flipMirror], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowStdDev_Plot(df_img, [lockControl, flipMirror], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_img, [lockControl, flipMirror], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColStdDev_Plot(df_img, [lockControl, flipMirror], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_img, [lockControl, flipMirror], document, pltPath, showPlt)

def DV_5_24_ETHERNET(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_5_24_MIPI_LOOPBACK_DPHY(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_5_24_MIPI_LOOPBACK_DPHY_SDR(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_5_24_MIPI_LOOPBACK_DPHY_DDR(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_5_24_MIPI_LOOPBACK_CPHY(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_5_25_SERIAL_PERIPHERAL_INTERFACE_SPI(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die


'''
6.00 PIXEL TESTS
'''

def DV_6_01_LINEAR_FULL_WELL(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_6_02_SATURATION_FULL_WELL(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_6_03_CONVERSION_GAIN_TF(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_6_04_ISO_GAINS_MAPPED_TO_ANALOG_DIGITAL_GAINS(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_6_05_READOUT_NOISE_VS_GAIN_BOTH_ANALOG_AND_ISO(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_6_06_PTC_FOR_ALL_GAINS_BOTH_ANALOG_AND_ISO(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_6_07_RESPONSIVITY_VLUXS_KELUXS(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_6_08_CHARGING_LAG(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_6_09_DISCHARGING_LAG(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_6_10_CHARGE_SHARING_LAG(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_6_11_BLOOMING_TEST(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_6_12_ROW_BANDING(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_6_13_COLOR_RATIO_VS_EXPOSURE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_6_14_COLOR_RATIO_VS_F_NUMBER(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_6_15_LINE_CRAWL(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_6_16_QE_PLUS_RELATIVE_RESPONSE_ETC(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_6_17_LINEARITY_FOR_DIFFERENT_GAINS(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_6_18_SPATIAL_NOISE_PFPN_VS_SIGNAL(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_6_19_BLACK_LEVEL_VS_GAIN(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_6_20_BLACK_LEVEL_UNIFORMITY_VS_GAIN(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_6_21_DARK_CURRENT(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_6_22_S_CURVE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_6_23_ISO_SNR_COMPLETE_CURVE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_6_24_LATEST_NOKIA_SNR_COMPLETE_CURVE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_6_25_APTINA_SNR_COMPLETE_CURVE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_6_26_IMAGE_CAPTURE_STAND_SCENE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_6_27_IMAGE_CAPTURE_IECF_CHART(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_6_28_IMAGE_CAPTURE_MACBETH(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_6_29_IMAGE_CAPTURE_FLAT_FIELD(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_6_30_IMAGE_CAPTURE_RESOLUTION_CHART(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_6_31_IMAGE_CAPTURE_MOAS(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_6_32_IMAGE_CAPTURE_MACBETH_SCENE_VS_tempERATURE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_6_33_IMAGE_CAPTURE_FULL_SCC(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_6_34_IMAGE_CAPTURE_MINI_SCC(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_6_35_MODULATION_TRANSFER_FUNCTION_MTF(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die


'''
7.00 AC DC ELECTRICAL SPECS
'''

def DV_7_01_AC_CHARACTERIZATION_OF_PARALLEL_INTERFACE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_7_06_DC_CHARACTERIZATION_OF_I_O_LOGIC_LEVELS(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die


'''
8.00 RELIABILITY
'''

def DV_8_01_ESD(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_8_02_ABSOLUTE_MAXIMUM_RATINGS(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_8_03_HTOL(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_8_04_LTOL(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_8_05_HAST(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_8_06_T_C(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_8_07_HTOL_PARAMETRIC_DRIFT_ANALYSIS(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die


'''
9.00 CPIPE TUNING AND VALIDATION
'''

def DV_9_01_AUTO_FOCUS_AF(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_9_03_JPEG(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_9_04_CPIPE_ARCHITECTURE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_9_07_WHITE_BALANCE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_9_08_COLOR_CORRECTION_MATRIX_CCM(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_9_09_SHARPNESS(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_9_10_LENS_SHADING_CORRECTION(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_9_11_DEFECT_CORRECTION(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_9_12_ZOOM(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_9_13_NOISE_REDUCTION(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_9_14_SPECIAL_EFFECTS(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_9_15_COLOUR_KILL(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_9_16_AUTO_EXPOSURE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_9_17_DEWARP_STE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_9_18_BINNING(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_9_19_TONE_MAPPING(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_9_20_GAMMA(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_9_21_tempERATURE_TESTING_WITH_TUNED_CPIPE_SETTINGS(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die


'''
11.00 USE CASE TESTING
'''

def DV_11_01_AUTOMOTIVE_VIEWING_DRIVING_DAYTIME(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_11_02_AUTOMOTIVE_VIEWING_DRIVING_LOW_LIGHT(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_11_03_SURVEILLANCE_CWF_LIGHTING(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_11_04_SURVEILLANCE_INDOOR_MIXED_LIGHT(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_11_05_SURVEILLANCE_PARKING_LOT_IN_LOW_LIGHT(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_11_06_SURVEILLANCE_OUTDOOR_MID_DAY(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_11_07_SURVEILLANCE_INDOOR_LOW_LIGHT(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die


'''
12.00 ASIL FUNCTIONS
'''

def DV_12_0_01_SM_M3ROM_UPLOAD_CRC(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    ULcolor = '#ff0000'
    LLcolor = '#0000ff'

    document.add_heading('SM Clock Counting vs. Die')
    VRG_Safety_Data.SM_CLOCK_COUNTING(df, [die, temp, 'Clk'], document, pltPath, showPlt)

    df_t1 = df[[temp, die]]
    document.add_heading('SM_I2C_CRC Results Table', level=2)
    VRG_Doc.df_to_table(df_t1, document)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df['Clk'].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' SM Clock Counting vs. Die', level=2)
        VRG_Safety_Data.SM_CLOCK_COUNTING(df_img, [die, temp, 'Clk'], document, pltPath, showPlt)

        for tst in TEST:  # Test
            df_test = VRG_Data_Frame.newdataframe(df_img, 'Clk', tst)

            document.add_heading(i + ' SM_CLOCK_COUNTING vs. Clk = ' + str(tst), level=1)
            document.add_heading(i + ' SM_CLOCK_COUNTING vs. Time vs. Clk =' + str(tst), level=2)
            VRG_Safety_Data.SM_CLOCK_COUNTING_vs_Time_Plot(df_test, None, None, document, pltPath, showPlt,
                                                           ax_hlines=[(die, ULcolor, '--', 3, 1)])

def DV_12_0_02_SM_OTPROM_UPLOAD_CRC(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    ULcolor = '#ff0000'
    LLcolor = '#0000ff'

    document.add_heading('SM Clock Counting vs. Die')
    VRG_Safety_Data.SM_CLOCK_COUNTING(df, [die, temp, 'Clk'], document, pltPath, showPlt)

    df_t1 = df[[temp, die]]
    document.add_heading('SM_I2C_CRC Results Table', level=2)
    VRG_Doc.df_to_table(df_t1, document)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df['Clk'].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' SM Clock Counting vs. Die', level=2)
        VRG_Safety_Data.SM_CLOCK_COUNTING(df_img, [die, temp, 'Clk'], document, pltPath, showPlt)

        for tst in TEST:  # Test
            df_test = VRG_Data_Frame.newdataframe(df_img, 'Clk', tst)

            document.add_heading(i + ' SM_CLOCK_COUNTING vs. Clk = ' + str(tst), level=1)
            document.add_heading(i + ' SM_CLOCK_COUNTING vs. Time vs. Clk =' + str(tst), level=2)
            VRG_Safety_Data.SM_CLOCK_COUNTING_vs_Time_Plot(df_test, None, None, document, pltPath, showPlt,
                                                           ax_hlines=[(die, ULcolor, '--', 3, 1)])

def DV_12_0_03_SM_STANDBY_REGISTER_CRC(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_0_04_SM_PDI_UPLOAD_CRC(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    ULcolor = '#ff0000'
    LLcolor = '#0000ff'

    document.add_heading('SM Clock Counting vs. Die')
    VRG_Safety_Data.SM_CLOCK_COUNTING(df, [die, temp, 'Clk'], document, pltPath, showPlt)

    df_t1 = df[[temp, die]]
    document.add_heading('SM_I2C_CRC Results Table', level=2)
    VRG_Doc.df_to_table(df_t1, document)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df['Clk'].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' SM Clock Counting vs. Die', level=2)
        VRG_Safety_Data.SM_CLOCK_COUNTING(df_img, [die, temp, 'Clk'], document, pltPath, showPlt)

        for tst in TEST:  # Test
            df_test = VRG_Data_Frame.newdataframe(df_img, 'Clk', tst)

            document.add_heading(i + ' SM_CLOCK_COUNTING vs. Clk = ' + str(tst), level=1)
            document.add_heading(i + ' SM_CLOCK_COUNTING vs. Time vs. Clk =' + str(tst), level=2)
            VRG_Safety_Data.SM_CLOCK_COUNTING_vs_Time_Plot(df_test, None, None, document, pltPath, showPlt,
                                                           ax_hlines=[(die, ULcolor, '--', 3, 1)])

def DV_12_0_05_SM_STANDBY_BIST_MEMORY(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_0_06_SM_STANDBY_TEST_FRAME(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    deltaDk = 'DELTA_DK_CONTROL'
    hiCalcCRC = 'CRC_FR_DTR_CALC_CHECKSUM_HIGH'
    hiWrtCRC = 'CRC_FR_DTR_WRT_CHECKSUM_HIGH'
    calcHi = 'CRC_FR_DTR_CALC_CHECKSUM_HIGH__CRC_FR_CALC_CHECKSUM_HIGH'
    calcLo = 'CRC_FR_CALC_CHECKSUM_LOW'
    wrtHi = 'CRC_FR_DTR_WRT_CHECKSUM_HIGH__CRC_FR_WRT_CHECKSUM_HIGH'
    wrtLo = 'CRC_FR_WRT_CHECKSUM_LOW'
    rnc = 'DARK_CONTROL__DARK_CONTROL_ROW_NOISE_CORRECTION_EN'
    dataPed = 'DATA_PEDESTAL_'
    crcContReg = 'CRC_CONTROL_REG'
    framePattern = 'Macro4'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, None, document, pltPath, showPlt)  # Temperature for each val test
    VRG_General_Data.FrameCount_Plot(df, None, document, pltPath, showPlt)  # Number of frames for each val test
    VRG_General_Data.Clk_Frequency_Plot(df, None, document, pltPath, showPlt)  # Plot each frequency for each test
    VRG_General_Data.TestTime_Plot(df, None, document, pltPath, showPlt)  # Time to run each val test
    VRG_General_Data.RunNumber_Plot(df, None, document, pltPath, showPlt)  # Val test run number
    VRG_General_Data.FrameWidth_Plot(df, None, document, pltPath, showPlt)  # Frame width
    VRG_General_Data.FrameHeight_Plot(df, None, document, pltPath, showPlt)  # Frame height
    VRG_General_Data.FrameBitDepth_Plot(df, None, document, pltPath, showPlt)  # Frame bit depth
    VRG_General_Data.DroppedFrames_Plot(df, None, document, pltPath, showPlt)  # Dropped frames
    VRG_General_Data.Sensor_FPS_Plot(df, None, document, pltPath, showPlt)  # Frames/second
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, None, document, pltPath, showPlt)  # Plot tempsensor data for all tests
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, None, document, pltPath, showPlt)  # Plot ASIL startup data for all tests

    document.add_heading('Additional Key Register Settings', level=1)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, rnc, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, dataPed, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, crcContReg, showPlt)

    document.add_heading('SM_STANDBY_TEST_FRAME Register Settings vs. Imaging Mode', level=1)
    VRG_Safety_Data.SM_STANDBY_TEST_FRAME(df, 'ImgMode', document, pltPath, showPlt)
    document.add_heading('SM_STANDBY_TEST_FRAME SYS_CHECK Values vs. vs. Imaging Mode')
    VRG_Safety_Data.SM_SYS_CHECK(df, 'ImgMode', document, pltPath, showPlt)

    document.add_heading('SM_STANDBY_TEST_FRAME Register Settings vs. Test Frame Patterns', level=1)
    VRG_Safety_Data.SM_STANDBY_TEST_FRAME(df, framePattern, document, pltPath, showPlt)
    document.add_heading('SM_STANDBY_TEST_FRAME SYS_CHECK Values vs. Test Frame Patterns')
    VRG_Safety_Data.SM_SYS_CHECK(df, framePattern, document, pltPath, showPlt)

    document.add_heading('SM_STANDBY_TEST_FRAME Calculated High CRC vs Expected High CRC vs. Imaging Mode')
    VRG_Register_Data.Reg_vs_Reg_Plot(df, 'ImgMode', document, pltPath, hiCalcCRC, hiWrtCRC, showPlt)
    document.add_heading('SM_STANDBY_TEST_FRAME Calculated High Frame CRC vs Expected High Frame CRC vs. Imaging Mode')
    VRG_Register_Data.Reg_vs_Reg_Plot(df, 'ImgMode', document, pltPath, calcHi, wrtHi, showPlt)
    document.add_heading('SM_STANDBY_TEST_FRAME Calculated Low CRC vs Expected Low CRC vs. Imaging Mode')
    VRG_Register_Data.Reg_vs_Reg_Plot(df, 'ImgMode', document, pltPath, calcLo, wrtLo, showPlt)

    df_t1 = df[[temp, 'ImgMode', framePattern, hiCalcCRC, calcHi, calcLo, hiWrtCRC, wrtHi, wrtLo]]
    document.add_heading('SM_STANDBY_TEST_FRAME Frame CRC Table vs. Pattern vs. Imaging Mode. vs. Temperature')
    VRG_Doc.df_to_table(df_t1, document)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[framePattern].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' SM_STANDBY_TEST_FRAME Register Values vs. Test Frame Patterns', level=2)
        VRG_Safety_Data.SM_STANDBY_TEST_FRAME(df_img, framePattern, document, pltPath, showPlt)
        document.add_heading(i + ' SM_STANDBY_TEST_FRAME SYS_CHECK Values vs. Test Frame Patterns', level=2)
        VRG_Safety_Data.SM_SYS_CHECK(df_img, framePattern, document, pltPath, showPlt)

        document.add_heading(i + ' SM_STANDBY_TEST_FRAME Calculated High CRC vs Test Frame Pattern', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, framePattern, document, pltPath, calcHi, showPlt)
        document.add_heading(i + ' SM_STANDBY_TEST_FRAME Calculated Low CRC vs Test Frame Pattern', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, framePattern, document, pltPath, calcLo, showPlt)

        document.add_heading(
            i + ' SM_STANDBY_TEST_FRAME Calculated High CRC vs Expected High CRC vs. Test Frame Pattern')
        VRG_Register_Data.Reg_vs_Reg_Plot(df, 'ImgMode', document, pltPath, hiCalcCRC, hiWrtCRC, showPlt)
        document.add_heading(
            i + ' SM_STANDBY_TEST_FRAME Calculated High Frame CRC vs Expected High Frame CRC vs. Test Frame Pattern')
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, framePattern, document, pltPath, calcHi, wrtHi, showPlt)
        document.add_heading(i + ' SM_STANDBY_TEST_FRAME Calculated Low CRC vs Expected Low CRC vs. Test Frame Pattern')
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, framePattern, document, pltPath, calcLo, wrtLo, showPlt)

        df_t2 = df_img[[temp, 'ImgMode', framePattern, hiCalcCRC, calcHi, calcLo, hiWrtCRC, wrtHi, wrtLo]]
        document.add_heading(i + ' SM_STANDBY_TEST_FRAME Frame CRC Table', level=2)
        VRG_Doc.df_to_table(df_t2, document)

        document.add_heading(i + ' SM_STANDBY_TEST_FRAME Image Mean & StdDev vs. Test Frame Pattern', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, framePattern, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, framePattern, document, pltPath, showPlt)

        for tst in TEST:  # Test
            df_test = VRG_Data_Frame.newdataframe(df_img, framePattern, tst)

            document.add_heading(i + ' SM_STANDBY_TEST_FRAME Frame Pattern: ' + str(tst), level=1)
            document.add_heading(
                i + ' SM_STANDBY_TEST_FRAME Frame Pattern: ' + str(tst) + ' Standby Test Frame Register Values',
                level=2)
            VRG_Safety_Data.SM_STANDBY_TEST_FRAME(df_test, framePattern, document, pltPath, showPlt)
            document.add_heading(i + ' SM_STANDBY_TEST_FRAME Frame Pattern: ' + str(tst) + ' SYS_CHECK Values', level=2)
            VRG_Safety_Data.SM_SYS_CHECK(df_test, framePattern, document, pltPath, showPlt)

            document.add_heading(i + ' SM_STANDBY_TEST_FRAME Frame Pattern: ' + str(tst) + ' Calculated High CRC',
                                 level=2)
            VRG_Register_Data.Reg_vs_Step_Plot(df_test, framePattern, document, pltPath, hiCalcCRC, showPlt)
            document.add_heading(i + ' SM_STANDBY_TEST_FRAME Frame Pattern: ' + str(tst) + ' Calculated High Frame CRC',
                                 level=2)
            VRG_Register_Data.Reg_vs_Step_Plot(df_test, framePattern, document, pltPath, calcHi, showPlt)
            document.add_heading(i + ' SM_STANDBY_TEST_FRAME Frame Pattern: ' + str(tst) + ' Calculated Low CRC',
                                 level=2)
            VRG_Register_Data.Reg_vs_Step_Plot(df_test, framePattern, document, pltPath, calcLo, showPlt)

            document.add_heading(
                i + ' SM_STANDBY_TEST_FRAME Frame Pattern: ' + str(tst) + ' Calculated High CRC vs Expected High CRC',
                level=2)
            VRG_Register_Data.Reg_vs_Reg_Plot(df_test, framePattern, document, pltPath, hiCalcCRC, hiWrtCRC, showPlt)
            document.add_heading(i + ' SM_STANDBY_TEST_FRAME Frame Pattern: ' + str(
                tst) + ' Calculated High Frame CRC vs Expected High Frame CRC', level=2)
            VRG_Register_Data.Reg_vs_Reg_Plot(df_test, framePattern, document, pltPath, calcHi, wrtHi, showPlt)
            document.add_heading(
                i + ' SM_STANDBY_TEST_FRAME Frame Pattern: ' + str(tst) + ' Calculated Low CRC vs Expected Low CRC',
                level=2)
            VRG_Register_Data.Reg_vs_Reg_Plot(df_test, framePattern, document, pltPath, calcLo, wrtLo, showPlt)

            df_t3 = df_test[[temp, 'ImgMode', framePattern, hiCalcCRC, calcHi, calcLo, hiWrtCRC, wrtHi, wrtLo]]
            document.add_heading(i + ' SM_STANDBY_TEST_FRAME Frame Pattern: ' + str(tst) + ' Frame CRC Table', level=2)
            VRG_Doc.df_to_table(df_t3, document)

            document.add_heading(i + ' SM_STANDBY_TEST_FRAME Frame Pattern: ' + str(tst) + ' Image Mean & StdDev',
                                 level=2)
            VRG_Stats_Arr.Arr_Mean_Plot(df_test, framePattern, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_StdDev_Plot(df_test, framePattern, document, pltPath, showPlt)

            for tmp in TEMP:  # Temperature
                df_tmp = VRG_Data_Frame.newdataframe(df_test, temp, tmp)
                if tmp == nomTemp:
                    document.add_heading(i + ' Image Capture' + str(tst) + ' at Temperature = ' + str(tmp), level=2)
                    VRG_Image_Analysis.Add_Image(df_tmp, 2, document, showPlt)

def DV_12_0_07_SM_SYS_CHECK(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_0_08_SM_AHM_BOOSTER_BANDGAP_MONITOR(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    reg1 = 'RegWr00_MODE_SELECT'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.LightLevel_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # Primary Voltage, Power, and Current
    document.add_heading('Power & Current vs. Voltage Level')
    VRG_Power_Data.Supply_Voltage_Plot(df, [die, temp, 'Power'], document, pltPath, showPlt)
    VRG_Power_Data.Power_Consumption_Plot(df, [die, temp, 'Power'], document, pltPath, showPlt)
    VRG_Power_Data.Current_Consumption_Plot(df, [die, temp, 'Power'], document, pltPath, showPlt)

    document.add_heading('Reset Register vs. Test Step')
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, reg1, showPlt)

    document.add_heading('All SM Booster Monitor Data vs. Die vs. Temp vs. Power')
    VRG_Safety_Data.SM_AHM_BOOSTER_BANDGAP_MONITOR(df, [die, temp, 'Power'], document, pltPath, showPlt)
    document.add_heading('All SM Booster Monitor Name Data vs. Imaging Mode')
    VRG_Safety_Data.SM_AHM_BOOSTER_BANDGAP_MONITOR_NAMES(df, 'ImgMode', document, pltPath, showPlt)
    document.add_heading('All SM Booster Monitor Name Data vs. Imaging Mode vs. Power', level=2)
    VRG_Safety_Data.SM_AHM_BOOSTER_BANDGAP_MONITOR_NAMES(df, ['ImgMode', 'Power'], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' SM Booster Monitor Registers vs. Die vs. Temp', level=2)
        VRG_Safety_Data.SM_AHM_BOOSTER_BANDGAP_MONITOR(df_img, [die, temp], document, pltPath, showPlt)
        document.add_heading(i + ' SM Booster Monitor Names vs. Temp', level=2)
        VRG_Safety_Data.SM_AHM_BOOSTER_BANDGAP_MONITOR_NAMES(df_img, temp, document, pltPath, showPlt)
        document.add_heading(i + ' SM Booster Monitor Names vs. Power', level=2)
        VRG_Safety_Data.SM_AHM_BOOSTER_BANDGAP_MONITOR_NAMES(df_img, 'Power', document, pltPath, showPlt)
        document.add_heading(i + ' SM Booster Monitor Names vs. Time vs. Power', level=2)
        VRG_Safety_Data.SM_AHM_BOOSTER_BANDGAP_MONITOR_NAMES_vs_Time_Plot(df_img, None, None, document, pltPath, showPlt)

        # Primary Voltage, Power, and Current
        document.add_heading(i + ' Power & Current vs. Voltage Level', level=2)
        VRG_Power_Data.Supply_Voltage_Plot(df_img, [die, temp, 'Power'], document, pltPath, showPlt)
        VRG_Power_Data.Power_Consumption_Plot(df_img, [die, temp, 'Power'], document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, [die, temp, 'Power'], document, pltPath, showPlt)

def DV_12_0_09_SM_CHIP_SUPPLY_VOLTAGE_MONITOR(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    reg1 = 'RegWr00_MODE_SELECT'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.LightLevel_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # Primary Voltage, Power, and Current
    document.add_heading('Power & Current vs. Voltage Level')
    VRG_Power_Data.Supply_Voltage_Plot(df, [die, temp, 'Power'], document, pltPath, showPlt)
    VRG_Power_Data.Power_Consumption_Plot(df, [die, temp, 'Power'], document, pltPath, showPlt)
    VRG_Power_Data.Current_Consumption_Plot(df, [die, temp, 'Power'], document, pltPath, showPlt)

    document.add_heading('Reset Register vs. Test Step')
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, reg1, showPlt)

    document.add_heading('All SM Supply Voltage Monitor Data vs. Die vs. Temp vs. Power')
    VRG_Safety_Data.SM_CHIP_SUPPLY_VOLTAGE_MONITOR(df, [die, temp, 'Power'], document, pltPath, showPlt)
    document.add_heading('All SM Supply Voltage Monitor Name Data vs. Imaging Mode')
    VRG_Safety_Data.SM_CHIP_SUPPLY_VOLTAGE_MONITOR_NAMES(df, 'ImgMode', document, pltPath, showPlt)
    document.add_heading('All SM Supply Voltage Monitor Name Data vs. Imaging Mode vs. Power', level=2)
    VRG_Safety_Data.SM_CHIP_SUPPLY_VOLTAGE_MONITOR_NAMES(df, ['ImgMode', 'Power'], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' SM Supply Voltage Monitor Registers vs. Die vs. Temp', level=2)
        VRG_Safety_Data.SM_CHIP_SUPPLY_VOLTAGE_MONITOR(df_img, [die, temp], document, pltPath, showPlt)
        document.add_heading(i + ' SM Supply Voltage Monitor Names vs. Temp', level=2)
        VRG_Safety_Data.SM_CHIP_SUPPLY_VOLTAGE_MONITOR_NAMES(df_img, temp, document, pltPath, showPlt)
        document.add_heading(i + ' SM Supply Voltage Monitor Names vs. Power', level=2)
        VRG_Safety_Data.SM_CHIP_SUPPLY_VOLTAGE_MONITOR_NAMES(df_img, 'Power', document, pltPath, showPlt)
        document.add_heading(i + ' SM Supply Voltage Monitor Names vs. Time vs. Power', level=2)
        VRG_Safety_Data.SM_CHIP_SUPPLY_VOLTAGE_MONITOR_NAMES_vs_Time_Plot(df_img, None, None, document, pltPath, showPlt)

        # Primary Voltage, Power, and Current
        document.add_heading(i + ' Power & Current vs. Voltage Level', level=2)
        VRG_Power_Data.Supply_Voltage_Plot(df_img, [die, temp, 'Power'], document, pltPath, showPlt)
        VRG_Power_Data.Power_Consumption_Plot(df_img, [die, temp, 'Power'], document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, [die, temp, 'Power'], document, pltPath, showPlt)

def DV_12_0_09_SM_CHIP_SUPPLY_VOLTAGE_MONITOR_SUPPLY_DECREASE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    vs1 = 'VAA_V'
    vs2 = 'VAA_PIX_V'
    vs3 = 'VDD_V'
    vs4 = 'VAA1V8_V'
    vs5 = 'VAA2V8_V'
    vs6 = 'VDD_IO_V'
    vs7 = 'VDDIO_PHY_V'
    supplyChange = 'DVM_Supply_Decrease'
    vChange = 'Voltage_Decrease'
    voltStep = -.02
    df[vChange] = (df[supplyChange] + 1) * voltStep

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.LightLevel_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # Primary Voltage, Power, and Current
    document.add_heading('Power & Current vs. Voltage Level')
    VRG_Power_Data.Supply_Voltage_Plot(df, [die, temp, 'Power'], document, pltPath, showPlt)
    VRG_Power_Data.Power_Consumption_Plot(df, [die, temp, 'Power'], document, pltPath, showPlt)
    VRG_Power_Data.Current_Consumption_Plot(df, [die, temp, 'Power'], document, pltPath, showPlt)

    document.add_heading('Supply Voltages vs. Test Step')
    VRG_Safety_Data.SM_BMON_VMON_Supply_Voltage_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('All SM Voltage Monitor Data')
    VRG_Safety_Data.SM_CHIP_SUPPLY_VOLTAGE_MONITOR(df, None, document, pltPath, showPlt, lines=False)
    document.add_heading('All SM Voltage Monitor Data vs. Voltage Increase')
    VRG_Safety_Data.SM_CHIP_SUPPLY_VOLTAGE_MONITOR(df, vChange, document, pltPath, showPlt, lines=False)
    document.add_heading('All SM Voltage Monitor Name Data')
    VRG_Safety_Data.SM_CHIP_SUPPLY_VOLTAGE_MONITOR_NAMES(df, None, document, pltPath, showPlt, lines=False)
    document.add_heading('All SM Voltage Monitor Name Data vs. Voltage Increase')
    VRG_Safety_Data.SM_CHIP_SUPPLY_VOLTAGE_MONITOR_NAMES(df, vChange, document, pltPath, showPlt, lines=False)
    document.add_heading('ALL SM Voltage Monitor Name Data vs. Supply Voltage vs. Die')
    VRG_Safety_Data.SM_CHIP_SUPPLY_VOLTAGE_MONITOR_NAMES_vs_Supply_Voltage(df, die, document, pltPath, showPlt,
                                                                           lines=False)
    document.add_heading('ALL SM Voltage Monitor Name Data vs. Supply Voltage')
    VRG_Safety_Data.SM_CHIP_SUPPLY_VOLTAGE_MONITOR_NAMES_vs_Supply_Voltage(df, None, document, pltPath, showPlt,
                                                                           lines=False)
    document.add_heading('Image Mean & StdDev vs. Supply Level Change -20mv * (' + supplyChange + ' + 1)', level=2)
    VRG_Stats_Arr.Arr_Mean_Plot(df, supplyChange, document, pltPath, showPlt)
    VRG_Stats_Arr.Arr_StdDev_Plot(df, supplyChange, document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Supply Voltages vs. Test Step', level=2)
        VRG_Safety_Data.SM_BMON_VMON_Supply_Voltage_Plot(df_img, [die, temp], document, pltPath, showPlt)
        document.add_heading(i + ' SM Voltage Supply Monitor Register vs. Test Step', level=2)
        VRG_Safety_Data.SM_CHIP_SUPPLY_VOLTAGE_MONITOR(df_img, None, document, pltPath, showPlt, lines=False)
        document.add_heading(i + ' SM Voltage Supply Monitor Register vs. Test Step vs. Voltage Increase', level=2)
        VRG_Safety_Data.SM_CHIP_SUPPLY_VOLTAGE_MONITOR(df_img, vChange, document, pltPath, showPlt, lines=False)
        document.add_heading(i + ' SM Voltage Supply Monitor Name vs. Test Step', level=2)
        VRG_Safety_Data.SM_CHIP_SUPPLY_VOLTAGE_MONITOR_NAMES(df_img, None, document, pltPath, showPlt, lines=False)
        document.add_heading(i + ' SM Voltage Supply Monitor Name vs. Test Step vs. Voltage Increase', level=2)
        VRG_Safety_Data.SM_CHIP_SUPPLY_VOLTAGE_MONITOR_NAMES(df_img, vChange, document, pltPath, showPlt, lines=False)
        document.add_heading(i + ' SM Voltage Supply Monitor Name vs. Supply Voltage vs. Die', level=2)
        VRG_Safety_Data.SM_CHIP_SUPPLY_VOLTAGE_MONITOR_NAMES_vs_Supply_Voltage(df_img, die, document, pltPath, showPlt,
                                                                               lines=False)
        document.add_heading(i + ' SM Voltage Supply Monitor Name vs. Supply Voltage', level=2)
        VRG_Safety_Data.SM_CHIP_SUPPLY_VOLTAGE_MONITOR_NAMES_vs_Supply_Voltage(df_img, None, document, pltPath, showPlt,
                                                                               lines=False)
        document.add_heading(i + ' SM Voltage Supply Monitor Names vs. Time', level=2)
        VRG_Safety_Data.SM_CHIP_SUPPLY_VOLTAGE_MONITOR_NAMES_vs_Time_Plot(df_img, None, None, document, pltPath, showPlt,
                                                                          lines=False)
        document.add_heading(i + ' Image Mean & StdDev vs. Supply Level Change -20mv * (' + supplyChange + ' + 1)',
                             level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, supplyChange, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, supplyChange, document, pltPath, showPlt)
        document.add_heading(i + ' Image Mean & StdDev vs. Voltage Increase', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, vChange, document, pltPath, showPlt, lines=False)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, vChange, document, pltPath, showPlt, lines=False)

        # document.add_heading(i + ' Image StdDev vs. Supply Level', level=2)
        # VRG_Stats_Arr.Arr_Mean_Plot(df_img, vs1, document, pltPath, showPlt)
        # VRG_Stats_Arr.Arr_Mean_Plot(df_img, vs2, document, pltPath, showPlt)
        # VRG_Stats_Arr.Arr_Mean_Plot(df_img, vs3, document, pltPath, showPlt)
        # VRG_Stats_Arr.Arr_Mean_Plot(df_img, vs4, document, pltPath, showPlt)
        # VRG_Stats_Arr.Arr_Mean_Plot(df_img, vs5, document, pltPath, showPlt)
        # VRG_Stats_Arr.Arr_Mean_Plot(df_img, vs6, document, pltPath, showPlt)
        # VRG_Stats_Arr.Arr_Mean_Plot(df_img, vs7, document, pltPath, showPlt)
        #
        # document.add_heading(i + ' Image StdDev vs. Supply Level', level=2)
        # VRG_Stats_Arr.Arr_StdDev_Plot(df_img, vs1, document, pltPath, showPlt)
        # VRG_Stats_Arr.Arr_StdDev_Plot(df_img, vs2, document, pltPath, showPlt)
        # VRG_Stats_Arr.Arr_StdDev_Plot(df_img, vs3, document, pltPath, showPlt)
        # VRG_Stats_Arr.Arr_StdDev_Plot(df_img, vs4, document, pltPath, showPlt)
        # VRG_Stats_Arr.Arr_StdDev_Plot(df_img, vs5, document, pltPath, showPlt)
        # VRG_Stats_Arr.Arr_StdDev_Plot(df_img, vs6, document, pltPath, showPlt)
        # VRG_Stats_Arr.Arr_StdDev_Plot(df_img, vs7, document, pltPath, showPlt)

def DV_12_0_09_SM_CHIP_SUPPLY_VOLTAGE_MONITOR_SUPPLY_INCREASE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    vs1 = 'VAA_V'
    vs2 = 'VAA_PIX_V'
    vs3 = 'VDD_V'
    vs4 = 'VAA1V8_V'
    vs5 = 'VAA2V8_V'
    vs6 = 'VDD_IO_V'
    vs7 = 'VDDIO_PHY_V'
    supplyChange = 'DVM_Supply_Increase'
    vChange = 'Voltage_Increase'
    voltStep = .02
    df[vChange] = (df[supplyChange] + 1) * voltStep

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.LightLevel_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # Primary Voltage, Power, and Current
    document.add_heading('Power & Current vs. Voltage Level')
    VRG_Power_Data.Supply_Voltage_Plot(df, [die, temp, 'Power'], document, pltPath, showPlt)
    VRG_Power_Data.Power_Consumption_Plot(df, [die, temp, 'Power'], document, pltPath, showPlt)
    VRG_Power_Data.Current_Consumption_Plot(df, [die, temp, 'Power'], document, pltPath, showPlt)

    document.add_heading('Supply Voltages vs. Test Step')
    VRG_Safety_Data.SM_BMON_VMON_Supply_Voltage_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('All SM Voltage Monitor Data')
    VRG_Safety_Data.SM_CHIP_SUPPLY_VOLTAGE_MONITOR(df, None, document, pltPath, showPlt, lines=False)
    document.add_heading('All SM Voltage Monitor Data vs. Voltage Increase')
    VRG_Safety_Data.SM_CHIP_SUPPLY_VOLTAGE_MONITOR(df, vChange, document, pltPath, showPlt, lines=False)
    document.add_heading('All SM Voltage Monitor Name Data')
    VRG_Safety_Data.SM_CHIP_SUPPLY_VOLTAGE_MONITOR_NAMES(df, None, document, pltPath, showPlt, lines=False)
    document.add_heading('All SM Voltage Monitor Name Data vs. Voltage Increase')
    VRG_Safety_Data.SM_CHIP_SUPPLY_VOLTAGE_MONITOR_NAMES(df, vChange, document, pltPath, showPlt, lines=False)
    document.add_heading('ALL SM Voltage Monitor Name Data vs. Supply Voltage vs. Die')
    VRG_Safety_Data.SM_CHIP_SUPPLY_VOLTAGE_MONITOR_NAMES_vs_Supply_Voltage(df, die, document, pltPath, showPlt,
                                                                           lines=False)
    document.add_heading('ALL SM Voltage Monitor Name Data vs. Supply Voltage')
    VRG_Safety_Data.SM_CHIP_SUPPLY_VOLTAGE_MONITOR_NAMES_vs_Supply_Voltage(df, None, document, pltPath, showPlt,
                                                                           lines=False)
    document.add_heading('Image Mean & StdDev vs. Supply Level Change +20mv * (' + supplyChange + ' + 1)', level=2)
    VRG_Stats_Arr.Arr_Mean_Plot(df, supplyChange, document, pltPath, showPlt)
    VRG_Stats_Arr.Arr_StdDev_Plot(df, supplyChange, document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Supply Voltages vs. Test Step', level=2)
        VRG_Safety_Data.SM_BMON_VMON_Supply_Voltage_Plot(df_img, [die, temp], document, pltPath, showPlt)
        document.add_heading(i + ' SM Voltage Supply Monitor Register vs. Test Step', level=2)
        VRG_Safety_Data.SM_CHIP_SUPPLY_VOLTAGE_MONITOR(df_img, None, document, pltPath, showPlt, lines=False)
        document.add_heading(i + ' SM Voltage Supply Monitor Register vs. Test Step vs. Voltage Increase', level=2)
        VRG_Safety_Data.SM_CHIP_SUPPLY_VOLTAGE_MONITOR(df_img, vChange, document, pltPath, showPlt, lines=False)
        document.add_heading(i + ' SM Voltage Supply Monitor Name vs. Test Step', level=2)
        VRG_Safety_Data.SM_CHIP_SUPPLY_VOLTAGE_MONITOR_NAMES(df_img, None, document, pltPath, showPlt, lines=False)
        document.add_heading(i + ' SM Voltage Supply Monitor Name vs. Test Step vs. Voltage Increase', level=2)
        VRG_Safety_Data.SM_CHIP_SUPPLY_VOLTAGE_MONITOR_NAMES(df_img, vChange, document, pltPath, showPlt, lines=False)
        document.add_heading(i + ' SM Voltage Supply Monitor Name vs. Supply Voltage vs. Die', level=2)
        VRG_Safety_Data.SM_CHIP_SUPPLY_VOLTAGE_MONITOR_NAMES_vs_Supply_Voltage(df_img, die, document, pltPath, showPlt,
                                                                               lines=False)
        document.add_heading(i + ' SM Voltage Supply Monitor Name vs. Supply Voltage', level=2)
        VRG_Safety_Data.SM_CHIP_SUPPLY_VOLTAGE_MONITOR_NAMES_vs_Supply_Voltage(df_img, None, document, pltPath, showPlt,
                                                                               lines=False)
        document.add_heading(i + ' SM Voltage Supply Monitor Names vs. Time', level=2)
        VRG_Safety_Data.SM_CHIP_SUPPLY_VOLTAGE_MONITOR_NAMES_vs_Time_Plot(df_img, None, None, document, pltPath, showPlt,
                                                                          lines=False)
        document.add_heading(i + ' Image Mean & StdDev vs. Supply Level Change +20mv * (' + supplyChange + ' + 1)',
                             level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, supplyChange, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, supplyChange, document, pltPath, showPlt)
        document.add_heading(i + ' Image Mean & StdDev vs. Voltage Increase', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, vChange, document, pltPath, showPlt, lines=False)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, vChange, document, pltPath, showPlt, lines=False)

        # document.add_heading(i + ' Image StdDev vs. Supply Level', level=2)
        # VRG_Stats_Arr.Arr_Mean_Plot(df_img, vs1, document, pltPath, showPlt)
        # VRG_Stats_Arr.Arr_Mean_Plot(df_img, vs2, document, pltPath, showPlt)
        # VRG_Stats_Arr.Arr_Mean_Plot(df_img, vs3, document, pltPath, showPlt)
        # VRG_Stats_Arr.Arr_Mean_Plot(df_img, vs4, document, pltPath, showPlt)
        # VRG_Stats_Arr.Arr_Mean_Plot(df_img, vs5, document, pltPath, showPlt)
        # VRG_Stats_Arr.Arr_Mean_Plot(df_img, vs6, document, pltPath, showPlt)
        # VRG_Stats_Arr.Arr_Mean_Plot(df_img, vs7, document, pltPath, showPlt)
        #
        # document.add_heading(i + ' Image StdDev vs. Supply Level', level=2)
        # VRG_Stats_Arr.Arr_StdDev_Plot(df_img, vs1, document, pltPath, showPlt)
        # VRG_Stats_Arr.Arr_StdDev_Plot(df_img, vs2, document, pltPath, showPlt)
        # VRG_Stats_Arr.Arr_StdDev_Plot(df_img, vs3, document, pltPath, showPlt)
        # VRG_Stats_Arr.Arr_StdDev_Plot(df_img, vs4, document, pltPath, showPlt)
        # VRG_Stats_Arr.Arr_StdDev_Plot(df_img, vs5, document, pltPath, showPlt)
        # VRG_Stats_Arr.Arr_StdDev_Plot(df_img, vs6, document, pltPath, showPlt)
        # VRG_Stats_Arr.Arr_StdDev_Plot(df_img, vs7, document, pltPath, showPlt)

def DV_12_0_10_SM_TEMP_SENSOR(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    ULcolor = '#ff0000'
    LLcolor = '#0000ff'
    tempK = 'SPARE_TEMPSENS1_DATA_K_REG'
    redCodeReg = 'RegWr01_TEMPVSENS1_TMG_CTRL_K0'
    redCode = 'TEMPVSENS1_TMG_CTRL_K0__TEMPSENS1_RED_TEMP_CODE_K'
    yellowCode = 'TEMPVSENS1_TMG_CTRL_K1__TEMPSENS1_YELLOW_OFF_RED_K'
    yellowHyst = 'TEMPVSENS1_TMG_CTRL_K1__TEMPSENS1_YELLOW_HYST_K'
    yellowStatus = 'TEMPVSENS1_STATUS__TEMPVSENS1_YELLOW_FLAG'
    redStatus = 'TEMPVSENS1_STATUS__TEMPVSENS1_RED_FLAG'
    yellowGatedStatus = 'TEMPVSENS1_STATUS__TEMPVSENS1_YELLOW_FLAG_GATED'
    redGatedStatus = 'TEMPVSENS1_STATUS__TEMPVSENS1_RED_FLAG_GATED'
    tempFlag = 'TempFlag'
    tempStatus = 'TEMPVSENS1_STATUS'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, None, document, pltPath, showPlt)  # Temperature for each val test
    VRG_General_Data.FrameCount_Plot(df, None, document, pltPath, showPlt)  # Number of frames for each val test
    VRG_General_Data.Clk_Frequency_Plot(df, None, document, pltPath, showPlt)  # Plot each frequency for each test
    VRG_General_Data.TestTime_Plot(df, None, document, pltPath, showPlt)  # Time to run each val test
    VRG_General_Data.RunNumber_Plot(df, None, document, pltPath, showPlt)  # Val test run number
    VRG_General_Data.FrameWidth_Plot(df, None, document, pltPath, showPlt)  # Frame width
    VRG_General_Data.FrameHeight_Plot(df, None, document, pltPath, showPlt)  # Frame height
    VRG_General_Data.FrameBitDepth_Plot(df, None, document, pltPath, showPlt)  # Frame bit depth
    VRG_General_Data.DroppedFrames_Plot(df, None, document, pltPath, showPlt)  # Dropped frames
    VRG_General_Data.Sensor_FPS_Plot(df, None, document, pltPath, showPlt)  # Frames/second
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, None, document, pltPath, showPlt)  # Plot tempsensor data for all tests
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, None, document, pltPath, showPlt)  # Plot ASIL startup data for all tests

    document.add_heading('Temperature Data vs. Imaging Mode')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, 'ImgMode', document, pltPath, showPlt)
    document.add_heading('SM_TEMP_SENSOR Registers vs. Imaging Mode')
    VRG_Safety_Data.SM_TEMP_SENSOR(df, 'ImgMode', document, pltPath, showPlt)

    VRG_General_Data.Data_vs_Data_vs_Step_Plot(df, 'ImgMode', document, pltPath, redStatus, tempFlag, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[redCodeReg].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Temperature Data', level=2)
        VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, None, document, pltPath, showPlt)

        document.add_heading(i + ' SM Tempsensor vs. Red Temp Code', level=2)
        VRG_Safety_Data.SM_TEMP_SENSOR(df_img, redCode, document, pltPath, showPlt)

        document.add_heading(i + ' Red Temp Code vs. ' + tempK, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, redCode, tempK, showPlt)

        document.add_heading(i + ' ' + tempStatus + ' vs. ' + tempK + ' vs. Red Temp Code', level=2)
        VRG_General_Data.Data_vs_Data_vs_Step_Plot(df_img, redCode, document, pltPath, tempStatus, tempK, showPlt)

        document.add_heading(i + ' ' + tempStatus + ' vs. ' + tempFlag + ' vs. Red Temp Code', level=2)
        VRG_General_Data.Data_vs_Data_vs_Step_Plot(df_img, redCode, document, pltPath, tempStatus, tempFlag, showPlt)

        document.add_heading(i + ' Red Flag Status vs. Temp Flag vs. Red Temp Code', level=2)
        VRG_General_Data.Data_vs_Data_vs_Step_Plot(df_img, redCode, document, pltPath, redStatus, tempFlag, showPlt)
        document.add_heading(i + ' Yellow Flag Status vs. Temp Flag vs. Red Temp Code', level=2)
        VRG_General_Data.Data_vs_Data_vs_Step_Plot(df_img, redCode, document, pltPath, yellowStatus, tempFlag, showPlt)
        document.add_heading(i + ' Red Flag Gated Status vs. Temp Flag vs. Red Temp Code', level=2)
        VRG_General_Data.Data_vs_Data_vs_Step_Plot(df_img, redCode, document, pltPath, redGatedStatus, tempFlag, showPlt)
        document.add_heading(i + ' Yellow Flag Gated Status vs. Temp Flag vs. Red Temp Code', level=2)
        VRG_General_Data.Data_vs_Data_vs_Step_Plot(df_img, redCode, document, pltPath, yellowGatedStatus, tempFlag,
                                                   showPlt)

        document.add_heading(i + ' SM_AHM_BOOSTER_BANDGAP_MONITOR_NAMES vs. Red Temp Code', level=2)
        VRG_Safety_Data.SM_AHM_BOOSTER_BANDGAP_MONITOR_NAMES(df_img, redCode, document, pltPath, showPlt)
        document.add_heading(i + ' SM_CHIP_SUPPLY_VOLTAGE_MONITOR_NAMES vs. Red Temp Code', level=2)
        VRG_Safety_Data.SM_CHIP_SUPPLY_VOLTAGE_MONITOR_NAMES(df_img, redCode, document, pltPath, showPlt, lines=False)

        document.add_heading(i + ' SM_AHM_BOOSTER_BANDGAP_MONITOR_NAMES vs. ' + tempFlag, level=2)
        VRG_Safety_Data.SM_AHM_BOOSTER_BANDGAP_MONITOR_NAMES(df_img, tempFlag, document, pltPath, showPlt)
        document.add_heading(i + ' SM_CHIP_SUPPLY_VOLTAGE_MONITOR_NAMES vs. ' + tempFlag, level=2)
        VRG_Safety_Data.SM_CHIP_SUPPLY_VOLTAGE_MONITOR_NAMES(df_img, tempFlag, document, pltPath, showPlt, lines=False)

        # Primary Voltage, Power, and Current
        document.add_heading(i + ' Power & Current vs. Red Temp Code', level=2)
        VRG_Power_Data.Power_Consumption_Plot(df_img, redCode, document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, redCode, document, pltPath, showPlt)

        df_t = df_img[[temp, tempK, redCode, redStatus, yellowStatus, redGatedStatus, yellowGatedStatus, tempFlag]]
        document.add_heading(i + ' SM_TEMP_SENSOR Results Table')
        VRG_Doc.df_to_table(df_t, document)

        for tst in TEST:  # Test
            df_test = VRG_Data_Frame.newdataframe(df_img, redCodeReg, tst)

            document.add_heading(i + ' Red Temp Code ' + str(tst), level=1)
            document.add_heading(i + ' SM_TEMP_SENSOR Register Values vs. Red Temp Code = ' + str(tst), level=2)
            VRG_Safety_Data.SM_TEMP_SENSOR(df_test, redCode, document, pltPath, showPlt)

            document.add_heading(i + ' Red Temp Code = ' + str(tst) + ' vs. ' + tempK, level=2)
            VRG_Register_Data.Reg_vs_Reg_Plot(df_test, None, document, pltPath, redCode, tempK, showPlt)

            document.add_heading(i + ' ' + tempStatus + ' vs. ' + tempFlag + ' vs. Red Temp Code = ' + str(tst),
                                 level=2)
            VRG_General_Data.Data_vs_Data_vs_Step_Plot(df_test, redCode, document, pltPath, tempStatus, tempFlag,
                                                       showPlt)

            document.add_heading(i + ' Red Flag Status vs. ' + tempK + ' vs. Red Temp Code = ' + str(tst), level=2)
            VRG_Register_Data.Reg_vs_Reg_Plot(df_test, redCode, document, pltPath, tempK, redStatus, showPlt,
                                              ax_hlines=[(redCode, ULcolor, '--', 3, 1)])
            document.add_heading(i + ' Yellow Flag Status vs. ' + tempK + ' vs. Red Temp Code = ' + str(tst), level=2)
            VRG_Register_Data.Reg_vs_Reg_Plot(df_test, redCode, document, pltPath, tempK, yellowStatus, showPlt,
                                              ax_hlines=[(redCode, ULcolor, '--', 3, 1)])
            document.add_heading(i + ' Red Flag Gated Status vs. ' + tempK + ' vs. Red Temp Code = ' + str(tst),
                                 level=2)
            VRG_Register_Data.Reg_vs_Reg_Plot(df_test, redCode, document, pltPath, tempK, redGatedStatus, showPlt,
                                              ax_hlines=[(redCode, ULcolor, '--', 3, 1)])
            document.add_heading(i + ' Yellow Flag Gated Status vs. ' + tempK + ' vs. Red Temp Code = ' + str(tst),
                                 level=2)
            VRG_Register_Data.Reg_vs_Reg_Plot(df_test, redCode, document, pltPath, tempK, yellowGatedStatus, showPlt,
                                              ax_hlines=[(redCode, ULcolor, '--', 3, 1)])
            document.add_heading(i + ' Temp Flag vs. ' + tempK + ' vs. Red Temp Code = ' + str(tst), level=2)
            VRG_General_Data.Data_vs_Data_vs_Step_Plot(df_test, redCode, document, pltPath, tempK, tempFlag, showPlt,
                                                       ax_hlines=[(redCode, ULcolor, '--', 3, 1)])

            # Primary Voltage, Power, and Current
            document.add_heading(i + ' Power & Current vs. Red Temp Code', level=2)
            VRG_Power_Data.Power_Consumption_Plot(df_test, redCode, document, pltPath, showPlt)
            VRG_Power_Data.Current_Consumption_Plot(df_test, redCode, document, pltPath, showPlt)

            df_t_test = df_img[
                [temp, tempK, redCode, redStatus, yellowStatus, redGatedStatus, yellowGatedStatus, tempFlag]]
            document.add_heading(i + ' SM_TEMP_SENSOR Results Table vs. Red Temp Code = ' + str(tst), level=2)
            VRG_Doc.df_to_table(df_t_test, document)

def DV_12_0_12_SM_AHM_ROW_ROM(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    reg1 = 'ATR_CHECK_CONTROL'
    reg2 = 'LINE_LENGTH_PCK_'
    reg3 = 'SMIA_TEST'
    reg4 = 'READ_MODE'
    reg5 = 'TEST_ASIL_ROWS'
    reg6 = 'DARK_CONTROL'
    reg7 = 'DBLC_CONTROL'
    reg8 = 'LFM2_T1_DBLC_TILT_ATR_CTRL'
    imgSize = 'Macro5'
    rrcAddrHi = 'RRC_ADDR_HI_THRESH'
    rrcAddrLo = 'RRC_ADDR_LO_THRESH'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, None, document, pltPath, showPlt)  # Temperature for each val test
    VRG_General_Data.FrameCount_Plot(df, None, document, pltPath, showPlt)  # Number of frames for each val test
    VRG_General_Data.Clk_Frequency_Plot(df, None, document, pltPath, showPlt)  # Plot each frequency for each test
    VRG_General_Data.TestTime_Plot(df, None, document, pltPath, showPlt)  # Time to run each val test
    VRG_General_Data.RunNumber_Plot(df, None, document, pltPath, showPlt)  # Val test run number
    VRG_General_Data.FrameWidth_Plot(df, None, document, pltPath, showPlt)  # Frame width
    VRG_General_Data.FrameHeight_Plot(df, None, document, pltPath, showPlt)  # Frame height
    VRG_General_Data.FrameBitDepth_Plot(df, None, document, pltPath, showPlt)  # Frame bit depth
    VRG_General_Data.DroppedFrames_Plot(df, None, document, pltPath, showPlt)  # Dropped frames
    VRG_General_Data.Sensor_FPS_Plot(df, None, document, pltPath, showPlt)  # Frames/second
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, None, document, pltPath, showPlt)  # Plot tempsensor data for all tests
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, None, document, pltPath, showPlt)  # Plot ASIL startup data for all tests

    document.add_heading('Key Register Settings vs. Imaging Mode')
    VRG_Register_Data.Reg_vs_Step_Plot(df, 'ImgMode', document, pltPath, reg1, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, 'ImgMode', document, pltPath, reg2, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, 'ImgMode', document, pltPath, reg3, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, 'ImgMode', document, pltPath, reg4, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, 'ImgMode', document, pltPath, reg5, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, 'ImgMode', document, pltPath, reg6, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, 'ImgMode', document, pltPath, reg7, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, 'ImgMode', document, pltPath, reg8, showPlt)

    document.add_heading('All RRC Register Values vs. Imaging Mode')
    VRG_Safety_Data.SM_AHM_ROW_ROM(df, 'ImgMode', document, pltPath, showPlt)

    document.add_heading('All SYS_CHECK Values vs. Imaging Mode')
    VRG_Safety_Data.SM_SYS_CHECK(df, 'ImgMode', document, pltPath, showPlt)

    document.add_heading('High Pixel Threshold For RRC ADDR CRC Values vs. Imaging Mode')
    VRG_General_Data.Data_vs_Step_Plot(df, 'ImgMode', document, pltPath, rrcAddrHi, showPlt)
    document.add_heading('Low Pixel Threshold For RRC ADDR CRC Values vs. Imaging Mode')
    VRG_General_Data.Data_vs_Step_Plot(df, 'ImgMode', document, pltPath, rrcAddrLo, showPlt)

    document.add_heading('RRC Address CRC & Statistics Values Expanded vs. Imaging Mode')
    VRG_Safety_Data.SM_Row_Rom_Address_Columns_Expanded_Plot(df, 'ImgMode', document, pltPath, showPlt)

    document.add_heading('RRC LDO Signal Integrity Columns Statistics Expanded vs. Imaging Mode')
    VRG_Safety_Data.SM_Row_Rom_SIC_Expanded_Plot(df, 'ImgMode', document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[imgSize].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' SM_AHM_ROW_ROM Register Values vs. Power', level=2)
        VRG_Safety_Data.SM_AHM_ROW_ROM(df_img, 'Power', document, pltPath, showPlt)
        document.add_heading(i + ' SM_AHM_ROW_ROM SYS_CHECK vs. Power', level=2)
        VRG_Safety_Data.SM_SYS_CHECK(df_img, 'Power', document, pltPath, showPlt)

        document.add_heading(i + ' High Pixel Threshold For RRC ADDR CRC Values vs. Power', level=2)
        VRG_General_Data.Data_vs_Step_Plot(df_img, 'Power', document, pltPath, rrcAddrHi, showPlt)
        document.add_heading(i + ' Low Pixel Threshold For RRC ADDR CRC Values vs. Power', level=2)
        VRG_General_Data.Data_vs_Step_Plot(df_img, 'Power', document, pltPath, rrcAddrLo, showPlt)

        document.add_heading(i + ' SM_AHM_ROW_ROM Address CRC & Statistics Values vs. Power', level=2)
        VRG_Safety_Data.SM_Row_Rom_Address_Columns_Plot(df_img, 'Power', document, pltPath, showPlt)
        document.add_heading(i + ' SM_AHM_ROW_ROM Address CRC & Statistics Values Expanded vs. Power', level=2)
        VRG_Safety_Data.SM_Row_Rom_Address_Columns_Expanded_Plot(df_img, 'Power', document, pltPath, showPlt)

        document.add_heading(i + ' SM_AHM_ROW_ROM LDO Signal Integrity Columns Statistics vs. Power', level=2)
        VRG_Safety_Data.SM_Row_Rom_SIC_Plot(df_img, 'Power', document, pltPath, showPlt)
        document.add_heading(i + ' SM_AHM_ROW_ROM LDO Signal Integrity Columns Statistics Expanded vs. Power', level=2)
        VRG_Safety_Data.SM_Row_Rom_SIC_Expanded_Plot(df_img, 'Power', document, pltPath, showPlt)

        document.add_heading(i + ' SM_AHM_ROW_ROM VS. TEMPERATURE', level=1)
        document.add_heading(i + ' SM_AHM_ROW_ROM Address CRC & Statistics Values vs. Temperature', level=2)
        VRG_Safety_Data.SM_Row_Rom_Address_Columns_Plot(df_img, temp, document, pltPath, showPlt)
        document.add_heading(i + ' SM_AHM_ROW_ROM Address CRC & Statistics Values Expanded vs. Temperature', level=2)
        VRG_Safety_Data.SM_Row_Rom_Address_Columns_Expanded_Plot(df_img, temp, document, pltPath, showPlt)

        document.add_heading(i + ' SM_AHM_ROW_ROM LDO Signal Integrity Columns Statistics vs. Temperature', level=2)
        VRG_Safety_Data.SM_Row_Rom_SIC_Plot(df_img, temp, document, pltPath, showPlt)
        document.add_heading(i + ' SM_AHM_ROW_ROM LDO Signal Integrity Columns Statistics Expanded vs. Temperature',
                             level=2)
        VRG_Safety_Data.SM_Row_Rom_SIC_Expanded_Plot(df_img, temp, document, pltPath, showPlt)

        document.add_heading(i + ' SM_AHM_ROW_ROM VS. IMAGE SIZE', level=1)
        document.add_heading(i + ' SM_AHM_ROW_ROM Address CRC & Statistics Values vs. Image Size', level=2)
        VRG_Safety_Data.SM_Row_Rom_Address_Columns_Plot(df_img, imgSize, document, pltPath, showPlt)
        document.add_heading(i + ' SM_AHM_ROW_ROM Address CRC & Statistics Values Expanded vs. Image Size', level=2)
        VRG_Safety_Data.SM_Row_Rom_Address_Columns_Expanded_Plot(df_img, imgSize, document, pltPath, showPlt)

        document.add_heading(i + ' SM_AHM_ROW_ROM LDO Signal Integrity Columns Statistics vs. Image Size', level=2)
        VRG_Safety_Data.SM_Row_Rom_SIC_Plot(df_img, imgSize, document, pltPath, showPlt)
        document.add_heading(i + ' SM_AHM_ROW_ROM LDO Signal Integrity Columns Statistics Expanded vs. Image Size',
                             level=2)
        VRG_Safety_Data.SM_Row_Rom_SIC_Expanded_Plot(df_img, imgSize, document, pltPath, showPlt)

        document.add_heading(i + ' Power & Current vs. Voltage Level', level=2)
        VRG_Power_Data.Power_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)

        document.add_heading(i + ' Image Mean & STD vs. Image Size', level=2)
        VRG_Stats_Frame.Rgn_Mean_Plot(df_img, imgSize, document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_StdDev_Plot(df_img, imgSize, document, pltPath, showPlt)

        # for tst in TEST:  # Test
        #     df_test = VRG_DataFrame.newdataframe(df_img, imgSize, tst)
        #
        #     document.add_heading(i + ' Image Size ' + str(tst), level=1)
        #     document.add_heading(i + ' Image Size ' + str(tst) + ' RRC Register Values vs. Power')
        #     VRG_AsilData.SM_AHM_ROW_ROM(df_test, 'Power', document, pltPath, showPlt)
        #     document.add_heading(i + ' Image Size ' + str(tst) + ' SYS_CHECK vs. Power')
        #     VRG_AsilData.SM_SYS_CHECK(df_test, 'Power', document, pltPath, showPlt)
        #
        #     document.add_heading(i + ' Image Size ' + str(tst) + ' High Pixel Threshold For SM_AHM_ROW_ROM ADDR CRC Values vs. Power')
        #     VRG_General_Data.Data_vs_Step_Plot(df_test, 'Power', document, pltPath, rrcAddrHi, showPlt)
        #     document.add_heading(i + ' Image Size ' + str(tst) + ' Low Pixel Threshold For SM_AHM_ROW_ROM ADDR CRC Values vs. Power')
        #     VRG_General_Data.Data_vs_Step_Plot(df_test, 'Power', document, pltPath, rrcAddrLo, showPlt)
        #
        #     document.add_heading(i + ' Image Size ' + str(tst) + ' SM_AHM_ROW_ROM Address CRC & Statistics Values vs. Power', level=2)
        #     VRG_AsilData.SM_Row_Rom_Address_Columns_Plot(df_test, 'Power', document, pltPath, showPlt)
        #     document.add_heading(i + ' Image Size ' + str(tst) + ' SM_AHM_ROW_ROM Address CRC & Statistics Values Expanded vs. Power', level=2)
        #     VRG_AsilData.SM_Row_Rom_Address_Columns_Expanded_Plot(df_test, 'Power', document, pltPath, showPlt)
        #
        #     document.add_heading(i + ' Image Size ' + str(tst) + ' SM_AHM_ROW_ROM LDO Signal Integrity Columns Statistics vs. Power', level=2)
        #     VRG_AsilData.SM_Row_Rom_SIC_Plot(df_test, 'Power', document, pltPath, showPlt)
        #     document.add_heading(i + ' Image Size ' + str(tst) + ' SM_AHM_ROW_ROM LDO Signal Integrity Columns Statistics Expanded vs. Power', level=2)
        #     VRG_AsilData.SM_Row_Rom_SIC_Expanded_Plot(df_test, 'Power', document, pltPath, showPlt)
        #
        #     document.add_heading(i + ' Image Size ' + str(tst) + ' SM_AHM_ROW_ROM Address CRC & Statistics Values vs. Temperature', level=2)
        #     VRG_AsilData.SM_Row_Rom_Address_Columns_Plot(df_test, temp, document, pltPath, showPlt)
        #     document.add_heading(i + ' Image Size ' + str(tst) + ' SM_AHM_ROW_ROM Address CRC & Statistics Values Expanded vs. Temperature', level=2)
        #     VRG_AsilData.SM_Row_Rom_Address_Columns_Expanded_Plot(df_test, temp, document, pltPath, showPlt)
        #     document.add_heading(i + ' Image Size ' + str(tst) + ' SM_AHM_ROW_ROM LDO Signal Integrity Columns Statistics Expanded vs. Temperature', level=2)
        #     VRG_AsilData.SM_Row_Rom_SIC_Plot(df_test, temp, document, pltPath, showPlt)
        #     document.add_heading(i + ' Image Size ' + str(tst) + ' SM_AHM_ROW_ROM LDO Signal Integrity Columns Statistics Expanded vs. Temperature', level=2)
        #     VRG_AsilData.SM_Row_Rom_SIC_Expanded_Plot(df_test, temp, document, pltPath, showPlt)

        VRG_Image_Utils.Image_Crop(df_img, 2, document, 34, 0, 64, 20, showPlt)  # RRC start
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 1504, 0, 1536, 20, showPlt)  # RRC mid
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 3100, 0, 3130, 20, showPlt)  # RRC end

def DV_12_0_12_SM_AHM_ROW_ROM_IMAGE_DATA(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

    document.add_heading('SM Clock Counting vs. Imaging Mode')
    VRG_Safety_Data.SM_Row_Rom_Address_Columns_Plot(df, 'ImgMode', document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' RRC CRC Values', level=2)
        VRG_Safety_Data.SM_Row_Rom_Address_Columns_Plot(df_img, None, document, pltPath, showPlt)
        document.add_heading(i + ' RRC CRC Values vs. Power', level=2)
        VRG_Safety_Data.SM_Row_Rom_Address_Columns_Expanded_Plot(df_img, 'Power', document, pltPath, showPlt)

        document.add_heading(i + ' RRC LDO SIC Values vs. Power', level=2)
        VRG_Safety_Data.SM_Row_Rom_SIC_Expanded_Plot(df_img, 'Power', document, pltPath, showPlt)

        VRG_Image_Utils.Image_Crop(df_img, 2, document, 34, 0, 64, 20, showPlt)  # RRC start
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 1504, 0, 1536, 20, showPlt)  # RRC mid
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 3100, 0, 3130, 20, showPlt)  # RRC end

def DV_12_0_15_SM_AHM_SREG_READBACK(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    cint = 'RegWr00_COARSE_INTEGRATION_TIME_'
    statcErrEn = 'RegWr01_STATC_ERR_EN'
    statcErr = 'RegVal_STATC_ERR'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, None, document, pltPath, showPlt)  # Temperature for each val test
    VRG_General_Data.FrameCount_Plot(df, None, document, pltPath, showPlt)  # Number of frames for each val test
    VRG_General_Data.Clk_Frequency_Plot(df, None, document, pltPath, showPlt)  # Plot each frequency for each test
    VRG_General_Data.TestTime_Plot(df, None, document, pltPath, showPlt)  # Time to run each val test
    VRG_General_Data.RunNumber_Plot(df, None, document, pltPath, showPlt)  # Val test run number
    VRG_General_Data.FrameWidth_Plot(df, None, document, pltPath, showPlt)  # Frame width
    VRG_General_Data.FrameHeight_Plot(df, None, document, pltPath, showPlt)  # Frame height
    VRG_General_Data.FrameBitDepth_Plot(df, None, document, pltPath, showPlt)  # Frame bit depth
    VRG_General_Data.DroppedFrames_Plot(df, None, document, pltPath, showPlt)  # Dropped frames
    VRG_General_Data.Sensor_FPS_Plot(df, None, document, pltPath, showPlt)  # Frames/second
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, None, document, pltPath, showPlt)  # Plot tempsensor data for all tests
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, None, document, pltPath, showPlt)  # Plot ASIL startup data for all tests

    document.add_heading('Power & Current vs. Voltage Level vs. Imaging Mode', level=2)
    VRG_Power_Data.Power_Consumption_Plot(df, ['Power', 'ImgMode'], document, pltPath, showPlt)
    VRG_Power_Data.Current_Consumption_Plot(df, ['Power', 'ImgMode'], document, pltPath, showPlt)

    document.add_heading('SM AHM SREG READBACK Registers vs. Imaging Mode', level=1)
    VRG_Register_Data.Reg_vs_Step_Plot(df, 'ImgMode', document, pltPath, statcErrEn, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, 'ImgMode', document, pltPath, statcErr, showPlt)
    VRG_Register_Data.Reg_vs_Reg_Plot(df, 'ImgMode', document, pltPath, statcErrEn, statcErr, showPlt)

    document.add_heading('SM AHM SREG READBACK Results vs. Imaging Mode')
    VRG_Safety_Data.SM_AHM_SREG_READBACK(df, 'ImgMode', document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' SM AHM SREG READBACK Results vs. Power', level=2)
        VRG_Safety_Data.SM_AHM_SREG_READBACK(df_img, 'Power', document, pltPath, showPlt)
        document.add_heading(i + ' SM AHM SREG READBACK Results vs. Temperature', level=2)
        VRG_Safety_Data.SM_AHM_SREG_READBACK(df_img, temp, document, pltPath, showPlt)

        document.add_heading('SM AHM SREG READBACK Registers vs. Power', level=1)
        VRG_Register_Data.Reg_vs_Step_Plot(df, 'Power', document, pltPath, statcErrEn, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df, 'Power', document, pltPath, statcErr, showPlt)
        VRG_Register_Data.Reg_vs_Reg_Plot(df, 'Power', document, pltPath, statcErrEn, statcErr, showPlt)

        document.add_heading('SM AHM SREG READBACK Registers vs. Temperature', level=1)
        VRG_Register_Data.Reg_vs_Step_Plot(df, temp, document, pltPath, statcErrEn, showPlt)
        VRG_Register_Data.Reg_vs_Step_Plot(df, temp, document, pltPath, statcErr, showPlt)
        VRG_Register_Data.Reg_vs_Reg_Plot(df, temp, document, pltPath, statcErrEn, statcErr, showPlt)

        document.add_heading(i + ' Image Mean & StdDev vs. Temperature', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, temp, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, temp, document, pltPath, showPlt)

def DV_12_SM_ANALOG_TEST_ROWS(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    cint = 'RegWr00_COARSE_INTEGRATION_TIME_'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath,
                                              showPlt)  # Temperature for each val test
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)  # Number of frames for each val test
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)  # Plot each frequency for each test
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)  # Time to run each val test
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)  # Val test run number
    VRG_General_Data.LightLevel_Plot(df, [die, temp], document, pltPath, showPlt)  # Light Level of each val test
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath,
                                             showPlt)  # Plot tempsensor data for all tests
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)  # Plot ASIL startup data for all tests

    document.add_heading('All SM_ATR Image Data vs. Imaging Mode')
    VRG_Safety_Data.SM_Analog_Test_Rows_Expanded_Plot(df, 'ImgMode', document, pltPath, showPlt)
    document.add_heading('All SM_ATR Self-Test Register Data vs. Imaging Mode')
    VRG_Safety_Data.SM_ATR(df, 'ImgMode', document, pltPath, showPlt)
    document.add_heading('SM_ATR SYS_CHECK vs. Imaging Mode')
    VRG_Safety_Data.SM_SYS_CHECK(df, 'ImgMode', document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' SM_ATR Test Data vs. Die', level=2)
        VRG_Safety_Data.SM_Analog_Test_Rows_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Safety_Data.SM_Analog_Test_Rows_Expanded_Plot(df_img, die, document, pltPath, showPlt)

        document.add_heading(i + ' SM_ATR Test Data vs. Power', level=2)
        VRG_Safety_Data.SM_Analog_Test_Rows_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Safety_Data.SM_Analog_Test_Rows_Expanded_Plot(df_img, 'Power', document, pltPath, showPlt)

        document.add_heading(i + ' SM_ATR Self-Test Register Data vs. Power', level=2)
        VRG_Safety_Data.SM_ATR(df_img, 'Power', document, pltPath, showPlt)
        document.add_heading(i + ' SM_ATR SYS_CHECK vs. Power', level=2)
        VRG_Safety_Data.SM_SYS_CHECK(df_img, 'Power', document, pltPath, showPlt)

        document.add_heading(i + ' SM_ATR Test Data vs. Thresholds', level=2)
        VRG_Safety_Data.SM_Analog_Test_Rows_vs_Thresholds_Plot(df_img, None, document, pltPath, showPlt)
        document.add_heading(i + ' SM_ATR Test Data vs. Thresholds vs. Die', level=2)
        VRG_Safety_Data.SM_Analog_Test_Rows_vs_Thresholds_Plot(df_img, die, document, pltPath, showPlt)
        document.add_heading(i + ' SM_ATR Test Data vs. Thresholds vs. Power', level=2)
        VRG_Safety_Data.SM_Analog_Test_Rows_vs_Thresholds_Plot(df_img, 'Power', document, pltPath, showPlt)

        document.add_heading(i + ' Power & Current vs. Voltage Level', level=2)
        VRG_Power_Data.Power_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)

        document.add_heading(i + ' SM_ATR Image @ Starting Location', level=2)
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 3140, 32, 3159, 80, showPlt)  # ATR start
        document.add_heading(i + ' SM_ATR Image @ Center Location', level=2)
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 3140, 2000, 3159, 2048, showPlt)  # ATR mid
        document.add_heading(i + ' SM_ATR Image @ Ending Location', level=2)
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 3140, 4088, 3159, 4136, showPlt)  # ATR end

        document.add_heading(i + ' Image Mean & StdDev vs. Light vs. Integration Time', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, ['Light', cint], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, ['Light', cint], document, pltPath, showPlt)

def DV_12_SM_ANALOG_TEST_ROWS_IMAGE_DATA(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath,
                                              showPlt)  # Temperature for each val test
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)  # Number of frames for each val test
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)  # Plot each frequency for each test
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)  # Time to run each val test
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)  # Val test run number
    VRG_General_Data.LightLevel_Plot(df, [die, temp], document, pltPath, showPlt)  # Light Level of each val test
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath,
                                             showPlt)  # Plot tempsensor data for all tests
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)  # Plot ASIL startup data for all tests

    # document.add_heading('All ATR Test Data')
    # VRG_AsilData.SM_Analog_Test_Rows_Plot(df, None, document, pltPath, showPlt)
    # VRG_AsilData.SM_Analog_Test_Rows_Expanded_Plot(df, None, document, pltPath, showPlt)
    # document.add_heading('ATR Test Data vs. Power')
    # VRG_AsilData.SM_Analog_Test_Rows_Plot(df, 'Power', document, pltPath, showPlt)
    # VRG_AsilData.SM_Analog_Test_Rows_Expanded_Plot(df, 'Power', document, pltPath, showPlt)
    #
    # # Primary Voltage, Power, and Current
    # document.add_heading('Power & Current vs. Voltage Level')
    # VRG_PowerData.Supply_Voltage_Plot(df, [die, temp, 'Power'], document, pltPath, showPlt)
    # VRG_PowerData.Power_Consumption_Plot(df, [die, temp, 'Power'], document, pltPath, showPlt)
    # VRG_PowerData.Current_Consumption_Plot(df, [die, temp, 'Power'], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' ATR Test Data vs. Die', level=2)
        VRG_Safety_Data.SM_Analog_Test_Rows_Plot(df_img, die, document, pltPath, showPlt)
        VRG_Safety_Data.SM_Analog_Test_Rows_Expanded_Plot(df_img, die, document, pltPath, showPlt)
        document.add_heading(i + ' ATR Test Data vs. Power', level=2)
        VRG_Safety_Data.SM_Analog_Test_Rows_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Safety_Data.SM_Analog_Test_Rows_Expanded_Plot(df_img, 'Power', document, pltPath, showPlt)
        # document.add_heading(i + ' ATR Test Data vs. Temp', level=2)
        # VRG_AsilData.SM_Analog_Test_Rows_Plot(df_img, temp, document, pltPath, showPlt)
        # VRG_AsilData.SM_Analog_Test_Rows_Expanded_Plot(df_img, temp, document, pltPath, showPlt)
        # document.add_heading(i + ' ATR Test Data vs. Power, Temp', level=2)
        # VRG_AsilData.SM_Analog_Test_Rows_Plot(df_img,  [temp, 'Power'], document, pltPath, showPlt)
        # VRG_AsilData.SM_Analog_Test_Rows_Expanded_Plot(df_img, [temp, 'Power'], document, pltPath, showPlt)
        # document.add_heading(i + ' ATR Test Data vs. Power, Die, Temp', level=2)
        # VRG_AsilData.SM_Analog_Test_Rows_Plot(df_img, [die, temp, 'Power'], document, pltPath, showPlt)
        # VRG_AsilData.SM_Analog_Test_Rows_Expanded_Plot(df_img, [die, temp, 'Power'], document, pltPath, showPlt)

        # Primary Voltage, Power, and Current
        document.add_heading(i + ' Power & Current vs. Voltage Level', level=2)
        VRG_Power_Data.Supply_Voltage_Plot(df_img, [die, temp, 'Power'], document, pltPath, showPlt)
        VRG_Power_Data.Power_Consumption_Plot(df_img, [die, temp, 'Power'], document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, [die, temp, 'Power'], document, pltPath, showPlt)

        VRG_Image_Utils.Image_Crop(df_img, 2, document, 3106, 32, 3126, 80, showPlt)  # ATR start
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 3106, 2000, 3126, 2048, showPlt)  # ATR mid
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 3106, 4088, 3126, 4136, showPlt)  # ATR end

def DV_12_0_16_SM_ATR_COLUMN_MEMORY_TESTS(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_0_17_SM_ATR_COLUMN_ROM(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_0_18_SM_ATR_FRAME_CHANGE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_0_19_SM_ATR_GRADIENT(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_0_20_SM_ATR_OVERDRIVE_1X(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_0_21_SM_ATR_OVERDRIVE_AT_GAIN(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_0_22_SM_ATR_VERT_PIXOUT_1(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_0_23_SM_ATR_VERT_PIXOUT_2(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_0_24_SM_ATR_ZEBRA_AB(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_0_25_SM_ATR_ZEBRA_BA(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_0_26_SM_ATR_OVERDRIVE_ROW_012345(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_0_27_SM_DIGITAL_FRAME_COUNTER(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    resetReg = 'RegWr00_MODE_SELECT'
    strmVal = 2140
    stbyVal = 2136

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, None, document, pltPath, showPlt)  # Temperature for each val test
    VRG_General_Data.FrameCount_Plot(df, None, document, pltPath, showPlt)  # Number of frames for each val test
    VRG_General_Data.Clk_Frequency_Plot(df, None, document, pltPath, showPlt)  # Plot each frequency for each test
    VRG_General_Data.TestTime_Plot(df, None, document, pltPath, showPlt)  # Time to run each val test
    VRG_General_Data.RunNumber_Plot(df, None, document, pltPath, showPlt)  # Val test run number
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, None, document, pltPath, showPlt)  # Plot ASIL startup data for all tests

    document.add_heading('SM_DIGITAL_FRAME_COUNTER Single Read Results')
    VRG_Safety_Data.SM_DIGITAL_FRAMECOUNTER(df, ['ImgMode', resetReg], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[resetReg].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' SM_DIGITAL_FRAME_COUNTER Register Values', level=2)
        VRG_Safety_Data.SM_DIGITAL_FRAMECOUNTER(df_img, None, document, pltPath, showPlt)

        document.add_heading('SM_DIGITAL_FRAME_COUNTER vs. Standby vs. Time')
        VRG_Safety_Data.SM_DIGITAL_FRAMECOUNTER_vs_Time_Plot(df_img, resetReg, stbyVal, document, pltPath, showPlt)

        document.add_heading('SM_DIGITAL_FRAME_COUNTER vs. Streaming vs. Time')
        VRG_Safety_Data.SM_DIGITAL_FRAMECOUNTER_vs_Time_Plot(df_img, resetReg, strmVal, document, pltPath, showPlt)

        for tst in TEST:  # Test
            df_test = VRG_Data_Frame.newdataframe(df_img, resetReg, tst)

            document.add_heading(i + ' SM_DIGITAL_FRAME_COUNTER vs. MODE_SELECT = ' + str(tst), level=1)

            document.add_heading(i + 'SM_DIGITAL_FRAME_COUNTER Register Values vs. MODE_SELECT = ' + str(tst),
                                 level=2)
            VRG_Safety_Data.SM_DIGITAL_FRAMECOUNTER(df_test, resetReg, document, pltPath, showPlt)

            document.add_heading(i + 'SM_DIGITAL_FRAME_COUNTER vs. Time vs. MODE_SELECT = ' + str(tst), level=2)
            VRG_Safety_Data.SM_DIGITAL_FRAMECOUNTER_vs_Time_Plot(df_test, None, None, document, pltPath, showPlt)

            document.add_heading(
                i + 'SM_DIGITAL_FRAME_COUNTER vs. Validation Test Number vs. MODE_SELECT = ' + str(tst), level=1)
            VRG_Safety_Data.SM_DIGITAL_FRAMECOUNTER_vs_TestNo_Plot(df_test, None, None, document, pltPath, showPlt)

def DV_12_0_28_SM_AUTO_CHECK_ATR(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_CLOCK_COUNTING(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    clkEn = 'ASIL_CHECK_ENABLES_00'
    clkStatus = 'ASIL_STATUS_00'

    document.add_heading('SM_CLOCK_COUNTING vs. Imaging Mode vs. Clk')
    VRG_Safety_Data.SM_CLOCK_COUNTING(df, ['ImgMode', 'Clk'], document, pltPath, showPlt)
    document.add_heading('SYS_CHECK vs. Imaging Mode vs. Clk')
    VRG_Safety_Data.SM_SYS_CHECK(df, ['ImgMode', 'Clk'], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df['Clk'].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' SM_CLOCK_COUNTING vs. ' + clkEn, level=2)
        VRG_Safety_Data.SM_CLOCK_COUNTING(df_img, clkEn, document, pltPath, showPlt)
        document.add_heading(i + ' SYS_CHECK vs. ' + clkEn)
        VRG_Safety_Data.SM_SYS_CHECK(df_img, clkEn, document, pltPath, showPlt)
        document.add_heading(i + ' SM_CLOCK_COUNTING vs. Clk', level=2)
        VRG_Safety_Data.SM_CLOCK_COUNTING(df_img, 'Clk', document, pltPath, showPlt)
        document.add_heading(i + ' SYS_CHECK vs. Clk')
        VRG_Safety_Data.SM_SYS_CHECK(df_img, 'Clk', document, pltPath, showPlt)
        document.add_heading(i + ' SM_CLOCK_COUNTING Conversions vs. Clk', level=2)
        VRG_Safety_Data.SM_CLOCK_COUNTING_Conversions(df_img, 'Clk', document, pltPath, showPlt)
        document.add_heading(i + ' SM_CLOCK_COUNTING Conversions Expanded vs. Clk', level=2)
        VRG_Safety_Data.SM_CLOCK_COUNTING_Conversions_Expanded(df_img, 'Clk', document, pltPath, showPlt)
        document.add_heading(i + ' SM_CLOCK_COUNTING ' + clkEn + ' vs. ' + clkStatus + ' vs. Clk', level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, 'Clk', document, pltPath, clkEn, clkStatus, showPlt)
        document.add_heading(i + ' SM_CLOCK_COUNTING vs. Time', level=2)
        VRG_Safety_Data.SM_CLOCK_COUNTING_vs_Time_Plot(df_img, None, None, document, pltPath, showPlt)

        for tst in TEST:  # Test
            df_test = VRG_Data_Frame.newdataframe(df_img, 'Clk', tst)

            document.add_heading(i + ' SM_CLOCK_COUNTING vs. Clk = ' + str(tst), level=1)
            document.add_heading(i + ' SM_CLOCK_COUNTING vs. Time vs. Clk =' + str(tst), level=2)
            VRG_Safety_Data.SM_CLOCK_COUNTING_vs_Time_Plot(df_test, None, None, document, pltPath, showPlt)

def DV_12_0_29_SM_COUNT_CLK_OP(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_0_30_SM_COUNT_CLK_PIX(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_0_31_SM_COUNT_CLK_REG(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_0_32_SM_COUNT_EXTCLK(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_0_33_SM_CLK_PIX_COUNT_100(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_0_34_SM_CLK_OP_COUNT_100(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_0_35_SM_CLK_REG_COUNT_100(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_0_36_SM_DELAY_BUFFER_RAM_CRC(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    ULcolor = '#ff0000'
    LLcolor = '#0000ff'
    cint1 = 'RegWr00_COARSE_INTEGRATION_TIME_'
    cint2 = 'RegWr01_COARSE_INTEGRATION_TIME2'
    test = 'RegWr02_DELAY_BUFFER_CRC_FAULT_CONTROL'
    asilCheck = 'DELAY_BUFFER_CRC_FAULT_CONTROL'
    faultFrm = 'DELAY_BUFFER_CRC_FAULT_FRAMES'
    faultPerFrm = 'DELAY_BUFFER_CRC_FAULTS_PER_FRAME'
    asilStatus = 'ASIL_STATUS_03__DELAY_BUFFER_CRC_FAULT'
    sysCheck = 'SYS_CHECK'
    colStdGr = 'ColStdDev_GreenR'
    colStdR = 'ColStdDev_Red'
    colStdGb = 'ColStdDev_GreenB'
    colStdB = 'ColStdDev_Blue'

    # VRG_General_Data Plots
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    # document.add_heading('Temperature Sensor')
    # VRG_TempsensorData.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Meta Data')
    VRG_Macro_Data.MetaData_Enable_Plot(df, [die, temp], document, pltPath, showPlt)

    document.add_heading('SM_DELAY_BUFFER_RAM_CRC Results vs. Imaging Mode')
    VRG_Safety_Data.SM_DELAY_BUFFER_RAM_CRC(df, 'ImgMode', document, pltPath, showPlt)
    document.add_heading('SM_DELAY_BUFFER_RAM_CRC SYS_CHECK vs. Imaging Mode')
    VRG_Safety_Data.SM_SYS_CHECK(df, 'ImgMode', document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[test].unique())
    TEST2 = np.asarray(df[cint1].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)
        print(i)
        document.add_heading(i, level=1)
        document.add_heading(i + ' SM_DELAY_BUFFER_RAM_CRC Results vs. ' + asilCheck, level=2)
        VRG_Safety_Data.SM_DELAY_BUFFER_RAM_CRC(df_img, test, document, pltPath, showPlt)
        document.add_heading(i + ' SM_DELAY_BUFFER_RAM_CRC SYS_CHECK vs. ' + asilCheck, level=2)
        VRG_Safety_Data.SM_SYS_CHECK(df_img, test, document, pltPath, showPlt)

        document.add_heading(i + ' SM_DELAY_BUFFER_RAM_CRC ' + cint1 + ' vs. ' + cint2, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, test, document, pltPath, cint1, cint2, showPlt)
        document.add_heading(i + ' SM_DELAY_BUFFER_RAM_CRC ' + cint1 + ' vs. ' + asilCheck, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, test, document, pltPath, cint1, asilCheck, showPlt)
        document.add_heading(i + ' SM_DELAY_BUFFER_RAM_CRC ' + cint1 + ' vs. ' + faultFrm, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, test, document, pltPath, cint1, faultFrm, showPlt)
        document.add_heading(i + ' SM_DELAY_BUFFER_RAM_CRC ' + cint1 + ' vs. ' + faultPerFrm, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, test, document, pltPath, cint1, faultPerFrm, showPlt)
        document.add_heading(i + ' SM_DELAY_BUFFER_RAM_CRC ' + cint1 + ' vs. ' + asilStatus, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, test, document, pltPath, cint1, asilStatus, showPlt)
        document.add_heading(i + ' SM_DELAY_BUFFER_RAM_CRC ' + cint2 + ' vs. ' + asilCheck, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, test, document, pltPath, cint2, asilCheck, showPlt)
        document.add_heading(i + ' SM_DELAY_BUFFER_RAM_CRC ' + cint2 + ' vs. ' + faultFrm, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, test, document, pltPath, cint1, faultFrm, showPlt)
        document.add_heading(i + ' SM_DELAY_BUFFER_RAM_CRC ' + cint2 + ' vs. ' + faultPerFrm, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, test, document, pltPath, cint2, faultPerFrm, showPlt)
        document.add_heading(i + ' SM_DELAY_BUFFER_RAM_CRC ' + cint2 + ' vs. ' + asilStatus, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, test, document, pltPath, cint2, asilStatus, showPlt)

        document.add_heading(i + ' SM_DELAY_BUFFER_RAM_CRC ' + asilCheck + ' vs. ' + asilStatus, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, asilCheck, asilStatus, showPlt)
        document.add_heading(i + ' SM_DELAY_BUFFER_RAM_CRC ' + asilStatus + ' vs. ' + sysCheck, level=2)
        VRG_General_Data.Data_vs_Data_vs_Step_Plot(df_img, None, document, pltPath, asilStatus, sysCheck, showPlt)

        document.add_heading(i + ' SM_DELAY_BUFFER_RAM_CRC FrameCount vs. ' + faultFrm + ' vs. ' + asilCheck, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, test, document, pltPath, 'FrameCount', faultFrm, showPlt)

        document.add_heading(i + ' SM_DELAY_BUFFER_RAM_CRC Image Means & StdDev vs. ' + asilCheck, level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, test, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, test, document, pltPath, showPlt)

        document.add_heading(i + ' SM_DELAY_BUFFER_RAM_CRC Image Means & StdDev vs. ' + asilStatus, level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, asilStatus, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, asilStatus, document, pltPath, showPlt)

        document.add_heading(i + ' SM_DELAY_BUFFER_RAM_CRC Image Column Statistics vs. ' + asilCheck, level=2)
        VRG_Stats_Arr.Arr_ColStdDev_Plot(df_img, test, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_img, test, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColFPN_Plot(df_img, test, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTempNoise_Plot(df_img, test, document, pltPath, showPlt)

        df_img_t1 = df_img[[temp, 'ImgMode', cint1, cint2, asilCheck, faultFrm, faultPerFrm, asilStatus, sysCheck]]
        document.add_heading(i + ' SM_DELAY_BUFFER_RAM_CRC Results Table', level=2)
        VRG_Doc.df_to_table(df_img_t1, document)

        df_img_t2 = df_img[
            [temp, 'ImgMode', cint1, cint2, asilCheck, colStdGr, colStdR, colStdGb, colStdB, faultFrm, faultPerFrm,
             asilStatus, sysCheck]]
        document.add_heading(i + ' SM_DELAY_BUFFER_RAM_CRC Results Table with Column Statistics', level=2)
        VRG_Doc.df_to_table(df_img_t2, document)

        for tst in TEST:  # Test Loop
            df_test = VRG_Data_Frame.newdataframe(df_img, test, tst)
            print(tst)
            document.add_heading(i + ' SM_DELAY_BUFFER_RAM_CRC vs. ' + asilCheck + ' = ' + str(tst), level=1)
            document.add_heading(i + ' SM_DELAY_BUFFER_RAM_CRC Results vs. ' + asilCheck + ' = ' + str(tst), level=2)
            VRG_Safety_Data.SM_DELAY_BUFFER_RAM_CRC(df_test, test, document, pltPath, showPlt)
            document.add_heading(i + ' SM_DELAY_BUFFER_RAM_CRC SYS_CHECK vs. ' + asilCheck + ' = ' + str(tst), level=2)
            VRG_Safety_Data.SM_SYS_CHECK(df_test, test, document, pltPath, showPlt)

            document.add_heading(
                i + ' SM_DELAY_BUFFER_RAM_CRC ' + cint1 + ' vs. ' + cint2 + ' vs. ' + asilCheck + ' = ' + str(tst),
                level=2)
            VRG_Register_Data.Reg_vs_Reg_Plot(df_test, test, document, pltPath, cint1, cint2, showPlt)
            document.add_heading(
                i + ' SM_DELAY_BUFFER_RAM_CRC ' + cint1 + ' vs. ' + cint2 + ' vs. ' + asilCheck + ' vs. ' + asilCheck + ' = ' + str(
                    tst), level=2)
            VRG_Register_Data.Reg_vs_Reg_Plot(df_test, cint2, document, pltPath, cint1, asilCheck, showPlt)
            document.add_heading(
                i + ' SM_DELAY_BUFFER_RAM_CRC ' + cint1 + ' vs. ' + cint2 + ' vs. ' + faultFrm + ' vs. ' + asilCheck + ' = ' + str(
                    tst), level=2)
            VRG_Register_Data.Reg_vs_Reg_Plot(df_test, cint2, document, pltPath, cint1, faultFrm, showPlt)
            document.add_heading(
                i + ' SM_DELAY_BUFFER_RAM_CRC ' + cint1 + ' vs. ' + cint2 + ' vs. ' + faultPerFrm + ' vs. ' + asilCheck + ' = ' + str(
                    tst), level=2)
            VRG_Register_Data.Reg_vs_Reg_Plot(df_test, cint2, document, pltPath, cint1, faultPerFrm, showPlt)
            document.add_heading(
                i + ' SM_DELAY_BUFFER_RAM_CRC ' + cint1 + ' vs. ' + cint2 + ' vs. ' + asilStatus + ' vs. ' + asilCheck + ' = ' + str(
                    tst), level=2)
            VRG_Register_Data.Reg_vs_Reg_Plot(df_test, cint2, document, pltPath, cint1, asilStatus, showPlt)

            document.add_heading(i + ' SM_DELAY_BUFFER_RAM_CRC Image Means & StdDev vs. ' + asilCheck + ' = ' + str(
                tst) + ' vs. ' + cint1, level=2)
            VRG_Stats_Arr.Arr_Mean_Plot(df_test, cint1, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_StdDev_Plot(df_test, cint1, document, pltPath, showPlt)

            document.add_heading(i + ' SM_DELAY_BUFFER_RAM_CRC Image Column Statistics vs. ' + asilCheck + ' = ' + str(
                tst) + ' vs. ' + cint1, level=2)
            VRG_Stats_Arr.Arr_ColStdDev_Plot(df_test, cint1, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_test, cint1, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_ColFPN_Plot(df_test, cint1, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_ColTempNoise_Plot(df_test, cint1, document, pltPath, showPlt)

            df_test_t1 = df_test[
                [temp, 'ImgMode', cint1, cint2, asilCheck, faultFrm, faultPerFrm, asilStatus, sysCheck]]
            document.add_heading(i + ' SM_DELAY_BUFFER_RAM_CRC Results Table vs. ' + asilCheck + ' = ' + str(tst),
                                 level=2)
            VRG_Doc.df_to_table(df_test_t1, document)

            df_test_t2 = df_img[
                [temp, 'ImgMode', cint1, cint2, asilCheck, colStdGr, colStdR, colStdGb, colStdB, faultFrm, faultPerFrm,
                 asilStatus, sysCheck]]
            document.add_heading(
                i + ' SM_DELAY_BUFFER_RAM_CRC Results Table with Column Statistics vs. ' + asilCheck + ' = ' + str(tst),
                level=2)
            VRG_Doc.df_to_table(df_test_t2, document)

            # for tmp in TEMP:  # Temperature
            #     df_tmp = VRG_DataFrame.newdataframe(df_test, temp, tmp)
            #     if tmp == nomTemp:
            #         document.add_heading(i + ' Image Capture with ' + asilCheck + ' = ' + str(tst) + ' at Temperature = ' + str(tmp), level=2)
            #         VRG_ImageAnalysis.Add_Image_Analysis(df_tmp, 5, document, showPlt)

            # for tst2 in TEST2:  # integration time loop
            #     df_test2 = VRG_DataFrame.newdataframe(df_test, cint1, tst2)
            #
            #     document.add_heading(i + ' SM_DELAY_BUFFER_RAM_CRC with ' + asilCheck + ' = ' + str(tst) + ' & ' + cint1 + ' = ' + str(tst2), level=1)
            #     document.add_heading(i + ' SM_DELAY_BUFFER_RAM_CRC Results with ' + asilCheck + ' = ' + str(tst) + ' & ' + cint1 + ' = ' + str(tst2) + ' vs. ' + cint2, level=2)
            #     VRG_AsilData.SM_DELAY_BUFFER_RAM_CRC(df_test2, cint2, document, pltPath, showPlt)
            #     document.add_heading(i + ' SM_DELAY_BUFFER_RAM_CRC SYS_CHECK with ' + asilCheck + ' = ' + str(tst) + ' & ' + cint1 + ' = ' + str(tst2) + ' vs. ' + cint2, level=2)
            #     VRG_AsilData.SM_SYS_CHECK(df_test2, cint2, document, pltPath, showPlt)
            #
            #     document.add_heading(i + ' SM_DELAY_BUFFER_RAM_CRC vs. ' + cint2 + ' with ' + asilCheck + ' = ' + str(tst) + ' & ' + cint1 + ' = ' + str(tst2), level=2)
            #     VRG_RegisterData.Reg_vs_Step_Plot(df_test2, cint1, document, pltPath, cint2, showPlt)
            #     document.add_heading(i + ' SM_DELAY_BUFFER_RAM_CRC  vs. ' + cint2 + ' vs. ' + asilCheck + ' with ' + asilCheck + ' = ' + str(tst) + ' & ' + cint1 + ' = ' + str(tst2), level=2)
            #     VRG_RegisterData.Reg_vs_Reg_Plot(df_test, cint2, document, pltPath, cint1, asilCheck, showPlt)
            #     document.add_heading(i + ' SM_DELAY_BUFFER_RAM_CRC vs. ' + cint2 + ' vs. ' + faultFrm + ' with ' + asilCheck + ' = ' + str(tst) + ' & ' + cint1 + ' = ' + str(tst2), level=2)
            #     VRG_RegisterData.Reg_vs_Reg_Plot(df_test2, cint2, document, pltPath, cint1, faultFrm, showPlt)
            #     document.add_heading(i + ' SM_DELAY_BUFFER_RAM_CRC vs. ' + cint2 + ' vs. ' + faultPerFrm + ' with ' + asilCheck + ' = ' + str(tst) + ' & ' + cint1 + ' = ' + str(tst2), level=2)
            #     VRG_RegisterData.Reg_vs_Reg_Plot(df_test2, cint2, document, pltPath, cint1, faultPerFrm, showPlt)
            #     document.add_heading(i + ' SM_DELAY_BUFFER_RAM_CRC vs. ' + cint2 + ' vs. ' + asilStatus + ' with ' + asilCheck + ' = ' + str(tst) + ' & ' + cint1 + ' = ' + str(tst2), level=2)
            #     VRG_RegisterData.Reg_vs_Reg_Plot(df_test2, cint2, document, pltPath, cint1, asilStatus, showPlt)
            #
            #     document.add_heading(i + ' SM_DELAY_BUFFER_RAM_CRC Image Means & StdDev  vs. ' + cint2 + ' with ' + asilCheck + ' = ' + str(tst) + ' & ' + cint1 + ' = ' + str(tst2), level=2)
            #     VRG_Stats_Arr.Arr_Mean_Plot(df_test2, cint2, document, pltPath, showPlt)
            #     VRG_Stats_Arr.Arr_StdDev_Plot(df_test2, cint2, document, pltPath, showPlt)
            #
            #     document.add_heading(i + ' SM_DELAY_BUFFER_RAM_CRC Image Column Statistics vs. ' + cint2 + ' with ' + asilCheck + ' = ' + str(tst) + ' & ' + cint1 + ' = ' + str(tst2), level=2)
            #     VRG_Stats_Arr.Arr_ColStdDev_Plot(df_test2, cint2, document, pltPath, showPlt)
            #     VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_test2, cint2, document, pltPath, showPlt)
            #     VRG_Stats_Arr.Arr_ColFPN_Plot(df_test2, cint2, document, pltPath, showPlt)
            #     VRG_Stats_Arr.Arr_ColTempNoise_Plot(df_test2, cint2, document, pltPath, showPlt)
            #
            #     df_test2_t1 = df_test2[[temp, 'ImgMode', cint1, cint2, asilCheck, faultFrm, faultPerFrm, asilStatus, sysCheck]]
            #     document.add_heading(i + ' SM_DELAY_BUFFER_RAM_CRC Results Table vs. ' + asilCheck + ' = ' + str(tst) + ' & ' + cint1 + ' = ' + str(tst2), level=2)
            #     VRG_Doc.df_to_table(df_test2_t1, document)
            #
            #     df_test2_t2 = df_img[[temp, 'ImgMode', cint1, cint2, asilCheck, colStdGr, colStdR, colStdGb, colStdB, faultFrm, faultPerFrm, asilStatus, sysCheck]]
            #     document.add_heading(i + ' SM_DELAY_BUFFER_RAM_CRC Results Table with Column Statistics vs. ' + asilCheck + ' = ' + str(tst) + ' & ' + cint1 + ' = ' + str(tst2), level=2)
            #     VRG_Doc.df_to_table(df_test2_t2, document)

def DV_12_0_37_SM_DOUBLE_LOCK(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    cint = 'RegWr00_COARSE_INTEGRATION_TIME_'
    lockControl = 'RegWr01_LOCK_CONTROL'
    flipMirror = 'RegWr02_READ_MODE'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Light Level Values', level=2)
        VRG_General_Data.LightLevel_Plot(df_img, None, document, pltPath, showPlt)
        document.add_heading(i + ' Lock Conrol Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, lockControl, showPlt)
        document.add_heading(i + ' Integration Time Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, cint, showPlt)
        document.add_heading(i + ' Horizontal Mirror & Vertical Flip Register Values', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, flipMirror, showPlt)

        document.add_heading(i + ' Frame Capture Pass/Fail vs. Lock Control')
        VRG_General_Data.FrameCapture_Plot(df_img, lockControl, document, pltPath, showPlt)

        document.add_heading(i + ' Frame Capture Pass/Fail vs. Lock Control vs. Flip & Mirror')
        VRG_General_Data.FrameCapture_Plot(df_img, [lockControl, flipMirror], document, pltPath, showPlt)

        document.add_heading(i + ' Frame Grab Attempts vs. Lock Control')
        VRG_General_Data.GrabAttempts_Plot(df_img, lockControl, document, pltPath, showPlt)

        document.add_heading(i + ' Frame Size Information vs. Lock Control')
        VRG_General_Data.FrameWidth_Plot(df_img, lockControl, document, pltPath, showPlt)
        VRG_General_Data.FrameHeight_Plot(df_img, lockControl, document, pltPath, showPlt)
        VRG_General_Data.FrameBitDepth_Plot(df_img, lockControl, document, pltPath, showPlt)
        VRG_General_Data.DroppedFrames_Plot(df_img, lockControl, document, pltPath, showPlt)

        document.add_heading(i + ' Frame Size Information vs. Lock Control vs. Flip and Mirror')
        VRG_General_Data.FrameWidth_Plot(df_img, [lockControl, flipMirror], document, pltPath, showPlt)
        VRG_General_Data.FrameHeight_Plot(df_img, [lockControl, flipMirror], document, pltPath, showPlt)
        VRG_General_Data.FrameBitDepth_Plot(df_img, [lockControl, flipMirror], document, pltPath, showPlt)
        VRG_General_Data.DroppedFrames_Plot(df_img, [lockControl, flipMirror], document, pltPath, showPlt)

        document.add_heading(i + ' Image Stats vs. Lock Control', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, lockControl, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, lockControl, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowStdDev_Plot(df_img, lockControl, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_img, lockControl, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColStdDev_Plot(df_img, lockControl, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_img, lockControl, document, pltPath, showPlt)

        document.add_heading(i + ' Image Stats vs. Lock Control vs. Flip and Mirror', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, [lockControl, flipMirror], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, [lockControl, flipMirror], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowStdDev_Plot(df_img, [lockControl, flipMirror], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_img, [lockControl, flipMirror], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColStdDev_Plot(df_img, [lockControl, flipMirror], document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_img, [lockControl, flipMirror], document, pltPath, showPlt)

def DV_12_0_38_SM_DTR(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    deltaDk = 'RegWr01_DELTA_DK_CONTROL'
    procDTR = 'RegWr02_PROCESS_DTR'
    hiCalcCRC = 'CRC_FR_DTR_CALC_CHECKSUM_HIGH'
    hiWrtCRC = 'CRC_FR_DTR_WRT_CHECKSUM_HIGH'
    calcHi = 'CRC_FR_DTR_CALC_CHECKSUM_HIGH__CRC_DTR_CALC_CHECKSUM_HIGH'
    calcLo = 'CRC_DTR_CALC_CHECKSUM_LOW'
    wrtHi = 'CRC_FR_DTR_WRT_CHECKSUM_HIGH__CRC_DTR_WRT_CHECKSUM_HIGH'
    wrtLo = 'CRC_DTR_WRT_CHECKSUM_LOW'
    rnc = 'DARK_CONTROL__DARK_CONTROL_ROW_NOISE_CORRECTION_EN'
    dataPed = 'DATA_PEDESTAL_'
    crcContReg = 'CRC_CONTROL_REG'
    dtrTest = 'Macro5'
    faultInject = 'Macro6'
    faultReg1 = 'TPG_HDR_RATIOS'
    faultReg2 = 'TPG_PD0_PD1_RATIOS'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, None, document, pltPath, showPlt)  # Temperature for each val test
    VRG_General_Data.FrameCount_Plot(df, None, document, pltPath, showPlt)  # Number of frames for each val test
    VRG_General_Data.Clk_Frequency_Plot(df, None, document, pltPath, showPlt)  # Plot each frequency for each test
    VRG_General_Data.TestTime_Plot(df, None, document, pltPath, showPlt)  # Time to run each val test
    VRG_General_Data.RunNumber_Plot(df, None, document, pltPath, showPlt)  # Val test run number
    VRG_General_Data.FrameWidth_Plot(df, None, document, pltPath, showPlt)  # Frame width
    VRG_General_Data.FrameHeight_Plot(df, None, document, pltPath, showPlt)  # Frame height
    VRG_General_Data.FrameBitDepth_Plot(df, None, document, pltPath, showPlt)  # Frame bit depth
    VRG_General_Data.DroppedFrames_Plot(df, None, document, pltPath, showPlt)  # Dropped frames
    VRG_General_Data.Sensor_FPS_Plot(df, None, document, pltPath, showPlt)  # Frames/second
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, None, document, pltPath, showPlt)  # Plot tempsensor data for all tests
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, None, document, pltPath, showPlt)  # Plot ASIL startup data for all tests

    document.add_heading('SM_DTR Register Settings', level=1)
    VRG_Safety_Data.SM_DTR(df, dtrTest, document, pltPath, showPlt)
    document.add_heading('SM_DTR SYS_CHECK Values vs. Digital Test Pattern')
    VRG_Safety_Data.SM_SYS_CHECK(df, dtrTest, document, pltPath, showPlt)
    document.add_heading('SM_DTR Fault Injection Register Settings', level=1)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, faultReg1, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, faultReg2, showPlt)
    document.add_heading('Additional Key Register Settings', level=1)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, rnc, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, dataPed, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, crcContReg, showPlt)

    document.add_heading('SM_DTR CRC Values vs. Imaging Mode')
    VRG_Safety_Data.SM_Digital_Test_Rows_Plot(df, 'ImgMode', document, pltPath, showPlt)
    document.add_heading('SM_DTR CRC Values Expanded vs. Imaging Mode')
    VRG_Safety_Data.SM_Digital_Test_Rows_Expanded_Plot(df, 'ImgMode', document, pltPath, showPlt)

    document.add_heading('DTR_CALC_CHECKSUM_HIGH vs DTR_WRT_CHECKSUM_HIGH vs. Imaging Mode')
    VRG_Register_Data.Reg_vs_Reg_Plot(df, 'ImgMode', document, pltPath, calcHi, wrtHi, showPlt)
    document.add_heading('DTR_CALC_CHECKSUM_LOW vs DTR_WRT_CHECKSUM_LOW vs. Imaging Mode')
    VRG_Register_Data.Reg_vs_Reg_Plot(df, 'ImgMode', document, pltPath, calcLo, wrtLo, showPlt)

    document.add_heading('SM_DTR CRC Values vs. Imaging Mode vs. DTR Pattern vs. Fault Injection')
    VRG_Safety_Data.SM_Digital_Test_Rows_Plot(df, ['ImgMode', dtrTest, faultInject], document, pltPath, showPlt)
    document.add_heading('SM_DTR CRC Values Expanded vs. Imaging Mode vs. DTR Pattern vs. Fault Injection')
    VRG_Safety_Data.SM_Digital_Test_Rows_Expanded_Plot(df, ['ImgMode', dtrTest, faultInject], document, pltPath, showPlt)

    document.add_heading(hiCalcCRC + ' vs ' + hiWrtCRC + ' vs. Imaging Mode vs. DTR Pattern vs. Fault Injection')
    VRG_Register_Data.Reg_vs_Reg_Plot(df, ['ImgMode', dtrTest, faultInject], document, pltPath, hiCalcCRC, hiWrtCRC,
                                      showPlt)
    document.add_heading(
        'DTR_CALC_CHECKSUM_HIGH vs DTR_WRT_CHECKSUM_HIGH vs. Imaging Mode vs. DTR Pattern vs. Fault Injection')
    VRG_Register_Data.Reg_vs_Reg_Plot(df, ['ImgMode', dtrTest, faultInject], document, pltPath, calcHi, wrtHi, showPlt)
    document.add_heading(
        'DTR_CALC_CHECKSUM_LOW vs DTR_WRT_CHECKSUM_LOW vs. Imaging Mode vs. DTR Pattern vs. Fault Injection')
    VRG_Register_Data.Reg_vs_Reg_Plot(df, ['ImgMode', dtrTest, faultInject], document, pltPath, calcLo, wrtLo, showPlt)

    # document.add_heading('All SM_DTR CRC Values vs. DBLC Dither')
    # VRG_AsilData.SM_Digital_Test_Rows_Plot(df, deltaDk, document, pltPath, showPlt)
    # document.add_heading('All SM_DTR CRC Values Expanded vs. DBLC Dither')
    # VRG_AsilData.SM_Digital_Test_Rows_Expanded_Plot(df, deltaDk, document, pltPath, showPlt)

    # document.add_heading('All DTR_CALC_CHECKSUM_HIGH vs DTR_WRT_CHECKSUM_HIGH vs. DBLC DITHER')
    # VRG_RegisterData.Reg_vs_Reg_Plot(df, deltaDk, document, pltPath, calcHi, wrtHi, showPlt)
    # document.add_heading('All DTR_CALC_CHECKSUM_LOW vs DTR_WRT_CHECKSUM_LOW vs. DBLC DITHER')
    # VRG_RegisterData.Reg_vs_Reg_Plot(df, deltaDk, document, pltPath, calcLo, wrtLo, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[dtrTest].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' SM_DTR vs. Digital Test Pattern', level=2)
        VRG_Safety_Data.SM_DTR(df_img, dtrTest, document, pltPath, showPlt)
        document.add_heading(i + ' SM_DTR SYS_CHECK vs. Digital Test Pattern', level=2)
        VRG_Safety_Data.SM_SYS_CHECK(df_img, dtrTest, document, pltPath, showPlt)

        document.add_heading(i + ' SM_DTR CRC Values', level=2)
        VRG_Safety_Data.SM_Digital_Test_Rows_Plot(df_img, None, document, pltPath, showPlt)
        document.add_heading(i + ' SM_DTR CRC Values Expanded', level=2)
        VRG_Safety_Data.SM_Digital_Test_Rows_Expanded_Plot(df_img, None, document, pltPath, showPlt)
        document.add_heading(i + ' SM_DTR CRC Values Expanded vs. Power', level=2)
        VRG_Safety_Data.SM_Digital_Test_Rows_Expanded_Plot(df_img, 'Power', document, pltPath, showPlt)
        document.add_heading(i + ' SM_DTR CRC Values Expanded vs. Temperature', level=2)
        VRG_Safety_Data.SM_Digital_Test_Rows_Expanded_Plot(df_img, temp, document, pltPath, showPlt)

        document.add_heading(i + ' SM_DTR CRC Values vs. DTR Test Pattern', level=2)
        VRG_Safety_Data.SM_Digital_Test_Rows_Plot(df_img, dtrTest, document, pltPath, showPlt)
        document.add_heading(i + ' SM_DTR CRC Values Expanded vs. DTR Test Pattern', level=2)
        VRG_Safety_Data.SM_Digital_Test_Rows_Expanded_Plot(df_img, dtrTest, document, pltPath, showPlt)

        document.add_heading(i + ' ' + hiCalcCRC + ' vs ' + hiWrtCRC + ' vs. DTR Test Pattern', level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, dtrTest, document, pltPath, hiCalcCRC, hiWrtCRC, showPlt)
        document.add_heading(i + ' DTR_CALC_CHECKSUM_HIGH vs DTR_WRT_CHECKSUM_HIGH vs. DTR Test Pattern', level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, dtrTest, document, pltPath, calcHi, wrtHi, showPlt)
        document.add_heading(i + ' DTR_CALC_CHECKSUM_LOW vs DTR_WRT_CHECKSUM_LOW vs. DTR Test Pattern', level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, dtrTest, document, pltPath, calcLo, wrtLo, showPlt)

        document.add_heading(i + ' SM_DTR CRC Values vs. DTR Test Pattern vs. Fault Injection', level=2)
        VRG_Safety_Data.SM_Digital_Test_Rows_Plot(df_img, [dtrTest, faultInject], document, pltPath, showPlt)
        document.add_heading(i + ' SM_DTR CRC Values Expanded vs. DTR Test Pattern', level=2)
        VRG_Safety_Data.SM_Digital_Test_Rows_Expanded_Plot(df_img, [dtrTest, faultInject], document, pltPath, showPlt)

        document.add_heading(i + ' ' + hiCalcCRC + ' vs ' + hiWrtCRC + ' vs. DTR Test Pattern vs. Fault Injection',
                             level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, [dtrTest, faultInject], document, pltPath, hiCalcCRC, hiWrtCRC,
                                          showPlt)
        document.add_heading(i + ' DTR_CALC_CHECKSUM_HIGH vs DTR_WRT_CHECKSUM_HIGH vs. DTR Test Pattern', level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, [dtrTest, faultInject], document, pltPath, calcHi, wrtHi, showPlt)
        document.add_heading(i + ' DTR_CALC_CHECKSUM_LOW vs DTR_WRT_CHECKSUM_LOW vs. DTR Test Pattern', level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, [dtrTest, faultInject], document, pltPath, calcLo, wrtLo, showPlt)

        # document.add_heading(i + ' DTR_CALC_CHECKSUM_HIGH vs. Test Step', level=2)
        # VRG_RegisterData.Reg_vs_Step_Plot(df_img, None, document, pltPath, calcHi, showPlt)
        # document.add_heading(i + ' DTR_CALC_CHECKSUM_LOW vs. Test Step', level=2)
        # VRG_RegisterData.Reg_vs_Step_Plot(df_img, None, document, pltPath, calcLo, showPlt)
        #
        # document.add_heading(i + ' DTR_CALC_CHECKSUM_HIGH vs DTR_WRT_CHECKSUM_HIGH vs. Test Step', level=2)
        # VRG_RegisterData.Reg_vs_Reg_Plot(df_img, None, document, pltPath, calcHi, wrtHi, showPlt)
        # document.add_heading(i + ' DTR_CALC_CHECKSUM_LOW vs DTR_WRT_CHECKSUM_LOW vs. Test Step', level=2)
        # VRG_RegisterData.Reg_vs_Reg_Plot(df_img, None, document, pltPath, calcLo, wrtLo, showPlt)

        # document.add_heading(i + ' SM_DTR CRC Values vs. DBLC Dither', level=2)
        # VRG_AsilData.SM_Digital_Test_Rows_Plot(df_img, [deltaDk, dtrTest], document, pltPath, showPlt)
        # VRG_AsilData.SM_Digital_Test_Rows_Expanded_Plot(df_img, [deltaDk, dtrTest], document, pltPath, showPlt)
        #
        # document.add_heading(i + ' SM_DTR CRC Values vs. DBLC Dither vs. Process DTR', level=2)
        # VRG_AsilData.SM_Digital_Test_Rows_Plot(df_img, [deltaDk, procDTR, dtrTest], document, pltPath, showPlt)
        # VRG_AsilData.SM_Digital_Test_Rows_Expanded_Plot(df_img, [deltaDk, procDTR, dtrTest], document, pltPath, showPlt)

        # document.add_heading(i + ' DTR_CALC_CHECKSUM_HIGH vs DTR_WRT_CHECKSUM_HIGH vs. DBLC DITHER', level=2)
        # VRG_RegisterData.Reg_vs_Reg_Plot(df_img, deltaDk, document, pltPath, calcHi, wrtHi, showPlt)
        # document.add_heading(i + ' DTR_CALC_CHECKSUM_LOW vs DTR_WRT_CHECKSUM_LOW vs. DBLC DITHER', level=2)
        # VRG_RegisterData.Reg_vs_Reg_Plot(df_img, deltaDk, document, pltPath, calcLo, wrtLo, showPlt)
        #
        # document.add_heading(i + ' DTR_CALC_CHECKSUM_HIGH vs DTR_WRT_CHECKSUM_HIGH vs. DBLC DITHER vs. Process DTR', level=2)
        # VRG_RegisterData.Reg_vs_Reg_Plot(df_img, [deltaDk, procDTR], document, pltPath, calcHi, wrtHi, showPlt)
        # document.add_heading(i + ' DTR_CALC_CHECKSUM_LOW vs DTR_WRT_CHECKSUM_LOW vs. DBLC DITHER vs. Process DTR', level=2)
        # VRG_RegisterData.Reg_vs_Reg_Plot(df_img, [deltaDk, procDTR], document, pltPath, calcLo, wrtLo, showPlt)

        for tst in TEST:  # Test
            df_test = VRG_Data_Frame.newdataframe(df_img, dtrTest, tst)

            document.add_heading(i + ' SM_DTR Pattern: ' + str(tst), level=1)
            document.add_heading(i + ' SM_DTR Pattern: ' + str(tst) + ' DTR Register Values', level=2)
            VRG_Safety_Data.SM_DTR(df_test, dtrTest, document, pltPath, showPlt)

            document.add_heading(i + ' SM_DTR Pattern: ' + str(tst) + ' DTR CRC Values', level=2)
            VRG_Safety_Data.SM_Digital_Test_Rows_Plot(df_test, dtrTest, document, pltPath, showPlt)
            document.add_heading(i + ' SM_DTR Pattern: ' + str(tst) + ' DTR CRC Values Expanded', level=2)
            VRG_Safety_Data.SM_Digital_Test_Rows_Expanded_Plot(df_test, dtrTest, document, pltPath, showPlt)

            document.add_heading(
                i + ' SM_DTR Pattern: ' + str(tst) + ' ' + hiCalcCRC + ' vs ' + hiWrtCRC + ' vs. Test Step', level=2)
            VRG_Register_Data.Reg_vs_Reg_Plot(df_test, dtrTest, document, pltPath, hiCalcCRC, hiWrtCRC, showPlt)
            document.add_heading(
                i + ' SM_DTR Pattern: ' + str(tst) + ' DTR_CALC_CHECKSUM_HIGH vs DTR_WRT_CHECKSUM_HIGH vs. Test Step',
                level=2)
            VRG_Register_Data.Reg_vs_Reg_Plot(df_test, dtrTest, document, pltPath, calcHi, wrtHi, showPlt)
            document.add_heading(
                i + ' SM_DTR Pattern: ' + str(tst) + ' DTR_CALC_CHECKSUM_LOW vs DTR_WRT_CHECKSUM_LOW vs. Test Step',
                level=2)
            VRG_Register_Data.Reg_vs_Reg_Plot(df_test, dtrTest, document, pltPath, calcLo, wrtLo, showPlt)

            document.add_heading(i + ' SM_DTR Pattern: ' + str(tst) + ' DTR CRC Values vs. Fault Injection', level=2)
            VRG_Safety_Data.SM_Digital_Test_Rows_Plot(df_test, [dtrTest, faultInject], document, pltPath, showPlt)
            document.add_heading(i + ' SM_DTR Pattern: ' + str(tst) + ' DTR CRC Values Expanded', level=2)
            VRG_Safety_Data.SM_Digital_Test_Rows_Expanded_Plot(df_test, [dtrTest, faultInject], document, pltPath, showPlt)

            document.add_heading(
                i + ' SM_DTR Pattern: ' + str(tst) + ' ' + hiCalcCRC + ' vs ' + hiWrtCRC + ' vs. Fault Injection',
                level=2)
            VRG_Register_Data.Reg_vs_Reg_Plot(df_test, [dtrTest, faultInject], document, pltPath, hiCalcCRC, hiWrtCRC,
                                              showPlt)
            document.add_heading(i + ' SM_DTR Pattern: ' + str(
                tst) + ' DTR_CALC_CHECKSUM_HIGH vs DTR_WRT_CHECKSUM_HIGH vs. Fault Injection', level=2)
            VRG_Register_Data.Reg_vs_Reg_Plot(df_test, [dtrTest, faultInject], document, pltPath, calcHi, wrtHi, showPlt)
            document.add_heading(i + ' SM_DTR Pattern: ' + str(
                tst) + ' DTR_CALC_CHECKSUM_LOW vs DTR_WRT_CHECKSUM_LOW vs. Fault Injection', level=2)
            VRG_Register_Data.Reg_vs_Reg_Plot(df_test, [dtrTest, faultInject], document, pltPath, calcLo, wrtLo, showPlt)

            # document.add_heading(i + ' SM_DTR Pattern: ' + str(tst) + ' DTR CRC Values vs. DBLC Dither', level=2)
            # VRG_AsilData.SM_Digital_Test_Rows_Plot(df_test, [deltaDk, dtrTest], document, pltPath, showPlt)
            # VRG_AsilData.SM_Digital_Test_Rows_Expanded_Plot(df_test, [deltaDk, dtrTest], document, pltPath, showPlt)

            # document.add_heading(i + ' SM_DTR Pattern: ' + str(tst) + ' DTR CRC Values vs. DBLC Dither vs. Process DTR', level=2)
            # VRG_AsilData.SM_Digital_Test_Rows_Plot(df_test, [deltaDk, procDTR, dtrTest], document, pltPath, showPlt)
            # VRG_AsilData.SM_Digital_Test_Rows_Expanded_Plot(df_test, [deltaDk, procDTR, dtrTest], document, pltPath, showPlt)

            # document.add_heading(i + ' SM_DTR Pattern: ' + str(tst) + ' DTR_CALC_CHECKSUM_HIGH vs DTR_WRT_CHECKSUM_HIGH vs. DBLC DITHER', level=2)
            # VRG_RegisterData.Reg_vs_Reg_Plot(df_test, [deltaDk, dtrTest], document, pltPath, calcHi, wrtHi, showPlt)
            # document.add_heading(i + ' SM_DTR Pattern: ' + str(tst) + ' DTR_CALC_CHECKSUM_LOW vs DTR_WRT_CHECKSUM_LOW vs. DBLC DITHER', level=2)
            # VRG_RegisterData.Reg_vs_Reg_Plot(df_test, [deltaDk, dtrTest], document, pltPath, calcLo, wrtLo, showPlt)

            # document.add_heading(i + ' SM_DTR Pattern: ' + str(tst) + ' DTR_CALC_CHECKSUM_HIGH vs DTR_WRT_CHECKSUM_HIGH vs. DBLC DITHER vs. Process DTR', level=2)
            # VRG_RegisterData.Reg_vs_Reg_Plot(df_test, [deltaDk, procDTR, dtrTest], document, pltPath, calcHi, wrtHi, showPlt)
            # document.add_heading(i + ' SM_DTR Pattern: ' + str(tst) + ' DTR_CALC_CHECKSUM_LOW vs DTR_WRT_CHECKSUM_LOW vs. DBLC DITHER vs. Process DTR', level=2)
            # VRG_RegisterData.Reg_vs_Reg_Plot(df_test, [deltaDk, procDTR, dtrTest], document, pltPath, calcLo, wrtLo, showPlt)

        VRG_Image_Utils.Image_Crop(df_img, 2, document, 4, 32, 12, 80, showPlt)  # DTR start
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 4, 2000, 12, 2048, showPlt)  # DTR mid
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 4, 4088, 12, 4136, showPlt)  # DTR end

def DV_12_0_38_SM_DTR_IMAGE_DATA(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    deltaDk = 'RegWr01_DELTA_DK_CONTROL'
    calcHi = 'RegVal_CRC_FR_DTR_CALC_CHECKSUM_HIGH'
    calcLo = 'RegVal_CRC_DTR_CALC_CHECKSUM_LOW'
    wrtHi = 'RegVal_CRC_FR_DTR_WRT_CHECKSUM_HIGH'
    wrtLo = 'RegVal_CRC_DTR_WRT_CHECKSUM_LOW'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, None, document, pltPath, showPlt)  # Temperature for each val test
    VRG_General_Data.FrameCount_Plot(df, None, document, pltPath, showPlt)  # Number of frames for each val test
    VRG_General_Data.Clk_Frequency_Plot(df, None, document, pltPath, showPlt)  # Plot each frequency for each test
    VRG_General_Data.TestTime_Plot(df, None, document, pltPath, showPlt)  # Time to run each val test
    VRG_General_Data.RunNumber_Plot(df, None, document, pltPath, showPlt)  # Val test run number
    VRG_General_Data.FrameWidth_Plot(df, None, document, pltPath, showPlt)  # Frame width
    VRG_General_Data.FrameHeight_Plot(df, None, document, pltPath, showPlt)  # Frame height
    VRG_General_Data.FrameBitDepth_Plot(df, None, document, pltPath, showPlt)  # Frame bit depth
    VRG_General_Data.DroppedFrames_Plot(df, None, document, pltPath, showPlt)  # Dropped frames
    VRG_General_Data.Sensor_FPS_Plot(df, None, document, pltPath, showPlt)  # Frames/second
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, None, document, pltPath, showPlt)  # Plot tempsensor data for all tests
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, None, document, pltPath, showPlt)  # Plot ASIL startup data for all tests

    document.add_heading('All DTR CRC Values vs. Imaging Mode')
    VRG_Safety_Data.SM_Digital_Test_Rows_Plot(df, 'ImgMode', document, pltPath, showPlt)
    document.add_heading('All DTR CRC Values Expanded vs. Imaging Mode')
    VRG_Safety_Data.SM_Digital_Test_Rows_Expanded_Plot(df, 'ImgMode', document, pltPath, showPlt)

    document.add_heading('All DTR CRC Values vs. DBLC Dither')
    VRG_Safety_Data.SM_Digital_Test_Rows_Plot(df, deltaDk, document, pltPath, showPlt)
    document.add_heading('All DTR CRC Values Expanded vs. DBLC Dither')
    VRG_Safety_Data.SM_Digital_Test_Rows_Expanded_Plot(df, deltaDk, document, pltPath, showPlt)

    document.add_heading('All DTR_CALC_CHECKSUM_HIGH vs DTR_WRT_CHECKSUM_HIGH vs. Imaging Mode')
    VRG_Register_Data.Reg_vs_Reg_Plot(df, 'ImgMode', document, pltPath, calcHi, wrtHi, showPlt)
    document.add_heading('All DTR_CALC_CHECKSUM_LOW vs DTR_WRT_CHECKSUM_LOW vs. Imaging Mode')
    VRG_Register_Data.Reg_vs_Reg_Plot(df, 'ImgMode', document, pltPath, calcLo, wrtLo, showPlt)

    document.add_heading('All DTR_CALC_CHECKSUM_HIGH vs DTR_WRT_CHECKSUM_HIGH vs. DBLC DITHER')
    VRG_Register_Data.Reg_vs_Reg_Plot(df, deltaDk, document, pltPath, calcHi, wrtHi, showPlt)
    document.add_heading('All DTR_CALC_CHECKSUM_LOW vs DTR_WRT_CHECKSUM_LOW vs. DBLC DITHER')
    VRG_Register_Data.Reg_vs_Reg_Plot(df, deltaDk, document, pltPath, calcLo, wrtLo, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' All DTR CRC Values vs. Power', level=2)
        VRG_Safety_Data.SM_Digital_Test_Rows_Plot(df_img, 'Power', document, pltPath, showPlt)
        document.add_heading(i + ' All DTR CRC Values Expanded vs. Power', level=2)
        VRG_Safety_Data.SM_Digital_Test_Rows_Expanded_Plot(df_img, 'Power', document, pltPath, showPlt)

        document.add_heading(i + ' DTR CRC Values vs. DBLC Dither', level=2)
        VRG_Safety_Data.SM_Digital_Test_Rows_Plot(df_img, deltaDk, document, pltPath, showPlt)
        VRG_Safety_Data.SM_Digital_Test_Rows_Expanded_Plot(df_img, deltaDk, document, pltPath, showPlt)

        document.add_heading(i + ' DTR_CALC_CHECKSUM_HIGH vs. Test Step')
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, calcHi, showPlt)
        document.add_heading(i + ' DTR_CALC_CHECKSUM_LOW vs. Test Step')
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, None, document, pltPath, calcLo, showPlt)
        document.add_heading(i + ' DTR_CALC_CHECKSUM_HIGH vs DTR_WRT_CHECKSUM_HIGH vs. Test Step')
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, calcHi, wrtHi, showPlt)
        document.add_heading(i + ' DTR_CALC_CHECKSUM_LOW vs DTR_WRT_CHECKSUM_LOW vs. Test Step')
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, calcLo, wrtLo, showPlt)

        document.add_heading(i + ' DTR_CALC_CHECKSUM_HIGH vs DTR_WRT_CHECKSUM_HIGH vs. DBLC DITHER')
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, deltaDk, document, pltPath, calcHi, wrtHi, showPlt)
        document.add_heading(i + ' DTR_CALC_CHECKSUM_LOW vs DTR_WRT_CHECKSUM_LOW vs. DBLC DITHER')
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, deltaDk, document, pltPath, calcLo, wrtLo, showPlt)

        VRG_Image_Utils.Image_Crop(df_img, 2, document, 4, 32, 12, 80, showPlt)  # DTR start
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 4, 2000, 12, 2048, showPlt)  # DTR mid
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 4, 4088, 12, 4136, showPlt)  # DTR end

def DV_12_0_39_SM_ECC_BLACK_LEVEL_RAM(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    ULcolor = '#ff0000'
    LLcolor = '#0000ff'
    test = 'RegWr01_ASIL_CHECK_ENABLES_02'
    asilCheck = 'ASIL_CHECK_ENABLES_02'
    asilCheck1 = 'ASIL_CHECK_ENABLES_02_DBLC_RAM_ECC_DED_ENABLE'
    asilCheck2 = 'ASIL_CHECK_ENABLES_02__DBLC_RAM_ECC_SEC_ENABLE'
    asilCheck3 = 'ASIL_CHECK_ENABLES_02__DBLC_STATE_PARITY_ENABLE'
    asilStatus = 'ASIL_STATUS_02'
    asilStatus1 = 'ASIL_STATUS_02__DBLC_RAM_ECC_DED_STATUS'
    asilStatus2 = 'ASIL_STATUS_02__DBLC_RAM_ECC_SEC_STATUS'
    asilStatus3 = 'ASIL_STATUS_02__DBLC_STATE_PARITY_STATUS'
    sysCheck = 'SYS_CHECK'
    metaData = 'DVM_Meta_Data'

    # VRG_General_Data Plots
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    # document.add_heading('Temperature Sensor')
    # VRG_TempsensorData.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Meta Data')
    VRG_Macro_Data.MetaData_Enable_Plot(df, [die, temp], document, pltPath, showPlt)

    document.add_heading('SM_ECC_BLACK_LEVEL_RAM vs. Imaging Mode')
    VRG_Safety_Data.SM_ECC_BLACK_LEVEL_RAM(df, 'ImgMode', document, pltPath, showPlt)
    document.add_heading('SM_ECC_BLACK_LEVEL_RAM SYS_CHECK vs. Imaging Mode')
    VRG_Safety_Data.SM_SYS_CHECK(df, 'ImgMode', document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[test].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' SM_ECC_BLACK_LEVEL_RAM vs. ' + asilCheck, level=2)
        VRG_Safety_Data.SM_ECC_BLACK_LEVEL_RAM(df_img, test, document, pltPath, showPlt)
        document.add_heading(i + ' SM_ECC_BLACK_LEVEL_RAM SYS_CHECK vs. ' + asilCheck, level=2)
        VRG_Safety_Data.SM_SYS_CHECK(df_img, test, document, pltPath, showPlt)

        document.add_heading(i + ' SM_ECC_BLACK_LEVEL_RAM ' + asilCheck + ' vs. ' + asilStatus, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, asilCheck, asilStatus, showPlt)
        document.add_heading(i + ' SM_ECC_BLACK_LEVEL_RAM ' + asilCheck1 + ' vs. ' + asilStatus1, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, asilCheck1, asilStatus1, showPlt)
        document.add_heading(i + ' SM_ECC_BLACK_LEVEL_RAM ' + asilCheck2 + ' vs. ' + asilStatus2, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, asilCheck2, asilStatus2, showPlt)
        document.add_heading(i + ' SM_ECC_BLACK_LEVEL_RAM ' + asilCheck3 + ' vs. ' + asilStatus3, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, asilCheck3, asilStatus3, showPlt)
        document.add_heading(i + ' SM_ECC_BLACK_LEVEL_RAM ' + asilStatus + ' vs. ' + sysCheck, level=2)
        VRG_General_Data.Data_vs_Data_vs_Step_Plot(df_img, None, document, pltPath, asilStatus, sysCheck, showPlt)

        df_t1 = df_img[[temp, 'ImgMode', 'Power', asilCheck, asilStatus, sysCheck]]
        document.add_heading(i + ' SM_ECC_BLACK_LEVEL_RAM Results Table', level=2)
        VRG_Doc.df_to_table(df_t1, document)

        df_t2 = df_img[
            [temp, 'ImgMode', asilCheck1, asilStatus1, asilCheck2, asilStatus2, asilCheck3, asilStatus3, sysCheck]]
        document.add_heading(i + ' SM_ECC_BLACK_LEVEL_RAM Expanded Results Table', level=2)
        VRG_Doc.df_to_table(df_t2, document)

def DV_12_0_40_SM_ECC_SEQUENCER_RAM(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    ULcolor = '#ff0000'
    LLcolor = '#0000ff'
    test = 'RegWr00_ASIL_CHECK_ENABLES_02__SEQUENCER_ECC_STATUS_ENABLE'
    asilCheck = 'ASIL_CHECK_ENABLES_02'
    asilStatus = 'ASIL_STATUS_02'
    asilStatus1 = 'ASIL_STATUS_02__AUX_SEQUENCER_ECC_STATUS'
    asilStatus2 = 'ASIL_STATUS_02__SEQUENCER_ECC_STATUS'
    sysCheck = 'SYS_CHECK'
    metaData = 'DVM_Meta_Data'

    # VRG_General_Data Plots
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    # document.add_heading('Temperature Sensor')
    # VRG_TempsensorData.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Meta Data')
    VRG_Macro_Data.MetaData_Enable_Plot(df, [die, temp], document, pltPath, showPlt)

    document.add_heading('SM_ECC_SEQUENCER_RAM vs. Imaging Mode')
    VRG_Safety_Data.SM_ECC_SEQUENCER_RAM(df, 'ImgMode', document, pltPath, showPlt)
    document.add_heading('SM_ECC_SEQUENCER_RAM SYS_CHECK vs. Imaging Mode')
    VRG_Safety_Data.SM_SYS_CHECK(df, 'ImgMode', document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[test].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' SM_ECC_SEQUENCER_RAM vs. ' + asilCheck, level=2)
        VRG_Safety_Data.SM_ECC_SEQUENCER_RAM(df_img, test, document, pltPath, showPlt)
        document.add_heading(i + ' SM_ECC_SEQUENCER_RAM SYS_CHECK vs. ' + asilCheck, level=2)
        VRG_Safety_Data.SM_SYS_CHECK(df_img, test, document, pltPath, showPlt)

        document.add_heading(i + ' SM_ECC_SEQUENCER_RAM ' + asilCheck + ' vs. ' + asilStatus, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, asilCheck, asilStatus, showPlt)
        document.add_heading(i + ' SM_ECC_SEQUENCER_RAM ' + asilCheck + ' vs. ' + asilStatus1, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, asilCheck, asilStatus1, showPlt)
        document.add_heading(i + ' SM_ECC_SEQUENCER_RAM ' + asilCheck + ' vs. ' + asilStatus2, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, asilCheck, asilStatus2, showPlt)
        document.add_heading(i + ' SM_ECC_SEQUENCER_RAM ' + asilStatus + ' vs. ' + sysCheck, level=2)
        VRG_General_Data.Data_vs_Data_vs_Step_Plot(df_img, None, document, pltPath, asilStatus, sysCheck, showPlt)

        df_t1 = df_img[[temp, 'ImgMode', 'Power', asilCheck, asilStatus, asilStatus1, asilStatus2, sysCheck]]
        document.add_heading(i + ' SM_ECC_SEQUENCER_RAM Results Table', level=2)
        VRG_Doc.df_to_table(df_t1, document)

def DV_12_0_41_SM_EMBEDDED_DATA_CRC(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    readMode = 'RegWr00_READ_MODE__EMBED_ROWS_NR'
    crcControlReg = 'CRC_CONTROL_REG'
    calcCRC = 'CRC_EMB_CALC_CHECKSUM'
    wrtCRC = 'CRC_EMB_WRT_CHECKSUM'
    asilCheck = 'ASIL_CHECK_ENABLES_02'
    asilPinEn = 'ASIL_PIN_ENABLES_02'
    asilStatus = 'ASIL_STATUS_02__AUX_SEQUENCER_ECC_EMB_CRC_STATUS'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, None, document, pltPath, showPlt)  # Temperature for each val test
    VRG_General_Data.FrameCount_Plot(df, None, document, pltPath, showPlt)  # Number of frames for each val test
    VRG_General_Data.Clk_Frequency_Plot(df, None, document, pltPath, showPlt)  # Plot each frequency for each test
    VRG_General_Data.TestTime_Plot(df, None, document, pltPath, showPlt)  # Time to run each val test
    VRG_General_Data.RunNumber_Plot(df, None, document, pltPath, showPlt)  # Val test run number
    VRG_General_Data.FrameWidth_Plot(df, None, document, pltPath, showPlt)  # Frame width
    VRG_General_Data.FrameHeight_Plot(df, None, document, pltPath, showPlt)  # Frame height
    VRG_General_Data.FrameBitDepth_Plot(df, None, document, pltPath, showPlt)  # Frame bit depth
    VRG_General_Data.DroppedFrames_Plot(df, None, document, pltPath, showPlt)  # Dropped frames
    VRG_General_Data.Sensor_FPS_Plot(df, None, document, pltPath, showPlt)  # Frames/second
    # document.add_heading('Temperature Sensor')
    # VRG_TempsensorData.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, None, document, pltPath, showPlt)  # Plot ASIL startup data for all tests

    document.add_heading('SM_EMBEDDED_DATA_CRC Registers vs. Imaging Mode')
    VRG_Safety_Data.SM_EMBEDDED_DATA_CRC(df, 'ImgMode', document, pltPath, showPlt)
    document.add_heading('SYS_CHECK vs. Imaging Mode')
    VRG_Safety_Data.SM_SYS_CHECK(df, 'ImgMode', document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[readMode].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' SM_EMBEDDED_DATA_CRC Registers vs. ' + crcControlReg, level=2)
        VRG_Safety_Data.SM_EMBEDDED_DATA_CRC(df_img, crcControlReg, document, pltPath, showPlt)
        document.add_heading(i + ' SYS_CHECK vs. ' + crcControlReg, level=2)
        VRG_Safety_Data.SM_SYS_CHECK(df_img, crcControlReg, document, pltPath, showPlt)

        document.add_heading(i + ' SM_EMBEDDED_DATA_CRC Registers vs. ' + crcControlReg + ' vs. ' + readMode, level=2)
        VRG_Safety_Data.SM_EMBEDDED_DATA_CRC(df_img, [crcControlReg, readMode], document, pltPath, showPlt)
        document.add_heading(i + ' SYS_CHECK vs. ' + crcControlReg + ' vs. ' + readMode, level=2)
        VRG_Safety_Data.SM_SYS_CHECK(df_img, [crcControlReg, readMode], document, pltPath, showPlt)

        df_t1 = df_img[
            [temp, 'ImgMode', readMode, crcControlReg, calcCRC, wrtCRC, asilPinEn, asilCheck, asilStatus, 'SYS_CHECK']]
        document.add_heading(i + ' SM_EMBEDDED_DATA_CRC Results Table')
        VRG_Doc.df_to_table(df_t1, document)

        df_emb_row = VRG_Data_Frame.newdataframe(df_img, readMode, 1)  # group dataframe with 2 emb rows
        df_emb = VRG_Data_Frame.newdataframe(df_emb_row, crcControlReg,
                                             37937)  # group dataframe with 2 emb rows & map enabled
        document.add_heading(
            i + ' SM_EMBEDDED_DATA_CRC Calc Checksum vs. Time vs. ' + crcControlReg + ' = 37937 vs. ' + readMode + ' = 1',
            level=2)
        VRG_Safety_Data.SM_EMBEDDED_DATA_CRC_vs_Time_Plot(df_emb, 'Power', 'Nom', document, pltPath, showPlt)

        for tst in TEST:  # Test
            df_test = VRG_Data_Frame.newdataframe(df_img, asilCheck, tst)

            document.add_heading(i + ' SM_EMBEDDED_DATA_CRC vs. ' + readMode + ' = ' + str(tst), level=1)

            document.add_heading(
                i + ' SM_EMBEDDED_DATA_CRC Registers vs. ' + readMode + ' = ' + str(tst) + ' vs. CRC_CONTROL_REG',
                level=2)
            VRG_Safety_Data.SM_EMBEDDED_DATA_CRC(df_test, [readMode, crcControlReg], document, pltPath, showPlt)
            document.add_heading(i + ' SYS_CHECK vs. ' + readMode + ' = ' + str(tst) + ' vs. CRC_CONTROL_REG', level=2)
            VRG_Safety_Data.SM_SYS_CHECK(df_test, [readMode, crcControlReg], document, pltPath, showPlt)

            df_t2 = df_test[
                [temp, 'ImgMode', readMode, crcControlReg, calcCRC, wrtCRC, asilPinEn, asilCheck, asilStatus,
                 'SYS_CHECK']]
            document.add_heading(i + ' SM_EMBEDDED_DATA_CRC Results Table vs. ' + readMode + ' = ' + str(tst))
            VRG_Doc.df_to_table(df_t2, document)

def DV_12_0_41_SM_HOST_CHECK_EMBEDDED_REGISTER_DATA(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_0_42_SM_HOST_CHECK_INVALID_IMAGE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    ULcolor = '#ff0000'
    LLcolor = '#0000ff'
    i2cStatus = 'I2C Status'
    mipiStatus = 'HISPI_STATUS__HISPI_CHECKSUM_VALID'
    hispiStatus = 'SENSOR_HISPI_STATUS__SENSOR_HISPI_CHECKSUM_VALID'
    fpgaStatus1 = 'MipiStatus'
    fpgaStatus2 = 'MipiStatus__SpEccError'
    fpgaStatus3 = 'MipiStatus__LpEccError'
    fpgaStatus4 = 'MipiStatus__TxPllLocked'

    # VRG_General_Data Plots
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Meta Data')
    VRG_Macro_Data.MetaData_Enable_Plot(df, [die, temp], document, pltPath, showPlt)

    document.add_heading('SM_HOST_CHECK_INVALID_IMAGE Results vs. Imaging Mode')
    VRG_Safety_Data.SM_HOST_CHECK_INVALID_IMAGE(df, 'ImgMode', document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df['Clk'].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' SM_HOST_CHECK_INVALID_IMAGE Results', level=2)
        VRG_Safety_Data.SM_HOST_CHECK_INVALID_IMAGE(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' SM_HOST_CHECK_INVALID_IMAGE Temperature Sensor')
        VRG_Tempsensor_Data.Tempsensor_Read_Plot(df_img, temp, document, pltPath, showPlt)

        document.add_heading(i + ' SM_HOST_CHECK_INVALID_IMAGE Image Means & StdDev', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, None, document, pltPath, showPlt)

        # Primary Voltage, Power, and Current
        document.add_heading(i + ' SM_HOST_CHECK_INVALID_IMAGE Power & Current vs. Voltage Level')
        VRG_Power_Data.Power_Consumption_Plot(df, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df, 'Power', document, pltPath, showPlt)

        df_t1 = df_img[
            [temp, 'ImgMode', 'Power', i2cStatus, hispiStatus, mipiStatus, fpgaStatus1, fpgaStatus2, fpgaStatus3,
             fpgaStatus4]]
        document.add_heading(i + ' SM_HOST_CHECK_INVALID_IMAGE Results Table', level=2)
        VRG_Doc.df_to_table(df_t1, document)

def DV_12_0_43_SM_HOST_CHECK_OPERATING_STATUS(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_0_44_SM_HOST_CHECK_STATISTICS_DATA(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_0_45_SM_I2C_CRC(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    cint = 'RegWr00_COARSE_INTEGRATION_TIME_'
    i2cRd = 'I2C_RD_CHECKSUM'
    i2cWrt = 'I2C_WRT_CHECKSUM'
    i2cWrtASIC = 'I2C_WRT_CHECKSUM_ASIC'
    i2cRdCalc = 'CALC_I2C_RD_CHECKSUM'
    i2cWrtCalc = 'CALC_I2C_WRT_CHECKSUM'
    i2cWrtInv = 'INVERSE_I2C_WRT_CHECKSUM'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, None, document, pltPath, showPlt)  # Temperature for each val test
    VRG_General_Data.Clk_Frequency_Plot(df, None, document, pltPath, showPlt)  # Plot each frequency for each test
    VRG_General_Data.TestTime_Plot(df, None, document, pltPath, showPlt)  # Time to run each val test
    VRG_General_Data.RunNumber_Plot(df, None, document, pltPath, showPlt)  # Val test run number

    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)

    document.add_heading('SM_I2C_CRC vs. Integration Time Register Write')
    VRG_Safety_Data.SM_I2C_CRC(df, cint, document, pltPath, showPlt)

    document.add_heading('SM_I2C_CRC Write CRC vs. Calculated Write CRC')
    VRG_Register_Data.Reg_vs_Reg_Plot(df, cint, document, pltPath, i2cWrt, i2cWrtCalc, showPlt)

    document.add_heading('SM_I2C_CRC Read CRC vs. Calculated Read CRC')
    VRG_Register_Data.Reg_vs_Reg_Plot(df, cint, document, pltPath, i2cRd, i2cRdCalc, showPlt)

    document.add_heading('SM_I2C_CRC Read CRC vs. Inverted Write CRC ', level=2)
    VRG_Register_Data.Reg_vs_Reg_Plot(df, cint, document, pltPath, i2cRd, i2cWrtInv, showPlt)

    df_t1 = df[[temp, cint, i2cWrt, i2cRd, i2cWrtASIC]]
    document.add_heading('SM_I2C_CRC Results Table', level=2)
    VRG_Doc.df_to_table(df_t1, document)

    df_t2 = df[[temp, cint, i2cWrt, i2cWrtCalc, i2cRd, i2cRdCalc, i2cWrtInv]]
    document.add_heading('SM_I2C_CRC Results vs. Calculated CRC Table', level=2)
    VRG_Doc.df_to_table(df_t2, document)

    # # IMAGE MODE SPECIFIC DATA
    # IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    # TEST = np.asarray(df[cint].unique())
    # TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    # nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    # for i in IMG:
    #     df_img = VRG_DataFrame.newdataframe(df, 'ImgMode', i)
    #
    #     document.add_heading(i, level=1)
    #     document.add_heading(i + ' SM_I2C_CRC Results')
    #     VRG_AsilData.SM_I2C_CRC(df_img, None, document, pltPath, showPlt)
    #
    #     document.add_heading(i + ' SM_I2C_CRC Write CRC vs. Calculated Write CRC')
    #     VRG_RegisterData.Reg_vs_Reg_Plot(df_img, cint, document, pltPath, i2cWrt, i2cWrtCalc, showPlt)
    #
    #     document.add_heading(i + ' SM_I2C_CRC Read CRC vs. Calculated Read CRC')
    #     VRG_RegisterData.Reg_vs_Reg_Plot(df_img, cint, document, pltPath, i2cRd, i2cRdCalc, showPlt)
    #
    #     document.add_heading(i + ' SM_I2C_CRC Read CRC vs. Inverted Write CRC ', level=2)
    #     VRG_RegisterData.Reg_vs_Reg_Plot(df_img, cint, document, pltPath, i2cRd, i2cWrtInv, showPlt)
    #
    #     document.add_heading(i + ' SM_I2C_CRC Results Table', level=2)
    #     df_t_img = df_img[[temp, 'ImgMode', cint, i2cWrt, i2cRd, i2cWrtASIC]]
    #     VRG_Doc.df_to_table(df_t_img, document)
    #
    #     document.add_heading(i + ' SM_I2C_CRC Results vs. Calculated CRC Table', level=2)
    #     df_t_img2 = df_img[[temp, 'ImgMode', cint, i2cWrt, i2cWrtCalc, i2cRd, i2cRdCalc, i2cWrtInv]]
    #     VRG_Doc.df_to_table(df_t_img2, document)
    #
    #     for tst in TEST:  # Test
    #         df_test = VRG_DataFrame.newdataframe(df_img, cint, tst)
    #
    #         document.add_heading(i + ' SM_I2C_CRC vs. Integration Time Register Write = ' + str(tst), level=1)
    #         document.add_heading(i + ' SM_I2C_CRC Results vs. Integration Time Register Write = ' + str(tst), level=2)
    #         VRG_AsilData.SM_I2C_CRC(df_test, cint, document, pltPath, showPlt)
    #
    #         document.add_heading(i + ' SM_I2C_CRC Write CRC vs. Calculated Write CRC vs. Integration Time Register Write = ' + str(tst) + ' vs. Response Results')
    #         VRG_RegisterData.Reg_vs_Reg_Plot(df_img, cint, document, pltPath, i2cWrt, i2cWrtCalc, showPlt)
    #
    #         document.add_heading(i + ' SM_I2C_CRC Read CRC vs. Calculated Read CRC vs. Integration Time Register Write = ' + str(tst), level=2)
    #         VRG_RegisterData.Reg_vs_Reg_Plot(df_test, cint, document, pltPath, i2cRd, i2cRdCalc, showPlt)
    #
    #         document.add_heading(i + ' SM_I2C_CRC Read CRC vs. Inverted Write CRC vs. Integration Time Register Write = ' + str(tst), level=2)
    #         VRG_RegisterData.Reg_vs_Reg_Plot(df_test, cint, document, pltPath, i2cRd, i2cWrtInv, showPlt)
    #
    #         document.add_heading(i + ' SM_I2C_CRC Results Table vs. Integration Time Register Write = ' + str(tst), level=2)
    #         df_t_tst = df_test[[temp, 'ImgMode', cint, i2cWrt, i2cRd, i2cWrtASIC]]
    #         VRG_Doc.df_to_table(df_t_tst, document)
    #
    #         document.add_heading(i + ' SM_I2C_CRC Results vs. Calculated CRC Table vs. Integration Time Register Write = ' + str(tst), level=2)
    #         df_t_tst2 = df_test[[temp, 'ImgMode', cint, i2cWrt, i2cWrtCalc, i2cRd, i2cRdCalc, i2cWrtInv]]
    #         VRG_Doc.df_to_table(df_t_tst2, document)

def DV_12_0_46_SM_IMAGE_DATA_CRC(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    ULcolor = '#ff0000'
    LLcolor = '#0000ff'
    deltaDk = 'DELTA_DK_CONTROL'
    calcHi = 'CRC_FR_DTR_CALC_CHECKSUM_HIGH__CRC_FR_CALC_CHECKSUM_HIGH'
    calcLo = 'CRC_FR_CALC_CHECKSUM_LOW'
    wrtHi = 'CRC_FR_DTR_WRT_CHECKSUM_HIGH__CRC_FR_WRT_CHECKSUM_HIGH'
    wrtLo = 'CRC_FR_WRT_CHECKSUM_LOW'
    rnc = 'DARK_CONTROL__DARK_CONTROL_ROW_NOISE_CORRECTION_EN'
    dataPed = 'DATA_PEDESTAL_'
    crcContReg = 'CRC_CONTROL_REG'
    testPattern = 'Macro5'
    asilCheck = 'ASIL_CHECK_ENABLES_02__ROW_FRAME_CRC_ENABLE'
    asilStatus = 'ASIL_STATUS_02__ROW_FRAME_CRC_STATUS'
    sysCheck = 'SYS_CHECK'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, None, document, pltPath, showPlt)  # Temperature for each val test
    VRG_General_Data.FrameCount_Plot(df, None, document, pltPath, showPlt)  # Number of frames for each val test
    VRG_General_Data.Clk_Frequency_Plot(df, None, document, pltPath, showPlt)  # Plot each frequency for each test
    VRG_General_Data.TestTime_Plot(df, None, document, pltPath, showPlt)  # Time to run each val test
    VRG_General_Data.RunNumber_Plot(df, None, document, pltPath, showPlt)  # Val test run number
    VRG_General_Data.FrameWidth_Plot(df, None, document, pltPath, showPlt)  # Frame width
    VRG_General_Data.FrameHeight_Plot(df, None, document, pltPath, showPlt)  # Frame height
    VRG_General_Data.FrameBitDepth_Plot(df, None, document, pltPath, showPlt)  # Frame bit depth
    VRG_General_Data.DroppedFrames_Plot(df, None, document, pltPath, showPlt)  # Dropped frames
    VRG_General_Data.Sensor_FPS_Plot(df, None, document, pltPath, showPlt)  # Frames/second
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, None, document, pltPath, showPlt)  # Plot tempsensor data for all tests
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, None, document, pltPath, showPlt)  # Plot ASIL startup data for all tests

    document.add_heading('SM_IMAGE_DATA_CRC Test Pattern Register Settings vs. Test Pattern', level=1)
    VRG_Register_Data.Test_Pattern_Register_Plot(df, testPattern, document, pltPath, showPlt)
    document.add_heading('SM_IMAGE_DATA_CRC TPG Register Settings vs. Test Pattern', level=1)
    VRG_Register_Data.TPG_Register_Plot(df, testPattern, document, pltPath, showPlt)

    document.add_heading('Additional Key Register Settings', level=1)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, rnc, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, dataPed, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, crcContReg, showPlt)

    document.add_heading('SM_IMAGE_DATA_CRC Register Settings vs. Imaging Mode vs. Test Pattern', level=1)
    VRG_Safety_Data.SM_IMAGE_DATA_CRC(df, ['ImgMode', testPattern], document, pltPath, showPlt)
    document.add_heading('SM_IMAGE_DATA_CRC SYS_CHECK Values vs. vs. Imaging Mode vs. Test Pattern')
    VRG_Safety_Data.SM_SYS_CHECK(df, ['ImgMode', testPattern], document, pltPath, showPlt)

    document.add_heading('All Calculated High CRC vs Expected High CRC vs. Imaging Mode vs. Test Pattern')
    VRG_Register_Data.Reg_vs_Reg_Plot(df, ['ImgMode', testPattern], document, pltPath, calcHi, wrtHi, showPlt)
    document.add_heading('All Calculated Low CRC vs Expected Low CRC vs. Imaging Mode vs. Test Pattern')
    VRG_Register_Data.Reg_vs_Reg_Plot(df, ['ImgMode', testPattern], document, pltPath, calcLo, wrtLo, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[testPattern].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' SM_IMAGE_DATA_CRC Register Values vs. Test Frame Patterns', level=2)
        VRG_Safety_Data.SM_IMAGE_DATA_CRC(df_img, testPattern, document, pltPath, showPlt)
        document.add_heading(i + ' SM_IMAGE_DATA_CRC SYS_CHECK Values vs. Test Frame Patterns', level=2)
        VRG_Safety_Data.SM_SYS_CHECK(df_img, testPattern, document, pltPath, showPlt)

        document.add_heading(i + ' SM_IMAGE_DATA_CRC Calculated High CRC vs Test Frame Pattern', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, testPattern, document, pltPath, calcHi, showPlt)
        document.add_heading(i + ' SM_IMAGE_DATA_CRC Calculated Low CRC vs Test Frame Pattern', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, testPattern, document, pltPath, calcLo, showPlt)

        document.add_heading(i + ' SM_IMAGE_DATA_CRC Calculated High CRC vs Expected High CRC vs. Test Frame Pattern')
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, testPattern, document, pltPath, calcHi, wrtHi, showPlt)
        document.add_heading(i + ' SM_IMAGE_DATA_CRC Calculated Low CRC vs Expected Low CRC vs. Test Frame Pattern')
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, testPattern, document, pltPath, calcLo, wrtLo, showPlt)

        df_t1 = df_img[[temp, 'ImgMode', 'Macro5', asilCheck, wrtHi, calcHi, wrtLo, calcLo, asilStatus, sysCheck]]
        document.add_heading('Calculated Frame CRC Table vs. Pattern vs. Imaging Mode. vs. Temperature')
        VRG_Doc.df_to_table(df_t1, document)

        document.add_heading(i + ' SM_IMAGE_DATA_CRC Image Mean & StdDev vs. Test Frame Pattern', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, testPattern, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, testPattern, document, pltPath, showPlt)

        for tst in TEST:  # Test
            df_test = VRG_Data_Frame.newdataframe(df_img, testPattern, tst)

            document.add_heading(i + ' SM_IMAGE_DATA_CRC Test Pattern: ' + str(tst), level=1)
            document.add_heading(
                i + ' SM_IMAGE_DATA_CRC Test Pattern: ' + str(tst) + ' Standby Test Frame Register Values', level=2)
            VRG_Safety_Data.SM_STANDBY_TEST_FRAME(df_test, testPattern, document, pltPath, showPlt)
            document.add_heading(i + ' SM_IMAGE_DATA_CRC Test Pattern: ' + str(tst) + ' SYS_CHECK Values', level=2)
            VRG_Safety_Data.SM_SYS_CHECK(df_test, testPattern, document, pltPath, showPlt)

            document.add_heading(i + ' SM_IMAGE_DATA_CRC Test Pattern: ' + str(tst) + ' Calculated High CRC', level=2)
            VRG_Register_Data.Reg_vs_Step_Plot(df_test, testPattern, document, pltPath, calcHi, showPlt)
            document.add_heading(i + ' SM_IMAGE_DATA_CRC Test Pattern: ' + str(tst) + ' Calculated Low CRC', level=2)
            VRG_Register_Data.Reg_vs_Step_Plot(df_test, testPattern, document, pltPath, calcLo, showPlt)

            document.add_heading(
                i + ' SM_IMAGE_DATA_CRC Test Pattern: ' + str(tst) + ' Calculated High CRC vs Expected High CRC')
            VRG_Register_Data.Reg_vs_Reg_Plot(df_test, testPattern, document, pltPath, calcHi, wrtHi, showPlt)
            document.add_heading(
                i + ' SM_IMAGE_DATA_CRC Test Pattern: ' + str(tst) + ' Calculated Low CRC vs Expected Low CRC')
            VRG_Register_Data.Reg_vs_Reg_Plot(df_test, testPattern, document, pltPath, calcLo, wrtLo, showPlt)

            df_t2 = df_test[[temp, 'ImgMode', 'Macro5', asilCheck, wrtHi, calcHi, wrtLo, calcLo, asilStatus, sysCheck]]
            document.add_heading('Calculated Frame CRC Table vs. Pattern vs. Imaging Mode. vs. Temperature')
            VRG_Doc.df_to_table(df_t2, document)

            document.add_heading(i + ' SM_IMAGE_DATA_CRC Test Pattern: ' + str(tst) + ' Image Mean & StdDev', level=2)
            VRG_Stats_Arr.Arr_Mean_Plot(df_test, testPattern, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_StdDev_Plot(df_test, testPattern, document, pltPath, showPlt)

            # for tmp in TEMP:  # Temperature
            #     df_tmp = VRG_DataFrame.newdataframe(df_test, temp, tmp)
            #     if tmp == nomTemp:
            #         document.add_heading(i + ' Image Capture' + str(tst) + ' at Temperature = ' + str(tmp), level=2)
            #         VRG_ImageAnalysis.Add_Image(df_tmp, 2, document, showPlt)

def DV_12_0_47_SM_TRANSPORT_ROW_TX(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_0_48_SM_MIPI_HISPI_CRC(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    testPattern = 'Macro5'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, None, document, pltPath, showPlt)  # Temperature for each val test
    VRG_General_Data.FrameCount_Plot(df, None, document, pltPath, showPlt)  # Number of frames for each val test
    VRG_General_Data.Clk_Frequency_Plot(df, None, document, pltPath, showPlt)  # Plot each frequency for each test
    VRG_General_Data.TestTime_Plot(df, None, document, pltPath, showPlt)  # Time to run each val test
    VRG_General_Data.RunNumber_Plot(df, None, document, pltPath, showPlt)  # Val test run number
    VRG_General_Data.FrameWidth_Plot(df, None, document, pltPath, showPlt)  # Frame width
    VRG_General_Data.FrameHeight_Plot(df, None, document, pltPath, showPlt)  # Frame height
    VRG_General_Data.FrameBitDepth_Plot(df, None, document, pltPath, showPlt)  # Frame bit depth
    VRG_General_Data.DroppedFrames_Plot(df, None, document, pltPath, showPlt)  # Dropped frames
    VRG_General_Data.Sensor_FPS_Plot(df, None, document, pltPath, showPlt)  # Frames/second
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, None, document, pltPath, showPlt)  # Plot tempsensor data for all tests
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, None, document, pltPath, showPlt)  # Plot ASIL startup data for all tests

    document.add_heading('Power & Current vs. Voltage Level vs. Imaging Mode', level=2)
    VRG_Power_Data.Power_Consumption_Plot(df, ['Power', 'ImgMode'], document, pltPath, showPlt)
    VRG_Power_Data.Current_Consumption_Plot(df, ['Power', 'ImgMode'], document, pltPath, showPlt)

    document.add_heading('TPG Registers vs. Validation Test Pattern', level=1)
    VRG_Register_Data.TPG_Register_Plot(df, testPattern, document, pltPath, showPlt)

    document.add_heading('Test Pattern Mode Registers vs. Validation Test Pattern', level=1)
    VRG_Register_Data.Test_Pattern_Register_Plot(df, testPattern, document, pltPath, showPlt)

    document.add_heading('SM MIPI HISPI CRC Register Data vs. Imaging Mode', level=1)
    VRG_Safety_Data.SM_MIPI_HISPI_CRC(df, 'ImgMode', document, pltPath, showPlt)

    document.add_heading('SM MIPI HISPI CRC Register Data vs. Imaging Mode vs. Validation Test Pattern', level=1)
    VRG_Safety_Data.SM_MIPI_HISPI_CRC(df, ['ImgMode', testPattern], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[testPattern].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' SM MIPI HISPI Register Values vs. Test Pattern', level=2)
        VRG_Safety_Data.SM_MIPI_HISPI_CRC(df_img, testPattern, document, pltPath, showPlt)

        document.add_heading(i + ' Image Mean & StdDev vs. Test Pattern', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, testPattern, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, testPattern, document, pltPath, showPlt)

        for tst in TEST:  # Test
            df_test = VRG_Data_Frame.newdataframe(df_img, testPattern, tst)

            document.add_heading(i + ' Test Pattern: ' + str(tst), level=1)

            document.add_heading(i + ' Test Pattern: ' + str(tst) + ' TPG Registers', level=1)
            VRG_Register_Data.TPG_Register_Plot(df_test, testPattern, document, pltPath, showPlt)

            document.add_heading(i + ' Test Pattern: ' + str(tst) + ' Test Pattern Mode Registers', level=1)
            VRG_Register_Data.Test_Pattern_Register_Plot(df_test, testPattern, document, pltPath, showPlt)

            document.add_heading(i + ' Test Pattern: ' + str(tst) + ' SM MIPI HISPI Register Values', level=2)
            VRG_Safety_Data.SM_MIPI_HISPI_CRC(df_test, testPattern, document, pltPath, showPlt)

            df_t = df_test[[temp, 'ImgMode', 'HISPI_STATUS__HISPI_CHECKSUM_VALID',
                            'HISPI_CRC_0', 'HISPI_CRC_1', 'HISPI_CRC_2', 'HISPI_CRC_3']]
            document.add_heading(i + ' Test Pattern: ' + str(tst) + ' SM MIPI CRC Register Table', level=2)
            VRG_Doc.df_to_table(df_t, document)

            df_t2 = df_test[[temp, 'ImgMode', 'SENSOR_HISPI_STATUS__SENSOR_HISPI_CHECKSUM_VALID',
                             'SENSOR_HISPI_CRC_0', 'SENSOR_HISPI_CRC_1', 'SENSOR_HISPI_CRC_2', 'SENSOR_HISPI_CRC_3']]
            document.add_heading(i + ' Test Pattern: ' + str(tst) + ' SM SENSOR HISPI CRC Register Table', level=2)
            VRG_Doc.df_to_table(df_t2, document)

            document.add_heading(i + ' Test Pattern: ' + str(tst) + ' Image Mean & StdDev', level=2)
            VRG_Stats_Arr.Arr_Mean_Plot(df_test, testPattern, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_StdDev_Plot(df_test, testPattern, document, pltPath, showPlt)

            for tmp in TEMP:  # Temperature
                df_tmp = VRG_Data_Frame.newdataframe(df_test, temp, tmp)
                if tmp == nomTemp:
                    document.add_heading(i + ' Image Capture' + str(tst) + ' at Temperature = ' + str(tmp), level=2)
                    VRG_Image_Analysis.Add_Image(df_tmp, 2, document, showPlt)

def DV_12_0_49_SM_OTPM_ECC(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_0_50_SM_HOST_CHECK_TEMP_ENABLE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_0_51_SM_MEC_CRC(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    ULcolor = '#ff0000'
    LLcolor = '#0000ff'
    test = 'RegWr00_MEC_CRC_FAULT_CONTROL'
    asilCheck = 'MEC_CRC_FAULT_CONTROL'
    faultFrm = 'MEC_CRC_FAULT_FRAMES'
    faultPerFrm = 'MEC_CRC_FAULTS_PER_FRAME'
    asilStatus = 'ASIL_STATUS_03__MEC_MEMORY_CRC_FAULT'
    sysCheck = 'SYS_CHECK'

    # VRG_General_Data Plots
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    # document.add_heading('Temperature Sensor')
    # VRG_TempsensorData.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Meta Data')
    VRG_Macro_Data.MetaData_Enable_Plot(df, [die, temp], document, pltPath, showPlt)

    document.add_heading('SM_MEC_RAM_CRC Results vs. Imaging Mode')
    VRG_Safety_Data.SM_MEC_RAM_CRC(df, 'ImgMode', document, pltPath, showPlt)
    document.add_heading('SM_MEC_RAM_CRC SYS_CHECK vs. Imaging Mode')
    VRG_Safety_Data.SM_SYS_CHECK(df, 'ImgMode', document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df['Clk'].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' SM_MEC_RAM_CRC Results vs. ' + asilCheck, level=2)
        VRG_Safety_Data.SM_MEC_RAM_CRC(df_img, test, document, pltPath, showPlt)
        document.add_heading(i + ' SM_MEC_RAM_CRC SYS_CHECK vs. ' + asilCheck, level=2)
        VRG_Safety_Data.SM_SYS_CHECK(df_img, test, document, pltPath, showPlt)

        document.add_heading(i + ' SM_MEC_RAM_CRC ' + asilCheck + ' vs. ' + faultFrm, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, asilCheck, faultFrm, showPlt)
        document.add_heading(i + ' SM_MEC_RAM_CRC ' + asilCheck + ' vs. ' + faultPerFrm, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, asilCheck, faultPerFrm, showPlt)
        document.add_heading(i + ' SM_MEC_RAM_CRC ' + asilCheck + ' vs. ' + asilStatus, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, asilCheck, asilStatus, showPlt)
        document.add_heading(i + ' SM_MEC_RAM_CRC ' + asilStatus + ' vs. ' + sysCheck, level=2)
        VRG_General_Data.Data_vs_Data_vs_Step_Plot(df_img, test, document, pltPath, asilStatus, sysCheck, showPlt)

        document.add_heading(i + ' SM_MEC_RAM_CRC FrameCount vs. ' + faultFrm + ' vs. ' + asilCheck, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, test, document, pltPath, 'FrameCount', faultFrm, showPlt)

        document.add_heading(i + ' SM_MEC_RAM_CRC Image Means & StdDev vs. ' + asilCheck, level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, test, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, test, document, pltPath, showPlt)

        df_t1 = df_img[[temp, 'ImgMode', 'Power', asilCheck, faultFrm, faultPerFrm, asilStatus, sysCheck]]
        document.add_heading(i + ' SM_MEC_RAM_CRC Results Table', level=2)
        VRG_Doc.df_to_table(df_t1, document)

def DV_12_0_61_SM_DDC_DEF_CNT(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_0_62_SM_ATR_ADC_LATCH(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_0_63_SM_ATR_OVERDRIVE_CODE_012(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_0_64_SM_ECC_CONTEXT_RAM(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    ULcolor = '#ff0000'
    LLcolor = '#0000ff'
    test = 'RegWr00_ASIL_CHECK_ENABLES_04'
    asilCheck = 'ASIL_CHECK_ENABLES_04'
    asilStatus = 'ASIL_STATUS_04'
    asilStatus1 = 'ASIL_STATUS_04__CTX_RAM_SEC'
    asilStatus2 = 'ASIL_STATUS_04__CTX_RAM_DED'
    sysCheck = 'SYS_CHECK'
    metaData = 'DVM_Meta_Data'

    # VRG_General_Data Plots
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    # document.add_heading('Temperature Sensor')
    # VRG_TempsensorData.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Meta Data')
    VRG_Macro_Data.MetaData_Enable_Plot(df, [die, temp], document, pltPath, showPlt)

    document.add_heading('SM_ECC_CONTEXT_RAM Results vs. Imaging Mode')
    VRG_Safety_Data.SM_ECC_CONTEXT_RAM(df, 'ImgMode', document, pltPath, showPlt)
    document.add_heading('SM_ECC_CONTEXT_RAM SYS_CHECK vs. Imaging Mode')
    VRG_Safety_Data.SM_SYS_CHECK(df, 'ImgMode', document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[test].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' SM_ECC_CONTEXT_RAM Results vs. ' + asilCheck, level=2)
        VRG_Safety_Data.SM_ECC_CONTEXT_RAM(df_img, test, document, pltPath, showPlt)
        document.add_heading(i + ' SM_ECC_CONTEXT_RAM SYS_CHECK vs. ' + asilCheck, level=2)
        VRG_Safety_Data.SM_SYS_CHECK(df_img, test, document, pltPath, showPlt)

        document.add_heading(i + ' SM_ECC_CONTEXT_RAM ' + asilCheck + ' vs. ' + asilStatus, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, asilCheck, asilStatus, showPlt)
        document.add_heading(i + ' SM_ECC_CONTEXT_RAM ' + asilCheck + ' vs. ' + asilStatus1, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, asilCheck, asilStatus1, showPlt)
        document.add_heading(i + ' SM_ECC_CONTEXT_RAM ' + asilCheck + ' vs. ' + asilStatus2, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, asilCheck, asilStatus2, showPlt)
        document.add_heading(i + ' SM_ECC_CONTEXT_RAM ' + asilStatus + ' vs. ' + sysCheck, level=2)
        VRG_General_Data.Data_vs_Data_vs_Step_Plot(df_img, None, document, pltPath, asilStatus, sysCheck, showPlt)

        df_t1 = df_img[[temp, 'ImgMode', 'Power', asilCheck, asilStatus, asilStatus1, asilStatus2, sysCheck]]
        document.add_heading(i + ' SM_ECC_CONTEXT_RAM Results Table', level=2)
        VRG_Doc.df_to_table(df_t1, document)

def DV_12_0_65_SM_CDS_MEM_CRC(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

    # Broke up into:
    # DV_12_0_65_SM_CDS_MEM_CRC_TOP
    # DV_12_0_65_SM_CDS_MEM_CRC_BTM

def DV_12_0_65_SM_CDS_MEM_CRC_TOP(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    ULcolor = '#ff0000'
    LLcolor = '#0000ff'
    test = 'RegWr00_DCDS_CRC_FAULT_CONTROL_TOP'
    asilCheck = 'DCDS_CRC_FAULT_CONTROL_TOP'
    faultFrm = 'DCDS_CRC_FAULT_FRAMES_TOP'
    faultPerFrm = 'DCDS_CRC_FAULTS_PER_FRAME_TOP'
    asilStatus = 'ASIL_STATUS_03__DCDS_TOP_MEMORY_CRC_FAULT'
    sysCheck = 'SYS_CHECK'

    # VRG_General_Data Plots
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    # document.add_heading('Temperature Sensor')
    # VRG_TempsensorData.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Meta Data')
    VRG_Macro_Data.MetaData_Enable_Plot(df, [die, temp], document, pltPath, showPlt)

    document.add_heading('SM_CDS_MEM_CRC_TOP Results vs. Imaging Mode')
    VRG_Safety_Data.SM_CDS_MEM_CRC_TOP(df, 'ImgMode', document, pltPath, showPlt)
    document.add_heading('SM_CDS_MEM_CRC_TOP SYS_CHECK vs. Imaging Mode')
    VRG_Safety_Data.SM_SYS_CHECK(df, 'ImgMode', document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df['Clk'].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' SM_CDS_MEM_CRC_TOP Results vs. ' + asilCheck, level=2)
        VRG_Safety_Data.SM_CDS_MEM_CRC_TOP(df_img, test, document, pltPath, showPlt)
        document.add_heading(i + ' SM_CDS_MEM_CRC_TOP SYS_CHECK vs. ' + asilCheck, level=2)
        VRG_Safety_Data.SM_SYS_CHECK(df_img, test, document, pltPath, showPlt)

        document.add_heading(i + ' SM_CDS_MEM_CRC_TOP ' + asilCheck + ' vs. ' + faultFrm, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, asilCheck, faultFrm, showPlt)
        document.add_heading(i + ' SM_CDS_MEM_CRC_TOP ' + asilCheck + ' vs. ' + faultPerFrm, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, asilCheck, faultPerFrm, showPlt)
        document.add_heading(i + ' SM_CDS_MEM_CRC_TOP ' + asilCheck + ' vs. ' + asilStatus, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, asilCheck, asilStatus, showPlt)
        document.add_heading(i + ' SM_CDS_MEM_CRC_TOP ' + asilStatus + ' vs. ' + sysCheck, level=2)
        VRG_General_Data.Data_vs_Data_vs_Step_Plot(df_img, test, document, pltPath, asilStatus, sysCheck, showPlt)

        document.add_heading(i + ' SM_CDS_MEM_CRC_TOP FrameCount vs. ' + faultFrm + ' vs. ' + asilCheck, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, test, document, pltPath, 'FrameCount', faultFrm, showPlt)

        document.add_heading(i + ' SM_CDS_MEM_CRC_TOP Image Means & StdDev vs. ' + asilCheck, level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, test, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, test, document, pltPath, showPlt)

        df_t1 = df_img[[temp, 'ImgMode', 'Power', asilCheck, faultFrm, faultPerFrm, asilStatus, sysCheck]]
        document.add_heading(i + ' SM_CDS_MEM_CRC_TOP Results Table', level=2)
        VRG_Doc.df_to_table(df_t1, document)

def DV_12_0_65_SM_CDS_MEM_CRC_BTM(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    ULcolor = '#ff0000'
    LLcolor = '#0000ff'
    test = 'RegWr00_DCDS_CRC_FAULT_CONTROL_BTM'
    asilCheck = 'DCDS_CRC_FAULT_CONTROL_BTM'
    faultFrm = 'DCDS_CRC_FAULT_FRAMES_BTM'
    faultPerFrm = 'DCDS_CRC_FAULTS_PER_FRAME_BTM'
    asilStatus = 'ASIL_STATUS_03__DCDS_BTM_MEMORY_CRC_FAULT'
    sysCheck = 'SYS_CHECK'

    # VRG_General_Data Plots
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    # document.add_heading('Temperature Sensor')
    # VRG_TempsensorData.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Meta Data')
    VRG_Macro_Data.MetaData_Enable_Plot(df, [die, temp], document, pltPath, showPlt)

    document.add_heading('SM_CDS_MEM_CRC_BTM Results vs. Imaging Mode')
    VRG_Safety_Data.SM_CDS_MEM_CRC_BTM(df, 'ImgMode', document, pltPath, showPlt)
    document.add_heading('SM_CDS_MEM_CRC_BTM SYS_CHECK vs. Imaging Mode')
    VRG_Safety_Data.SM_SYS_CHECK(df, 'ImgMode', document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df['Clk'].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' SM_CDS_MEM_CRC_BTM Results vs. ' + asilCheck, level=2)
        VRG_Safety_Data.SM_CDS_MEM_CRC_BTM(df_img, test, document, pltPath, showPlt)
        document.add_heading(i + ' SM_CDS_MEM_CRC_BTM SYS_CHECK vs. ' + asilCheck, level=2)
        VRG_Safety_Data.SM_SYS_CHECK(df_img, test, document, pltPath, showPlt)

        document.add_heading(i + ' SM_CDS_MEM_CRC_BTM ' + asilCheck + ' vs. ' + faultFrm, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, asilCheck, faultFrm, showPlt)
        document.add_heading(i + ' SM_CDS_MEM_CRC_BTM ' + asilCheck + ' vs. ' + faultPerFrm, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, asilCheck, faultPerFrm, showPlt)
        document.add_heading(i + ' SM_CDS_MEM_CRC_BTM ' + asilCheck + ' vs. ' + asilStatus, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, asilCheck, asilStatus, showPlt)
        document.add_heading(i + ' SM_CDS_MEM_CRC_BTM ' + asilStatus + ' vs. ' + sysCheck, level=2)
        VRG_General_Data.Data_vs_Data_vs_Step_Plot(df_img, test, document, pltPath, asilStatus, sysCheck, showPlt)

        document.add_heading(i + ' SM_CDS_MEM_CRC_BTM FrameCount vs. ' + faultFrm + ' vs. ' + asilCheck, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, test, document, pltPath, 'FrameCount', faultFrm, showPlt)

        document.add_heading(i + ' SM_CDS_MEM_CRC_BTM Image Means & StdDev vs. ' + asilCheck, level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, test, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, test, document, pltPath, showPlt)

        df_t1 = df_img[[temp, 'ImgMode', 'Power', asilCheck, faultFrm, faultPerFrm, asilStatus, sysCheck]]
        document.add_heading(i + ' SM_CDS_MEM_CRC_BTM Results Table', level=2)
        VRG_Doc.df_to_table(df_t1, document)

def DV_12_0_66_SM_OFL_MEM_CRC(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    ULcolor = '#ff0000'
    LLcolor = '#0000ff'
    test = 'RegWr00_LFM2_CRC_FAULT_CONTROL'
    asilCheck = 'LFM2_CRC_FAULT_CONTROL'
    faultFrm = 'LFM2_CRC_FAULT_FRAMES'
    faultPerFrm = 'LFM2_CRC_FAULTS_PER_FRAME'
    asilStatus = 'ASIL_STATUS_03__LFM2_MEMORY_CRC_FAULT'
    sysCheck = 'SYS_CHECK'

    # VRG_General_Data Plots
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    # document.add_heading('Temperature Sensor')
    # VRG_TempsensorData.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Meta Data')
    VRG_Macro_Data.MetaData_Enable_Plot(df, [die, temp], document, pltPath, showPlt)

    document.add_heading('SM_OFL_MEM_CRC Results vs. Imaging Mode')
    VRG_Safety_Data.SM_OFL_MEM_CRC(df, 'ImgMode', document, pltPath, showPlt)
    document.add_heading('SM_OFL_MEM_CRC SYS_CHECK vs. Imaging Mode')
    VRG_Safety_Data.SM_SYS_CHECK(df, 'ImgMode', document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df['Clk'].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' SM_OFL_MEM_CRC Results vs. ' + asilCheck, level=2)
        VRG_Safety_Data.SM_OFL_MEM_CRC(df_img, test, document, pltPath, showPlt)
        document.add_heading(i + ' SM_OFL_MEM_CRC SYS_CHECK vs. ' + asilCheck, level=2)
        VRG_Safety_Data.SM_SYS_CHECK(df_img, test, document, pltPath, showPlt)

        document.add_heading(i + ' SM_OFL_MEM_CRC ' + asilCheck + ' vs. ' + faultFrm, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, asilCheck, faultFrm, showPlt)
        document.add_heading(i + ' SM_OFL_MEM_CRC ' + asilCheck + ' vs. ' + faultPerFrm, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, asilCheck, faultPerFrm, showPlt)
        document.add_heading(i + ' SM_OFL_MEM_CRC ' + asilCheck + ' vs. ' + asilStatus, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, asilCheck, asilStatus, showPlt)
        document.add_heading(i + ' SM_OFL_MEM_CRC ' + asilStatus + ' vs. ' + sysCheck, level=2)
        VRG_General_Data.Data_vs_Data_vs_Step_Plot(df_img, test, document, pltPath, asilStatus, sysCheck, showPlt)

        document.add_heading(i + ' SM_OFL_MEM_CRC FrameCount vs. ' + faultFrm + ' vs. ' + asilCheck, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, test, document, pltPath, 'FrameCount', faultFrm, showPlt)

        document.add_heading(i + ' SM_OFL_MEM_CRC Image Means & StdDev vs. ' + asilCheck, level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, test, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, test, document, pltPath, showPlt)

        df_t1 = df_img[[temp, 'ImgMode', 'Power', asilCheck, faultFrm, faultPerFrm, asilStatus, sysCheck]]
        document.add_heading(i + ' SM_OFL_MEM_CRC Results Table', level=2)
        VRG_Doc.df_to_table(df_t1, document)

def DV_12_0_67_SM_DEF_CORR_RAM_CRC(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    ULcolor = '#ff0000'
    LLcolor = '#0000ff'
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    ULcolor = '#ff0000'
    LLcolor = '#0000ff'
    test = 'RegWr00_ASIL_CHECK_ENABLES_00'
    asilCheck = 'ASIL_CHECK_ENABLES_00'
    asilStatus = 'ASIL_STATUS_00'
    asilStatus1 = 'T1_SM_STATUS'
    asilStatus2 = 'T4_SM_STATUS'
    sysCheck = 'SYS_CHECK'

    # VRG_General_Data Plots
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    # document.add_heading('Temperature Sensor')
    # VRG_TempsensorData.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Meta Data')
    VRG_Macro_Data.MetaData_Enable_Plot(df, [die, temp], document, pltPath, showPlt)

    document.add_heading('SM_DEF_CORR_RAM_CRC Results vs. Imaging Mode')
    VRG_Safety_Data.SM_DEF_CORR_RAM_CRC(df, 'ImgMode', document, pltPath, showPlt)
    document.add_heading('SM_DEF_CORR_RAM_CRC SYS_CHECK vs. Imaging Mode')
    VRG_Safety_Data.SM_SYS_CHECK(df, 'ImgMode', document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[test].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' SM_DEF_CORR_RAM_CRC Results vs. ' + asilCheck, level=2)
        VRG_Safety_Data.SM_DEF_CORR_RAM_CRC(df_img, test, document, pltPath, showPlt)
        document.add_heading(i + ' SM_DEF_CORR_RAM_CRC SYS_CHECK vs. ' + asilCheck, level=2)
        VRG_Safety_Data.SM_SYS_CHECK(df_img, test, document, pltPath, showPlt)

        document.add_heading(i + ' SM_DEF_CORR_RAM_CRC ' + asilCheck + ' vs. ' + asilStatus, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, asilCheck, asilStatus, showPlt)
        document.add_heading(i + ' SM_DEF_CORR_RAM_CRC ' + asilCheck + ' vs. ' + asilStatus1, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, test, document, pltPath, asilCheck, asilStatus1, showPlt)
        document.add_heading(i + ' SM_DEF_CORR_RAM_CRC ' + asilCheck + ' vs. ' + asilStatus2, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, test, document, pltPath, asilCheck, asilStatus2, showPlt)
        document.add_heading(i + ' SM_DEF_CORR_RAM_CRC ' + asilStatus + ' vs. ' + sysCheck, level=2)
        VRG_General_Data.Data_vs_Data_vs_Step_Plot(df_img, test, document, pltPath, asilStatus, sysCheck, showPlt)

        document.add_heading(i + ' SM_DEF_CORR_RAM_CRC Image Means & StdDev vs. ' + asilCheck, level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, test, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, test, document, pltPath, showPlt)

        df_t1 = df_img[[temp, 'ImgMode', 'Power', asilCheck, asilStatus, asilStatus1, asilStatus2, sysCheck]]
        document.add_heading(i + ' SM_DEF_CORR_RAM_CRC Results Table', level=2)
        VRG_Doc.df_to_table(df_t1, document)

def DV_12_0_68_SM_MC_RAM(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_0_69_SM_STATS_RAM_ECC(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    ULcolor = '#ff0000'
    LLcolor = '#0000ff'
    test = 'RegWr00_ASIL_CHECK_ENABLES_04'
    asilCheck = 'ASIL_CHECK_ENABLES_04'
    asilStatus = 'ASIL_STATUS_04'
    sysCheck = 'SYS_CHECK'
    metaData = 'DVM_Meta_Data'

    # VRG_General_Data Plots
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    # document.add_heading('Temperature Sensor')
    # VRG_TempsensorData.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Meta Data')
    VRG_Macro_Data.MetaData_Enable_Plot(df, [die, temp], document, pltPath, showPlt)

    document.add_heading('SM_STATS_RAM_ECC vs. Imaging Mode')
    VRG_Safety_Data.SM_STATS_RAM_ECC(df, 'ImgMode', document, pltPath, showPlt)
    document.add_heading('SM_STATS_RAM_ECC SYS_CHECK vs. Imaging Mode')
    VRG_Safety_Data.SM_SYS_CHECK(df, 'ImgMode', document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[test].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' SM_STATS_RAM_ECC vs. ' + asilCheck, level=2)
        VRG_Safety_Data.SM_STATS_RAM_ECC(df_img, test, document, pltPath, showPlt)
        document.add_heading(i + ' SM_STATS_RAM_ECC SYS_CHECK vs. ' + asilCheck, level=2)
        VRG_Safety_Data.SM_SYS_CHECK(df_img, test, document, pltPath, showPlt)

        document.add_heading(i + ' SM_STATS_RAM_ECC ' + asilCheck + ' vs. ' + asilStatus, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, asilCheck, asilStatus, showPlt)
        document.add_heading(i + ' SM_STATS_RAM_ECC ' + asilStatus + ' vs. ' + sysCheck, level=2)
        VRG_General_Data.Data_vs_Data_vs_Step_Plot(df_img, None, document, pltPath, asilStatus, sysCheck, showPlt)

        df_t1 = df_img[[temp, 'ImgMode', 'Power', metaData, asilCheck, asilStatus, sysCheck]]
        document.add_heading(i + ' SM_STATS_RAM_ECC Results Table', level=2)
        VRG_Doc.df_to_table(df_t1, document)

def DV_12_0_70_SM_MASTER_STATE_CHA_RES(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    test = 'RegWr00_MASTER_FSM_REQ_CODE'
    challenge = 'MASTER_FSM_REQ_CODE'
    response = 'MASTER_FSM_RSP_CODE'
    calcResp = 'CALC_MASTER_FSM_RSP_CODE'
    status = 'MASTER_FSM_STATUS'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, None, document, pltPath, showPlt)  # Temperature for each val test
    VRG_General_Data.FrameCount_Plot(df, None, document, pltPath, showPlt)  # Number of frames for each val test
    VRG_General_Data.Clk_Frequency_Plot(df, None, document, pltPath, showPlt)  # Plot each frequency for each test
    VRG_General_Data.TestTime_Plot(df, None, document, pltPath, showPlt)  # Time to run each val test
    VRG_General_Data.RunNumber_Plot(df, None, document, pltPath, showPlt)  # Val test run number
    VRG_General_Data.FrameWidth_Plot(df, None, document, pltPath, showPlt)  # Frame width
    VRG_General_Data.FrameHeight_Plot(df, None, document, pltPath, showPlt)  # Frame height
    VRG_General_Data.FrameBitDepth_Plot(df, None, document, pltPath, showPlt)  # Frame bit depth
    VRG_General_Data.DroppedFrames_Plot(df, None, document, pltPath, showPlt)  # Dropped frames
    VRG_General_Data.Sensor_FPS_Plot(df, None, document, pltPath, showPlt)  # Frames/second
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, None, document, pltPath, showPlt)  # Plot ASIL startup data for all tests

    document.add_heading('SM_MASTER_STATE_CHA_RES vs. Imaging Mode')
    VRG_Safety_Data.SM_MASTER_STATE_CHA_RES(df, 'ImgMode', document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[test].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' SM_MASTER_STATE_CHA_RES Results')
        VRG_Safety_Data.SM_MASTER_STATE_CHA_RES(df_img, None, document, pltPath, showPlt)

        document.add_heading(i + ' SM_MASTER_STATE_CHA_RES Results vs. Temperature')
        VRG_Safety_Data.SM_MASTER_STATE_CHA_RES(df_img, temp, document, pltPath, showPlt)

        document.add_heading(i + ' SM_MASTER_STATE_CHA_RES Results vs. Power')
        VRG_Safety_Data.SM_MASTER_STATE_CHA_RES(df_img, 'Power', document, pltPath, showPlt)

        document.add_heading(i + ' SM_MASTER_STATE_CHA_RES Challenge vs. Response Results')
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, challenge, response, showPlt)

        df_t_img = df_img[[temp, 'ImgMode', challenge, response, calcResp, status]]
        document.add_heading(i + ' SM_MASTER_STATE_CHA_RES Results Table', level=2)
        VRG_Doc.df_to_table(df_t_img, document)

        document.add_heading(i + ' Image Mean & StdDev vs. Challenge', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, challenge, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, challenge, document, pltPath, showPlt)

        for tst in TEST:  # Test
            df_test = VRG_Data_Frame.newdataframe(df_img, test, tst)

            document.add_heading(i + ' SM_MASTER_STATE_CHA_RES vs. Challenge = ' + str(tst), level=1)
            document.add_heading(i + ' SM_MASTER_STATE_CHA_RES Results vs. Challenge = ' + str(tst), level=2)
            VRG_Safety_Data.SM_MASTER_STATE_CHA_RES(df_test, challenge, document, pltPath, showPlt)

            document.add_heading(i + ' SM_MASTER_STATE_CHA_RES Challenge = ' + str(tst) + ' vs. Response Results')
            VRG_Register_Data.Reg_vs_Reg_Plot(df_test, None, document, pltPath, challenge, response, showPlt)

            document.add_heading(i + ' SM_MASTER_STATE_CHA_RES Response Results vs. Challenge = ' + str(tst), level=2)
            VRG_Register_Data.Reg_vs_Step_Plot(df_test, challenge, document, pltPath, response, showPlt)

            df_t_tst = df_test[[temp, 'ImgMode', challenge, response, calcResp, status]]
            document.add_heading(i + ' SM_MASTER_STATE_CHA_RES Results Table vs. Challenge = ' + str(tst), level=2)
            VRG_Doc.df_to_table(df_t_tst, document)

def DV_12_0_71_SM_ADDR_STATE_CRC(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    addrPinEn = 'ASIL_PIN_ENABLES_02__ADDRESS_SM_CRC_PIN_ENABLE'
    addrCheckEn = 'ASIL_CHECK_ENABLES_02__ADDRESS_SM_CRC_ENABLE'
    addrStatus = 'ASIL_STATUS_02__ADDRESS_SM_CRC_STATUS'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, None, document, pltPath, showPlt)  # Temperature for each val test
    VRG_General_Data.FrameCount_Plot(df, None, document, pltPath, showPlt)  # Number of frames for each val test
    VRG_General_Data.Clk_Frequency_Plot(df, None, document, pltPath, showPlt)  # Plot each frequency for each test
    VRG_General_Data.TestTime_Plot(df, None, document, pltPath, showPlt)  # Time to run each val test
    VRG_General_Data.RunNumber_Plot(df, None, document, pltPath, showPlt)  # Val test run number
    VRG_General_Data.FrameWidth_Plot(df, None, document, pltPath, showPlt)  # Frame width
    VRG_General_Data.FrameHeight_Plot(df, None, document, pltPath, showPlt)  # Frame height
    VRG_General_Data.FrameBitDepth_Plot(df, None, document, pltPath, showPlt)  # Frame bit depth
    VRG_General_Data.DroppedFrames_Plot(df, None, document, pltPath, showPlt)  # Dropped frames
    VRG_General_Data.Sensor_FPS_Plot(df, None, document, pltPath, showPlt)  # Frames/second
    # document.add_heading('Temperature Sensor')
    # VRG_TempsensorData.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, None, document, pltPath, showPlt)  # Plot ASIL startup data for all tests

    document.add_heading('SM_ADDR_STATE_CRC Registers vs. Imaging Mode')
    VRG_Safety_Data.SM_ADDR_STATE_CRC(df, 'ImgMode', document, pltPath, showPlt)
    document.add_heading('SYS_CHECK vs. Imaging Mode')
    VRG_Safety_Data.SM_SYS_CHECK(df, 'ImgMode', document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[addrCheckEn].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' SM_ADDR_STATE_CRC Registers vs. ASIL_CHECK_ENABLES__ADDRESS_SM_CRC_ENABLE', level=2)
        VRG_Safety_Data.SM_ADDR_STATE_CRC(df_img, addrCheckEn, document, pltPath, showPlt)
        document.add_heading(i + ' SYS_CHECK vs. ASIL_CHECK_ENABLES__ADDRESS_SM_CRC_ENABLE', level=2)
        VRG_Safety_Data.SM_SYS_CHECK(df_img, addrCheckEn, document, pltPath, showPlt)

        document.add_heading(
            i + ' SM_ADDR_STATE_CRC Registers vs. Temperature vs. ASIL_CHECK_ENABLES__ADDRESS_SM_CRC_ENABLE', level=2)
        VRG_Safety_Data.SM_ADDR_STATE_CRC(df_img, [temp, addrCheckEn], document, pltPath, showPlt)
        document.add_heading(i + ' SYS_CHECK vs. Temperature vs. ASIL_CHECK_ENABLES__ADDRESS_SM_CRC_ENABLE', level=2)
        VRG_Safety_Data.SM_SYS_CHECK(df_img, [temp, addrCheckEn], document, pltPath, showPlt)

        document.add_heading(i + ' SM_ADDR_STATE_CRC Registers vs. Power vs. ASIL_CHECK_ENABLES__ADDRESS_SM_CRC_ENABLE',
                             level=2)
        VRG_Safety_Data.SM_ADDR_STATE_CRC(df_img, ['Power', addrCheckEn], document, pltPath, showPlt)
        document.add_heading(i + ' SYS_CHECK vs. Power vs. ASIL_CHECK_ENABLES__ADDRESS_SM_CRC_ENABLE', level=2)
        VRG_Safety_Data.SM_SYS_CHECK(df_img, ['Power', addrCheckEn], document, pltPath, showPlt)

        document.add_heading(i + ' ASIL_CHECK_ENABLES__ADDRESS_SM_CRC_ENABLE vs. ASIL_STATUS_02__ADDRESS_SM_CRC_STATUS',
                             level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, addrCheckEn, addrStatus, showPlt)

        df_t = df_img[[temp, 'ImgMode', addrPinEn, addrCheckEn, addrStatus, 'SYS_CHECK']]
        document.add_heading(i + ' SM_ADDR_STATE_CRC Results Table')
        VRG_Doc.df_to_table(df_t, document)

        for tst in TEST:  # Test
            df_test = VRG_Data_Frame.newdataframe(df_img, addrCheckEn, tst)

            document.add_heading(i + ' SM_ADDR_STATE_CRC vs. ASIL_CHECK_ENABLES__ADDRESS_SM_CRC_ENABLE = ' + str(tst),
                                 level=1)
            document.add_heading(
                i + ' SM_ADDR_STATE_CRC Registers vs. Temperature vs. ASIL_CHECK_ENABLES__ADDRESS_SM_CRC_ENABLE = ' + str(
                    tst), level=2)
            VRG_Safety_Data.SM_ADDR_STATE_CRC(df_test, [temp, addrCheckEn], document, pltPath, showPlt)
            document.add_heading(
                i + ' SYS_CHECK vs. Temperature vs. ASIL_CHECK_ENABLES__ADDRESS_SM_CRC_ENABLE = ' + str(tst), level=2)
            VRG_Safety_Data.SM_SYS_CHECK(df_test, [temp, addrCheckEn], document, pltPath, showPlt)

            document.add_heading(
                i + ' ASIL_CHECK_ENABLES__ADDRESS_SM_CRC_ENABLE vs. ASIL_STATUS_02__ADDRESS_SM_CRC_STATUS', level=2)
            VRG_Register_Data.Reg_vs_Reg_Plot(df_test, None, document, pltPath, addrCheckEn, addrStatus, showPlt)

def DV_12_0_72_SM_POWERON_MBIST(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_0_73_SM_POWERON_MBIST2(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_0_74_SM_HOST_CHECK_GPIO(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    gpioTest = 'DVM_12_SM_74_SM_HOST_CHECK_GPIO_Settings'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, None, document, pltPath, showPlt)  # Temperature for each val test
    VRG_General_Data.FrameCount_Plot(df, None, document, pltPath, showPlt)  # Number of frames for each val test
    VRG_General_Data.Clk_Frequency_Plot(df, None, document, pltPath, showPlt)  # Plot each frequency for each test
    VRG_General_Data.TestTime_Plot(df, None, document, pltPath, showPlt)  # Time to run each val test
    VRG_General_Data.RunNumber_Plot(df, None, document, pltPath, showPlt)  # Val test run number
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, None, document, pltPath, showPlt)  # Plot ASIL startup data for all tests

    df_gpio_1 = df[[temp, 'GPI_STATUS', 'GPI_STATUS_ASIC', 'GPIO0', 'GPIO1', 'GPIO2', 'GPIO3']]
    df_gpio_2 = df[[temp, 'GPIO0', 'GPI_STATUS__GPIO0_PIN_STATUS', 'GPI_STATUS_ASIC__GPIO0_PIN_STATUS_ASIC', 'GPIO1',
                    'GPI_STATUS__GPIO1_PIN_STATUS',
                    'GPIO2', 'GPI_STATUS__GPIO2_PIN_STATUS', 'GPIO3', 'GPI_STATUS__GPIO3_PIN_STATUS']]

    document.add_heading('GPI_STATUS vs. GPIO Levels')
    VRG_Doc.df_to_table(df_gpio_1, document)

    document.add_heading('GPI_STATUS & GPI_STATUS_ASIC vs. GPIO Levels')
    VRG_Doc.df_to_table(df_gpio_2, document)

    document.add_heading('SM HOST CHECK GPIO Data vs. GPIO Test')
    VRG_Safety_Data.SM_HOST_CHECK_GPIO(df, gpioTest, document, pltPath, showPlt)
    document.add_heading('SADDR Pin Levels vs. GPIO Test')
    VRG_Pins_Data.GPIO_Plot_4_Pins(df, gpioTest, document, pltPath, showPlt)
    document.add_heading('SADDR Pin Levels vs. GPIO Test')
    VRG_Pins_Data.SADDR_Plot_4_Pins(df, gpioTest, document, pltPath, showPlt)

def DV_12_0_75_SM_RESET(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_0_76_SM_MEC_CRC_NEW(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    ULcolor = '#ff0000'
    LLcolor = '#0000ff'
    test = 'RegWr00_MEC_CRC_FAULT_CONTROL'
    asilCheck = 'MEC_CRC_FAULT_CONTROL'
    faultFrm = 'MEC_CRC_FAULT_FRAMES'
    faultPerFrm = 'MEC_CRC_FAULTS_PER_FRAME'
    asilStatus = 'ASIL_STATUS_03__MEC_MEMORY_CRC_FAULT'
    sysCheck = 'SYS_CHECK'

    # VRG_General_Data Plots
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    # document.add_heading('Temperature Sensor')
    # VRG_TempsensorData.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Meta Data')
    VRG_Macro_Data.MetaData_Enable_Plot(df, [die, temp], document, pltPath, showPlt)

    document.add_heading('SM_MEC_RAM_CRC Results vs. Imaging Mode')
    VRG_Safety_Data.SM_MEC_RAM_CRC(df, 'ImgMode', document, pltPath, showPlt)
    document.add_heading('SM_MEC_RAM_CRC SYS_CHECK vs. Imaging Mode')
    VRG_Safety_Data.SM_SYS_CHECK(df, 'ImgMode', document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df['Clk'].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' SM_MEC_RAM_CRC Results vs. ' + asilCheck, level=2)
        VRG_Safety_Data.SM_MEC_RAM_CRC(df_img, test, document, pltPath, showPlt)
        document.add_heading(i + ' SM_MEC_RAM_CRC SYS_CHECK vs. ' + asilCheck, level=2)
        VRG_Safety_Data.SM_SYS_CHECK(df_img, test, document, pltPath, showPlt)

        document.add_heading(i + ' SM_MEC_RAM_CRC ' + asilCheck + ' vs. ' + faultFrm, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, asilCheck, faultFrm, showPlt)
        document.add_heading(i + ' SM_MEC_RAM_CRC ' + asilCheck + ' vs. ' + faultPerFrm, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, asilCheck, faultPerFrm, showPlt)
        document.add_heading(i + ' SM_MEC_RAM_CRC ' + asilCheck + ' vs. ' + asilStatus, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, asilCheck, asilStatus, showPlt)
        document.add_heading(i + ' SM_MEC_RAM_CRC ' + asilStatus + ' vs. ' + sysCheck, level=2)
        VRG_General_Data.Data_vs_Data_vs_Step_Plot(df_img, test, document, pltPath, asilStatus, sysCheck, showPlt)

        document.add_heading(i + ' SM_MEC_RAM_CRC FrameCount vs. ' + faultFrm + ' vs. ' + asilCheck, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, test, document, pltPath, 'FrameCount', faultFrm, showPlt)

        document.add_heading(i + ' SM_MEC_RAM_CRC Image Means & StdDev vs. ' + asilCheck, level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, test, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, test, document, pltPath, showPlt)

        df_t1 = df_img[[temp, 'ImgMode', 'Power', asilCheck, faultFrm, faultPerFrm, asilStatus, sysCheck]]
        document.add_heading(i + ' SM_MEC_RAM_CRC Results Table', level=2)
        VRG_Doc.df_to_table(df_t1, document)

def DV_12_0_77_SM_PDI_RAM_CRC(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, None, document, pltPath, showPlt)  # Temperature for each val test
    VRG_General_Data.FrameCount_Plot(df, None, document, pltPath, showPlt)  # Number of frames for each val test
    VRG_General_Data.Clk_Frequency_Plot(df, None, document, pltPath, showPlt)  # Plot each frequency for each test
    VRG_General_Data.TestTime_Plot(df, None, document, pltPath, showPlt)  # Time to run each val test
    VRG_General_Data.RunNumber_Plot(df, None, document, pltPath, showPlt)  # Val test run number
    VRG_General_Data.FrameWidth_Plot(df, None, document, pltPath, showPlt)  # Frame width
    VRG_General_Data.FrameHeight_Plot(df, None, document, pltPath, showPlt)  # Frame height
    VRG_General_Data.FrameBitDepth_Plot(df, None, document, pltPath, showPlt)  # Frame bit depth
    VRG_General_Data.DroppedFrames_Plot(df, None, document, pltPath, showPlt)  # Dropped frames
    VRG_General_Data.Sensor_FPS_Plot(df, None, document, pltPath, showPlt)  # Frames/second
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, None, document, pltPath, showPlt)  # Plot tempsensor data for all tests
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, None, document, pltPath, showPlt)  # Plot ASIL startup data for all tests

    document.add_heading('Power & Current vs. Voltage Level vs. Imaging Mode', level=2)
    VRG_Power_Data.Power_Consumption_Plot(df, ['Power', 'ImgMode'], document, pltPath, showPlt)
    VRG_Power_Data.Current_Consumption_Plot(df, ['Power', 'ImgMode'], document, pltPath, showPlt)

    document.add_heading('SM PDI RAM CRC Results vs. Imaging Mode')
    VRG_Safety_Data.SM_PDI_RAM_CRC(df, 'ImgMode', document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' SM PDI RAM CRC Results vs. Power', level=2)
        VRG_Safety_Data.SM_PDI_RAM_CRC(df_img, 'Power', document, pltPath, showPlt)

        document.add_heading(i + ' SM PDI RAM CRC Results vs. Temperature', level=2)
        VRG_Safety_Data.SM_PDI_RAM_CRC(df_img, temp, document, pltPath, showPlt)

        document.add_heading(i + ' SM PDI RAM CRC Results vs. Die', level=2)
        VRG_Safety_Data.SM_PDI_RAM_CRC(df_img, die, document, pltPath, showPlt)

        document.add_heading(i + ' Image Mean & StdDev vs. Temperature', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, temp, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, temp, document, pltPath, showPlt)

def DV_12_0_78_SM_TEST_FRAME(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    deltaDk = 'DELTA_DK_CONTROL'
    hiCalcCRC = 'CRC_FR_DTR_CALC_CHECKSUM_HIGH'
    hiWrtCRC = 'CRC_FR_DTR_WRT_CHECKSUM_HIGH'
    calcHi = 'CRC_FR_DTR_CALC_CHECKSUM_HIGH__CRC_FR_CALC_CHECKSUM_HIGH'
    calcLo = 'CRC_FR_CALC_CHECKSUM_LOW'
    wrtHi = 'CRC_FR_DTR_WRT_CHECKSUM_HIGH__CRC_FR_WRT_CHECKSUM_HIGH'
    wrtLo = 'CRC_FR_WRT_CHECKSUM_LOW'
    rnc = 'DARK_CONTROL__DARK_CONTROL_ROW_NOISE_CORRECTION_EN'
    dataPed = 'DATA_PEDESTAL_'
    crcContReg = 'CRC_CONTROL_REG'
    framePattern = 'Macro4'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, None, document, pltPath, showPlt)  # Temperature for each val test
    VRG_General_Data.FrameCount_Plot(df, None, document, pltPath, showPlt)  # Number of frames for each val test
    VRG_General_Data.Clk_Frequency_Plot(df, None, document, pltPath, showPlt)  # Plot each frequency for each test
    VRG_General_Data.TestTime_Plot(df, None, document, pltPath, showPlt)  # Time to run each val test
    VRG_General_Data.RunNumber_Plot(df, None, document, pltPath, showPlt)  # Val test run number
    VRG_General_Data.FrameWidth_Plot(df, None, document, pltPath, showPlt)  # Frame width
    VRG_General_Data.FrameHeight_Plot(df, None, document, pltPath, showPlt)  # Frame height
    VRG_General_Data.FrameBitDepth_Plot(df, None, document, pltPath, showPlt)  # Frame bit depth
    VRG_General_Data.DroppedFrames_Plot(df, None, document, pltPath, showPlt)  # Dropped frames
    VRG_General_Data.Sensor_FPS_Plot(df, None, document, pltPath, showPlt)  # Frames/second
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, None, document, pltPath, showPlt)  # Plot tempsensor data for all tests
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, None, document, pltPath, showPlt)  # Plot ASIL startup data for all tests

    document.add_heading('Additional Key Register Settings', level=1)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, rnc, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, dataPed, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, crcContReg, showPlt)

    document.add_heading('SM_STANDBY_TEST_FRAME Register Settings vs. Imaging Mode', level=1)
    VRG_Safety_Data.SM_STANDBY_TEST_FRAME(df, 'ImgMode', document, pltPath, showPlt)
    document.add_heading('SM_STANDBY_TEST_FRAME SYS_CHECK Values vs. vs. Imaging Mode')
    VRG_Safety_Data.SM_SYS_CHECK(df, 'ImgMode', document, pltPath, showPlt)

    document.add_heading('SM_STANDBY_TEST_FRAME Register Settings vs. Test Frame Patterns', level=1)
    VRG_Safety_Data.SM_STANDBY_TEST_FRAME(df, framePattern, document, pltPath, showPlt)
    document.add_heading('SM_STANDBY_TEST_FRAME SYS_CHECK Values vs. Test Frame Patterns')
    VRG_Safety_Data.SM_SYS_CHECK(df, framePattern, document, pltPath, showPlt)

    document.add_heading('SM_STANDBY_TEST_FRAME Calculated High CRC vs Expected High CRC vs. Imaging Mode')
    VRG_Register_Data.Reg_vs_Reg_Plot(df, 'ImgMode', document, pltPath, hiCalcCRC, hiWrtCRC, showPlt)
    document.add_heading('SM_STANDBY_TEST_FRAME Calculated High Frame CRC vs Expected High Frame CRC vs. Imaging Mode')
    VRG_Register_Data.Reg_vs_Reg_Plot(df, 'ImgMode', document, pltPath, calcHi, wrtHi, showPlt)
    document.add_heading('SM_STANDBY_TEST_FRAME Calculated Low CRC vs Expected Low CRC vs. Imaging Mode')
    VRG_Register_Data.Reg_vs_Reg_Plot(df, 'ImgMode', document, pltPath, calcLo, wrtLo, showPlt)

    df_t1 = df[[temp, 'ImgMode', framePattern, hiCalcCRC, calcHi, calcLo, hiWrtCRC, wrtHi, wrtLo]]
    document.add_heading('SM_STANDBY_TEST_FRAME Frame CRC Table vs. Pattern vs. Imaging Mode. vs. Temperature')
    VRG_Doc.df_to_table(df_t1, document)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[framePattern].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' SM_STANDBY_TEST_FRAME Register Values vs. Test Frame Patterns', level=2)
        VRG_Safety_Data.SM_STANDBY_TEST_FRAME(df_img, framePattern, document, pltPath, showPlt)
        document.add_heading(i + ' SM_STANDBY_TEST_FRAME SYS_CHECK Values vs. Test Frame Patterns', level=2)
        VRG_Safety_Data.SM_SYS_CHECK(df_img, framePattern, document, pltPath, showPlt)

        document.add_heading(i + ' SM_STANDBY_TEST_FRAME Calculated High CRC vs Test Frame Pattern', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, framePattern, document, pltPath, calcHi, showPlt)
        document.add_heading(i + ' SM_STANDBY_TEST_FRAME Calculated Low CRC vs Test Frame Pattern', level=2)
        VRG_Register_Data.Reg_vs_Step_Plot(df_img, framePattern, document, pltPath, calcLo, showPlt)

        document.add_heading(
            i + ' SM_STANDBY_TEST_FRAME Calculated High CRC vs Expected High CRC vs. Test Frame Pattern')
        VRG_Register_Data.Reg_vs_Reg_Plot(df, 'ImgMode', document, pltPath, hiCalcCRC, hiWrtCRC, showPlt)
        document.add_heading(
            i + ' SM_STANDBY_TEST_FRAME Calculated High Frame CRC vs Expected High Frame CRC vs. Test Frame Pattern')
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, framePattern, document, pltPath, calcHi, wrtHi, showPlt)
        document.add_heading(i + ' SM_STANDBY_TEST_FRAME Calculated Low CRC vs Expected Low CRC vs. Test Frame Pattern')
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, framePattern, document, pltPath, calcLo, wrtLo, showPlt)

        df_t2 = df_img[[temp, 'ImgMode', framePattern, hiCalcCRC, calcHi, calcLo, hiWrtCRC, wrtHi, wrtLo]]
        document.add_heading(i + ' SM_STANDBY_TEST_FRAME Frame CRC Table', level=2)
        VRG_Doc.df_to_table(df_t2, document)

        document.add_heading(i + ' SM_STANDBY_TEST_FRAME Image Mean & StdDev vs. Test Frame Pattern', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, framePattern, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, framePattern, document, pltPath, showPlt)

        for tst in TEST:  # Test
            df_test = VRG_Data_Frame.newdataframe(df_img, framePattern, tst)

            document.add_heading(i + ' SM_STANDBY_TEST_FRAME Frame Pattern: ' + str(tst), level=1)
            document.add_heading(
                i + ' SM_STANDBY_TEST_FRAME Frame Pattern: ' + str(tst) + ' Standby Test Frame Register Values',
                level=2)
            VRG_Safety_Data.SM_STANDBY_TEST_FRAME(df_test, framePattern, document, pltPath, showPlt)
            document.add_heading(i + ' SM_STANDBY_TEST_FRAME Frame Pattern: ' + str(tst) + ' SYS_CHECK Values', level=2)
            VRG_Safety_Data.SM_SYS_CHECK(df_test, framePattern, document, pltPath, showPlt)

            document.add_heading(i + ' SM_STANDBY_TEST_FRAME Frame Pattern: ' + str(tst) + ' Calculated High CRC',
                                 level=2)
            VRG_Register_Data.Reg_vs_Step_Plot(df_test, framePattern, document, pltPath, hiCalcCRC, showPlt)
            document.add_heading(i + ' SM_STANDBY_TEST_FRAME Frame Pattern: ' + str(tst) + ' Calculated High Frame CRC',
                                 level=2)
            VRG_Register_Data.Reg_vs_Step_Plot(df_test, framePattern, document, pltPath, calcHi, showPlt)
            document.add_heading(i + ' SM_STANDBY_TEST_FRAME Frame Pattern: ' + str(tst) + ' Calculated Low CRC',
                                 level=2)
            VRG_Register_Data.Reg_vs_Step_Plot(df_test, framePattern, document, pltPath, calcLo, showPlt)

            document.add_heading(
                i + ' SM_STANDBY_TEST_FRAME Frame Pattern: ' + str(tst) + ' Calculated High CRC vs Expected High CRC',
                level=2)
            VRG_Register_Data.Reg_vs_Reg_Plot(df_test, framePattern, document, pltPath, hiCalcCRC, hiWrtCRC, showPlt)
            document.add_heading(i + ' SM_STANDBY_TEST_FRAME Frame Pattern: ' + str(
                tst) + ' Calculated High Frame CRC vs Expected High Frame CRC', level=2)
            VRG_Register_Data.Reg_vs_Reg_Plot(df_test, framePattern, document, pltPath, calcHi, wrtHi, showPlt)
            document.add_heading(
                i + ' SM_STANDBY_TEST_FRAME Frame Pattern: ' + str(tst) + ' Calculated Low CRC vs Expected Low CRC',
                level=2)
            VRG_Register_Data.Reg_vs_Reg_Plot(df_test, framePattern, document, pltPath, calcLo, wrtLo, showPlt)

            df_t3 = df_test[[temp, 'ImgMode', framePattern, hiCalcCRC, calcHi, calcLo, hiWrtCRC, wrtHi, wrtLo]]
            document.add_heading(i + ' SM_STANDBY_TEST_FRAME Frame Pattern: ' + str(tst) + ' Frame CRC Table', level=2)
            VRG_Doc.df_to_table(df_t3, document)

            document.add_heading(i + ' SM_STANDBY_TEST_FRAME Frame Pattern: ' + str(tst) + ' Image Mean & StdDev',
                                 level=2)
            VRG_Stats_Arr.Arr_Mean_Plot(df_test, framePattern, document, pltPath, showPlt)
            VRG_Stats_Arr.Arr_StdDev_Plot(df_test, framePattern, document, pltPath, showPlt)

            for tmp in TEMP:  # Temperature
                df_tmp = VRG_Data_Frame.newdataframe(df_test, temp, tmp)
                if tmp == nomTemp:
                    document.add_heading(i + ' Image Capture' + str(tst) + ' at Temperature = ' + str(tmp), level=2)
                    VRG_Image_Analysis.Add_Image(df_tmp, 2, document, showPlt)

def DV_12_0_79_SM_ATR_GRAY_TRANSFER(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_0_80_SM_LRE_RAM_CRC(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_0_81_SM_ODP_BUFFER_CRC(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    ULcolor = '#ff0000'
    LLcolor = '#0000ff'
    test = 'RegWr00_ODP_CRC_FAULT_CONTROL'
    asilCheck = 'ODP_CRC_FAULT_CONTROL'
    faultFrm = 'ODP_CRC_FAULT_FRAMES'
    faultPerFrm = 'ODP_CRC_FAULTS_PER_FRAME'
    asilStatus = 'ASIL_STATUS_03__ODP_MEMORY_CRC_FAULT'
    sysCheck = 'SYS_CHECK'

    # VRG_General_Data Plots
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    # document.add_heading('Temperature Sensor')
    # VRG_TempsensorData.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Meta Data')
    VRG_Macro_Data.MetaData_Enable_Plot(df, [die, temp], document, pltPath, showPlt)

    document.add_heading('SM_ODP_BUFFER_CRC Results vs. Imaging Mode')
    VRG_Safety_Data.SM_ODP_BUFFER_CRC(df, 'ImgMode', document, pltPath, showPlt)
    document.add_heading('SM_ODP_BUFFER_CRC SYS_CHECK vs. Imaging Mode')
    VRG_Safety_Data.SM_SYS_CHECK(df, 'ImgMode', document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df['Clk'].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' SM_ODP_BUFFER_CRC Results vs. ' + asilCheck, level=2)
        VRG_Safety_Data.SM_ODP_BUFFER_CRC(df_img, test, document, pltPath, showPlt)
        document.add_heading(i + ' SM_ODP_BUFFER_CRC SYS_CHECK vs. ' + asilCheck, level=2)
        VRG_Safety_Data.SM_SYS_CHECK(df_img, test, document, pltPath, showPlt)

        document.add_heading(i + ' SM_ODP_BUFFER_CRC ' + asilCheck + ' vs. ' + faultFrm, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, asilCheck, faultFrm, showPlt)
        document.add_heading(i + ' SM_ODP_BUFFER_CRC ' + asilCheck + ' vs. ' + faultPerFrm, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, asilCheck, faultPerFrm, showPlt)
        document.add_heading(i + ' SM_ODP_BUFFER_CRC ' + asilCheck + ' vs. ' + asilStatus, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, asilCheck, asilStatus, showPlt)
        document.add_heading(i + ' SM_ODP_BUFFER_CRC ' + asilStatus + ' vs. ' + sysCheck, level=2)
        VRG_General_Data.Data_vs_Data_vs_Step_Plot(df_img, test, document, pltPath, asilStatus, sysCheck, showPlt)

        document.add_heading(i + ' SM_ODP_BUFFER_CRC FrameCount vs. ' + faultFrm + ' vs. ' + asilCheck, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, test, document, pltPath, 'FrameCount', faultFrm, showPlt)

        document.add_heading(i + ' SM_ODP_BUFFER_CRC Image Means & StdDev vs. ' + asilCheck, level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, test, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, test, document, pltPath, showPlt)

        df_t1 = df_img[[temp, 'ImgMode', 'Power', asilCheck, faultFrm, faultPerFrm, asilStatus, sysCheck]]
        document.add_heading(i + ' SM_ODP_BUFFER_CRC Results Table', level=2)
        VRG_Doc.df_to_table(df_t1, document)

def DV_12_0_82_SM_SCALER_RAM_CRC(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_0_83_SM_PDI_DEF_CNT(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, None, document, pltPath, showPlt)  # Temperature for each val test
    VRG_General_Data.FrameCount_Plot(df, None, document, pltPath, showPlt)  # Number of frames for each val test
    VRG_General_Data.Clk_Frequency_Plot(df, None, document, pltPath, showPlt)  # Plot each frequency for each test
    VRG_General_Data.TestTime_Plot(df, None, document, pltPath, showPlt)  # Time to run each val test
    VRG_General_Data.RunNumber_Plot(df, None, document, pltPath, showPlt)  # Val test run number
    VRG_General_Data.FrameWidth_Plot(df, None, document, pltPath, showPlt)  # Frame width
    VRG_General_Data.FrameHeight_Plot(df, None, document, pltPath, showPlt)  # Frame height
    VRG_General_Data.FrameBitDepth_Plot(df, None, document, pltPath, showPlt)  # Frame bit depth
    VRG_General_Data.DroppedFrames_Plot(df, None, document, pltPath, showPlt)  # Dropped frames
    VRG_General_Data.Sensor_FPS_Plot(df, None, document, pltPath, showPlt)  # Frames/second
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, None, document, pltPath, showPlt)  # Plot tempsensor data for all tests
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, None, document, pltPath, showPlt)  # Plot ASIL startup data for all tests

    document.add_heading('Power & Current vs. Voltage Level vs. Imaging Mode', level=2)
    VRG_Power_Data.Power_Consumption_Plot(df, ['Power', 'ImgMode'], document, pltPath, showPlt)
    VRG_Power_Data.Current_Consumption_Plot(df, ['Power', 'ImgMode'], document, pltPath, showPlt)

    document.add_heading('SM PDI RAM CRC Results vs. Imaging Mode')
    VRG_Safety_Data.SM_PDI_RAM_CRC(df, 'ImgMode', document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' SM PDI RAM CRC Results vs. Power', level=2)
        VRG_Safety_Data.SM_PDI_RAM_CRC(df_img, 'Power', document, pltPath, showPlt)

        document.add_heading(i + ' SM PDI RAM CRC Results vs. Temperature', level=2)
        VRG_Safety_Data.SM_PDI_RAM_CRC(df_img, temp, document, pltPath, showPlt)

        document.add_heading(i + ' SM PDI RAM CRC Results vs. Die', level=2)
        VRG_Safety_Data.SM_PDI_RAM_CRC(df_img, die, document, pltPath, showPlt)

        document.add_heading(i + ' Image Mean & StdDev vs. Temperature', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, temp, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, temp, document, pltPath, showPlt)

def DV_12_0_84_SM_ATR_OVERDRIVE_012(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_0_85_SM_ATR_OVERDRIVE_PSRR(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_0_86_SM_DTC(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_0_90_SM_SMART_CRC(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_0_91_SM_FIFO_CRC(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_0_92_SM_ATR_OVERDRIVE_4T(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_0_93_SM_DTR_MEC(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    ULcolor = '#ff0000'
    LLcolor = '#0000ff'
    test = 'RegWr00_MEC_SM_ERR_TH'
    reg1 = 'MEC_SM_ERR_COUNT_LSB'
    reg2 = 'MEC_SM_ERR_COUNT_MSB'
    reg3 = 'MEC_SM_ERR_HIGH_LSB'
    reg4 = 'MEC_SM_ERR_HIGH_MSB'
    reg5 = 'MEC_SM_ERR_LOW_LSB'
    reg6 = 'MEC_SM_ERR_LOW_MSB'
    reg7 = 'MEC_SM_ERR_STATUS'
    asilStatus = 'ASIL_STATUS_06__FAIL_MEC_SM'

    # VRG_General_Data Plots
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    # document.add_heading('Temperature Sensor')
    # VRG_TempsensorData.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Meta Data')
    VRG_Macro_Data.MetaData_Enable_Plot(df, [die, temp], document, pltPath, showPlt)

    document.add_heading('SM_DTR_MEC vs. Imaging Mode')
    VRG_Safety_Data.SM_DTR_MEC(df, 'ImgMode', document, pltPath, showPlt)
    document.add_heading('SM_DTR_MEC SYS_CHECK vs. Imaging Mode')
    VRG_Safety_Data.SM_SYS_CHECK(df, 'ImgMode', document, pltPath, showPlt)

    document.add_heading('SM_DTR_MEC vs. Imaging Mode vs. ' + test)
    VRG_Safety_Data.SM_DTR_MEC(df, ['ImgMode', test], document, pltPath, showPlt)
    document.add_heading('SM_DTR_MEC SYS_CHECK vs. Imaging Mode')
    VRG_Safety_Data.SM_SYS_CHECK(df, ['ImgMode', test], document, pltPath, showPlt)

    document.add_heading('SM_DTR_MEC ' + test + " vs. " + asilStatus + ' vs. Imaging Mode')
    VRG_Register_Data.Reg_vs_Reg_Plot(df, 'ImgMode', document, pltPath, test, asilStatus, showPlt)

    df_t1 = df[[temp, 'ImgMode', test, asilStatus, reg1, reg2, reg3, reg4, reg5, reg6, reg7]]
    document.add_heading('SM_DTR_MEC Results Table')
    VRG_Doc.df_to_table(df_t1, document)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df['Clk'].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' SM_DTR_MEC vs. ' + test, level=2)
        VRG_Safety_Data.SM_DTR_MEC(df_img, test, document, pltPath, showPlt)
        document.add_heading(i + ' SM_DTR_MEC SYS_CHECK vs.' + test, level=2)
        VRG_Safety_Data.SM_SYS_CHECK(df_img, test, document, pltPath, showPlt)

        document.add_heading(i + ' SM_DTR_MEC ' + test + " vs. " + asilStatus)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, 'ImgMode', document, pltPath, test, asilStatus, showPlt)

        df_t2 = df_img[[temp, 'ImgMode', test, asilStatus, reg1, reg2, reg3, reg4, reg5, reg6, reg7]]
        document.add_heading(i + ' SM_DTR_MEC Results Table', level=2)
        VRG_Doc.df_to_table(df_t2, document)

def DV_12_0_94_SM_ATR_ECLIPSE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_0_95_SM_ATR_ADAPT(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_0_97_SM_ATR_OVERDRIVE_3T(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_0_98_SM_TBRS_RAM_ECC(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_0_99_SM_TBRS_LOCKED_CRC(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_0_100_SM_TBRS_PROCESSING(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_0_108_SM_LDO_BG_MONITOR(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    reg1 = 'RegWr00_MODE_SELECT'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.LightLevel_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # Primary Voltage, Power, and Current
    document.add_heading('Power & Current vs. Voltage Level')
    VRG_Power_Data.Supply_Voltage_Plot(df, [die, temp, 'Power'], document, pltPath, showPlt)
    VRG_Power_Data.Power_Consumption_Plot(df, [die, temp, 'Power'], document, pltPath, showPlt)
    VRG_Power_Data.Current_Consumption_Plot(df, [die, temp, 'Power'], document, pltPath, showPlt)

    document.add_heading('Reset Register vs. Test Step')
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, reg1, showPlt)

    document.add_heading('All SM Booster Monitor Data vs. Die vs. Temp vs. Power')
    VRG_Safety_Data.SM_AHM_BOOSTER_BANDGAP_MONITOR(df, [die, temp, 'Power'], document, pltPath, showPlt)
    document.add_heading('All SM Booster Monitor Name Data vs. Imaging Mode')
    VRG_Safety_Data.SM_AHM_BOOSTER_BANDGAP_MONITOR_NAMES(df, 'ImgMode', document, pltPath, showPlt)
    document.add_heading('All SM Booster Monitor Name Data vs. Imaging Mode vs. Power', level=2)
    VRG_Safety_Data.SM_AHM_BOOSTER_BANDGAP_MONITOR_NAMES(df, ['ImgMode', 'Power'], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' SM Booster Monitor Registers vs. Die vs. Temp', level=2)
        VRG_Safety_Data.SM_AHM_BOOSTER_BANDGAP_MONITOR(df_img, [die, temp], document, pltPath, showPlt)
        document.add_heading(i + ' SM Booster Monitor Names vs. Temp', level=2)
        VRG_Safety_Data.SM_AHM_BOOSTER_BANDGAP_MONITOR_NAMES(df_img, temp, document, pltPath, showPlt)
        document.add_heading(i + ' SM Booster Monitor Names vs. Power', level=2)
        VRG_Safety_Data.SM_AHM_BOOSTER_BANDGAP_MONITOR_NAMES(df_img, 'Power', document, pltPath, showPlt)
        document.add_heading(i + ' SM Booster Monitor Names vs. Time vs. Power', level=2)
        VRG_Safety_Data.SM_AHM_BOOSTER_BANDGAP_MONITOR_NAMES_vs_Time_Plot(df_img, None, None, document, pltPath, showPlt)

        # Primary Voltage, Power, and Current
        document.add_heading(i + ' Power & Current vs. Voltage Level', level=2)
        VRG_Power_Data.Supply_Voltage_Plot(df_img, [die, temp, 'Power'], document, pltPath, showPlt)
        VRG_Power_Data.Power_Consumption_Plot(df_img, [die, temp, 'Power'], document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, [die, temp, 'Power'], document, pltPath, showPlt)

def DV_12_0_109_SM_CHIP_SUPPLY_PMU_MONITOR(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    reg1 = 'RegWr00_MODE_SELECT'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.LightLevel_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # Primary Voltage, Power, and Current
    document.add_heading('Power & Current vs. Voltage Level')
    VRG_Power_Data.Supply_Voltage_Plot(df, [die, temp, 'Power'], document, pltPath, showPlt)
    VRG_Power_Data.Power_Consumption_Plot(df, [die, temp, 'Power'], document, pltPath, showPlt)
    VRG_Power_Data.Current_Consumption_Plot(df, [die, temp, 'Power'], document, pltPath, showPlt)

    document.add_heading('Reset Register vs. Test Step')
    VRG_Register_Data.Reg_vs_Step_Plot(df, die, document, pltPath, reg1, showPlt)

    document.add_heading('All SM Supply Voltage Monitor Data vs. Die vs. Temp vs. Power')
    VRG_Safety_Data.SM_CHIP_SUPPLY_VOLTAGE_MONITOR(df, [die, temp, 'Power'], document, pltPath, showPlt)
    document.add_heading('All SM Supply Voltage Monitor Name Data vs. Imaging Mode')
    VRG_Safety_Data.SM_CHIP_SUPPLY_VOLTAGE_MONITOR_NAMES(df, 'ImgMode', document, pltPath, showPlt)
    document.add_heading('All SM Supply Voltage Monitor Name Data vs. Imaging Mode vs. Power', level=2)
    VRG_Safety_Data.SM_CHIP_SUPPLY_VOLTAGE_MONITOR_NAMES(df, ['ImgMode', 'Power'], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' SM Supply Voltage Monitor Registers vs. Die vs. Temp', level=2)
        VRG_Safety_Data.SM_CHIP_SUPPLY_VOLTAGE_MONITOR(df_img, [die, temp], document, pltPath, showPlt)
        document.add_heading(i + ' SM Supply Voltage Monitor Names vs. Temp', level=2)
        VRG_Safety_Data.SM_CHIP_SUPPLY_VOLTAGE_MONITOR_NAMES(df_img, temp, document, pltPath, showPlt)
        document.add_heading(i + ' SM Supply Voltage Monitor Names vs. Power', level=2)
        VRG_Safety_Data.SM_CHIP_SUPPLY_VOLTAGE_MONITOR_NAMES(df_img, 'Power', document, pltPath, showPlt)
        document.add_heading(i + ' SM Supply Voltage Monitor Names vs. Time vs. Power', level=2)
        VRG_Safety_Data.SM_CHIP_SUPPLY_VOLTAGE_MONITOR_NAMES_vs_Time_Plot(df_img, None, None, document, pltPath, showPlt)

        # Primary Voltage, Power, and Current
        document.add_heading(i + ' Power & Current vs. Voltage Level', level=2)
        VRG_Power_Data.Supply_Voltage_Plot(df_img, [die, temp, 'Power'], document, pltPath, showPlt)
        VRG_Power_Data.Power_Consumption_Plot(df_img, [die, temp, 'Power'], document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, [die, temp, 'Power'], document, pltPath, showPlt)

def DV_12_0_110_SM_SENSOR_HISPI_TX_RX_CRC(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    ULcolor = '#ff0000'
    LLcolor = '#0000ff'
    test = 'RegWr01_DEFRAMER_FAULT_CTRL'
    test2 = 'RegWr02_DEFRAMER_CTRL2__CRC_ENABLE'
    asilCheck = 'DEFRAMER_FAULT_CTRL'
    asilCheck2 = 'DEFRAMER_CTRL2'
    asilStatus = 'ASIL_STATUS_03__DEFRAMER_FAULT'
    asilStatus2 = 'DEFRAMER_ERROR_STATUS__CRC_ERROR'
    sysCheck = 'SYS_CHECK'

    # VRG_General_Data Plots
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    # document.add_heading('Temperature Sensor')
    # VRG_TempsensorData.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Meta Data')
    VRG_Macro_Data.MetaData_Enable_Plot(df, [die, temp], document, pltPath, showPlt)

    document.add_heading('SM_SENSOR_HISPI_TX_RX_CRC Results vs. Imaging Mode')
    VRG_Safety_Data.SM_SENSOR_HISPI_TX_RX_CRC(df, 'ImgMode', document, pltPath, showPlt)
    document.add_heading('SM_SENSOR_HISPI_TX_RX_CRC SYS_CHECK vs. Imaging Mode')
    VRG_Safety_Data.SM_SYS_CHECK(df, 'ImgMode', document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df['Clk'].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' SM_SENSOR_HISPI_TX_RX_CRC Results vs. ' + asilCheck, level=2)
        VRG_Safety_Data.SM_SENSOR_HISPI_TX_RX_CRC(df_img, test, document, pltPath, showPlt)
        document.add_heading(i + ' SM_SENSOR_HISPI_TX_RX_CRC SYS_CHECK vs. ' + asilCheck, level=2)
        VRG_Safety_Data.SM_SYS_CHECK(df_img, test, document, pltPath, showPlt)

        document.add_heading(i + ' SM_SENSOR_HISPI_TX_RX_CRC ' + asilCheck + ' vs. ' + asilStatus, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, asilCheck, asilStatus, showPlt)
        document.add_heading(i + ' SM_SENSOR_HISPI_TX_RX_CRC ' + asilCheck + ' vs. ' + asilStatus2, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, asilCheck, asilStatus2, showPlt)

        document.add_heading(i + ' SM_SENSOR_HISPI_TX_RX_CRC ' + asilStatus + ' vs. ' + sysCheck, level=2)
        VRG_General_Data.Data_vs_Data_vs_Step_Plot(df_img, test, document, pltPath, asilStatus, sysCheck, showPlt)
        document.add_heading(i + ' SM_SENSOR_HISPI_TX_RX_CRC ' + asilStatus2 + ' vs. ' + sysCheck, level=2)
        VRG_General_Data.Data_vs_Data_vs_Step_Plot(df_img, test, document, pltPath, asilStatus2, sysCheck, showPlt)

        document.add_heading(i + ' SM_SENSOR_HISPI_TX_RX_CRC Image Means & StdDev vs. ' + asilCheck, level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, test, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, test, document, pltPath, showPlt)

        df_t1 = df_img[[temp, 'ImgMode', 'Power', asilCheck, asilCheck2, asilStatus, asilStatus2, sysCheck]]
        document.add_heading(i + ' SM_SENSOR_HISPI_TX_RX_CRC Results Table', level=2)
        VRG_Doc.df_to_table(df_t1, document)

def DV_12_0_111_SM_STATS_MON_EXT(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    ULcolor = '#ff0000'
    LLcolor = '#0000ff'

    document.add_heading('SM Clock Counting vs. Die')
    VRG_Safety_Data.SM_CLOCK_COUNTING(df, [die, temp, 'Clk'], document, pltPath, showPlt)

    df_t1 = df[[temp, die]]
    document.add_heading('SM_I2C_CRC Results Table', level=2)
    VRG_Doc.df_to_table(df_t1, document)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df['Clk'].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' SM Clock Counting vs. Die', level=2)
        VRG_Safety_Data.SM_CLOCK_COUNTING(df_img, [die, temp, 'Clk'], document, pltPath, showPlt)

        for tst in TEST:  # Test
            df_test = VRG_Data_Frame.newdataframe(df_img, 'Clk', tst)

            document.add_heading(i + ' SM_CLOCK_COUNTING vs. Clk = ' + str(tst), level=1)
            document.add_heading(i + ' SM_CLOCK_COUNTING vs. Time vs. Clk =' + str(tst), level=2)
            VRG_Safety_Data.SM_CLOCK_COUNTING_vs_Time_Plot(df_test, None, None, document, pltPath, showPlt,
                                                           ax_hlines=[(die, ULcolor, '--', 3, 1)])

def DV_12_0_112_SM_DATA_FORMAT(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    ULcolor = '#ff0000'
    LLcolor = '#0000ff'
    test = 'RegWr02_ASIL_CHECK_ENABLES_00__ASIL_CHECK_DATA_FORMAT_ENABLE'
    asilCheck = 'ASIL_CHECK_ENABLES_00__ASIL_CHECK_DATA_FORMAT_ENABLE'
    formatBits = 'DATA_FORMAT_BITS'
    formatActual = 'DATA_FORMAT_ACTUAL'
    asilStatus = 'ASIL_STATUS_00__ASIL_STATUS_DATA_FORMAT_ERROR'
    sysCheck = 'SYS_CHECK'
    formatTest = 'Macro5'

    # VRG_General_Data Plots
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    # document.add_heading('Temperature Sensor')
    # VRG_TempsensorData.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Meta Data')
    VRG_Macro_Data.MetaData_Enable_Plot(df, [die, temp], document, pltPath, showPlt)

    document.add_heading('SM_DATA_FORMAT Results vs. Imaging Mode')
    VRG_Safety_Data.SM_DATA_FORMAT(df, 'ImgMode', document, pltPath, showPlt)
    document.add_heading('SM_DATA_FORMAT SYS_CHECK vs. Imaging Mode')
    VRG_Safety_Data.SM_SYS_CHECK(df, 'ImgMode', document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df['Clk'].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' SM_DATA_FORMAT Results vs. ' + asilCheck, level=2)
        VRG_Safety_Data.SM_DATA_FORMAT(df_img, test, document, pltPath, showPlt)
        document.add_heading(i + ' SM_DATA_FORMAT SYS_CHECK vs. ' + asilCheck, level=2)
        VRG_Safety_Data.SM_SYS_CHECK(df_img, test, document, pltPath, showPlt)

        document.add_heading(i + ' SM_DATA_FORMAT ' + formatBits + ' vs. ' + formatActual, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, formatBits, formatActual, showPlt)
        document.add_heading(i + ' SM_DATA_FORMAT ' + asilCheck + ' vs. ' + asilStatus, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, formatTest, document, pltPath, asilCheck, asilStatus, showPlt)
        document.add_heading(i + ' SM_DATA_FORMAT ' + asilStatus + ' vs. ' + sysCheck, level=2)
        VRG_General_Data.Data_vs_Data_vs_Step_Plot(df_img, formatTest, document, pltPath, asilStatus, sysCheck, showPlt)

        df_t1 = df_img[[temp, 'ImgMode', formatTest, asilCheck, formatBits, formatActual, asilStatus, sysCheck]]
        document.add_heading(i + ' SM_DATA_FORMAT Results Table', level=2)
        VRG_Doc.df_to_table(df_t1, document)

def DV_12_0_113_SM_SENSOR_DATAPATH_BUFFER_CRC(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    ULcolor = '#ff0000'
    LLcolor = '#0000ff'
    test = 'RegWr00_FOR_CRC_FAULT_CONTROL'
    asilCheck = 'FOR_CRC_FAULT_CONTROL'
    faultFrm = 'FOR_CRC_FAULT_FRAMES'
    faultPerFrm = 'FOT_CRC_FAULTS_PER_FRAME'
    sysCheck = 'SYS_CHECK'

    # VRG_General_Data Plots
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    # document.add_heading('Temperature Sensor')
    # VRG_TempsensorData.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Meta Data')
    VRG_Macro_Data.MetaData_Enable_Plot(df, [die, temp], document, pltPath, showPlt)

    document.add_heading('SM_SENSOR_DATAPATH_BUFFER_CRC Results vs. Imaging Mode')
    VRG_Safety_Data.SM_SENSOR_DATAPATH_BUFFER_CRC(df, 'ImgMode', document, pltPath, showPlt)
    document.add_heading('SM_SENSOR_DATAPATH_BUFFER_CRC SYS_CHECK vs. Imaging Mode')
    VRG_Safety_Data.SM_SYS_CHECK(df, 'ImgMode', document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df['Clk'].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' SM_SENSOR_DATAPATH_BUFFER_CRC Results vs. ' + asilCheck, level=2)
        VRG_Safety_Data.SM_SENSOR_DATAPATH_BUFFER_CRC(df_img, test, document, pltPath, showPlt)
        document.add_heading(i + ' SM_SENSOR_DATAPATH_BUFFER_CRC SYS_CHECK vs. ' + asilCheck, level=2)
        VRG_Safety_Data.SM_SYS_CHECK(df_img, test, document, pltPath, showPlt)

        document.add_heading(i + ' SM_SENSOR_DATAPATH_BUFFER_CRC ' + asilCheck + ' vs. ' + faultFrm, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, asilCheck, faultFrm, showPlt)
        document.add_heading(i + ' SM_SENSOR_DATAPATH_BUFFER_CRC ' + asilCheck + ' vs. ' + faultPerFrm, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, asilCheck, faultPerFrm, showPlt)
        document.add_heading(i + ' SM_SENSOR_DATAPATH_BUFFER_CRC ' + asilCheck + ' vs. ' + sysCheck, level=2)
        VRG_General_Data.Data_vs_Data_vs_Step_Plot(df_img, None, document, pltPath, asilCheck, sysCheck, showPlt)

        document.add_heading(i + ' SM_SENSOR_DATAPATH_BUFFER_CRC FrameCount vs. ' + faultFrm + ' vs. ' + asilCheck,
                             level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, test, document, pltPath, 'FrameCount', faultFrm, showPlt)

        document.add_heading(i + ' SM_SENSOR_DATAPATH_BUFFER_CRC Image Means & StdDev vs. ' + asilCheck, level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, test, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, test, document, pltPath, showPlt)

        df_t1 = df_img[[temp, 'ImgMode', 'Power', asilCheck, faultFrm, faultPerFrm, sysCheck]]
        document.add_heading(i + ' SM_SENSOR_DATAPATH_BUFFER_CRC Results Table', level=2)
        VRG_Doc.df_to_table(df_t1, document)

def DV_12_0_114_SM_ASIC_DATAPATH_BUFFER_CRC(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    ULcolor = '#ff0000'
    LLcolor = '#0000ff'
    test = 'RegWr00_FOR_CRC_FAULT_CONTROL'
    asilCheck = 'FOR_CRC_FAULT_CONTROL'
    faultFrm = 'FOR_ASIC_CRC_FAULT_FRAMES'
    faultPerFrm = 'FOT_ASIC_CRC_FAULTS_PER_FRAME'
    sysCheck = 'SYS_CHECK'

    # VRG_General_Data Plots
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    # document.add_heading('Temperature Sensor')
    # VRG_TempsensorData.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Meta Data')
    VRG_Macro_Data.MetaData_Enable_Plot(df, [die, temp], document, pltPath, showPlt)

    document.add_heading('SM_ASIC_DATAPATH_BUFFER_CRC Results vs. Imaging Mode')
    VRG_Safety_Data.SM_ASIC_DATAPATH_BUFFER_CRC(df, 'ImgMode', document, pltPath, showPlt)
    document.add_heading('SM_ASIC_DATAPATH_BUFFER_CRC SYS_CHECK vs. Imaging Mode')
    VRG_Safety_Data.SM_SYS_CHECK(df, 'ImgMode', document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df['Clk'].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' SM_ASIC_DATAPATH_BUFFER_CRC Results vs. ' + asilCheck, level=2)
        VRG_Safety_Data.SM_ASIC_DATAPATH_BUFFER_CRC(df_img, test, document, pltPath, showPlt)
        document.add_heading(i + ' SM_ASIC_DATAPATH_BUFFER_CRC SYS_CHECK vs. ' + asilCheck, level=2)
        VRG_Safety_Data.SM_SYS_CHECK(df_img, test, document, pltPath, showPlt)

        document.add_heading(i + ' SM_ASIC_DATAPATH_BUFFER_CRC ' + asilCheck + ' vs. ' + faultFrm, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, asilCheck, faultFrm, showPlt)
        document.add_heading(i + ' SM_ASIC_DATAPATH_BUFFER_CRC ' + asilCheck + ' vs. ' + faultPerFrm, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, asilCheck, faultPerFrm, showPlt)
        document.add_heading(i + ' SM_ASIC_DATAPATH_BUFFER_CRC ' + asilCheck + ' vs. ' + sysCheck, level=2)
        VRG_General_Data.Data_vs_Data_vs_Step_Plot(df_img, None, document, pltPath, asilCheck, sysCheck, showPlt)

        document.add_heading(i + ' SM_ASIC_DATAPATH_BUFFER_CRC FrameCount vs. ' + faultFrm + ' vs. ' + asilCheck,
                             level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, test, document, pltPath, 'FrameCount', faultFrm, showPlt)

        document.add_heading(i + ' SM_ASIC_DATAPATH_BUFFER_CRC Image Means & StdDev vs. ' + asilCheck, level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, test, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, test, document, pltPath, showPlt)

        df_t1 = df_img[[temp, 'ImgMode', 'Power', asilCheck, faultFrm, faultPerFrm, sysCheck]]
        document.add_heading(i + ' SM_ASIC_DATAPATH_BUFFER_CRC Results Table', level=2)
        VRG_Doc.df_to_table(df_t1, document)

def DV_12_0_120_SM_BIN2_RAM_CRC(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    ULcolor = '#ff0000'
    LLcolor = '#0000ff'
    test = 'RegWr01_ODP_SKIP_BIN_CRC_FAULT_CONTROL'
    test2 = 'Macro5'
    asilCheck = 'ODP_SKIP_BIN_CRC_FAULT_CONTROL'
    faultFrm = 'ODP_SKIP_BIN_CRC_FAULT_FRAMES'
    faultPerFrm = 'ODP_SKIP_BIN_CRC_FAULTS_PER_FRAME'
    asilStatus = 'ASIL_STATUS_03__ODP_SKIP_BIN_MEM_CRC_FAULT'
    sysCheck = 'SYS_CHECK'

    # VRG_General_Data Plots
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Meta Data')
    VRG_Macro_Data.MetaData_Enable_Plot(df, [die, temp], document, pltPath, showPlt)

    document.add_heading('SM_BIN2_RAM_CRC Results vs. Imaging Mode')
    VRG_Safety_Data.SM_BIN2_RAM_CRC(df, 'ImgMode', document, pltPath, showPlt)
    document.add_heading('SM_BIN2_RAM_CRC SYS_CHECK vs. Imaging Mode')
    VRG_Safety_Data.SM_SYS_CHECK(df, 'ImgMode', document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[test2].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' SM_BIN2_RAM_CRC Results vs. ' + asilCheck, level=2)
        VRG_Safety_Data.SM_BIN2_RAM_CRC(df_img, test, document, pltPath, showPlt)
        document.add_heading(i + ' SM_BIN2_RAM_CRC SYS_CHECK vs. ' + asilCheck, level=2)
        VRG_Safety_Data.SM_SYS_CHECK(df_img, test, document, pltPath, showPlt)

        document.add_heading(i + ' SM_BIN2_RAM_CRC ' + asilCheck + ' vs. ' + faultFrm, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, asilCheck, faultFrm, showPlt)
        document.add_heading(i + ' SM_BIN2_RAM_CRC ' + asilCheck + ' vs. ' + faultPerFrm, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, asilCheck, faultPerFrm, showPlt)
        document.add_heading(i + ' SM_BIN2_RAM_CRC ' + asilCheck + ' vs. ' + asilStatus, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, asilCheck, asilStatus, showPlt)
        document.add_heading(i + ' SM_BIN2_RAM_CRC ' + asilStatus + ' vs. ' + sysCheck, level=2)
        VRG_General_Data.Data_vs_Data_vs_Step_Plot(df_img, test, document, pltPath, asilStatus, sysCheck, showPlt)

        document.add_heading(i + ' SM_BIN2_RAM_CRC FrameCount vs. ' + faultFrm + ' vs. ' + asilCheck, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, test, document, pltPath, 'FrameCount', faultFrm, showPlt)

        document.add_heading(i + ' SM_BIN2_RAM_CRC Image Means & StdDev vs. ' + asilCheck, level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, test, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, test, document, pltPath, showPlt)

        df_t1 = df_img[[temp, 'ImgMode', 'Power', asilCheck, faultFrm, faultPerFrm, asilStatus, sysCheck]]
        document.add_heading(i + ' SM_BIN2_RAM_CRC Results Table', level=2)
        VRG_Doc.df_to_table(df_t1, document)

        for tst in TEST:  # Test
            df_test = VRG_Data_Frame.newdataframe(df_img, test2, tst)
            document.add_heading(i + ' SM_BIN2_RAM_CRC vs. Test Settings = ' + str(tst), level=1)
            document.add_heading(i + ' SM_BIN2_RAM_CRC vs. Test Settings = ' + str(tst) + ' vs. ' + asilCheck, level=2)
            VRG_Safety_Data.SM_BIN2_RAM_CRC(df_test, test, document, pltPath, showPlt)
            document.add_heading(i + ' SM_BIN2_RAM_CRC SYS_CHECK vs. Test Settings = ' + str(tst) + ' vs. ' + asilCheck,
                                 level=2)
            VRG_Safety_Data.SM_SYS_CHECK(df_test, test, document, pltPath, showPlt)

def DV_12_0_121_SM_24_TO_16_BUFFER_CRC(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    ULcolor = '#ff0000'
    LLcolor = '#0000ff'
    test = 'RegWr00_CONV_CRC_FAULT_CONTROL'
    asilCheck = 'CONV_CRC_FAULT_CONTROL'
    faultFrm = 'CONV_CRC_FAULT_FRAMES'
    faultPerFrm = 'CONV_CRC_FAULTS_PER_FRAME'
    asilStatus = 'ASIL_STATUS_03__CONV_MEMORY_CRC_FAULT'
    sysCheck = 'SYS_CHECK'

    # VRG_General_Data Plots
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    # document.add_heading('Temperature Sensor')
    # VRG_TempsensorData.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Meta Data')
    VRG_Macro_Data.MetaData_Enable_Plot(df, [die, temp], document, pltPath, showPlt)

    document.add_heading('SM_24_TO_16_BUFFER_CRC Results vs. Imaging Mode')
    VRG_Safety_Data.SM_24_TO_16_BUFFER_CRC(df, 'ImgMode', document, pltPath, showPlt)
    document.add_heading('SM_24_TO_16_BUFFER_CRC SYS_CHECK vs. Imaging Mode')
    VRG_Safety_Data.SM_SYS_CHECK(df, 'ImgMode', document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df['Clk'].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' SM_24_TO_16_BUFFER_CRC Results vs. ' + asilCheck, level=2)
        VRG_Safety_Data.SM_24_TO_16_BUFFER_CRC(df_img, test, document, pltPath, showPlt)
        document.add_heading(i + ' SM_24_TO_16_BUFFER_CRC SYS_CHECK vs. ' + asilCheck, level=2)
        VRG_Safety_Data.SM_SYS_CHECK(df_img, test, document, pltPath, showPlt)

        document.add_heading(i + ' SM_24_TO_16_BUFFER_CRC ' + asilCheck + ' vs. ' + faultFrm, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, asilCheck, faultFrm, showPlt)
        document.add_heading(i + ' SM_24_TO_16_BUFFER_CRC ' + asilCheck + ' vs. ' + faultPerFrm, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, asilCheck, faultPerFrm, showPlt)
        document.add_heading(i + ' SM_24_TO_16_BUFFER_CRC ' + asilCheck + ' vs. ' + asilStatus, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, asilCheck, asilStatus, showPlt)
        document.add_heading(i + ' SM_24_TO_16_BUFFER_CRC ' + asilStatus + ' vs. ' + sysCheck, level=2)
        VRG_General_Data.Data_vs_Data_vs_Step_Plot(df_img, test, document, pltPath, asilStatus, sysCheck, showPlt)

        document.add_heading(i + ' SM_24_TO_16_BUFFER_CRC FrameCount vs. ' + faultFrm + ' vs. ' + asilCheck, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, test, document, pltPath, 'FrameCount', faultFrm, showPlt)

        document.add_heading(i + ' SM_24_TO_16_BUFFER_CRC Image Means & StdDev vs. ' + asilCheck, level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, test, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, test, document, pltPath, showPlt)

        df_t1 = df_img[[temp, 'ImgMode', 'Power', asilCheck, faultFrm, faultPerFrm, asilStatus, sysCheck]]
        document.add_heading(i + ' SM_24_TO_16_BUFFER_CRC Results Table', level=2)
        VRG_Doc.df_to_table(df_t1, document)

def DV_12_0_122_SM_ECC_TPG_RAM(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    ULcolor = '#ff0000'
    LLcolor = '#0000ff'
    test = 'RegWr00_ASIL_CHECK_ENABLES_02'
    asilCheck = 'ASIL_CHECK_ENABLES_02'
    asilStatus = 'ASIL_STATUS_02'
    asilStatus1 = 'ASIL_STATUS_02__TPG_RAM_ECC_SEC'
    asilStatus2 = 'ASIL_STATUS_02__TPG_RAM_ECC_DED'
    sysCheck = 'SYS_CHECK'
    metaData = 'DVM_Meta_Data'

    # VRG_General_Data Plots
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    # document.add_heading('Temperature Sensor')
    # VRG_TempsensorData.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Meta Data')
    VRG_Macro_Data.MetaData_Enable_Plot(df, [die, temp], document, pltPath, showPlt)

    document.add_heading('SM_ECC_TPG_RAM Results vs. Imaging Mode')
    VRG_Safety_Data.SM_ECC_TPG_RAM(df, 'ImgMode', document, pltPath, showPlt)
    document.add_heading('SM_ECC_TPG_RAM SYS_CHECK vs. Imaging Mode')
    VRG_Safety_Data.SM_SYS_CHECK(df, 'ImgMode', document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[test].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' SM_ECC_TPG_RAM Results vs. ' + asilCheck, level=2)
        VRG_Safety_Data.SM_ECC_TPG_RAM(df_img, test, document, pltPath, showPlt)
        document.add_heading(i + ' SM_ECC_TPG_RAM SYS_CHECK vs. ' + asilCheck, level=2)
        VRG_Safety_Data.SM_SYS_CHECK(df_img, test, document, pltPath, showPlt)

        document.add_heading(i + ' SM_ECC_TPG_RAM ' + asilCheck + ' vs. ' + asilStatus, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, asilCheck, asilStatus, showPlt)
        document.add_heading(i + ' SM_ECC_TPG_RAM ' + asilCheck + ' vs. ' + asilStatus1, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, asilCheck, asilStatus1, showPlt)
        document.add_heading(i + ' SM_ECC_TPG_RAM ' + asilCheck + ' vs. ' + asilStatus2, level=2)
        VRG_Register_Data.Reg_vs_Reg_Plot(df_img, None, document, pltPath, asilCheck, asilStatus2, showPlt)
        document.add_heading(i + ' SM_ECC_TPG_RAM ' + asilStatus + ' vs. ' + sysCheck, level=2)
        VRG_General_Data.Data_vs_Data_vs_Step_Plot(df_img, None, document, pltPath, asilStatus, sysCheck, showPlt)

        df_t1 = df_img[[temp, 'ImgMode', 'Power', asilCheck, asilStatus, asilStatus1, asilStatus2, sysCheck]]
        document.add_heading(i + ' SM_ECC_TPG_RAM Results Table', level=2)
        VRG_Doc.df_to_table(df_t1, document)

def DV_12_0_177_SM_PDI_RAM_DED(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_1_00_SM_UPLOAD_CALIBRATION(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_1_00_SM_RUNTIME_CALIBRATION(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die'

def DV_12_1_00_SM_FAULT_CALIBRATION(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_1_00_SM_UPLOAD_PRE_CALIBRATION(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

    document.add_heading('ASIL STARTUP vs. Power')
    VRG_Safety_Data.SM_Startup_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('ASIL STARTUP Expanded vs. Power')
    VRG_Safety_Data.SM_Startup_Expanded_Plot(df, 'Power', document, pltPath, showPlt)

    document.add_heading('ASIL STARTUP vs. Temperature')
    VRG_Safety_Data.SM_Startup_Plot(df, temp, document, pltPath, showPlt)
    document.add_heading('ASIL STARTUP Expanded vs. Temperature')
    VRG_Safety_Data.SM_Startup_Expanded_Plot(df, temp, document, pltPath, showPlt)

    document.add_heading('ASIL STARTUP vs. Die')
    VRG_Safety_Data.SM_Startup_Plot(df, die, document, pltPath, showPlt)
    document.add_heading('ASIL STARTUP Expanded vs. Die')
    VRG_Safety_Data.SM_Startup_Expanded_Plot(df, die, document, pltPath, showPlt)

def DV_12_1_00_SM_UPLOAD_FAULT_PRE_CALIBRATION(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

    document.add_heading('ASIL STARTUP Fault Inject vs. Power')
    VRG_Safety_Data.SM_Startup_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('ASIL STARTUP Fault Inject Expanded vs. Power')
    VRG_Safety_Data.SM_Startup_Expanded_Plot(df, 'Power', document, pltPath, showPlt)

    document.add_heading('ASIL STARTUP Fault Inject vs. Temperature')
    VRG_Safety_Data.SM_Startup_Plot(df, temp, document, pltPath, showPlt)
    document.add_heading('ASIL STARTUP Fault Inject Expanded vs. Temperature')
    VRG_Safety_Data.SM_Startup_Expanded_Plot(df, temp, document, pltPath, showPlt)

    document.add_heading('ASIL STARTUP Fault Inject vs. Die')
    VRG_Safety_Data.SM_Startup_Plot(df, die, document, pltPath, showPlt)
    document.add_heading('ASIL STARTUP Fault Inject Expanded vs. Die')
    VRG_Safety_Data.SM_Startup_Expanded_Plot(df, die, document, pltPath, showPlt)

def DV_12_1_00_SM_UPLOAD(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

    document.add_heading('ASIL STARTUP vs. Power')
    VRG_Safety_Data.SM_Startup_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('ASIL STARTUP Expanded vs. Power')
    VRG_Safety_Data.SM_Startup_Expanded_Plot(df, 'Power', document, pltPath, showPlt)

    document.add_heading('ASIL STARTUP vs. Temperature')
    VRG_Safety_Data.SM_Startup_Plot(df, temp, document, pltPath, showPlt)
    document.add_heading('ASIL STARTUP Expanded vs. Temperature')
    VRG_Safety_Data.SM_Startup_Expanded_Plot(df, temp, document, pltPath, showPlt)

    document.add_heading('ASIL STARTUP vs. Die')
    VRG_Safety_Data.SM_Startup_Plot(df, die, document, pltPath, showPlt)
    document.add_heading('ASIL STARTUP Expanded vs. Die')
    VRG_Safety_Data.SM_Startup_Expanded_Plot(df, die, document, pltPath, showPlt)

def DV_12_1_00_SM_UPLOAD_FAULT(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

    document.add_heading('ASIL STARTUP Fault Inject vs. Power')
    VRG_Safety_Data.SM_Startup_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('ASIL STARTUP Fault Inject Expanded vs. Power')
    VRG_Safety_Data.SM_Startup_Expanded_Plot(df, 'Power', document, pltPath, showPlt)

    document.add_heading('ASIL STARTUP Fault Inject vs. Temperature')
    VRG_Safety_Data.SM_Startup_Plot(df, temp, document, pltPath, showPlt)
    document.add_heading('ASIL STARTUP Fault Inject Expanded vs. Temperature')
    VRG_Safety_Data.SM_Startup_Expanded_Plot(df, temp, document, pltPath, showPlt)

    document.add_heading('ASIL STARTUP Fault Inject vs. Die')
    VRG_Safety_Data.SM_Startup_Plot(df, die, document, pltPath, showPlt)
    document.add_heading('ASIL STARTUP Fault Inject Expanded vs. Die')
    VRG_Safety_Data.SM_Startup_Expanded_Plot(df, die, document, pltPath, showPlt)

def DV_12_1_00_SM_UPLOAD_RUNTIME(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

    # VRG_General_Data Plots
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)

    document.add_heading('ASIL STARTUP vs. Imaging Mode')
    VRG_Safety_Data.SM_Startup_Plot(df, 'ImgMode', document, pltPath, showPlt)
    document.add_heading('ASIL STARTUP Expanded vs. Imaging Mode')
    VRG_Safety_Data.SM_Startup_Expanded_Plot(df, 'ImgMode', document, pltPath, showPlt)

    document.add_heading('ASIL STARTUP vs. Power')
    VRG_Safety_Data.SM_Startup_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('ASIL STARTUP Expanded vs. Power')
    VRG_Safety_Data.SM_Startup_Expanded_Plot(df, 'Power', document, pltPath, showPlt)

    document.add_heading('ASIL STARTUP vs. Temperature')
    VRG_Safety_Data.SM_Startup_Plot(df, temp, document, pltPath, showPlt)
    document.add_heading('ASIL STARTUP Expanded vs. Temperature')
    VRG_Safety_Data.SM_Startup_Expanded_Plot(df, temp, document, pltPath, showPlt)

    document.add_heading('ASIL STARTUP vs. Die')
    VRG_Safety_Data.SM_Startup_Plot(df, die, document, pltPath, showPlt)
    document.add_heading('ASIL STARTUP Expanded vs. Die')
    VRG_Safety_Data.SM_Startup_Expanded_Plot(df, die, document, pltPath, showPlt)

    document.add_heading('ASIL STARTUP RUNTIME vs. Imaging Mode')
    VRG_Safety_Data.SM_Startup_Runtime_Plot(df, 'ImgMode', document, pltPath, showPlt)
    document.add_heading('ASIL STARTUP RUNTIME Expanded vs. Die')
    VRG_Safety_Data.SM_Startup_Runtime_Expanded_Plot(df, 'ImgMode', document, pltPath, showPlt)

    document.add_heading('ASIL STARTUP RUNTIME vs. Die')
    VRG_Safety_Data.SM_Startup_Runtime_Plot(df, die, document, pltPath, showPlt)
    document.add_heading('ASIL STARTUP RUNTIME Expanded vs. Die')
    VRG_Safety_Data.SM_Startup_Runtime_Expanded_Plot(df, die, document, pltPath, showPlt)

    document.add_heading('ASIL STARTUP vs. STARTUP RUNTIME vs. Imaging Mode')
    VRG_Safety_Data.SM_Startup_vs_Startup_Runtime_Plot(df, 'ImgMode', document, pltPath, showPlt)

    document.add_heading('ASIL STARTUP vs. STARTUP RUNTIME vs. Imaging Mode vs. Die')
    VRG_Safety_Data.SM_Startup_vs_Startup_Runtime_Plot(df, ['ImgMode', die], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' ASIL STARTUP', level=2)

        document.add_heading(i + ' ASIL STARTUP vs. Die', level=2)
        VRG_Safety_Data.SM_Startup_Plot(df_img, die, document, pltPath, showPlt)
        document.add_heading(i + ' ASIL STARTUP Expanded vs. Die', level=2)
        VRG_Safety_Data.SM_Startup_Expanded_Plot(df_img, die, document, pltPath, showPlt)

        document.add_heading(i + ' ASIL STARTUP RUNTIME vs. Die', level=2)
        VRG_Safety_Data.SM_Startup_Runtime_Plot(df_img, die, document, pltPath, showPlt)
        document.add_heading(i + ' ASIL STARTUP RUNTIME Expanded vs. Die', level=2)
        VRG_Safety_Data.SM_Startup_Runtime_Expanded_Plot(df_img, die, document, pltPath, showPlt)

        document.add_heading(i + ' ASIL STARTUP vs. STARTUP RUNTIME vs. Die', level=2)
        VRG_Safety_Data.SM_Startup_vs_Startup_Runtime_Plot(df_img, die, document, pltPath, showPlt)

def DV_12_1_00_SM_TEST_FRAME(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_1_00_SM_TEST_FRAME_FAULT(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_1_00_SM_RESTORE_TEST_FRAME(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_1_00_SM_FAULT(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_1_00_SM_RESTORE_FAULT(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_12_1_00_SM_RUNTIME(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

    # VRG_General_Data Plots
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    # Primary Voltage, Power, and Current
    document.add_heading('Power & Current vs. Voltage Level')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    VRG_Power_Data.Power_Consumption_Plot(df, 'Power', document, pltPath, showPlt)
    VRG_Power_Data.Current_Consumption_Plot(df, 'Power', document, pltPath, showPlt)

    document.add_heading('All ASIL Runtime Data')
    VRG_Safety_Data.SM_Runtime_Plot(df, 'ImgMode', document, pltPath, showPlt)

    # document.add_heading('All ATR Test Data')
    # VRG_AsilData.SM_Analog_Test_Rows_Plot(df, None, document, pltPath, showPlt)
    # VRG_AsilData.SM_Analog_Test_Rows_Expanded_Plot(df, None, document, pltPath, showPlt)
    #
    # document.add_heading('All DTR CRC Values')
    # VRG_AsilData.SM_Digital_Test_Rows_Plot(df, None, document, pltPath, showPlt)
    # VRG_AsilData.SM_Digital_Test_Rows_Expanded_Plot(df, None, document, pltPath, showPlt)
    #
    # document.add_heading('All RRC CRC Values')
    # # VRG_AsilData.SM_Row_Rom_Address_Columns_Plot(df, None, document, pltPath, showPlt)
    # VRG_General_Data.Data_vs_Step_Plot(df, None, document, pltPath, 'RRC_ADDR_CRC', showPlt)
    #
    # document.add_heading('All ASIL Safe State Data')
    # VRG_AsilData.SM_Safe_State(df, None, document, pltPath, showPlt)
    # VRG_AsilData.SM_Safe_State_Current_Consumption_Plot(df, None, document, pltPath, showPlt)
    # VRG_AsilData.SM_Safe_State_Power_Consumption_Plot(df, None, document, pltPath, showPlt)
    #
    # document.add_heading('Active Array Image Stats')
    # VRG_Stats_Frame.Rgn_Mean_Plot(df, None, document, pltPath, showPlt)
    # VRG_Stats_Frame.Rgn_StdDev_Plot(df, None, document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' ASIL Runtime Data', level=2)
        VRG_Safety_Data.SM_Runtime_Plot(df_img, None, document, pltPath, showPlt)
        document.add_heading(i + ' ASIL Runtime Data vs. Power', level=2)
        VRG_Safety_Data.SM_Runtime_Plot(df_img, 'Power', document, pltPath, showPlt)

        # document.add_heading(i + ' ATR Test Data', level=2)
        # VRG_AsilData.SM_Analog_Test_Rows_Plot(df_img, None, document, pltPath, showPlt)
        document.add_heading(i + ' ATR Test Data vs. Power', level=2)
        VRG_Safety_Data.SM_Analog_Test_Rows_Expanded_Plot(df_img, 'Power', document, pltPath, showPlt)

        # document.add_heading(i + ' DTR CRC Values', level=2)
        # VRG_AsilData.SM_Digital_Test_Rows_Plot(df_img, None, document, pltPath, showPlt)
        document.add_heading(i + ' DTR CRC Values vs. Power', level=2)
        VRG_Safety_Data.SM_Digital_Test_Rows_Expanded_Plot(df_img, 'Power', document, pltPath, showPlt)

        # document.add_heading(i + ' RRC CRC Values', level=2)
        # VRG_AsilData.SM_Row_Rom_Address_Columns_Plot(df_img, None, document, pltPath, showPlt)
        document.add_heading(i + ' RRC CRC Values vs. Power', level=2)
        VRG_Safety_Data.SM_Row_Rom_Address_Columns_Expanded_Plot(df_img, 'Power', document, pltPath, showPlt)

        document.add_heading(i + ' RRC LDO SIC Values vs. Power', level=2)
        VRG_Safety_Data.SM_Row_Rom_SIC_Expanded_Plot(df_img, 'Power', document, pltPath, showPlt)

        VRG_Image_Utils.Image_Crop(df_img, 2, document, 34, 0, 64, 20, showPlt)  # RRC start
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 1504, 0, 1536, 20, showPlt)  # RRC mid
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 3100, 0, 3130, 20, showPlt)  # RRC end
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 4, 32, 12, 80, showPlt)  # DTR start
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 4, 2000, 12, 2048, showPlt)  # DTR mid
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 4, 4088, 12, 4136, showPlt)  # DTR end
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 3140, 32, 3160, 80, showPlt)  # ATR start
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 3140, 2000, 3160, 2048, showPlt)  # ATR mid
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 3140, 4088, 3160, 4136, showPlt)  # ATR end

        document.add_heading(i + ' ASIL Safe State', level=2)
        VRG_Safety_Data.SM_Safe_State(df_img, None, document, pltPath, showPlt)
        VRG_Safety_Data.SM_Safe_State_Current_Consumption_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Safety_Data.SM_Safe_State_Power_Consumption_Plot(df_img, None, document, pltPath, showPlt)
        document.add_heading(i + ' ASIL Safe State vs. Power', level=2)
        VRG_Safety_Data.SM_Safe_State(df_img, None, document, pltPath, showPlt)
        VRG_Safety_Data.SM_Safe_State_Current_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Safety_Data.SM_Safe_State_Power_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)

        document.add_heading(i + ' Image Stats Active Array', level=2)
        VRG_Stats_Frame.Rgn_Mean_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_StdDev_Plot(df_img, None, document, pltPath, showPlt)

        # Primary Voltage, Power, and Current
        document.add_heading(i + ' Power & Current vs. Voltage Level')
        VRG_Power_Data.Supply_Voltage_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.Power_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)

def DV_12_1_00_SM_SAFE_STATE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

    document.add_heading('All ASIL Safe State Data')
    VRG_Safety_Data.SM_Safe_State(df, None, document, pltPath, showPlt)
    VRG_Safety_Data.SM_Safe_State_Current_Consumption_Plot(df, None, document, pltPath, showPlt)
    VRG_Safety_Data.SM_Safe_State_Power_Consumption_Plot(df, None, document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i + ' ASIL Safe State', level=2)
        VRG_Safety_Data.SM_Safe_State(df_img, None, document, pltPath, showPlt)
        VRG_Safety_Data.SM_Safe_State_Current_Consumption_Plot(df_img, None, document, pltPath, showPlt)
        VRG_Safety_Data.SM_Safe_State_Power_Consumption_Plot(df_img, None, document, pltPath, showPlt)

def DV_12_1_00_SM_SEQUENCE(df, document, imgPath, pltPath):
    showPlt = True  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'
    die = 'Die'

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        # ImgMode 1
        document.add_heading(i, level=1)

def DV_12_SM_FAULT_INJECT_ATR(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    faultInj = 'DAC_LD_34_35'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.LightLevel_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    document.add_heading('SM_ATR Fault Injection Registers vs. Imaging Mode')
    VRG_Safety_Data.SM_ATR_FAULT_INJECTION(df, 'ImgMode', document, pltPath, showPlt)

    document.add_heading('SM_ATR Image Data vs. Imaging Mode')
    VRG_Safety_Data.SM_Analog_Test_Rows_Expanded_Plot(df, 'ImgMode', document, pltPath, showPlt)

    document.add_heading('SM_ATR Self-Test Register Data vs. Imaging Mode')
    VRG_Safety_Data.SM_ATR(df, 'ImgMode', document, pltPath, showPlt)

    document.add_heading('SM_ATR SYS_CHECK vs. Imaging Mode')
    VRG_Safety_Data.SM_SYS_CHECK(df, 'ImgMode', document, pltPath, showPlt)

    document.add_heading('SM_ATR Test Data vs. Thresholds vs. Imaging Mode vs. Fault Injection (' + faultInj + ')')
    VRG_Safety_Data.SM_Analog_Test_Rows_vs_Thresholds_Plot(df, ['ImgMode', faultInj], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' SM_ATR Fault Injection Registers', level=2)
        VRG_Safety_Data.SM_ATR_FAULT_INJECTION(df_img, 'ImgMode', document, pltPath, showPlt)

        document.add_heading(i + ' SM_ATR Test Data vs. Fault Injection (' + faultInj + ')', level=2)
        VRG_Safety_Data.SM_Analog_Test_Rows_Plot(df_img, faultInj, document, pltPath, showPlt)
        VRG_Safety_Data.SM_Analog_Test_Rows_Expanded_Plot(df_img, faultInj, document, pltPath, showPlt)

        document.add_heading(i + ' SM_ATR Self-Test Register Data vs. Fault Injection (' + faultInj + ')', level=2)
        VRG_Safety_Data.SM_ATR(df_img, faultInj, document, pltPath, showPlt)
        document.add_heading(i + ' SM_ATR SYS_CHECK vs. Fault Injection (' + faultInj + ')', level=2)
        VRG_Safety_Data.SM_SYS_CHECK(df_img, faultInj, document, pltPath, showPlt)

        document.add_heading(i + ' SM_ATR Test Data vs. Thresholds vs. Fault Injection (' + faultInj + ')', level=2)
        VRG_Safety_Data.SM_Analog_Test_Rows_vs_Thresholds_Plot(df_img, faultInj, document, pltPath, showPlt)

        document.add_heading(i + ' Power & Current vs. Voltage Level vs. Fault Injection (' + faultInj + ')', level=2)
        VRG_Power_Data.Power_Consumption_Plot(df_img, ['Power', faultInj], document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, ['Power', faultInj], document, pltPath, showPlt)

        document.add_heading(i + ' SM_ATR Image @ Starting Location with Fault Injection (' + faultInj + ')', level=2)
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 3106, 32, 3126, 80, showPlt)  # ATR start
        document.add_heading(i + ' SM_ATR Image @ Center Location with Fault Injection (' + faultInj + ')', level=2)
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 3106, 2000, 3126, 2048, showPlt)  # ATR mid
        document.add_heading(i + ' SM_ATR Image @ Ending Location with Fault Injection (' + faultInj + ')', level=2)
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 3106, 4088, 3126, 4136, showPlt)  # ATR end

        document.add_heading(i + ' Image Mean & StdDev vs. Fault Injection (' + faultInj + ')', level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, faultInj, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, faultInj, document, pltPath, showPlt)

def DV_12_SM_FAULT_INJECT_RRC(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    reg1 = 'ATR_CHECK_CONTROL'
    reg2 = 'LINE_LENGTH_PCK_'
    reg3 = 'SMIA_TEST'
    reg4 = 'READ_MODE'
    reg5 = 'TEST_ASIL_ROWS'
    reg6 = 'DARK_CONTROL'
    reg7 = 'DBLC_CONTROL'
    reg8 = 'LFM2_T1_DBLC_TILT_ATR_CTRL'
    imgSize = 'Macro5'
    rrcAddrHi = 'RRC_ADDR_HI_THRESH'
    rrcAddrLo = 'RRC_ADDR_LO_THRESH'
    faultInj = 'DAC_LD_34_35'

    # GeneralData
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, None, document, pltPath, showPlt)  # Temperature for each val test
    VRG_General_Data.FrameCount_Plot(df, None, document, pltPath, showPlt)  # Number of frames for each val test
    VRG_General_Data.Clk_Frequency_Plot(df, None, document, pltPath, showPlt)  # Plot each frequency for each test
    VRG_General_Data.TestTime_Plot(df, None, document, pltPath, showPlt)  # Time to run each val test
    VRG_General_Data.RunNumber_Plot(df, None, document, pltPath, showPlt)  # Val test run number
    VRG_General_Data.FrameWidth_Plot(df, None, document, pltPath, showPlt)  # Frame width
    VRG_General_Data.FrameHeight_Plot(df, None, document, pltPath, showPlt)  # Frame height
    VRG_General_Data.FrameBitDepth_Plot(df, None, document, pltPath, showPlt)  # Frame bit depth
    VRG_General_Data.DroppedFrames_Plot(df, None, document, pltPath, showPlt)  # Dropped frames
    VRG_General_Data.Sensor_FPS_Plot(df, None, document, pltPath, showPlt)  # Frames/second
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, None, document, pltPath, showPlt)  # Plot tempsensor data for all tests
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, None, document, pltPath, showPlt)  # Plot ASIL startup data for all tests

    document.add_heading('Key Register Settings vs. Imaging Mode')
    VRG_Register_Data.Reg_vs_Step_Plot(df, 'ImgMode', document, pltPath, reg1, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, 'ImgMode', document, pltPath, reg2, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, 'ImgMode', document, pltPath, reg3, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, 'ImgMode', document, pltPath, reg4, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, 'ImgMode', document, pltPath, reg5, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, 'ImgMode', document, pltPath, reg6, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, 'ImgMode', document, pltPath, reg7, showPlt)
    VRG_Register_Data.Reg_vs_Step_Plot(df, 'ImgMode', document, pltPath, reg8, showPlt)

    document.add_heading('All RRC Register Values vs. Imaging Mode')
    VRG_Safety_Data.SM_AHM_ROW_ROM(df, 'ImgMode', document, pltPath, showPlt)
    document.add_heading('All SYS_CHECK Values vs. Imaging Mode')
    VRG_Safety_Data.SM_SYS_CHECK(df, 'ImgMode', document, pltPath, showPlt)

    document.add_heading('High Pixel Threshold For RRC ADDR CRC Values vs. Imaging Mode')
    VRG_General_Data.Data_vs_Step_Plot(df, 'ImgMode', document, pltPath, rrcAddrHi, showPlt)
    document.add_heading('Low Pixel Threshold For RRC ADDR CRC Values vs. Imaging Mode')
    VRG_General_Data.Data_vs_Step_Plot(df, 'ImgMode', document, pltPath, rrcAddrLo, showPlt)

    document.add_heading(
        'RRC Address CRC & Statistics Values Expanded vs. Imaging Mode vs. Fault Injection (' + faultInj + ')')
    VRG_Safety_Data.SM_Row_Rom_Address_Columns_Expanded_Plot(df, ['ImgMode', faultInj], document, pltPath, showPlt)

    document.add_heading(
        'RRC LDO Signal Integrity Columns Statistics Expanded vs. Imaging Mode vs. Fault Injection (' + faultInj + ')')
    VRG_Safety_Data.SM_Row_Rom_SIC_Expanded_Plot(df, ['ImgMode', faultInj], document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[imgSize].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' SM_AHM_ROW_ROM Register Values vs. Fault Injection (' + faultInj + ')', level=2)
        VRG_Safety_Data.SM_AHM_ROW_ROM(df_img, faultInj, document, pltPath, showPlt)
        document.add_heading(i + ' SM_AHM_ROW_ROM SYS_CHECK vs. Fault Injection (' + faultInj + ')', level=2)
        VRG_Safety_Data.SM_SYS_CHECK(df_img, faultInj, document, pltPath, showPlt)

        document.add_heading(i + ' High Pixel Threshold For RRC ADDR CRC Values vs. Power', level=2)
        VRG_General_Data.Data_vs_Step_Plot(df_img, 'Power', document, pltPath, rrcAddrHi, showPlt)
        document.add_heading(i + ' Low Pixel Threshold For RRC ADDR CRC Values vs. Power', level=2)
        VRG_General_Data.Data_vs_Step_Plot(df_img, 'Power', document, pltPath, rrcAddrLo, showPlt)

        document.add_heading(
            i + ' SM_AHM_ROW_ROM Address CRC & Statistics Values vs. Fault Injection (' + faultInj + ')', level=2)
        VRG_Safety_Data.SM_Row_Rom_Address_Columns_Plot(df_img, faultInj, document, pltPath, showPlt)
        document.add_heading(
            i + ' SM_AHM_ROW_ROM Address CRC & Statistics Values Expanded vs. Fault Injection (' + faultInj + ')',
            level=2)
        VRG_Safety_Data.SM_Row_Rom_Address_Columns_Expanded_Plot(df_img, faultInj, document, pltPath, showPlt)

        document.add_heading(
            i + ' SM_AHM_ROW_ROM LDO Signal Integrity Columns Statistics vs. Fault Injection (' + faultInj + ')',
            level=2)
        VRG_Safety_Data.SM_Row_Rom_SIC_Plot(df_img, faultInj, document, pltPath, showPlt)
        document.add_heading(
            i + ' SM_AHM_ROW_ROM LDO Signal Integrity Columns Statistics Expanded vs. Fault Injection (' + faultInj + ')',
            level=2)
        VRG_Safety_Data.SM_Row_Rom_SIC_Expanded_Plot(df_img, faultInj, document, pltPath, showPlt)

        document.add_heading(i + ' Power & Current vs. Voltage Level', level=2)
        VRG_Power_Data.Power_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)
        VRG_Power_Data.Current_Consumption_Plot(df_img, 'Power', document, pltPath, showPlt)

        document.add_heading(i + ' Image Mean & STD vs. Fault Injection (' + faultInj + ')', level=2)
        VRG_Stats_Frame.Rgn_Mean_Plot(df_img, faultInj, document, pltPath, showPlt)
        VRG_Stats_Frame.Rgn_StdDev_Plot(df_img, faultInj, document, pltPath, showPlt)

        document.add_heading(i + ' SM_AHM_ROW_ROM Image @ Starting Location with Fault Injection (' + faultInj + ')',
                             level=2)
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 34, 0, 64, 20, showPlt)  # RRC start
        document.add_heading(i + ' SM_AHM_ROW_ROM Image @ Center Location with Fault Injection (' + faultInj + ')',
                             level=2)
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 1504, 0, 1536, 20, showPlt)  # RRC mid
        document.add_heading(i + ' SM_AHM_ROW_ROM Image @ Ending Location with Fault Injection (' + faultInj + ')',
                             level=2)
        VRG_Image_Utils.Image_Crop(df_img, 2, document, 3100, 0, 3130, 20, showPlt)  # RRC end

def DV_12_FAULT_MEMORY_TEST_1(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    ULcolor = '#ff0000'
    LLcolor = '#0000ff'
    test = 'Macro5'
    t1_reg1 = 'ODP_CRC_FAULT_CONTROL'
    t1_reg2 = 'ODP_CRC_FAULT_FRAMES'
    t1_reg3 = 'ODP_CRC_FAULTS_PER_FRAME'
    t1_reg4 = 'ASIL_STATUS_03__ODP_MEMORY_CRC_FAULT'
    t2_reg1 = 'LFM2_CRC_FAULT_CONTROL'
    t2_reg2 = 'LFM2_CRC_FAULT_FRAMES'
    t2_reg3 = 'LFM2_CRC_FAULTS_PER_FRAME'
    t2_reg4 = 'ASIL_STATUS_03__LFM2_MEMORY_CRC_FAULT'
    t3_reg1 = 'DCDS_CRC_FAULT_CONTROL_TOP'
    t3_reg2 = 'DCDS_CRC_FAULT_FRAMES_TOP'
    t3_reg3 = 'DCDS_CRC_FAULTS_PER_FRAME_TOP'
    t3_reg4 = 'ASIL_STATUS_03__DCDS_TOP_MEMORY_CRC_FAULT'
    t4_reg1 = 'DCDS_CRC_FAULT_CONTROL_BTM'
    t4_reg2 = 'DCDS_CRC_FAULT_FRAMES_BTM'
    t4_reg3 = 'DCDS_CRC_FAULTS_PER_FRAME_BTM'
    t4_reg4 = 'ASIL_STATUS_03__DCDS_BTM_MEMORY_CRC_FAULT'
    t5_reg1 = 'CONV_CRC_FAULT_CONTROL'
    t5_reg2 = 'CONV_CRC_FAULT_FRAMES'
    t5_reg3 = 'CONV_CRC_FAULTS_PER_FRAME'
    t5_reg4 = 'ASIL_STATUS_03__CONV_MEMORY_CRC_FAULT'
    t6_reg1 = 'MEC_CRC_FAULT_CONTROL'
    t6_reg2 = 'MEC_CRC_FAULT_FRAMES'
    t6_reg3 = 'MEC_CRC_FAULTS_PER_FRAME'
    t6_reg4 = 'ASIL_STATUS_03__MEC_MEMORY_CRC_FAULT'
    t7_reg1 = 'FOR_CRC_FAULT_CONTROL'
    t7_reg2 = 'FOT_CRC_FAULTS_PER_FRAME'
    t7_reg3 = 'FOR_CRC_FAULT_FRAMES'
    t8_reg1 = 'T1_SM_STATUS'
    t8_reg2 = 'T4_SM_STATUS'
    t8_reg3 = 'T4_SM_PDC_FULL_CRC'
    t8_reg4 = 'T4_SM_PDC_DTR_CRC'

    # VRG_General_Data Plots
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Meta Data')
    VRG_Macro_Data.MetaData_Enable_Plot(df, [die, temp], document, pltPath, showPlt)

    document.add_heading('Startup Fault Inject Memory Test #1 vs. Imaging Mode')
    VRG_Safety_Data.SM_Fault_Memory_Test_1_Plot(df, 'ImgMode', document, pltPath, showPlt)
    document.add_heading('Startup Fault Inject Memory Test #1 SYS_CHECK vs. Imaging Mode')
    VRG_Safety_Data.SM_SYS_CHECK(df, 'ImgMode', document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[test].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Startup Fault Inject Memory Test #1', level=2)
        VRG_Safety_Data.SM_Fault_Memory_Test_1_Plot(df_img, None, document, pltPath, showPlt)
        document.add_heading(i + ' Startup Fault Inject Memory Test #1 SYS_CHECK')
        VRG_Safety_Data.SM_SYS_CHECK(df_img, None, document, pltPath, showPlt)

        df_t1 = df_img[[temp, 'ImgMode', 'Power', t1_reg1, t1_reg2, t1_reg3, t1_reg4]]
        document.add_heading(i + ' ' + t1_reg1 + ' Results Table', level=2)
        VRG_Doc.df_to_table(df_t1, document)

        df_t2 = df_img[[temp, 'ImgMode', 'Power', t2_reg1, t2_reg2, t2_reg3, t2_reg4]]
        document.add_heading(i + ' ' + t2_reg1 + ' Results Table', level=2)
        VRG_Doc.df_to_table(df_t2, document)

        df_t3 = df_img[[temp, 'ImgMode', 'Power', t3_reg1, t3_reg2, t3_reg3, t3_reg4]]
        document.add_heading(i + ' ' + t3_reg1 + ' Results Table', level=2)
        VRG_Doc.df_to_table(df_t3, document)

        df_t4 = df_img[[temp, 'ImgMode', 'Power', t4_reg1, t4_reg2, t4_reg3, t4_reg4]]
        document.add_heading(i + ' ' + t4_reg1 + ' Results Table', level=2)
        VRG_Doc.df_to_table(df_t4, document)

        df_t5 = df_img[[temp, 'ImgMode', 'Power', t5_reg1, t5_reg2, t5_reg3, t5_reg4]]
        document.add_heading(i + ' ' + t5_reg1 + ' Results Table', level=2)
        VRG_Doc.df_to_table(df_t5, document)

        df_t6 = df_img[[temp, 'ImgMode', 'Power', t6_reg1, t6_reg2, t6_reg3, t6_reg4]]
        document.add_heading(i + ' ' + t6_reg1 + ' Results Table', level=2)
        VRG_Doc.df_to_table(df_t6, document)

        df_t7 = df_img[[temp, 'ImgMode', 'Power', t7_reg1, t7_reg2, t7_reg3]]
        document.add_heading(i + ' ' + t7_reg1 + ' Results Table', level=2)
        VRG_Doc.df_to_table(df_t7, document)

        df_t8 = df_img[[temp, 'ImgMode', 'Power', t8_reg1, t8_reg2, t8_reg3, t8_reg4]]
        document.add_heading(i + ' ' + t8_reg1 + ' Results Table', level=2)
        VRG_Doc.df_to_table(df_t8, document)

        for tmp in TEMP:  # Temperature
            df_tmp = VRG_Data_Frame.newdataframe(df_img, temp, tmp)
            if tmp == nomTemp:
                document.add_heading(i + ' Image Capture at Temperature = ' + str(tmp), level=2)
                VRG_Image_Analysis.Add_Image_Analysis(df_tmp, 2, document, showPlt)

        document.add_heading(
            i + ' Startup Fault Inject Memory Test #1 Image Means & StdDev vs. Integration Time vs. Test Settings',
            level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, test, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, test, document, pltPath, showPlt)

        document.add_heading(
            i + ' Startup Fault Inject Memory Test #1 Image Column Statistics vs. Integration Time vs. Test Settings',
            level=2)
        VRG_Stats_Arr.Arr_ColStdDev_Plot(df_img, test, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_img, test, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColFPN_Plot(df_img, test, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTempNoise_Plot(df_img, test, document, pltPath, showPlt)

        document.add_heading(
            i + ' Startup Fault Inject Memory Test #1 Image Row Statistics vs. Integration Time vs. Test Settings',
            level=2)
        VRG_Stats_Arr.Arr_RowStdDev_Plot(df_img, test, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_img, test, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowFPN_Plot(df_img, test, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTempNoise_Plot(df_img, test, document, pltPath, showPlt)

def DV_12_FAULT_MEMORY_TEST_2(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    ULcolor = '#ff0000'
    LLcolor = '#0000ff'
    test = 'Macro5'
    t1_reg1 = 'DELAY_BUFFER_CRC_FAULT_CONTROL'
    t1_reg2 = 'DELAY_BUFFER_CRC_FAULT_FRAMES'
    t1_reg3 = 'DELAY_BUFFER_CRC_FAULTS_PER_FRAME'
    t1_reg4 = 'ASIL_STATUS_03__DELAY_BUFFER_CRC_FAULT'
    sysCheck = 'SYS_CHECK'
    testPattern = 'TEST_PATTERN_MODE_'

    # VRG_General_Data Plots
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Power Supply Levels')
    VRG_Power_Data.Supply_Voltage_Plot(df, 'Power', document, pltPath, showPlt)
    document.add_heading('Temperature Sensor')
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('Meta Data')
    VRG_Macro_Data.MetaData_Enable_Plot(df, [die, temp], document, pltPath, showPlt)

    document.add_heading('Startup Fault Inject Memory Test #2 vs. Imaging Mode')
    VRG_Safety_Data.SM_Fault_Memory_Test_2_Plot(df, 'ImgMode', document, pltPath, showPlt)
    document.add_heading('Startup Fault Inject Memory Test #2 SYS_CHECK vs. Imaging Mode')
    VRG_Safety_Data.SM_SYS_CHECK(df, 'ImgMode', document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[test].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' Startup Fault Inject Memory Test #2', level=2)
        VRG_Safety_Data.SM_Fault_Memory_Test_2_Plot(df_img, None, document, pltPath, showPlt)
        document.add_heading(i + ' Startup Fault Inject Memory Test #2 SYS_CHECK')
        VRG_Safety_Data.SM_SYS_CHECK(df_img, None, document, pltPath, showPlt)

        df_t1 = df_img[[temp, 'ImgMode', 'Power', testPattern, t1_reg1, t1_reg2, t1_reg3, t1_reg4, sysCheck]]
        document.add_heading(i + ' ' + t1_reg1 + ' Results Table', level=2)
        VRG_Doc.df_to_table(df_t1, document)

        for tmp in TEMP:  # Temperature
            df_tmp = VRG_Data_Frame.newdataframe(df_img, temp, tmp)
            if tmp == nomTemp:
                document.add_heading(i + ' Image Capture at Temperature = ' + str(tmp), level=2)
                VRG_Image_Analysis.Add_Image_Analysis(df_tmp, 2, document, showPlt)

        document.add_heading(
            i + ' Startup Fault Inject Memory Test #2 Image Means & StdDev vs. Integration Time vs. Test Settings',
            level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, test, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, test, document, pltPath, showPlt)

        document.add_heading(
            i + ' Startup Fault Inject Memory Test #2 Image Column Statistics vs. Integration Time vs. Test Settings',
            level=2)
        VRG_Stats_Arr.Arr_ColStdDev_Plot(df_img, test, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_img, test, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColFPN_Plot(df_img, test, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTempNoise_Plot(df_img, test, document, pltPath, showPlt)

        document.add_heading(
            i + ' Startup Fault Inject Memory Test #2 Image Row Statistics vs. Integration Time vs. Test Settings',
            level=2)
        VRG_Stats_Arr.Arr_RowStdDev_Plot(df_img, test, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_img, test, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowFPN_Plot(df_img, test, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTempNoise_Plot(df_img, test, document, pltPath, showPlt)

def DV_12_SM_MEMORY_CRC_TEST(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    cint = 'RegWr00_COARSE_INTEGRATION_TIME_'
    test = 'Macro5'

    # VRG_General_Data Plots
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameCount_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.TestTime_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Clk_Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Frequency_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.RunNumber_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameWidth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameHeight_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.FrameBitDepth_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.DroppedFrames_Plot(df, [die, temp], document, pltPath, showPlt)
    VRG_General_Data.Sensor_FPS_Plot(df, [die, temp], document, pltPath, showPlt)
    # document.add_heading('Temperature Sensor')
    # VRG_TempsensorData.Tempsensor_Read_Plot(df, [die, temp], document, pltPath, showPlt)
    document.add_heading('SM Startup')
    VRG_Safety_Data.SM_Startup_Plot(df, [die, temp], document, pltPath, showPlt)

    document.add_heading('SM_Memory & SM_ECC Test Data vs. Imaging Mode')
    VRG_Safety_Data.SM_Memory_CRC_Test_Plot(df, 'ImgMode', document, pltPath, showPlt)
    document.add_heading('SM_Memory & SM_ECC SYS_CHECK vs. Imaging Mode')
    VRG_Safety_Data.SM_SYS_CHECK(df, 'ImgMode', document, pltPath, showPlt)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df[test].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' SM_Memory & SM_ECC Test Data vs. Test Settings', level=2)
        VRG_Safety_Data.SM_Memory_CRC_Test_Plot(df_img, test, document, pltPath, showPlt)
        document.add_heading(i + ' SM_Memory & SM_ECC SYS_CHECK vs. Test Settings', level=2)
        VRG_Safety_Data.SM_SYS_CHECK(df_img, test, document, pltPath, showPlt)

        document.add_heading(i + ' SM_Memory & SM_ECC Test Image Means & StdDev vs. Integration Time vs. Test Settings',
                             level=2)
        VRG_Stats_Arr.Arr_Mean_Plot(df_img, test, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_StdDev_Plot(df_img, test, document, pltPath, showPlt)

        document.add_heading(
            i + ' SM_Memory & SM_ECC Test Image Column Statistics vs. Integration Time vs. Test Settings', level=2)
        VRG_Stats_Arr.Arr_ColStdDev_Plot(df_img, test, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df_img, test, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColFPN_Plot(df_img, test, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_ColTempNoise_Plot(df_img, test, document, pltPath, showPlt)

        document.add_heading(i + ' SM_Memory & SM_ECC Test Image Row Statistics vs. Integration Time vs. Test Settings',
                             level=2)
        VRG_Stats_Arr.Arr_RowStdDev_Plot(df_img, test, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df_img, test, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowFPN_Plot(df_img, test, document, pltPath, showPlt)
        VRG_Stats_Arr.Arr_RowTempNoise_Plot(df_img, test, document, pltPath, showPlt)

        for tst in TEST:  # Test
            df_test = VRG_Data_Frame.newdataframe(df_img, test, tst)
            document.add_heading(i + ' vs. Test Settings = ' + str(tst), level=1)
            document.add_heading(i + ' SM_Memory & SM_ECC Test Data vs. Test Settings = ' + str(tst), level=2)
            VRG_Safety_Data.SM_Memory_CRC_Test_Plot(df_img, test, document, pltPath, showPlt)
            document.add_heading(i + ' SM_Memory & SM_ECC SYS_CHECK vs. Test Settings = ' + str(tst), level=2)
            VRG_Safety_Data.SM_SYS_CHECK(df_img, test, document, pltPath, showPlt)


'''
13.00 PROCESS INTEGRATION
'''

def DV_13_1_IMPLANT_RECIPE_VERIFICATION(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die
    ULcolor = '#ff0000'
    LLcolor = '#0000ff'

    document.add_heading('SM Clock Counting vs. Die')
    VRG_Safety_Data.SM_CLOCK_COUNTING(df, [die, temp, 'Clk'], document, pltPath, showPlt)

    df_t1 = df[[temp, die]]
    document.add_heading('SM_I2C_CRC Results Table', level=2)
    VRG_Doc.df_to_table(df_t1, document)

    # IMAGE MODE SPECIFIC DATA
    IMG = np.asarray(df['ImgMode'].unique())  # List of unique image modes
    TEST = np.asarray(df['Clk'].unique())
    TEMP = np.asarray(df[temp].unique())  # List of unique temperatures
    nomTemp = min(TEMP, key=lambda x: abs(x - 60))  # closest temp to 60C
    for i in IMG:
        df_img = VRG_Data_Frame.newdataframe(df, 'ImgMode', i)

        document.add_heading(i, level=1)
        document.add_heading(i + ' SM Clock Counting vs. Die', level=2)
        VRG_Safety_Data.SM_CLOCK_COUNTING(df_img, [die, temp, 'Clk'], document, pltPath, showPlt)

        for tst in TEST:  # Test
            df_test = VRG_Data_Frame.newdataframe(df_img, 'Clk', tst)

            document.add_heading(i + ' SM_CLOCK_COUNTING vs. Clk = ' + str(tst), level=1)
            document.add_heading(i + ' SM_CLOCK_COUNTING vs. Time vs. Clk =' + str(tst), level=2)
            VRG_Safety_Data.SM_CLOCK_COUNTING_vs_Time_Plot(df_test, None, None, document, pltPath, showPlt,
                                                           ax_hlines=[(die, ULcolor, '--', 3, 1)])

def DV_13_2_INLINE_CD_DATA_COLLECTION_PROCESS_RELEASE(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_13_3_FULL_SCRIBE_PARAM_VERIFICATION(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_13_4_ANOVA_MODEL_BOXES(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

def DV_13_5_PROBE_SUMMARY(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die


'''
COMMANDS
'''

def VRG_COMMAND_LIST(df, document, imgPath, pltPath):
    showPlt = False  # Show Plots (T/F)
    temp = 'TemperatureSetPoint'  # Group Plots by Temperatures
    die = 'Die'  # Group Plots by Die

    df_minV = VRG_Data_Frame.newdataframe(df, 'Power', 'Min')
    df_nomV = VRG_Data_Frame.newdataframe(df, 'Power', 'Nom')
    df_maxV = VRG_Data_Frame.newdataframe(df, 'Power', 'Max')

    df_im1_minV = VRG_Data_Frame.newdataframe(df_im1, 'Power', 'Min')
    df_im1_nomV = VRG_Data_Frame.newdataframe(df_im1, 'Power', 'Nom')
    df_im1_maxV = VRG_Data_Frame.newdataframe(df_im1, 'Power', 'Max')
    df_im1_Light = VRG_Data_Frame.newdataframe(df_im1, 'Light', '0')

    df_im2_minV = VRG_Data_Frame.newdataframe(df_im2, 'Power', 'Min')
    df_im2_nomV = VRG_Data_Frame.newdataframe(df_im2, 'Power', 'Nom')
    df_im2_maxV = VRG_Data_Frame.newdataframe(df_im2, 'Power', 'Max')
    df_im2_Light = VRG_Data_Frame.newdataframe(df_im1, 'Light', '0')

    # VRG_General_Data Plots
    document.add_heading('General Test Data')
    VRG_General_Data.TemperatureSetPoint_Plot(df, None, document, pltPath, showPlt)  # Temperature for each val test
    VRG_General_Data.FrameCount_Plot(df, None, document, pltPath, showPlt)  # Number of frames for each val test
    VRG_General_Data.TestTime_Plot(df, None, document, pltPath, showPlt)  # Time to run each val test
    VRG_General_Data.Clk_Frequency_Plot(df, None, document, pltPath, showPlt)  # Plot each frequency for each test
    VRG_General_Data.Frequency_Plot(df, None, document, pltPath, showPlt)  # Plot each frequency for each test
    VRG_General_Data.RunNumber_Plot(df, None, document, pltPath, showPlt)  # Val test run number
    VRG_General_Data.FrameWidth_Plot(df, None, document, pltPath, showPlt)  # Val test run number
    VRG_General_Data.FrameHeight_Plot(df, None, document, pltPath, showPlt)  # Val test run number
    VRG_General_Data.FrameBitDepth_Plot(df, None, document, pltPath, showPlt)  # Val test run number
    VRG_General_Data.DroppedFrames_Plot(df, None, document, pltPath, showPlt)  # Val test run number

    # VRG_MacroData Plots
    VRG_Macro_Data.MetaData_Enable_Plot(df, None, document, pltPath, showPlt)  # Plot which tests had Meta Data enabled
    VRG_General_Data.LightLevel_Plot(df, None, document, pltPath, showPlt)  # Light Level of each val test

    # VRG_Stats_Frame Plots
    VRG_Stats_Frame.Rgn_Mean_Plot(df, None, document, pltPath, showPlt)
    VRG_Stats_Frame.Rgn_StdDev_Plot(df, None, document, pltPath, showPlt)
    VRG_Stats_Frame.Rgn_TotalNoise_Plot(df, None, document, pltPath, showPlt)
    VRG_Stats_Frame.Rgn_FPN_Plot(df, None, document, pltPath, showPlt)
    VRG_Stats_Frame.Rgn_Temporal_Plot(df, None, document, pltPath, showPlt)
    VRG_Stats_Frame.Rgn_RowStdDev_Plot(df, None, document, pltPath, showPlt)
    VRG_Stats_Frame.Rgn_RowTotalNoise_Plot(df, None, document, pltPath, showPlt)
    VRG_Stats_Frame.Rgn_RowFPN_Plot(df, None, document, pltPath, showPlt)
    VRG_Stats_Frame.Rgn_RowTempNoise_Plot(df, None, document, pltPath, showPlt)
    VRG_Stats_Frame.Rgn_ColStdDev_Plot(df, None, document, pltPath, showPlt)
    VRG_Stats_Frame.Rgn_ColTotalNoise_Plot(df, None, document, pltPath, showPlt)
    VRG_Stats_Frame.Rgn_ColFPN_Plot(df, None, document, pltPath, showPlt)
    VRG_Stats_Frame.Rgn_ColTempNoise_Plot(df, None, document, pltPath, showPlt)
    VRG_Stats_Frame.Rgn_Flicker_Plot(df, None, document, pltPath, showPlt)

    # VRG_Stats_Frame Plots
    VRG_Stats_Arr.Arr_Mean_BoxPlot(df, None, None, document, pltPath, showPlt)
    VRG_Stats_Arr.Arr_StdDev_BoxPlot(df, None, None, document, pltPath, showPlt)
    VRG_Stats_Arr.Arr_Mean_Plot(df, None, document, pltPath, showPlt)
    VRG_Stats_Arr.Arr_StdDev_Plot(df, None, document, pltPath, showPlt)
    VRG_Stats_Arr.Arr_TotalNoise_Plot(df, None, document, pltPath, showPlt)
    VRG_Stats_Arr.Arr_FPN_Plot(df, None, document, pltPath, showPlt)
    VRG_Stats_Arr.Arr_Temporal_Plot(df, None, document, pltPath, showPlt)
    VRG_Stats_Arr.Arr_RowStdDev_Plot(df, None, document, pltPath, showPlt)
    VRG_Stats_Arr.Arr_RowTotalNoise_Plot(df, None, document, pltPath, showPlt)
    VRG_Stats_Arr.Arr_RowFPN_Plot(df, None, document, pltPath, showPlt)
    VRG_Stats_Arr.Arr_RowTempNoise_Plot(df, None, document, pltPath, showPlt)
    VRG_Stats_Arr.Arr_ColStdDev_Plot(df, None, document, pltPath, showPlt)
    VRG_Stats_Arr.Arr_ColTotalNoise_Plot(df, None, document, pltPath, showPlt)
    VRG_Stats_Arr.Arr_ColFPN_Plot(df, None, document, pltPath, showPlt)
    VRG_Stats_Arr.Arr_ColTempNoise_Plot(df, None, document, pltPath, showPlt)
    VRG_Stats_Arr.Arr_Flicker_Plot(df, None, document, pltPath, showPlt)
    VRG_Stats_Arr.Arr_PixelTotalNoise_Plot(df, None, document, pltPath, showPlt)
    VRG_Stats_Arr.Arr_PixelTemporalNoise_Plot(df, None, document, pltPath, showPlt)
    VRG_Stats_Arr.Arr_PixelFPN_Plot(df, None, document, pltPath, showPlt)
    VRG_Stats_Arr.Arr_RowTemporalNoiseRatio_Plot(df, None, document, pltPath, showPlt)
    VRG_Stats_Arr.Arr_ColumnTemporalNoiseRatio_Plot(df, None, document, pltPath, showPlt)
    VRG_Stats_Arr.Arr_RowFPNRatio_Plot(df, None, document, pltPath, showPlt)
    VRG_Stats_Arr.Arr_ColumnFPNRatio_Plot(df, None, document, pltPath, showPlt)

    # VRG_Calculate Plots
    VRG_Calculate.Calc_DigitalGain_Plot(df, None, document, pltPath, None, None, None, showPlt)
    VRG_Calculate.Calc_AnalogGain_Plot(df, None, document, pltPath, None, None, None, showPlt)
    VRG_Calculate.Calc_AnalogGain_Error_Plot(df, None, document, pltPath, None, None, None, showPlt)

    # VRG_TempsensorData Plots
    VRG_Tempsensor_Data.Tempsensor_Register_Plot(df, None, document, pltPath, 'RegVal_TEMPSENS1_DATA_REG', showPlt)
    VRG_Tempsensor_Data.Tempsensor_Read_Plot(df, None, document, pltPath, showPlt)
    VRG_Tempsensor_Data.Tempsensor_Register_vs_Time_Plot(df, None, None, document, pltPath, 'TEMPSENS1_DATA_REG', showPlt)
    VRG_Tempsensor_Data.Tempsensor_Read_vs_TestNo_Plot(df, None, None, document, pltPath, showPlt)
    VRG_Tempsensor_Data.Tempsensor_Read_vs_Time_Plot(df, None, None, document, pltPath, showPlt)
    VRG_Tempsensor_Data.Tempsensor_Register_Average_Plot(df, None, document, pltPath,
                                                        'SPARE_TEMPSENS1_DATA_K_REG_Celsius', showPlt)
    VRG_Tempsensor_Data.Tempsensor_Read_Average_Plot(df, None, document, pltPath, showPlt)

    # VRG_PowerData Plots
    VRG_Power_Data.Supply_Voltage_Plot(df, None, document, pltPath, showPlt)  # Plot voltage supply levels for each test
    VRG_Power_Data.Power_Consumption_Plot(df, None, document, pltPath, showPlt)
    VRG_Power_Data.Current_Consumption_Plot(df, None, document, pltPath, showPlt)
    VRG_Power_Data.Power_and_Current_Consumption_Plot(df, None, document, pltPath, showPlt)
    VRG_Power_Data.ResetClkOn_Current_Mean_Plot(df, None, document, pltPath, showPlt)
    VRG_Power_Data.ResetClkOn_Current_Std_Plot(df, None, document, pltPath, showPlt)
    VRG_Power_Data.ResetClkOff_Current_Mean_Plot(df, None, document, pltPath, showPlt)
    VRG_Power_Data.ResetClkOff_Current_Std_Plot(df, None, document, pltPath, showPlt)
    VRG_Power_Data.STREAMING_Current_Mean_Plot(df, None, document, pltPath, showPlt)
    VRG_Power_Data.STREAMING_Current_Std_Plot(df, None, document, pltPath, showPlt)
    VRG_Power_Data.Booster_Voltage_Plot(df, None, document, pltPath, showPlt)
    VRG_Power_Data.Positive_Booster_Voltage_Plot(df, None, document, pltPath, showPlt)
    VRG_Power_Data.Middle_Booster_Voltage_Plot(df, None, document, pltPath, showPlt)
    VRG_Power_Data.Negative_Booster_Voltage_Plot(df, None, document, pltPath, showPlt)

    # VRG_AsilData SM VALIDATION Plots
    VRG_Safety_Data.SM_Startup_Plot(df, None, document, pltPath, showPlt)
    VRG_Safety_Data.SM_Startup_Expanded_Plot(df, None, document, pltPath, showPlt)
    VRG_Safety_Data.SM_Analog_Test_Rows_Plot(df, None, document, pltPath, showPlt)
    VRG_Safety_Data.SM_Analog_Test_Rows_Expanded_Plot(df, None, document, pltPath, showPlt)
    VRG_Safety_Data.SM_Digital_Test_Rows_Plot(df, None, document, pltPath, showPlt)
    VRG_Safety_Data.SM_Digital_Test_Rows_Expanded_Plot(df, None, document, pltPath, showPlt)
    VRG_Safety_Data.SM_Row_Rom_SIC_Plot(df, None, document, pltPath, showPlt)
    VRG_Safety_Data.SM_Row_Rom_SIC_Expanded_Plot(df, None, document, pltPath, showPlt)
    VRG_Safety_Data.SM_Row_Rom_Address_Columns_Plot(df, None, document, pltPath, showPlt)
    VRG_Safety_Data.SM_Row_Rom_Address_Columns_Expanded_Plot(df, None, document, pltPath, showPlt)

    # VRG_ImageAnalysis
    VRG_Image_Analysis.Add_Image(df, 1, document, showPlt)
    VRG_Image_Analysis.Add_Image_Info(df, 1, document, showPlt)
    VRG_Image_Analysis.Add_Image_Analysis(df, 1, document, showPlt)
    VRG_Image_Analysis.Add_Image_Analysis_Info(df, 1, document, showPlt)
    VRG_Image_Analysis.Add_External_Image(imgPath, 'FileName.PNG', document, showPlt)
    VRG_Image_Analysis.Add_External_Image_Analysis(imgPath, 'FileName.PNG', document, showPlt)

    # VRG_AsilData STARTUP SM'S Plots
    VRG_Safety_Data.SM_RESET(df, None, document, pltPath, showPlt)  # Not Working Yet
    VRG_Safety_Data.SM_HOST_CHECK_GPIO(df, None, document, pltPath, showPlt)  # Not Working Yet
    VRG_Safety_Data.SM_POWERON_MBIST(df, None, document, pltPath, showPlt)  # Not Working Yet
    VRG_Safety_Data.SM_POWERON_MBIST2(df, None, document, pltPath, showPlt)  # Not Working Yet
    VRG_Safety_Data.SM_M3ROM_UPLOAD_CRC(df, None, document, pltPath, showPlt)  #
    VRG_Safety_Data.SM_M3ROM_UPLOAD_CRC_ASIC(df, None, document, pltPath, showPlt)  #
    VRG_Safety_Data.SM_OTPM_UPLOAD_CRC(df, None, document, pltPath, showPlt)  #
    VRG_Safety_Data.SM_OTPM_UPLOAD_CRC_SENSOR(df, None, document, pltPath, showPlt)  #
    VRG_Safety_Data.SM_PDIM_UPLOAD_CRC(df, None, document, pltPath, showPlt)  #
    VRG_Safety_Data.SM_STANDBY_REGISTER_CRC(df, None, document, pltPath, showPlt)  #
    VRG_Safety_Data.SM_STANDBY_BIST_MEMORY(df, None, document, pltPath, showPlt)  # Not Working Yet
    VRG_Safety_Data.SM_STANDBY_TEST_FRAME(df, None, document, pltPath, showPlt)  # Not Working Yet
    # VRG_AsilData ATR SM'S Plots
    VRG_Safety_Data.SM_ATR_VERT_PIXOUT_1(df, None, document, pltPath, showPlt)  # Not Working Yet
    VRG_Safety_Data.SM_ATR_VERT_PIXOUT_2(df, None, document, pltPath, showPlt)  # Not Working Yet
    VRG_Safety_Data.SM_ATR_OVERDRIVE_1(df, None, document, pltPath, showPlt)  # Not Working Yet
    VRG_Safety_Data.SM_ATR_OVERDRIVE_2(df, None, document, pltPath, showPlt)  # Not Working Yet
    VRG_Safety_Data.SM_ATR_OVERDRIVE_3(df, None, document, pltPath, showPlt)  # Not Working Yet
    VRG_Safety_Data.SM_ATR_ZEBRA_AB(df, None, document, pltPath, showPlt)  # Not Working Yet
    VRG_Safety_Data.SM_ATR_ZEBRA_BA(df, None, document, pltPath, showPlt)  # Not Working Yet
    VRG_Safety_Data.SM_ATR_COLUMN_ROM(df, None, document, pltPath, showPlt)  # Not Working Yet
    VRG_Safety_Data.SM_ATR_ADC_LATCH(df, None, document, pltPath, showPlt)  # Not Working Yet
    VRG_Safety_Data.SM_ATR_OVERDRIVE_CODE0(df, None, document, pltPath, showPlt)  # Not Working Yet
    VRG_Safety_Data.SM_ATR_OVERDRIVE_CODE1(df, None, document, pltPath, showPlt)  # Not Working Yet
    VRG_Safety_Data.SM_ATR_OVERDRIVE_CODE2(df, None, document, pltPath, showPlt)  # Not Working Yet
    VRG_Safety_Data.SM_ATR_OVERDRIVE_CODE3(df, None, document, pltPath, showPlt)  # Not Working Yet
    VRG_Safety_Data.SM_ATR_COLUMN_MEMORY_TEST_1(df, None, document, pltPath, showPlt)  # Not Working Yet
    VRG_Safety_Data.SM_ATR_COLUMN_MEMORY_TEST_2(df, None, document, pltPath, showPlt)  # Not Working Yet
    VRG_Safety_Data.SM_ATR_COLUMN_MEMORY_TEST_3(df, None, document, pltPath, showPlt)  # Not Working Yet
    VRG_Safety_Data.SM_ATR_ECL_COMPARATOR_LOGIC(df, None, document, pltPath, showPlt)  # Not Working Yet
    # VRG_AsilData BMON & VMON SM'S Plots
    VRG_Safety_Data.SM_AHM_BOOSTER_BANDGAP_MONITOR(df, None, document, pltPath, showPlt)  # Not Working Yet
    VRG_Safety_Data.SM_CHIP_SUPPLY_VOLTAGE_MONITOR(df, None, document, pltPath, showPlt)  # Not Working Yet
    # VRG_AsilData RRC SM'S Plots
    VRG_Safety_Data.SM_AHM_ROW_ROM(df, None, document, pltPath, showPlt)  # Not Working Yet
    # VRG_AsilData DTR SM'S Plots
    VRG_Safety_Data.SM_DTR(df, None, document, pltPath, showPlt)  # Not Working Yet
    VRG_Safety_Data.SM_DTR_MEC(df, None, document, pltPath, showPlt)  # Not Working Yet
    # VRG_AsilData CLOCK COUNTING SM'S Plots
    VRG_Safety_Data.SM_COUNT_EXTCLK(df, None, document, pltPath, showPlt)  # Not Working Yet
    VRG_Safety_Data.SM_COUNT_CLK_PIX(df, None, document, pltPath, showPlt)  # Not Working Yet
    VRG_Safety_Data.SM_COUNT_CLK_REG(df, None, document, pltPath, showPlt)  # Not Working Yet
    VRG_Safety_Data.SM_COUNT_CLK_OP(df, None, document, pltPath, showPlt)  # Not Working Yet
    # VRG_AsilData EMBEDDED DATA & STATS SM'S Plots
    VRG_Safety_Data.SM_HOST_CHECK_EMBEDDED_REGISTER_DATA(df, None, document, pltPath, showPlt)  # Not Working Yet
    VRG_Safety_Data.SM_STATS_MON_EXT(df, None, document, pltPath, showPlt)  # Not Working Yet
    # VRG_AsilData ECC CHECK SM'S Plots
    VRG_Safety_Data.SM_STATS_RAM_ECC(df, None, document, pltPath, showPlt)  # Not Working Yet
    VRG_Safety_Data.SM_ECC_BLACK_LEVEL_RAM(df, None, document, pltPath, showPlt)  # Not Working Yet
    VRG_Safety_Data.SM_ECC_SEQUENCER_RAM(df, None, document, pltPath, showPlt)  # Not Working Yet
    VRG_Safety_Data.SM_ECC_CONTEXT_RAM(df, None, document, pltPath, showPlt)  # Not Working Yet
    # VRG_AsilData REGISTER ACCESS SM'S Plots
    VRG_Safety_Data.SM_I2C_CRC(df, None, document, pltPath, showPlt)  # Not Working Yet
    VRG_Safety_Data.SM_DOUBLE_LOCK(df, None, document, pltPath, showPlt)  # Not Working Yet
    # VRG_AsilData CRC CHECK SM'S Plots
    VRG_Safety_Data.SM_PDI_RAM_CRC(df, None, document, pltPath, showPlt)  # Not Working Yet
    VRG_Safety_Data.SM_CDS_MEM_CRC(df, None, document, pltPath, showPlt)  # Not Working Yet
    VRG_Safety_Data.SM_OFL_MEM_CRC(df, None, document, pltPath, showPlt)  # Not Working Yet
    VRG_Safety_Data.SM_DELAY_BUFFER_RAM_CRC(df, None, document, pltPath, showPlt)  # Not Working Yet
    VRG_Safety_Data.SM_DEF_CORR_RAM_CRC(df, None, document, pltPath, showPlt)  # Not Working Yet
    VRG_Safety_Data.SM_MC_RAM_CRC(df, None, document, pltPath, showPlt)  # Not Working Yet
    VRG_Safety_Data.SM_ADDR_STATE_CRC(df, None, document, pltPath, showPlt)  # Not Working Yet
    VRG_Safety_Data.SM_ODP_BUFFER_CRC(df, None, document, pltPath, showPlt)  # Not Working Yet
    VRG_Safety_Data.SM_Sensor_Datapath_Buffer_CRC(df, None, document, pltPath, showPlt)  # Not Working Yet
    VRG_Safety_Data.SM_ASIC_Datapath_Buffer_CRC(df, None, document, pltPath, showPlt)  # Not Working Yet
    VRG_Safety_Data.SM_24_TO_16_BUFFER_CRC(df, None, document, pltPath, showPlt)  # Not Working Yet
    VRG_Safety_Data.SM_BIN2_RAM_CRC(df, None, document, pltPath, showPlt)  # Not Working Yet
    # VRG_AsilData CHALLENGE RESPONSE SM'S Plots
    VRG_Safety_Data.SM_MASTER_STATE_CHA_RES(df, None, document, pltPath, showPlt)  # Not Working Yet
    # VRG_AsilData ANALOG TO DIGITAL SM'S Plots
    VRG_Safety_Data.SM_AHM_SREG_READBACK(df, None, document, pltPath, showPlt)  # Not Working Yet
    # VRG_AsilData INVALID IMAGE SM'S Plots
    VRG_Safety_Data.SM_HOST_CHECK_INVALID_IMAGE(df, None, document, pltPath, showPlt)  # Not Working Yet
    # VRG_AsilData temp SENSOR SM'S Plots
    VRG_Safety_Data.SM_temp_SENSOR(df, None, document, pltPath, showPlt)  # Not Working Yet

    # VRG_TimingData Plots
    VRG_General_Data.Sensor_FPS_Plot(df, None, document, pltPath, showPlt)
    VRG_General_Data.FrameTime_Plot(df, None, document, pltPath, showPlt)
    VRG_General_Data.PLL_Clock_Plot(df, None, document, pltPath, showPlt)
    VRG_General_Data.I2C_Status_Plot(df, None, document, pltPath, showPlt)

    # VRG_OTPMData Plots
    VRG_OTPM_Data.OTPM_Initial_Check_Plot(df, None, document, pltPath, showPlt)
    VRG_OTPM_Data.OTPM_Manual_Read_Plot(df, None, document, pltPath, showPlt)  # NOT WORKING YET
    VRG_OTPM_Data.OTPM_Auto_Read_Plot(df, None, document, pltPath, showPlt)  # NOT WORKING YET

    # VRG_RegVsData Plots
    VRG_General_Data.Data_vs_Step_Plot(df, None, document, pltPath, 'MaxINL', showPlt)

    # Single Register Plots
    VRG_Register_Data.Reg_vs_Step_Plot(df, None, document, pltPath, 'RegWr01_DATA_PEDESTAL_', showPlt)
    VRG_Power_Data.Reg_vs_Power_and_Current_Consumption_Plot(df, None, document, pltPath, 'RegWr01_DATA_PEDESTAL_',
                                                             showPlt)
    VRG_Power_Data.Reg_vs_Power_Consumption_Plot(df, None, document, pltPath, 'RegWr01_DATA_PEDESTAL_', showPlt)
    VRG_Power_Data.Reg_vs_Power_Consumption_Plot(df, None, document, pltPath, 'RegWr01_DATA_PEDESTAL_', showPlt)
    VRG_Power_Data.Reg_vs_Current_Consumption_Plot(df, None, document, pltPath, 'RegWr01_DATA_PEDESTAL_', showPlt)
    VRG_Tempsensor_Data.Reg_vs_Tempsensor_Plot(df, None, document, pltPath, 'RegWr01_DATA_PEDESTAL_', showPlt)
    VRG_General_Data.Reg_vs_Sensor_FPS_Plot(df, None, document, pltPath, 'RegWr01_DATA_PEDESTAL_', showPlt)
    VRG_General_Data.Reg_vs_FrameTime_Plot(df, None, document, pltPath, 'RegWr01_DATA_PEDESTAL_', showPlt)
    VRG_General_Data.Reg_vs_PLL_Clock_Plot(df, None, document, pltPath, 'RegWr01_DATA_PEDESTAL_', showPlt)
    VRG_General_Data.Reg_vs_I2C_Status_Plot(df, None, document, pltPath, 'RegWr01_DATA_PEDESTAL_', showPlt)

    # Dual Register Plots
    VRG_Register_Data.Reg_vs_Reg_Plot(df_im1, None, document, pltPath, 'RegWr01_GLOBAL_GAIN',
                                     'RegWr00_COARSE_INTEGRATION_TIME_', showPlt)

    # Single Reg vs. Macro Plots
    VRG_Macro_Data.Reg_vs_Macro_Plot(df, None, document, pltPath, 'RegWr01_DATA_PEDESTAL_', 'DVM_3_09_Analog_Gain',
                                     showPlt)

    # Full-Res vs Single Register Plots
    VRG_Stats_Frame.Reg_vs_Img_Mean_Plot(df, None, document, pltPath, 'RegWr01_DATA_PEDESTAL_', showPlt)
    VRG_Stats_Frame.Reg_vs_Img_StdDev_Plot(df, None, document, pltPath, 'RegWr01_DATA_PEDESTAL_', showPlt)
    VRG_Stats_Frame.Reg_vs_Img_TotalNoise_Plot(df, None, document, pltPath, 'RegWr01_DATA_PEDESTAL_', showPlt)
    VRG_Stats_Frame.Reg_vs_Img_FPN_Plot(df, None, document, pltPath, 'RegWr01_DATA_PEDESTAL_', showPlt)
    VRG_Stats_Frame.Reg_vs_Img_Temporal_Plot(df, None, document, pltPath, 'RegWr01_DATA_PEDESTAL_', showPlt)
    VRG_Stats_Frame.Reg_vs_Img_RowStdDev_Plot(df, None, document, pltPath, 'RegWr01_DATA_PEDESTAL_', showPlt)
    VRG_Stats_Frame.Reg_vs_Img_RowTotalNoise_Plot(df, None, document, pltPath, 'RegWr01_DATA_PEDESTAL_', showPlt)
    VRG_Stats_Frame.Reg_vs_Img_RowFPN_Plot(df, None, document, pltPath, 'RegWr01_DATA_PEDESTAL_', showPlt)
    VRG_Stats_Frame.Reg_vs_Img_RowTempNoise_Plot(df, None, document, pltPath, 'RegWr01_DATA_PEDESTAL_', showPlt)
    VRG_Stats_Frame.Reg_vs_Img_ColStdDev_Plot(df, None, document, pltPath, 'RegWr01_DATA_PEDESTAL_', showPlt)
    VRG_Stats_Frame.Reg_vs_Img_ColTotalNoise_Plot(df, None, document, pltPath, 'RegWr01_DATA_PEDESTAL_', showPlt)
    VRG_Stats_Frame.Reg_vs_Img_ColFPN_Plot(df, None, document, pltPath, 'RegWr01_DATA_PEDESTAL_', showPlt)
    VRG_Stats_Frame.Reg_vs_Img_ColTempNoise_Plot(df, None, document, pltPath, 'RegWr01_DATA_PEDESTAL_', showPlt)
    VRG_Stats_Frame.Reg_vs_Img_Flicker_Plot(df, None, document, pltPath, 'RegWr01_DATA_PEDESTAL_', showPlt)
    VRG_Stats_Frame.Reg_vs_Img_PixelTotalNoise_Plot(df, None, document, pltPath, 'RegWr01_DATA_PEDESTAL_', showPlt)
    VRG_Stats_Frame.Reg_vs_Img_PixelTemporalNoise_Plot(df, None, document, pltPath, 'RegWr01_DATA_PEDESTAL_', showPlt)
    VRG_Stats_Frame.Reg_vs_Img_PixelFPN_Plot(df, None, document, pltPath, 'RegWr01_DATA_PEDESTAL_', showPlt)
    VRG_Stats_Frame.Reg_vs_Img_RowTemporalNoiseRatio_Plot(df, None, document, pltPath, 'RegWr01_DATA_PEDESTAL_',
                                                          showPlt)
    VRG_Stats_Frame.Reg_vs_Img_ColumnTemporalNoiseRatio_Plot(df, None, document, pltPath, 'RegWr01_DATA_PEDESTAL_',
                                                             showPlt)
    VRG_Stats_Frame.Reg_vs_Img_RowFPNRatio_Plot(df, None, document, pltPath, 'RegWr01_DATA_PEDESTAL_', showPlt)
    VRG_Stats_Frame.Reg_vs_Img_ColumnFPNRatio_Plot(df, None, document, pltPath, 'RegWr01_DATA_PEDESTAL_', showPlt)
    # Region vs Single Register Plots
    VRG_Stats_Frame.Reg_vs_Rgn_Mean_Plot(df, None, document, pltPath, 'RegWr01_DATA_PEDESTAL_', showPlt)
    VRG_Stats_Frame.Reg_vs_Rgn_StdDev_Plot(df, None, document, pltPath, 'RegWr01_DATA_PEDESTAL_', showPlt)
    VRG_Stats_Frame.Reg_vs_Rgn_TotalNoise_Plot(df, None, document, pltPath, 'RegWr01_DATA_PEDESTAL_', showPlt)
    VRG_Stats_Frame.Reg_vs_Rgn_FPN_Plot(df, None, document, pltPath, 'RegWr01_DATA_PEDESTAL_', showPlt)
    VRG_Stats_Frame.Reg_vs_Rgn_Temporal_Plot(df, None, document, pltPath, 'RegWr01_DATA_PEDESTAL_', showPlt)
    VRG_Stats_Frame.Reg_vs_Rgn_RowStdDev_Plot(df, None, document, pltPath, 'RegWr01_DATA_PEDESTAL_', showPlt)
    VRG_Stats_Frame.Reg_vs_Rgn_RowTotalNoise_Plot(df, None, document, pltPath, 'RegWr01_DATA_PEDESTAL_', showPlt)
    VRG_Stats_Frame.Reg_vs_Rgn_RowFPN_Plot(df, None, document, pltPath, 'RegWr01_DATA_PEDESTAL_', showPlt)
    VRG_Stats_Frame.Reg_vs_Rgn_RowTempNoise_Plot(df, None, document, pltPath, 'RegWr01_DATA_PEDESTAL_', showPlt)
    VRG_Stats_Frame.Reg_vs_Rgn_ColStdDev_Plot(df, None, document, pltPath, 'RegWr01_DATA_PEDESTAL_', showPlt)
    VRG_Stats_Frame.Reg_vs_Rgn_ColTotalNoise_Plot(df, None, document, pltPath, 'RegWr01_DATA_PEDESTAL_', showPlt)
    VRG_Stats_Frame.Reg_vs_Rgn_ColFPN_Plot(df, None, document, pltPath, 'RegWr01_DATA_PEDESTAL_', showPlt)
    VRG_Stats_Frame.Reg_vs_Rgn_ColTempNoise_Plot(df, None, document, pltPath, 'RegWr01_DATA_PEDESTAL_', showPlt)
    VRG_Stats_Frame.Reg_vs_Rgn_Flicker_Plot(df, None, document, pltPath, 'RegWr01_DATA_PEDESTAL_', showPlt)
    # Full-Res vs Dual Register Plots
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_Mean_Plot(df, None, document, pltPath, 'DVM_3_09_Analog_Gain',
                                                'RegWr00_COARSE_INTEGRATION_TIME_', showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_StdDev_Plot(df, None, document, pltPath, 'DVM_3_09_Analog_Gain',
                                                  'RegWr00_COARSE_INTEGRATION_TIME_', showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_FPN_Plot(df, None, document, pltPath, 'DVM_3_09_Analog_Gain',
                                               'RegWr00_COARSE_INTEGRATION_TIME_', showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_Temporal_Plot(df, None, document, pltPath, 'DVM_3_09_Analog_Gain',
                                                    'RegWr00_COARSE_INTEGRATION_TIME_', showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_RowStdDev_Plot(df, None, document, pltPath, 'DVM_3_09_Analog_Gain',
                                                     'RegWr00_COARSE_INTEGRATION_TIME_', showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_RowTotalNoise_Plot(df, None, document, pltPath, 'DVM_3_09_Analog_Gain',
                                                         'RegWr00_COARSE_INTEGRATION_TIME_', showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_RowFPN_Plot(df, None, document, pltPath, 'DVM_3_09_Analog_Gain',
                                                  'RegWr00_COARSE_INTEGRATION_TIME_', showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_RowTempNoise_Plot(df, None, document, pltPath, 'DVM_3_09_Analog_Gain',
                                                        'RegWr00_COARSE_INTEGRATION_TIME_', showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_ColStdDev_Plot(df, None, document, pltPath, 'DVM_3_09_Analog_Gain',
                                                     'RegWr00_COARSE_INTEGRATION_TIME_', showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_ColTotalNoise_Plot(df, None, document, pltPath, 'DVM_3_09_Analog_Gain',
                                                         'RegWr00_COARSE_INTEGRATION_TIME_', showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_ColFPN_Plot(df, None, document, pltPath, 'DVM_3_09_Analog_Gain',
                                                  'RegWr00_COARSE_INTEGRATION_TIME_', showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_ColTempNoise_Plot(df, None, document, pltPath, 'DVM_3_09_Analog_Gain',
                                                        'RegWr00_COARSE_INTEGRATION_TIME_', showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_Flicker_Plot(df, None, document, pltPath, 'DVM_3_09_Analog_Gain',
                                                   'RegWr00_COARSE_INTEGRATION_TIME_', showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_PixelTotalNoise_Plot(df, None, document, pltPath, 'DVM_3_09_Analog_Gain',
                                                           'RegWr00_COARSE_INTEGRATION_TIME_', showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_PixelTemporalNoise_Plot(df, None, document, pltPath, 'DVM_3_09_Analog_Gain',
                                                              'RegWr00_COARSE_INTEGRATION_TIME_', showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_PixelFPN_Plot(df, None, document, pltPath, 'DVM_3_09_Analog_Gain',
                                                    'RegWr00_COARSE_INTEGRATION_TIME_', showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_RowTemporalNoiseRatio_Plot(df, None, document, pltPath, 'DVM_3_09_Analog_Gain',
                                                                 'RegWr00_COARSE_INTEGRATION_TIME_', showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_ColumnTemporalNoiseRatio_Plot(df, None, document, pltPath, 'DVM_3_09_Analog_Gain',
                                                                    'RegWr00_COARSE_INTEGRATION_TIME_', showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_RowFPNRatio_Plot(df, None, document, pltPath, 'DVM_3_09_Analog_Gain',
                                                       'RegWr00_COARSE_INTEGRATION_TIME_', showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Img_ColumnFPNRatio_Plot(df, None, document, pltPath, 'DVM_3_09_Analog_Gain',
                                                          'RegWr00_COARSE_INTEGRATION_TIME_', showPlt)
    # Region vs Dual Register Plots
    VRG_Stats_Frame.Reg_vs_Reg_vs_Rgn_Mean_Plot(df, None, document, pltPath, 'DVM_3_09_Analog_Gain',
                                                'RegWr00_COARSE_INTEGRATION_TIME_', showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Rgn_StdDev_Plot(df, None, document, pltPath, 'DVM_3_09_Analog_Gain',
                                                  'RegWr00_COARSE_INTEGRATION_TIME_', showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Rgn_TotalNoise_Plot(df, None, document, pltPath, 'DVM_3_09_Analog_Gain',
                                                      'RegWr00_COARSE_INTEGRATION_TIME_', showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Rgn_FPN_Plot(df, None, document, pltPath, 'DVM_3_09_Analog_Gain',
                                               'RegWr00_COARSE_INTEGRATION_TIME_', showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Rgn_Temporal_Plot(df, None, document, pltPath, 'DVM_3_09_Analog_Gain',
                                                    'RegWr00_COARSE_INTEGRATION_TIME_', showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Rgn_RowStdDev_Plot(df, None, document, pltPath, 'DVM_3_09_Analog_Gain',
                                                     'RegWr00_COARSE_INTEGRATION_TIME_', showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Rgn_RowTotalNoise_Plot(df, None, document, pltPath, 'DVM_3_09_Analog_Gain',
                                                         'RegWr00_COARSE_INTEGRATION_TIME_', showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Rgn_RowFPN_Plot(df, None, document, pltPath, 'DVM_3_09_Analog_Gain',
                                                  'RegWr00_COARSE_INTEGRATION_TIME_', showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Rgn_RowTempNoise_Plot(df, None, document, pltPath, 'DVM_3_09_Analog_Gain',
                                                        'RegWr00_COARSE_INTEGRATION_TIME_', showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Rgn_ColStdDev_Plot(df, None, document, pltPath, 'DVM_3_09_Analog_Gain',
                                                     'RegWr00_COARSE_INTEGRATION_TIME_', showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Rgn_ColTotalNoise_Plot(df, None, document, pltPath, 'DVM_3_09_Analog_Gain',
                                                         'RegWr00_COARSE_INTEGRATION_TIME_', showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Rgn_ColFPN_Plot(df, None, document, pltPath, 'DVM_3_09_Analog_Gain',
                                                  'RegWr00_COARSE_INTEGRATION_TIME_', showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Rgn_ColTempNoise_Plot(df, None, document, pltPath, 'DVM_3_09_Analog_Gain',
                                                        'RegWr00_COARSE_INTEGRATION_TIME_', showPlt)
    VRG_Stats_Frame.Reg_vs_Reg_vs_Rgn_Flicker_Plot(df, None, document, pltPath, 'DVM_3_09_Analog_Gain',
                                                   'RegWr00_COARSE_INTEGRATION_TIME_', showPlt)