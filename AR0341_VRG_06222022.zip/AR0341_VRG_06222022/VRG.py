__author__ = 'fg83rh'

import matplotlib
import matplotlib.pyplot as plt
from matplotlib import pyplot
from docx import Document
from docx.shared import Inches
from docx.shared import Pt
from tkinter import *
from tkinter import filedialog
from tkinter import messagebox
from PIL import Image
import numpy as np
import csv
import argparse
import os
import pandas as pd
import pixelcrunch as pc
import fivecentplots as fcp
import bokeh
import sys
import io
import multiprocessing
import VRG_Safety_Data
import VRG_Calculate
import VRG_Data_Frame
import VRG_Doc
import VRG_General_Data
import VRG_Image_Analysis
import VRG_Image_Utils
import VRG_Macro_Data
import VRG_OTPM_Data
import VRG_Pins_Data
import VRG_Power_Data
import VRG_Register_Data
import VRG_Stats_Arr
import VRG_Stats_ArrCenter
import VRG_Stats_ArrQuad1
import VRG_Stats_ArrQuad2
import VRG_Stats_ArrQuad3
import VRG_Stats_ArrQuad4
import VRG_Stats_ArrRoi1
import VRG_Stats_ArrRoi2
import VRG_Stats_ArrRoi3
import VRG_Stats_ArrRoi4
import VRG_Stats_ArrRoi5
import VRG_Stats_ArrRoi6
import VRG_Stats_ArrRoi7
import VRG_Stats_ArrRoi8
import VRG_Stats_ArrRoi9
import VRG_Stats_DBLC
import VRG_Stats_Frame
import VRG_Stats_Lag
import VRG_Stats_RNC
import VRG_Stats_Tilt
import VRG_Tempsensor_Data
import VRG_Reports
import time

if __name__ == '__main__':
    '''
    Gui Setup 
    '''
    engrNameDef = "Travis Oliver - FG83RH"  # Engineer Name & EID
    designIdDef = "AR0341-R034A"  # Project Name
    designRevDef = "1.0"  # Silicon Revision

    # Program Path
    program_path = os.path.dirname(sys.argv[0])

    # Gui Design
    windowTitleText = "VALIDATION REPORT GENERATION (VGR) APP"
    windowLogo_check = os.path.isfile(program_path + '/OnSemiLogo.png')

    # Output Error Message If File Does Not Exist
    if not windowLogo_check:
        print("File Does Not Exist : ", program_path + '/OnSemiLogo.png')
    else:
        print(program_path + '/OnSemiLogo.png', "File Exists")

    #ONSEMI Logo
    # image = Image.open(program_path + '/OnSemiLogo.png')
    # # The (450, 350) is (height, width)
    # image = image.resize((150, 50), Image.ANTIALIAS)
    # image.save(program_path + '/OnSemiLogo.png')

    windowLogo = program_path + '/OnSemiLogo.png'

    # Gui Background
    mainBg = 'gray20'

    # FCP Design
    fcpThemeColor = 'white' #'gray'

    # Template File
    valTemplate_check = os.path.isfile(program_path + '/ES_Validation_Template.docx')

    # Output Error Message If File Does Not Exist
    if not windowLogo_check:
        print("File Does Not Exist : ", program_path + '/ES_Validation_Template.docx')
    else:
        print(program_path + '/ES_Validation_Template.docx' + '/OnSemiLogo.png', "File Exists")

    valTemplate = program_path + '/ES_Validation_Template.docx'

    # Label Text
    infileLblText1 = "Select CSV File 1:"
    infileLblText2 = "Select CSV File 2:"
    infileLblText3 = "Select CSV File 3:"
    infileLblText4 = "Select CSV File 4:"
    infileLblText5 = "Select CSV File 5:"
    infileLblText6 = "Select CSV File 6:"
    infileLblText7 = "Select CSV File 7:"
    infileLblText8 = "Select CSV File 8:"
    infileLblText9 = "Select CSV File 9:"
    imgpathLblText = "Select External Image Directory:"
    outfileLblText1 = "Select Report Directory:"
    outfileLblText2 = "Input Report Name:"
    pltsavepathLblText = "Select Plot Directory:"
    testBoxLblText = "Select Report Name:"
    engrNameLblText = "Enter Engineer Name:"
    designIdLblText = "Enter Product ID:"
    designRevLblText = "Enter Silicon Revision:"

    # Padding Values
    padY = 5
    padX = 5

    # Default Entry Text
    csvFileDef1 = ''
    csvFileDef2 = ''
    csvFileDef3 = ''
    csvFileDef4 = ''
    csvFileDef5 = ''
    csvFileDef6 = ''
    csvFileDef7 = ''
    csvFileDef8 = ''
    csvFileDef9 = ''

    # Check for correct file paths
    imgPathDef_check = os.path.isdir(program_path + '/Images/')
    reportFileDirDef_path_check = os.path.isdir(program_path + '/Reports/')
    pltPathDef_check = os.path.isdir(program_path + '/Plots/')
    trackingPathDef_check =  os.path.isdir(program_path + '/Tracking/')

    # Create file path if it doesnt exist
    if not imgPathDef_check:
        os.makedirs(program_path + '/Images/')
        print("Created Folder : ", program_path + '/Images/')
    else:
        print(program_path + '/Images/', "Folder Exists")

    # Create file path if it doesnt exist
    if not reportFileDirDef_path_check:
        os.makedirs(program_path + '/Reports/')
        print("Created Folder : ", program_path + '/Reports/')
    else:
        print(program_path + '/Reports/', "Folder Exists")

    # Create file path if it doesnt exist
    if not pltPathDef_check:
        os.makedirs(program_path + '/Plots/')
        print("Created Folder : ", program_path + '/Plots/')
    else:
        print(program_path + '/Plots/', "Folder Exists")

    # Create file path if it doesnt exist
    if not trackingPathDef_check:
        os.makedirs(program_path + '/Tracking/')
        print("Created Folder : ", program_path + '/Tracking/')
    else:
        print(program_path + '/Tracking/', "Folder Exists")

    imgPathDef = program_path + '/Images/' # Image Directory Path
    reportFileDirDef = program_path + '/Reports/' # Report Directory
    reportFileDef = "myReport1.docx" # Report Name (.docx)
    pltPathDef = program_path + '/Plots/' # Plot Directory
    trackingPathDef = program_path + '/Tracking/'  # Plot Directory

    # Button Text
    infileBtnDef1 = "CSV File 1"
    infileBtnDef2 = "CSV File 2"
    infileBtnDef3 = "CSV File 3"
    infileBtnDef4 = "CSV File 4"
    infileBtnDef5 = "CSV File 5"
    infileBtnDef6 = "CSV File 6"
    infileBtnDef7 = "CSV File 7"
    infileBtnDef8 = "CSV File 8"
    infileBtnDef9 = "CSV File 9"
    imgfileBtnDef = "Ext. Image Directory"
    outfileBtnDef1 = "Report Directory"
    outfileBtnDef2 = "Report Name"
    pltfileBtnDef = "Plot Directory"
    runBtnDef = "RUN"
    quitBtnDef = "EXIT"

    window = Tk()
    window.title(windowTitleText)
    screen_width = window.winfo_screenwidth()
    screen_height = window.winfo_screenheight()
    if screen_height <=1200:
        windowSize = '1100x800'

        # Label Design
        lblFG = 'white'
        lblFont = "Helvetica 8 bold"
        entryFont = "Helvetica 8 bold"
        scrollFont = "Helvetica 8 bold"

        # Button Design
        btnBG = 'Slategray4'
        btnFG = 'black'
        btnFont = "Helvetica 8 bold"
        runBtnBG = 'green3'
        runBtnFG = 'black'
        runBtnFont = "Helvetica 8 bold"
        quitBtnBG = 'firebrick1'
        quitBtnFG = 'white'
        quitBtnFont = "Helvetica 8 bold"
    elif screen_height > 1200:
        windowSize = '1300x900'

        # Label Design
        lblFG = 'white'
        lblFont = "Helvetica 10 bold"
        entryFont = "Helvetica 10 bold"
        scrollFont = "Helvetica 10 bold"

        # Button Design
        btnBG = 'Slategray4'
        btnFG = 'black'
        btnFont = "Helvetica 10 bold"
        runBtnBG = 'green3'
        runBtnFG = 'black'
        runBtnFont = "Helvetica 10 bold"
        quitBtnBG = 'firebrick1'
        quitBtnFG = 'white'
        quitBtnFont = "Helvetica 10 bold"

    window.geometry(windowSize)
    window.minsize(100, 100)
    window.configure(bg=mainBg)
    logo = PhotoImage(file=windowLogo)
    logoLbl = Label(window, image=logo).grid(row=0, column=4, columnspan=2, rowspan=3, sticky=W+N, padx=padX, pady=padY)

    infilepathLbl1 = Label(window)
    infilenameLbl1 = Label(window)
    infileLbl1 = Label(window, text=infileLblText1, bg=mainBg, fg=lblFG, font=lblFont)
    infileLbl1.grid(row=0, column=1, pady=padY, sticky=E)

    infilepathLbl2 = Label(window)
    infilenameLbl2 = Label(window)
    infileLbl2 = Label(window, text=infileLblText2, bg=mainBg, fg=lblFG, font=lblFont)
    infileLbl2.grid(row=1, column=1, pady=padY, sticky=E)

    infilepathLbl3 = Label(window)
    infilenameLbl3 = Label(window)
    infileLbl3 = Label(window, text=infileLblText3, bg=mainBg, fg=lblFG, font=lblFont)
    infileLbl3.grid(row=2, column=1, pady=padY, sticky=E)

    infilepathLbl4 = Label(window)
    infilenameLbl4 = Label(window)
    infileLbl4 = Label(window, text=infileLblText4, bg=mainBg, fg=lblFG, font=lblFont)
    infileLbl4.grid(row=3, column=1, pady=padY, sticky=E)

    infilepathLbl5 = Label(window)
    infilenameLbl5 = Label(window)
    infileLbl5 = Label(window, text=infileLblText5, bg=mainBg, fg=lblFG, font=lblFont)
    infileLbl5.grid(row=4, column=1, pady=padY, sticky=E)

    infilepathLbl6 = Label(window)
    infilenameLbl6 = Label(window)
    infileLbl6 = Label(window, text=infileLblText6, bg=mainBg, fg=lblFG, font=lblFont)
    infileLbl6.grid(row=5, column=1, pady=padY, sticky=E)

    infilepathLbl7 = Label(window)
    infilenameLbl7 = Label(window)
    infileLbl7 = Label(window, text=infileLblText7, bg=mainBg, fg=lblFG, font=lblFont)
    infileLbl7.grid(row=6, column=1, pady=padY, sticky=E)

    infilepathLbl8 = Label(window)
    infilenameLbl8 = Label(window)
    infileLbl8 = Label(window, text=infileLblText8, bg=mainBg, fg=lblFG, font=lblFont)
    infileLbl8.grid(row=7, column=1, pady=padY, sticky=E)

    infilepathLbl9 = Label(window)
    infilenameLbl9 = Label(window)
    infileLbl9 = Label(window, text=infileLblText9, bg=mainBg, fg=lblFG, font=lblFont)
    infileLbl9.grid(row=8, column=1, pady=padY, sticky=E)

    imgpathLbl= Label(window, text=imgpathLblText, bg=mainBg, fg=lblFG, font=lblFont)
    imgpathLbl.grid(row=9, column=1, pady=padY, sticky=E)

    outfilepathLbl1 = Label(window)
    outfilenameLbl1 = Label(window)
    outfileLbl1 = Label(window, text=outfileLblText1, bg=mainBg, fg=lblFG, font=lblFont)
    outfileLbl1.grid(row=10, column=1, pady=padY, sticky=E)

    outfilepathLbl2 = Label(window)
    outfilenameLbl2 = Label(window)
    outfileLbl2 = Label(window, text=outfileLblText2, bg=mainBg, fg=lblFG, font=lblFont)
    outfileLbl2.grid(row=11, column=1, pady=padY, sticky=E)

    pltsavepathLbl= Label(window, text=pltsavepathLblText, bg=mainBg, fg=lblFG, font=lblFont)
    pltsavepathLbl.grid(row=12, column=1, pady=padY, sticky=E)

    testBoxLbl = Label(window, text=testBoxLblText, bg=mainBg, fg=lblFG, font=lblFont)
    testBoxLbl.grid(row=13, column=1, pady=padY, sticky=E)

    engrNameLbl = Label(window, text=engrNameLblText, bg=mainBg, fg=lblFG, font=lblFont)
    engrNameLbl.grid(row=14, column=1, pady=padY, sticky=E)

    designIdLbl = Label(window, text=designIdLblText, bg=mainBg, fg=lblFG, font=lblFont)
    designIdLbl.grid(row=15, column=1, pady=padY, sticky=E)

    designRevLbl = Label(window, text=designRevLblText, bg=mainBg, fg=lblFG, font=lblFont)
    designRevLbl.grid(row=16, column=1, pady=padY, sticky=E)

    infilepathEnt1 = Entry(window, width=0)#fake label for file path
    infilenameEnt1 = Entry(window, width=0)#fake label for file name
    infileEnt1 = Entry(window, width=100)
    infileEnt1.insert(0, csvFileDef1) #C:/Users/fgxxxx/Documents/ValidationData.csv
    infileEnt1.configure(font=entryFont)
    infileEnt1.grid(row=0, column=2, pady=padY, padx=padX)

    infilepathEnt2 = Entry(window, width=0)#fake label for file path
    infilenameEnt2 = Entry(window, width=0)#fake label for file name
    infileEnt2 = Entry(window, width=100)
    infileEnt2.insert(0, csvFileDef2) #C:/Users/fgxxxx/Documents/ValidationData.csv
    infileEnt2.configure(font=entryFont)
    infileEnt2.grid(row=1, column=2, pady=padY, padx=padX)

    infilepathEnt3 = Entry(window, width=0)#fake label for file path
    infilenameEnt3 = Entry(window, width=0)#fake label for file name
    infileEnt3 = Entry(window, width=100)
    infileEnt3.insert(0, csvFileDef3) #C:/Users/fgxxxx/Documents/ValidationData.csv
    infileEnt3.configure(font=entryFont)
    infileEnt3.grid(row=2, column=2, pady=padY, padx=padX)

    infilepathEnt4 = Entry(window, width=0)#fake label for file path
    infilenameEnt4 = Entry(window, width=0)#fake label for file name
    infileEnt4 = Entry(window, width=100)
    infileEnt4.insert(0, csvFileDef4) #C:/Users/fgxxxx/Documents/ValidationData.csv
    infileEnt4.configure(font=entryFont)
    infileEnt4.grid(row=3, column=2, pady=padY, padx=padX)

    infilepathEnt5 = Entry(window, width=0)#fake label for file path
    infilenameEnt5 = Entry(window, width=0)#fake label for file name
    infileEnt5 = Entry(window, width=100)
    infileEnt5.insert(0, csvFileDef5) #C:/Users/fgxxxx/Documents/ValidationData.csv
    infileEnt5.configure(font=entryFont)
    infileEnt5.grid(row=4, column=2, pady=padY, padx=padX)

    infilepathEnt6 = Entry(window, width=0)#fake label for file path
    infilenameEnt6 = Entry(window, width=0)#fake label for file name
    infileEnt6 = Entry(window, width=100)
    infileEnt6.insert(0, csvFileDef6) #C:/Users/fgxxxx/Documents/ValidationData.csv
    infileEnt6.configure(font=entryFont)
    infileEnt6.grid(row=5, column=2, pady=padY, padx=padX)

    infilepathEnt7 = Entry(window, width=0)#fake label for file path
    infilenameEnt7 = Entry(window, width=0)#fake label for file name
    infileEnt7 = Entry(window, width=100)
    infileEnt7.insert(0, csvFileDef7) #C:/Users/fgxxxx/Documents/ValidationData.csv
    infileEnt7.configure(font=entryFont)
    infileEnt7.grid(row=6, column=2, pady=padY, padx=padX)

    infilepathEnt8 = Entry(window, width=0)#fake label for file path
    infilenameEnt8 = Entry(window, width=0)#fake label for file name
    infileEnt8 = Entry(window, width=100)
    infileEnt8.insert(0, csvFileDef8) #C:/Users/fgxxxx/Documents/ValidationData.csv
    infileEnt8.configure(font=entryFont)
    infileEnt8.grid(row=7, column=2, pady=padY, padx=10)

    infilepathEnt9 = Entry(window, width=0)#fake label for file path
    infilenameEnt9 = Entry(window, width=0)#fake label for file name
    infileEnt9 = Entry(window, width=100)
    infileEnt9.insert(0, csvFileDef9) #C:/Users/fgxxxx/Documents/ValidationData.csv
    infileEnt9.configure(font=entryFont)
    infileEnt9.grid(row=8, column=2, pady=padY, padx=10)

    imgSavePathLbl = Entry(window, width=0) #fake label for file path
    imgSavePathEnt = Entry(window, width=100)
    imgSavePathEnt.insert(0, imgPathDef) #C:/Users/fgxxxx/Documents/
    imgSavePathEnt.configure(font=entryFont)
    imgSavePathEnt.grid(row=9, column=2, pady=padY, padx=10)

    outfilepathLbl1 = Entry(window, width=0) #fake label for file path
    outfilenameLbl1 = Entry(window, width=0) #fake label for file name
    outfileEnt1 = Entry(window, width=100)
    outfileEnt1.insert(0, reportFileDirDef)#C:/Users/fgxxxx/Documents/ReportName.docx
    outfileEnt1.configure(font=entryFont)
    outfileEnt1.grid(row=10, column=2, pady=padY, padx=10)

    outfilepathLbl2 = Entry(window, width=0) #fake label for file path
    outfilenameLbl2 = Entry(window, width=0) #fake label for file name
    outfileEnt2 = Entry(window, width=100)
    outfileEnt2.insert(0, reportFileDef)#C:/Users/fgxxxx/Documents/ReportName.docx
    outfileEnt2.configure(font=entryFont)
    outfileEnt2.grid(row=11, column=2, pady=padY, padx=10)

    pltSavePathLbl = Entry(window, width=0) #fake label for file path
    pltSavePathEnt = Entry(window, width=100)
    pltSavePathEnt.insert(0, pltPathDef) #C:/Users/fgxxxx/Documents/
    pltSavePathEnt.configure(font=entryFont)
    pltSavePathEnt.grid(row=12, column=2, pady=padY, padx=10)

    scrollbar = Scrollbar(window)
    scrollbar.grid(row=13, column=3, pady=padY, padx=10, sticky=N+S+W)
    testBox = Listbox(window, width=100)
    testBox.config(yscrollcommand=scrollbar.set, font=scrollFont)
    testBox.grid(row=13, column=2, pady=padY, padx=10, sticky=W+E)
    scrollbar.config(command=testBox.yview)

    engrNameEnt = Entry(window, width=100)
    engrNameEnt.insert(0, engrNameDef)
    engrNameEnt.configure(font=entryFont)
    engrNameEnt.grid(row=14, column=2, pady=padY, padx=10, sticky=W)

    designIdEnt = Entry(window, width=100)
    designIdEnt.insert(0, designIdDef)
    designIdEnt.configure(font=entryFont)
    designIdEnt.grid(row=15, column=2, pady=padY, padx=10, sticky=W)

    designRevEnt = Entry(window, width=100)
    designRevEnt.insert(0, designRevDef)
    designRevEnt.configure(font=entryFont)
    designRevEnt.grid(row=16, column=2, pady=padY, padx=10, sticky=W)

    tests = ["-- SELECT REPORT TO GENERATE --",
             "DV_CUSTOM_TEST_1",
             "DV_CUSTOM_TEST_2",
             "DV_CUSTOM_TEST_3",
             "DV_CUSTOM_TEST_4",
             "DV_CUSTOM_TEST_5",
             "DV_CUSTOM_TEST_6",
             "DV_CUSTOM_TEST_7",
             "DV_CUSTOM_TEST_8",
             "DV_CUSTOM_TEST_9",
             "DV_CUSTOM_TEST_10",
             "DV_0_00_ASIC_RAPID_CHECK",
             "DV_0_01_GLOBAL_FUNCTIONS",
             "DV_0_01_FRAME_RATE_ARGO",
             "DV_1_00_STANDBY_CURRENT",
             "DV_1_00_OPERATING_CURRENT",
             "DV_1_01_POWER_UP_SEQUENCE",
             "DV_1_01_POWER_UP_SEQUENCE_MIN",
             "DV_1_01_POWER_UP_SEQUENCE_NOM",
             "DV_1_01_POWER_UP_SEQUENCE_MAX",
             "DV_1_02_POWER_DOWN_SEQUENCE",
             "DV_1_03_HARD_RESET",
             "DV_1_04_SOFT_RESET",
             "DV_1_05_HARD_STANDBY",
             "DV_1_06_SOFT_STANDBY",
             "DV_1_07_DEFAULT_REGISTER_SHORT",
             "DV_1_07_DEFAULT_REGISTER",
             "DV_1_08_OPERATING_MODES",
             "DV_1_09_CONTEXT_SWITCHING_REGISTER",
             "DV_1_09_CONTEXT_SWITCHING_RAM_AUTOMATIC",
             "DV_1_09_CONTEXT_SWITCHING_RAM_MANUAL",
             "DV_1_09_CONTEXT_SWITCHING_RAM_CUSTOMER",
             "DV_1_10_DYNAMIC_GAIN_AND_EXPOSURE_CHANGES",
             "DV_1_10_DYNAMIC_EXPOSURE_CHANGES",
             "DV_1_11_IMAGE_PERFORMANCE_IN_STREAMING",
             "DV_2_01_POR_BYPASS",
             "DV_2_02_TRIM_CALCULATE",
             "DV_2_02_REFERENCE_CURRENT",
             "DV_2_02_REFERENCE_VOLTAGE",
             "DV_2_02_REFERENCE_CURRENT_VS_TRIM",
             "DV_2_02_REFERENCE_VOLTAGE_VS_TRIM",
             "DV_2_03_ADC_TEST_MODE",
             "DV_2_04_ASC_TEST_MODE",
             "DV_2_05_PLL_BYPASS",
             "DV_2_06_NAND_TREE",
             "DV_2_07_MEMORY_BIST",
             "DV_2_08_SCAN_CHAIN",
             "DV_2_08_BOUNDRY_SCAN_CHAIN",
             "DV_2_09_INPUT_OUTPUT_LEAKAGE",
             "DV_2_11_COLUMN_MEMORY",
             "DV_2_12_DIGITAL_TEST_PATTERN_LEGACY",
             "DV_2_12_DIGITAL_TEST_PATTERN_TPG",
             "DV_2_13_PFA_PROCEDURES_DOCUMENT_VALIDATION",
             "DV_2_14_ALTERNATING_COLUMN_MODE",
             "DV_3_00_LINEARITY_IMAGE_ANALYSIS",
             "DV_3_01_DARK_IMAGE_ANALYSIS",
             "DV_3_02_LOW_MIDLEVEL_IMAGE_ANALYSIS",
             "DV_3_03_SATURATED_IMAGE_ANALYSIS",
             "DV_3_04_PIXOUT_AND_ROW_DRIVER_ANALYSIS",
             "DV_3_04_PIXOUT_ANALYSIS",
             "DV_3_05_OFFSET_DAC",
             "DV_3_06_DATA_PEDESTAL",
             "DV_3_07_ADC",
             "DV_3_07_ADC_E1",
             "DV_3_07_ADC_E2",
             "DV_3_07_ADC_E3",
             "DV_3_07_ADC_T2",
             "DV_3_08_DIGITAL_GAIN",
             "DV_3_08_DIGITAL_GAIN_PRE_HDR",
             "DV_3_08_DIGITAL_GAIN_TPG_PRE_HDR",
             "DV_3_08_DIGITAL_GAIN_POST_HDR",
             "DV_3_08_DIGITAL_GAIN_TPG_POST_HDR",
             "DV_3_09_ANALOG_GAIN",
             "DV_3_10_BLACK_LEVEL_OPERATION",
             "DV_3_11_OFFSET_CORRECTION",
             "DV_3_12_FINE_DIGITAL_CORRECTION",
             "DV_3_13_COLUMN_FPN_CORRECTION",
             "DV_3_14_ANALOG_ROW_WISE_CORRECTION",
             "DV_3_15_DIGITAL_ROW_WISE_CORRECTION",
             "DV_3_16_COLUMN_BALANCE",
             "DV_3_17_AUTOMATIC_GAIN_SELECTION",
             "DV_3_18_DARK_CURRENT_AND_DELTA_DARK_OPERATION",
             "DV_3_19_ANTI_ECLIPSE",
             "DV_3_20_ROW_COLUMN_BANDING",
             "DV_3_21_FUSE_BASED_DEFECT_CORRECTION",
             "DV_3_22_HORIZONTAL_MIRROR",
             "DV_3_22_VERTICAL_FLIP",
             "DV_3_22_HORIZONTAL_MIRROR_AND_VERTICAL_FLIP",
             "DV_3_24_VALIDATE_PIXEL_ARRAY_ARCHITECTURE",
             "DV_3_25_PSRR",
             "DV_3_25_PSRR_VAA",
             "DV_3_25_PSRR_VDD",
             "DV_3_25_PSRR_VAAPIX",
             "DV_3_25_PSRR_VAA2V8",
             "DV_3_25_PSRR_VAA1V8",
             "DV_3_26_CONTINUOUS_TRIGGER_MODE",
             "DV_3_26_PULSE_TRIGGER_MODE",
             "DV_3_26_SHUTTER_SYNC_TRIGGER_MODE",
             "DV_3_27_GLOBAL_RESET_RELEASE",
             "DV_3_28_FLOATING_NODE_CHECK",
             "DV_3_29_COLUMN_BINNING_AND_ROW_SKIPPING",
             "DV_3_29_SKIPPING_SUB_SAMPLING",
             "DV_3_30_ANALOG_BINNING",
             "DV_3_31_SCALAR",
             "DV_3_32_DYNAMIC_POWER_MODE",
             "DV_3_33_SLAVE_MODE",
             "DV_3_34_COLUMN_SHUFFLE_MODE",
             "DV_3_35_HORIZONTAL_SHADING_CORRECTION",
             "DV_3_36_GLOBAL_GRADIENT_REMOVAL",
             "DV_3_37_DIGITAL_CROP_WINDOWING",
             "DV_3_39_HDR_MULTIPLE_EXPOSURE",
             "DV_3_39_SE_MULTIPLE_EXPOSURE",
             "DV_3_40_IHDR_INTERLACED_HDR",
             "DV_3_41_LINE_INTERLEAVED_HDR_AMBARELLA_READOUT_MODE",
             "DV_3_41_DUAL_OUTPUT_MODE",
             "DV_3_42_HDR_COMPANDING",
             "DV_3_43_GLOBAL_SHUTTER",
             "DV_3_44_LED_FLICKER_MITIGATION",
             "DV_3_45_EXPOSURE_TEST",
             "DV_3_45_EXPOSURE_TEST_T1",
             "DV_3_45_EXPOSURE_TEST_EXPOSURE_RATIO",
             "DV_3_45_EXPOSURE_TEST_T2",
             "DV_3_46_LAG_CORRECTION",
             "DV_3_47_LOW_POWER_MODE",
             "DV_3_50_SMART_ROI",
             "DV_3_50_EIGHT_ROI",
             "DV_4_01_DYNAMIC_DEFECT_PIXEL_CORRECTION",
             "DV_4_02_LENS_SHADING_CORRECTION",
             "DV_4_03_DYNAMIC_CLUSTER_CORRECTION",
             "DV_4_04_FLASH_SUPPORT",
             "DV_4_05_DYNAMIC_SEQUENCER",
             "DV_4_06_COLOR_CORRECTION_MATRIX",
             "DV_4_07_AUTO_EXPOSURE",
             "DV_4_08_ADACD",
             "DV_4_09_MOTION_COMPENSATION",
             "DV_5_01_POR",
             "DV_5_02_OTPM",
             "DV_5_03_FIFO_AND_WATERMARK",
             "DV_5_04_PIN_FUNCTIONALITY_AND_IO_PAD_TEST",
             "DV_5_05_STREAMING_AND_BLANKING",
             "DV_5_06_ITU_R_BTU_656",
             "DV_5_07_DUAL_CAMERA_OPERATION",
             "DV_5_08_FUSE_ID_AND_CUSTOMER_REVISION",
             "DV_5_09_MIPI",
             "DV_5_10_VOICE_COIL_MOTOR_VCM_DRIVER",
             "DV_5_11_VOLTAGE_REGULATOR",
             "DV_5_11_LDO_OUTPUT_MEASURE_VS_TRIM",
             "DV_5_11_LDO_OUTPUT_MEASURE",
             "DV_5_12_I2C_CCI_CAMERA_CONTROL_INTERFACE",
             "DV_5_14_HISPI_SLVS",
             "DV_5_16_STEREO_MODE",
             "DV_5_17_TEMPERATURE_SENSOR",
             "DV_5_17_TEMPERATURE_SENSOR_IP_TEMPSENSOR",
             "DV_5_17_TEMPERATURE_SENSOR_DIODE_1",
             "DV_5_17_TEMPERATURE_SENSOR_DIODE_2",
             "DV_5_17_TEMPERATURE_SENSOR_DIODE_SEQUENCE",
             "DV_5_17_TEMPERATURE_SENSOR_SAFETY_PTAT_MODE",
             "DV_5_17_TEMPERATURE_SENSOR_SAFETY_CONSTANT_MODE",
             "DV_5_17_TEMPERATURE_SENSOR_SAFETY_SEQUENCE",
             "DV_5_17_TEMPERATURE_SENSOR_SCHMOO",
             "DV_5_18_PLL",
             "DV_5_19_NTSC",
             "DV_5_20_THREE_WIRE_SERIAL_INTERFACE",
             "DV_5_21_OUTPUT_DATA_COMPRESSION",
             "DV_5_22_EMBEDDED_DATA_AND_STATISTICS_ROWS",
             "DV_5_23_I2C_FEATURE_LOCK",
             "DV_5_24_ETHERNET",
             "DV_5_24_MIPI_LOOPBACK_DPHY",
             "DV_5_24_MIPI_LOOPBACK_DPHY_SDR",
             "DV_5_24_MIPI_LOOPBACK_DPHY_DDR",
             "DV_5_24_MIPI_LOOPBACK_CPHY",
             "DV_5_25_SERIAL_PERIPHERAL_INTERFACE_SPI",
             "DV_6_01_LINEAR_FULL_WELL",
             "DV_6_02_SATURATION_FULL_WELL",
             "DV_6_03_CONVERSION_GAIN_TF",
             "DV_6_04_ISO_GAINS_MAPPED_TO_ANALOG_DIGITAL_GAINS",
             "DV_6_05_READOUT_NOISE_VS_GAIN_BOTH_ANALOG_AND_ISO",
             "DV_6_06_PTC_FOR_ALL_GAINS_BOTH_ANALOG_AND_ISO",
             "DV_6_07_RESPONSIVITY_VLUXS_KELUXS",
             "DV_6_08_CHARGING_LAG",
             "DV_6_09_DISCHARGING_LAG",
             "DV_6_10_CHARGE_SHARING_LAG",
             "DV_6_11_BLOOMING_TEST",
             "DV_6_12_ROW_BANDING",
             "DV_6_13_COLOR_RATIO_VS_EXPOSURE",
             "DV_6_14_COLOR_RATIO_VS_F_NUMBER",
             "DV_6_15_LINE_CRAWL",
             "DV_6_16_QE_PLUS_RELATIVE_RESPONSE_ETC",
             "DV_6_17_LINEARITY_FOR_DIFFERENT_GAINS",
             "DV_6_18_SPATIAL_NOISE_PFPN_VS_SIGNAL",
             "DV_6_19_BLACK_LEVEL_VS_GAIN",
             "DV_6_20_BLACK_LEVEL_UNIFORMITY_VS_GAIN",
             "DV_6_21_DARK_CURRENT",
             "DV_6_22_S_CURVE",
             "DV_6_23_ISO_SNR_COMPLETE_CURVE",
             "DV_6_24_LATEST_NOKIA_SNR_COMPLETE_CURVE",
             "DV_6_25_APTINA_SNR_COMPLETE_CURVE",
             "DV_6_26_IMAGE_CAPTURE_STAND_SCENE",
             "DV_6_27_IMAGE_CAPTURE_IECF_CHART",
             "DV_6_28_IMAGE_CAPTURE_MACBETH",
             "DV_6_29_IMAGE_CAPTURE_FLAT_FIELD",
             "DV_6_30_IMAGE_CAPTURE_RESOLUTION_CHART",
             "DV_6_31_IMAGE_CAPTURE_MOAS",
             "DV_6_32_IMAGE_CAPTURE_MACBETH_SCENE_VS_TEMPERATURE",
             "DV_6_33_IMAGE_CAPTURE_FULL_SCC",
             "DV_6_34_IMAGE_CAPTURE_MINI_SCC",
             "DV_6_35_MODULATION_TRANSFER_FUNCTION_MTF",
             "DV_7_01_AC_CHARACTERIZATION_OF_PARALLEL_INTERFACE",
             "DV_7_06_DC_CHARACTERIZATION_OF_I_O_LOGIC_LEVELS",
             "DV_8_01_ESD",
             "DV_8_02_ABSOLUTE_MAXIMUM_RATINGS",
             "DV_8_03_HTOL",
             "DV_8_04_LTOL",
             "DV_8_05_HAST",
             "DV_8_06_T_C",
             "DV_8_07_HTOL_PARAMETRIC_DRIFT_ANALYSIS",
             "DV_9_01_AUTO_FOCUS_AF",
             "DV_9_03_JPEG",
             "DV_9_04_CPIPE_ARCHITECTURE",
             "DV_9_07_WHITE_BALANCE",
             "DV_9_08_COLOR_CORRECTION_MATRIX_CCM",
             "DV_9_09_SHARPNESS",
             "DV_9_10_LENS_SHADING_CORRECTION",
             "DV_9_11_DEFECT_CORRECTION",
             "DV_9_12_ZOOM",
             "DV_9_13_NOISE_REDUCTION",
             "DV_9_14_SPECIAL_EFFECTS",
             "DV_9_15_COLOUR_KILL",
             "DV_9_16_AUTO_EXPOSURE",
             "DV_9_17_DEWARP_STE",
             "DV_9_18_BINNING",
             "DV_9_19_TONE_MAPPING",
             "DV_9_20_GAMMA",
             "DV_9_21_TEMPERATURE_TESTING_WITH_TUNED_CPIPE_SETTINGS",
             "DV_10_01_AUTO_EXPOSURE",
             "DV_10_02_AUTO_WHITE_BALANCE",
             "DV_10_03_COLOR_CORRECTION",
             "DV_10_04_BLACK_LEVEL_STATS_CONTROL",
             "DV_10_05_DEFECT_CORRECTION_SUPPORT",
             "DV_10_06_NOISE_REDUCTION_SUPPORT",
             "DV_10_07_TONE_MAPPING",
             "DV_10_08_CONTRAST_GAMMA",
             "DV_10_09_LOWLIGHT_STATS_CONTROL",
             "DV_10_10_CAMERA_ADAPTATION",
             "DV_10_11_CAMERA_CONTROL",
             "DV_10_12_SYSTEM_CONTROL",
             "DV_10_13_SYSTEM_CONFIGURATION",
             "DV_10_14_HOST_COMMAND_INTERFACE",
             "DV_10_15_SPI_NVM_SUPPORT",
             "DV_10_16_I2C_MASTER_NVM_SUPPORT",
             "DV_10_17_OTPM_SUPPORT",
             "DV_10_18_TEMPERATURE_SENSOR_SUPPORT",
             "DV_10_19_GPIO_SUPPORT",
             "DV_10_20_CALIBRATION_SUPPORT",
             "DV_10_21_EVENT_MONITORING",
             "DV_10_22_SENSOR_CONTROL",
             "DV_10_23_UART_CONTROL",
             "DV_10_24_DEWARP_SUPPORT",
             "DV_10_25_OVERLAY_SUPPORT",
             "DV_10_26_DIAGNOSTICS_SUPPORT",
             "DV_11_01_AUTOMOTIVE_VIEWING:_DRIVING_DAYTIME",
             "DV_11_02_AUTOMOTIVE_VIEWING:_DRIVING_LOW_LIGHT",
             "DV_11_03_SURVEILLANCE_CWF_LIGHTING",
             "DV_11_04_SURVEILLANCE_INDOOR_MIXED_LIGHT",
             "DV_11_05_SURVEILLANCE_PARKING_LOT_IN_LOW_LIGHT",
             "DV_11_06_SURVEILLANCE_OUTDOOR_MID_DAY",
             "DV_11_07_SURVEILLANCE_INDOOR_LOW_LIGHT",
             "DV_12_0_01_SM_M3ROM_UPLOAD_CRC",
             "DV_12_0_02_SM_OTPROM_UPLOAD_CRC",
             "DV_12_0_03_SM_STANDBY_REGISTER_CRC",
             "DV_12_0_04_SM_PDI_UPLOAD_CRC",
             "DV_12_0_05_SM_STANDBY_BIST_MEMORY",
             "DV_12_0_06_SM_STANDBY_TEST_FRAME",
             "DV_12_0_07_SM_SYS_CHECK",
             "DV_12_0_08_SM_AHM_BOOSTER_BANDGAP_MONITOR",
             "DV_12_0_09_SM_CHIP_SUPPLY_VOLTAGE_MONITOR",
             "DV_12_0_09_SM_CHIP_SUPPLY_VOLTAGE_MONITOR_SUPPLY_DECREASE",
             "DV_12_0_09_SM_CHIP_SUPPLY_VOLTAGE_MONITOR_SUPPLY_INCREASE",
             "DV_12_0_10_SM_TEMP_SENSOR",
             "DV_12_0_12_SM_AHM_ROW_ROM",
             "DV_12_0_12_SM_AHM_ROW_ROM_IMAGE_DATA",
             "DV_12_0_15_SM_AHM_SREG_READBACK",
             "DV_12_SM_ANALOG_TEST_ROWS",
             "DV_12_SM_ANALOG_TEST_ROWS_IMAGE_DATA",
             "DV_12_0_16_SM_ATR_COLUMN_MEMORY_TESTS",
             "DV_12_0_17_SM_ATR_COLUMN_ROM",
             "DV_12_0_18_SM_ATR_FRAME_CHANGE",
             "DV_12_0_19_SM_ATR_GRADIENT",
             "DV_12_0_20_SM_ATR_OVERDRIVE_1X",
             "DV_12_0_21_SM_ATR_OVERDRIVE_AT_GAIN",
             "DV_12_0_22_SM_ATR_VERT_PIXOUT_1",
             "DV_12_0_23_SM_ATR_VERT_PIXOUT_2",
             "DV_12_0_24_SM_ATR_ZEBRA_AB",
             "DV_12_0_25_SM_ATR_ZEBRA_BA",
             "DV_12_0_26_SM_ATR_OVERDRIVE_ROW_012345",
             "DV_12_0_27_SM_DIGITAL_FRAME_COUNTER",
             "DV_12_0_28_SM_AUTO_CHECK_ATR",
             "DV_12_CLOCK_COUNTING",
             "DV_12_0_29_SM_COUNT_CLK_OP",
             "DV_12_0_30_SM_COUNT_CLK_PIX",
             "DV_12_0_31_SM_COUNT_CLK_REG",
             "DV_12_0_32_SM_COUNT_EXTCLK",
             "DV_12_0_33_SM_CLK_PIX_COUNT_100",
             "DV_12_0_34_SM_CLK_OP_COUNT_100",
             "DV_12_0_35_SM_CLK_REG_COUNT_100",
             "DV_12_0_36_SM_DELAY_BUFFER_RAM_CRC",
             "DV_12_0_37_SM_DOUBLE_LOCK",
             "DV_12_0_38_SM_DTR",
             "DV_12_0_38_SM_DTR_IMAGE_DATA",
             "DV_12_0_39_SM_ECC_BLACK_LEVEL_RAM",
             "DV_12_0_40_SM_ECC_SEQUENCER_RAM",
             "DV_12_0_41_SM_EMBEDDED_DATA_CRC",
             "DV_12_0_41_SM_HOST_CHECK_EMBEDDED_REGISTER_DATA",
             "DV_12_0_42_SM_HOST_CHECK_INVALID_IMAGE",
             "DV_12_0_43_SM_HOST_CHECK_OPERATING_STATUS",
             "DV_12_0_44_SM_HOST_CHECK_STATISTICS_DATA",
             "DV_12_0_45_SM_I2C_CRC",
             "DV_12_0_46_SM_IMAGE_DATA_CRC",
             "DV_12_0_47_SM_TRANSPORT_ROW_TX",
             "DV_12_0_48_SM_MIPI_HISPI_CRC",
             "DV_12_0_49_SM_OTPM_ECC",
             "DV_12_0_50_SM_HOST_CHECK_TEMP_ENABLE",
             "DV_12_0_51_SM_MEC_CRC",
             "DV_12_0_61_SM_DDC_DEF_CNT",
             "DV_12_0_62_SM_ATR_ADC_LATCH",
             "DV_12_0_63_SM_ATR_OVERDRIVE_CODE_012",
             "DV_12_0_64_SM_ECC_CONTEXT_RAM",
             "DV_12_0_65_SM_CDS_MEM_CRC",
             "DV_12_0_65_SM_CDS_MEM_CRC_TOP",
             "DV_12_0_65_SM_CDS_MEM_CRC_BTM",
             "DV_12_0_66_SM_OFL_MEM_CRC",
             "DV_12_0_67_SM_DEF_CORR_RAM_CRC",
             "DV_12_0_68_SM_MC_RAM",
             "DV_12_0_69_SM_STATS_RAM_ECC",
             "DV_12_0_70_SM_MASTER_STATE_CHA_RES",
             "DV_12_0_71_SM_ADDR_STATE_CRC",
             "DV_12_0_72_SM_POWERON_MBIST",
             "DV_12_0_73_SM_POWERON_MBIST2",
             "DV_12_0_74_SM_HOST_CHECK_GPIO",
             "DV_12_0_75_SM_RESET",
             "DV_12_0_76_SM_MEC_CRC_NEW",
             "DV_12_0_77_SM_PDI_RAM_CRC",
             "DV_12_0_78_SM_TEST_FRAME",
             "DV_12_0_79_SM_ATR_GRAY_TRANSFER",
             "DV_12_0_80_SM_LRE_RAM_CRC",
             "DV_12_0_81_SM_ODP_BUFFER_CRC",
             "DV_12_0_82_SM_SCALER_RAM_CRC",
             "DV_12_0_83_SM_PDI_DEF_CNT",
             "DV_12_0_84_SM_ATR_OVERDRIVE_012",
             "DV_12_0_85_SM_ATR_OVERDRIVE_PSRR",
             "DV_12_0_86_SM_DTC",
             "DV_12_0_90_SM_SMART_CRC",
             "DV_12_0_91_SM_FIFO_CRC",
             "DV_12_0_92_SM_ATR_OVERDRIVE_4T",
             "DV_12_0_93_SM_DTR_MEC",
             "DV_12_0_94_SM_ATR_ECLIPSE",
             "DV_12_0_95_SM_ATR_ADAPT",
             "DV_12_0_97_SM_ATR_OVERDRIVE_3T",
             "DV_12_0_98_SM_TBRS_RAM_ECC",
             "DV_12_0_99_SM_TBRS_LOCKED_CRC",
             "DV_12_0_100_SM_TBRS_PROCESSING",
             "DV_12_0_108_SM_LDO_BG_MONITOR",
             "DV_12_0_109_SM_CHIP_SUPPLY_PMU_MONITOR",
             "DV_12_0_110_SM_SENSOR_HISPI_TX_RX_CRC",
             "DV_12_0_111_SM_STATS_MON_EXT",
             "DV_12_0_112_SM_DATA_FORMAT",
             "DV_12_0_113_SM_SENSOR_DATAPATH_BUFFER_CRC",
             "DV_12_0_114_SM_ASIC_DATAPATH_BUFFER_CRC",
             "DV_12_0_120_SM_BIN2_RAM_CRC",
             "DV_12_0_121_SM_24_TO_16_BUFFER_CRC",
             "DV_12_0_122_SM_ECC_TPG_RAM",
             "DV_12_0_177_SM_PDI_RAM_DED",
             "DV_12_1_00_SM_UPLOAD_CALIBRATION",
             "DV_12_1_00_SM_RUNTIME_CALIBRATION",
             "DV_12_1_00_SM_FAULT_CALIBRATION",
             "DV_12_1_00_SM_UPLOAD_PRE_CALIBRATION",
             "DV_12_1_00_SM_UPLOAD_FAULT_PRE_CALIBRATION",
             "DV_12_1_00_SM_UPLOAD",
             "DV_12_1_00_SM_UPLOAD_FAULT",
             "DV_12_1_00_SM_UPLOAD_RUNTIME",
             "DV_12_1_00_SM_TEST_FRAME",
             "DV_12_1_00_SM_TEST_FRAME_FAULT",
             "DV_12_1_00_SM_RESTORE_TEST_FRAME",
             "DV_12_1_00_SM_FAULT",
             "DV_12_1_00_SM_RESTORE_FAULT",
             "DV_12_1_00_SM_RUNTIME",
             "DV_12_1_00_SM_SAFE_STATE",
             "DV_12_1_00_SM_SEQUENCE",
             "DV_12_SM_FAULT_INJECT_ATR",
             "DV_12_SM_FAULT_INJECT_RRC",
             "DV_12_FAULT_MEMORY_TEST_1",
             "DV_12_FAULT_MEMORY_TEST_2",
             "DV_12_SM_MEMORY_CRC_TEST",
             "DV_13_1_IMPLANT_RECIPE_VERIFICATION",
             "DV_13_2_INLINE_CD_DATA_COLLECTION_PROCESS_RELEASE",
             "DV_13_3_FULL_SCRIBE_PARAM_VERIFICATION",
             "DV_13_4_ANOVA_MODEL_BOXES",
             "DV_13_5_PROBE_SUMMARY"]

    for test in tests:
        testBox.insert(END, test)

    def infileClick1(): # Get CSV 1 input file
        infile1 = filedialog.askopenfilename()
        infileEnt1.delete(0, END)
        infileEnt1.insert(0, infile1)# Update entry with file path and file name
        infileEnt1.configure(font=entryFont)

    def infileClick2(): # Get CSV 2 input file
        infile2 = filedialog.askopenfilename()
        infileEnt2.delete(0, END)
        infileEnt2.insert(0, infile2)  # Update entry with file path and file name
        infileEnt2.configure(font=entryFont)

    def infileClick3(): # Get CSV 3 input file
        infile3 = filedialog.askopenfilename()
        infileEnt3.delete(0, END)
        infileEnt3.insert(0, infile3)  #  Update entry with file path and file name
        infileEnt3.configure(font=entryFont)

    def infileClick4(): # Get CSV 1 input file
        infile4 = filedialog.askopenfilename()
        infileEnt4.delete(0, END)
        infileEnt4.insert(0, infile4)# Update entry with file path and file name
        infileEnt4.configure(font=entryFont)

    def infileClick5(): # Get CSV 2 input file
        infile5 = filedialog.askopenfilename()
        infileEnt5.delete(0, END)
        infileEnt5.insert(0, infile5)  # Update entry with file path and file name
        infileEnt5.configure(font=entryFont)

    def infileClick6(): # Get CSV 3 input file
        infile6 = filedialog.askopenfilename()
        infileEnt6.delete(0, END)
        infileEnt6.insert(0, infile6)  #  Update entry with file path and file name
        infileEnt6.configure(font=entryFont)

    def infileClick7(): # Get CSV 1 input file
        infile7 = filedialog.askopenfilename()
        infileEnt7.delete(0, END)
        infileEnt7.insert(0, infile7)# Update entry with file path and file name
        infileEnt7.configure(font=entryFont)

    def infileClick8(): # Get CSV 2 input file
        infile8 = filedialog.askopenfilename()
        infileEnt8.delete(0, END)
        infileEnt8.insert(0, infile8)  # Update entry with file path and file name
        infileEnt8.configure(font=entryFont)

    def infileClick9(): # Get CSV 3 input file
        infile9 = filedialog.askopenfilename()
        infileEnt9.delete(0, END)
        infileEnt9.insert(0, infile9)  #  Update entry with file path and file name
        infileEnt9.configure(font=entryFont)

    def imgfileDir(): #Get Directory for plots to be saved
        imgSavePathDir = filedialog.askdirectory()
        imgSavePathLbl.delete(0, END)
        imgSavePathLbl.insert(0, os.path.dirname(imgSavePathDir))  # file path only
        imgSavePathLbl.configure(font=entryFont)
        imgSavePathEnt.delete(0, END)
        imgSavePathEnt.insert(0, imgSavePathDir)
        imgSavePathEnt.configure(font=entryFont)  # Update entry with file path and file name

    def outfileClick1(): # Get directory for report to be saved
        outfileDir = filedialog.askdirectory()
        outfileEnt1.delete(0, END)
        outfileEnt1.insert(0, outfileDir)
        outfileEnt1.configure(font=entryFont) # Update entry with file path and file name

    def outfileClick2(): # Get file for report to be saved
        outfile = filedialog.askopenfilename()
        outfileEnt2.delete(0, END)
        outfileEnt2.insert(0, os.path.basename(outfile)) # file name only
        outfileEnt2.configure(font=entryFont) # Update entry with file path and file name

    def pltfileDir(): #Get Directory for plots to be saved
        pltSavePathDir = filedialog.askdirectory()
        pltSavePathLbl.delete(0, END)
        pltSavePathLbl.insert(0, os.path.dirname(pltSavePathDir))  # file path only
        pltSavePathLbl.configure(font=entryFont)

        pltSavePathEnt.delete(0, END)
        pltSavePathEnt.insert(0, pltSavePathDir)
        pltSavePathEnt.configure(font=entryFont)  # Update entry with file path and file name

    def VRG_Get_Inputs():
        timestamp = time.strftime("%m/%d/%Y %I:%M:%S %p")  # Time stamp
        print("VRG Get Inputs:", timestamp)


        # Get data from GUI window
        filePath1 = infileEnt1.get()
        dirPath1 = os.path.dirname(filePath1)
        filePath2 = infileEnt2.get()
        dirPath2 = os.path.dirname(filePath2)
        filePath3 = infileEnt3.get()
        dirPath3 = os.path.dirname(filePath3)
        filePath4 = infileEnt4.get()
        dirPath4 = os.path.dirname(filePath4)
        filePath5 = infileEnt5.get()
        dirPath5 = os.path.dirname(filePath5)
        filePath6 = infileEnt6.get()
        dirPath6 = os.path.dirname(filePath6)
        filePath7 = infileEnt7.get()
        dirPath7 = os.path.dirname(filePath7)
        filePath8 = infileEnt8.get()
        dirPath8 = os.path.dirname(filePath8)
        filePath9 = infileEnt9.get()
        dirPath9 = os.path.dirname(filePath9)
        imgPath = imgSavePathEnt.get()
        reportFileDir = outfileEnt1.get()
        reportFileName = outfileEnt2.get()
        reportFilePath = os.path.join(reportFileDir, reportFileName)
        pltPath = pltSavePathEnt.get()
        test = testBox.get(ACTIVE)
        engrName = engrNameEnt.get()
        designID = designIdEnt.get()
        designRev = designRevEnt.get()

        # Start time
        startTime = time.time()
        # After collecting inputs, start processing
        VRG_Start_Processing(filePath1, dirPath1, filePath2, dirPath2, filePath3, dirPath3, filePath4, dirPath4, filePath5, dirPath5,
                             filePath6, dirPath6, filePath7, dirPath7, filePath8, dirPath8, filePath9, dirPath9, imgPath, reportFileDir,
                             reportFileName, reportFilePath, pltPath, test, engrName, designID, designRev, startTime)


    def VRG_Start_Processing(filePath1, dirPath1, filePath2, dirPath2, filePath3, dirPath3, filePath4, dirPath4, filePath5, dirPath5,
                             filePath6, dirPath6, filePath7, dirPath7, filePath8, dirPath8, filePath9, dirPath9, imgPath, reportFileDir,
                             reportFileName, reportFilePath, pltPath, test, engrName, designID, designRev, startTime):

        timestamp = time.strftime("%m/%d/%Y %I:%M:%S %p")  # Time stamp
        print("VRG Start Processing:", timestamp)

        fileCnt = 9 #Expected ES level file count
        valFile = np.empty((0))
        filePaths = []

        # Check for valid CSV files to extract dataframes
        if os.path.exists(filePath1) == False:
            filePath1 = None # set filepath to None for checks later
            fileCnt -= 1 # decrement file count
        elif os.path.exists(filePath1) == True:
            df1 = VRG_Data_Frame.dataframe(filePath1) # Get the dataframe
            df1 = VRG_Data_Frame.dataframe_imagelink(df1, dirPath1) #update imagelinks with directory
            valFile = np.append(valFile, "1")
            filePaths.append(filePath1)

        if os.path.exists(filePath2) == False:
            filePath2 = None # set filepath to None for checks later
            fileCnt -= 1 # decrement file count
        elif os.path.exists(filePath2) == True:
            df2 = VRG_Data_Frame.dataframe(filePath2) # Get the dataframe
            df2 = VRG_Data_Frame.dataframe_imagelink(df2, dirPath2) #update imagelinks with directory
            valFile = np.append(valFile, "2")
            filePaths.append(filePath2)

        if os.path.exists(filePath3) == False:
            filePath3 = None # set filepath to None for checks later
            fileCnt -= 1 # decrement file count
        elif os.path.exists(filePath3) == True:
            df3 = VRG_Data_Frame.dataframe(filePath3) # Get the dataframe
            df3 = VRG_Data_Frame.dataframe_imagelink(df3, dirPath3) #update imagelinks with directory
            valFile = np.append(valFile, "3")
            filePaths.append(filePath3)

        if os.path.exists(filePath4) == False:
            filePath4 = None # set filepath to None for checks later
            fileCnt -= 1 # decrement file count
        elif os.path.exists(filePath4) == True:
            df4 = VRG_Data_Frame.dataframe(filePath4) # Get the dataframe
            df4 = VRG_Data_Frame.dataframe_imagelink(df4, dirPath4) #update imagelinks with directory
            valFile = np.append(valFile, "4")
            filePaths.append(filePath4)

        if os.path.exists(filePath5) == False:
            filePath5 = None # set filepath to None for checks later
            fileCnt -= 1 # decrement file count
        elif os.path.exists(filePath5) == True:
            df5 = VRG_Data_Frame.dataframe(filePath5) # Get the dataframe
            df5 = VRG_Data_Frame.dataframe_imagelink(df5, dirPath5) #update imagelinks with directory
            valFile = np.append(valFile, "5")
            filePaths.append(filePath5)

        if os.path.exists(filePath6) == False:
            filePath6 = None # set filepath to None for checks later
            fileCnt -= 1 # decrement file count
        elif os.path.exists(filePath6) == True:
            df6 = VRG_Data_Frame.dataframe(filePath6) # Get the dataframe
            df6 = VRG_Data_Frame.dataframe_imagelink(df6, dirPath6) #update imagelinks with directory
            valFile = np.append(valFile, "6")
            filePaths.append(filePath6)

        if os.path.exists(filePath7) == False:
            filePath7 = None # set filepath to None for checks later
            fileCnt -= 1 # decrement file count
        elif os.path.exists(filePath7) == True:
            df7 = VRG_Data_Frame.dataframe(filePath7) # Get the dataframe
            df7 = VRG_Data_Frame.dataframe_imagelink(df7, dirPath7) #update imagelinks with directory
            valFile = np.append(valFile, "7")
            filePaths.append(filePath7)

        if os.path.exists(filePath8) == False:
            filePath2 = None # set filepath to None for checks later
            fileCnt -= 1 # decrement file count
        elif os.path.exists(filePath8) == True:
            df8 = VRG_Data_Frame.dataframe(filePath8) # Get the dataframe
            df8 = VRG_Data_Frame.dataframe_imagelink(df8, dirPath8) #update imagelinks with directory
            valFile = np.append(valFile, "8")
            filePaths.append(filePath8)

        if os.path.exists(filePath9) == False:
            filePath9 = None # set filepath to None for checks later
            fileCnt -= 1 # decrement file count
        elif os.path.exists(filePath9) == True:
            df9 = VRG_Data_Frame.dataframe(filePath9) # Get the dataframe
            df9 = VRG_Data_Frame.dataframe_imagelink(df9, dirPath9) #update imagelinks with directory
            valFile = np.append(valFile, "9")
            filePaths.append(filePath9)


        # Create DataFrames based on # of files
        if fileCnt == 1:
            df = pd.concat([eval("df" + valFile[0])])
        elif fileCnt == 2:
            df = pd.concat([eval("df" + valFile[0]), eval("df" + valFile[1])])
        elif fileCnt == 3:
            df = pd.concat([eval("df" + valFile[0]), eval("df" + valFile[1]), eval("df" + valFile[2])])
        elif fileCnt == 4:
            df = pd.concat([eval("df" + valFile[0]), eval("df" + valFile[1]), eval("df" + valFile[2]), eval("df" + valFile[3])])
        elif fileCnt == 5:
            df = pd.concat([eval("df" + valFile[0]), eval("df" + valFile[1]), eval("df" + valFile[2]), eval("df" + valFile[3]), eval("df" + valFile[4])])
        elif fileCnt == 6:
            df = pd.concat([eval("df" + valFile[0]), eval("df" + valFile[1]), eval("df" + valFile[2]), eval("df" + valFile[3]), eval("df" + valFile[4]), eval("df" + valFile[5])])
        elif fileCnt == 7:
            df = pd.concat([eval("df" + valFile[0]), eval("df" + valFile[1]), eval("df" + valFile[2]), eval("df" + valFile[3]), eval("df" + valFile[4]), eval("df" + valFile[5]), eval("df" + valFile[6])])
        elif fileCnt == 8:
            df = pd.concat([eval("df" + valFile[0]), eval("df" + valFile[1]), eval("df" + valFile[2]), eval("df" + valFile[3]), eval("df" + valFile[4]), eval("df" + valFile[5]), eval("df" + valFile[6]), eval("df" + valFile[7])])
        elif fileCnt == 9:
            df = pd.concat([eval("df" + valFile[0]), eval("df" + valFile[1]), eval("df" + valFile[2]), eval("df" + valFile[3]), eval("df" + valFile[4]), eval("df" + valFile[5]), eval("df" + valFile[6]), eval("df" + valFile[7]), eval("df" + valFile[8])])

        df = VRG_Data_Frame.dataframe_configure(df) # Update step column after combining dataframes
        df = VRG_Data_Frame.dataframe_column_rename(df) # Fix any column names
        document = Document(valTemplate) # will always be the template document
        VRG_Doc.UpdateTestProcedure(df, document, engrName, filePaths) # Update Test Procedure Table
        VRG_Doc.ClearPlotDirectory(pltPath) # Clear the plots from the folder to save space
        fcp.set_theme(fcpThemeColor) # set theme for fcp
        FIDarr = np.asarray(df['FID'].unique()) # Obtain array of unique FIDS from CSV files

        # Assign Die column based on FID
        for i in range(len(FIDarr)):
            FID_indexer = df[df['FID'] == FIDarr[i]].index
            df.loc[FID_indexer, 'Die'] = i

        # Save combined CSV data file
        dfCSVFilePath = os.path.splitext(reportFilePath)[0] + "_df2csv.csv" # Create df CSV filepath name
        df.to_csv(dfCSVFilePath) # Save final df with report
        print("DataFrame Saved to Combined CSV File")

        # Create Individual Input File Report
        inputFileListPath = os.path.splitext(reportFilePath)[0] + "_InputFiles.txt" # Create filepath name for input files
        inputFile = open(inputFileListPath, "w")

        # Create a global file for tracking all reports run
        program_path = os.path.dirname(sys.argv[0])
        trackingPathDef = program_path + '/Tracking/'  # Plot Directory
        trackingCheck = os.path.isfile(trackingPathDef + '/VRG_Tracker.txt') # Check if file exists

        # Output Error Message If File Does Not Exist
        if not trackingCheck:
            trackingFile = open(trackingPathDef + '/VRG_Tracker.txt', "w") #create new file
            print("Created Folder : ", trackingPathDef + '/VRG_Tracker.txt')
        else:
            print(trackingPathDef + '/VRG_Tracker.txt', "Folder Exists")
            trackingFile = open(trackingPathDef + '/VRG_Tracker.txt', "a") #append to existing one

        # Write to both files
        currDate = time.strftime("%m/%d/%Y")  # Time stamp
        currTime = time.strftime("%I:%M:%S %p")  # Time stamp
        inputFile.write("DATE" + "\t" + currDate + "\n")
        inputFile.write("TIME" + "\t" + currTime + "\n")
        inputFile.write("TEST" + "\t" + test + "\n")
        trackingFile.write("DATE" + "\t" + currDate + "\n")
        trackingFile.write("TIME" + "\t" + currTime + "\n")
        trackingFile.write("TEST" + "\t" + test + "\n")

        inputCnt = 1
        for f in filePaths:
            inputFile.write("CSV_FILE_" + str(inputCnt) + "\t" + f + "\n")
            trackingFile.write("CSV_FILE_" + str(inputCnt) + "\t" + f + "\n")
            inputCnt += 1

        inputFile.write("REPORT_FILE" + "\t" + reportFileName + "\n")
        inputFile.write("REPORT_FILE_PATH" + "\t" + reportFilePath + "\n")
        inputFile.write("PLOT_FILE_PATH" + "\t" + pltPath + "\n")
        inputFile.write("EXT_IMAGE_PATH" + "\t" + imgPath + "\n")
        inputFile.close()
        trackingFile.write("REPORT_FILE" + "\t" + reportFileName + "\n")
        trackingFile.write("REPORT_FILE_PATH" + "\t" + reportFilePath + "\n")
        trackingFile.write("PLOT_FILE_PATH" + "\t" + pltPath + "\n")
        trackingFile.write("EXT_IMAGE_PATH" + "\t" + imgPath + "\n")
        trackingFile.close()

        # get all the DV names in VRG_Reports.py for future use
        # for reportName in dir(VRG_Reports):
        #     if reportName.__contains__('DV_'):
        #         print(reportName)



        timestamp = time.strftime("%m/%d/%Y %I:%M:%S %p")  # Time stamp
        print("VRG Report Starting: ", timestamp)

        if test == "SELECT TEST":
            messagebox.showinfo("WRONG TEST SELECTED", "Select A Valid Test Name")
        elif test == "DV_CUSTOM_TEST_1":
            docTitle = 'DV_CUSTOM_TEST_1'  # set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev) #update val template with new info
            VRG_Reports.DV_CUSTOM_TEST_1(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_CUSTOM_TEST_2":
            docTitle = 'DV_CUSTOM_TEST_2'  # set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_CUSTOM_TEST_2(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_CUSTOM_TEST_3":
            docTitle = 'DV_CUSTOM_TEST_3'  # set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_CUSTOM_TEST_3(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_CUSTOM_TEST_4":
            docTitle = 'DV_CUSTOM_TEST_4'  # set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_CUSTOM_TEST_4(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_CUSTOM_TEST_5":
            docTitle = 'DV_CUSTOM_TEST_5'  # set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_CUSTOM_TEST_5(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_CUSTOM_TEST_6":
            docTitle = 'DV_CUSTOM_TEST_6'  # set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_CUSTOM_TEST_6(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_CUSTOM_TEST_7":
            docTitle = 'DV_CUSTOM_TEST_7'  # set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_CUSTOM_TEST_7(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_CUSTOM_TEST_8":
            docTitle = 'DV_CUSTOM_TEST_8'  # set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_CUSTOM_TEST_8(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_CUSTOM_TEST_9":
            docTitle = 'DV_CUSTOM_TEST_9'  # set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_CUSTOM_TEST_9(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_CUSTOM_TEST_10":
            docTitle = 'DV_CUSTOM_TEST_10'  # set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_CUSTOM_TEST_10(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_0_00_ASIC_RAPID_CHECK":
            docTitle = 'DV_0_00_ASIC_RAPID_CHECK'  # set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_0_00_ASIC_RAPID_CHECK(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_0_01_GLOBAL_FUNCTIONS":
            docTitle = 'DV_0_01_GLOBAL_FUNCTIONS' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev) #update val template with new info
            VRG_Reports.DV_0_01_GLOBAL_FUNCTIONS(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_0_01_FRAME_RATE":
            docTitle = 'DV_0_01_FRAME_RATE' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev) #update val template with new info
            VRG_Reports.DV_0_01_FRAME_RATE_ARGO(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_1_00_STANDBY_CURRENT":
            docTitle = 'DV_1_00_STANDBY_CURRENT' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev) #update val template with new info
            VRG_Reports.DV_1_00_STANDBY_CURRENT(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_1_00_OPERATING_CURRENT":
            docTitle = 'DV_1_00_OPERATING_CURRENT' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev) #update val template with new info
            VRG_Reports.DV_1_00_OPERATING_CURRENT(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_1_01_POWER_UP_SEQUENCE":
            docTitle = 'DV_1_01_POWER_UP_SEQUENCE' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev) #update val template with new info
            VRG_Reports.DV_1_01_POWER_UP_SEQUENCE(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_1_01_POWER_UP_SEQUENCE_MIN":
            docTitle = 'DV_1_01_POWER_UP_SEQUENCE_MIN' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev) #update val template with new info
            VRG_Reports.DV_1_01_POWER_UP_SEQUENCE_MIN(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_1_01_POWER_UP_SEQUENCE_NOM":
            docTitle = 'DV_1_01_POWER_UP_SEQUENCE_NOM' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev) #update val template with new info
            VRG_Reports.DV_1_01_POWER_UP_SEQUENCE_NOM(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_1_01_POWER_UP_SEQUENCE_MAX":
            docTitle = 'DV_1_01_POWER_UP_SEQUENCE_MAX' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev) #update val template with new info
            VRG_Reports.DV_1_01_POWER_UP_SEQUENCE_MAX(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_1_02_POWER_DOWN_SEQUENCE":
            docTitle = 'DV_1_02_POWER_DOWN_SEQUENCE' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev) #update val template with new info
            VRG_Reports.DV_1_02_POWER_DOWN_SEQUENCE(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_1_03_HARD_RESET":
            docTitle = 'DV_1_03_HARD_RESET' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev) #update val template with new info
            VRG_Reports.DV_1_03_HARD_RESET(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_1_04_SOFT_RESET":
            docTitle = 'DV_1_04_SOFT_RESET' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev) #update val template with new info
            VRG_Reports.DV_1_04_SOFT_RESET(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_1_05_HARD_STANDBY":
            docTitle = 'DV_1_05_HARD_STANDBY' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev) #update val template with new info
            VRG_Reports.DV_1_05_HARD_STANDBY(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_1_06_SOFT_STANDBY":
            docTitle = 'DV_1_06_SOFT_STANDBY' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev) #update val template with new info
            VRG_Reports.DV_1_06_SOFT_STANDBY(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_1_07_DEFAULT_REGISTER_SHORT":
            docTitle = 'DV_1_07_DEFAULT_REGISTER_SHORT' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev) #update val template with new info
            VRG_Reports.DV_1_07_DEFAULT_REGISTER_SHORT(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_1_07_DEFAULT_REGISTER":
            docTitle = 'DV_1_07_DEFAULT_REGISTER' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev) #update val template with new info
            VRG_Reports.DV_1_07_DEFAULT_REGISTER(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_1_08_OPERATING_MODES":
            docTitle = 'DV_1_08_OPERATING_MODES' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev) #update val template with new info
            VRG_Reports.DV_1_08_OPERATING_MODES(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_1_09_CONTEXT_SWITCHING_REGISTER":
            docTitle = 'DV_1_09_CONTEXT_SWITCHING_REG' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev) #update val template with new info
            VRG_Reports.DV_1_09_CONTEXT_SWITCHING_REG(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_1_09_CONTEXT_SWITCHING_RAM_AUTOMATIC":
            docTitle = 'DV_1_09_CONTEXT_SWITCHING_AUTOMATIC' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev) #update val template with new info
            VRG_Reports.DV_1_09_CONTEXT_SWITCHING_AUTOMATIC(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_1_09_CONTEXT_SWITCHING_RAM_MANUAL":
            docTitle = 'DV_1_09_CONTEXT_SWITCHING_MANUAL' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev) #update val template with new info
            VRG_Reports.DV_1_09_CONTEXT_SWITCHING_MANUAL(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_1_09_CONTEXT_SWITCHING_RAM_CUSTOMER":
            docTitle = 'DV_1_09_CONTEXT_SWITCHING_CUSTOMER' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev) #update val template with new info
            VRG_Reports.DV_1_09_CONTEXT_SWITCHING_CUSTOMER(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_1_10_DYNAMIC_GAIN_AND_EXPOSURE_CHANGES":
            docTitle = 'DV_1_10_DYNAMIC_GAIN_AND_EXPOSURE_CHANGES' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev) #update val template with new info
            VRG_Reports.DV_1_10_DYNAMIC_GAIN_AND_EXPOSURE_CHANGES(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_1_10_DYNAMIC_EXPOSURE_CHANGES":
            docTitle = 'DV_1_10_DYNAMIC_EXPOSURE_CHANGES' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev) #update val template with new info
            VRG_Reports.DV_1_10_DYNAMIC_EXPOSURE_CHANGES(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_1_11_IMAGE_PERFORMANCE_IN_STREAMING":
            docTitle = 'DV_1_11_IMAGE_PERFORMANCE_IN_STREAMING' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev) #update val template with new info
            VRG_Reports.DV_1_11_IMAGE_PERFORMANCE_IN_STREAMING(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_2_01_POR_BYPASS":
            docTitle = 'DV_2_01_POR_BYPASS' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev) #update val template with new info
            VRG_Reports.DV_2_01_POR_BYPASS(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_2_02_TRIM_CALCULATE":
            docTitle = 'DV_2_02_TRIM_CALCULATE'  # set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_2_02_TRIM_CALCULATE(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_2_02_REFERENCE_CURRENT":
            docTitle = 'DV_2_02_REFERENCE_CURRENT' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev) #update val template with new info
            VRG_Reports.DV_2_02_REFERENCE_CURRENT(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_2_02_REFERENCE_VOLTAGE":
            docTitle = 'DV_2_02_REFERENCE_VOLTAGE' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev) #update val template with new info
            VRG_Reports.DV_2_02_REFERENCE_VOLTAGE(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_2_02_REFERENCE_CURRENT_VS_TRIM":
            docTitle = 'DV_2_02_REFERENCE_CURRENT_TRIM' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev) #update val template with new info
            VRG_Reports.DV_2_02_REFERENCE_CURRENT_TRIM(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_2_02_REFERENCE_VOLTAGE_VS_TRIM":
            docTitle = 'DV_2_02_REFERENCE_VOLTAGE_TRIM' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev) #update val template with new info
            VRG_Reports.DV_2_02_REFERENCE_VOLTAGE_TRIM(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_2_03_ADC_TEST_MODE":
            docTitle = 'DV_2_03_ADC_TEST_MODE' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev) #update val template with new info
            VRG_Reports.DV_2_03_ADC_TEST_MODE(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_2_04_ASC_TEST_MODE":
            docTitle = 'DV_2_04_ASC_TEST_MODE' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev) #update val template with new info
            VRG_Reports.DV_2_04_ASC_TEST_MODE(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_2_05_PLL_BYPASS":
            docTitle = 'DV_2_05_PLL_BYPASS' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev) #update val template with new info
            VRG_Reports.DV_2_05_PLL_BYPASS(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_2_06_NAND_TREE":
            docTitle = 'DV_2_06_NAND_TREE' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev) #update val template with new info
            VRG_Reports.DV_2_06_NAND_TREE(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_2_07_MEMORY_BIST":
            docTitle = 'DV_2_07_MEMORY_BIST' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev) #update val template with new info
            VRG_Reports.DV_2_07_MEMORY_BIST(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_2_08_SCAN_CHAIN":
            docTitle = 'DV_2_08_SCAN_CHAIN' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev) #update val template with new info
            VRG_Reports.DV_2_08_SCAN_CHAIN(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_2_08_BOUNDRY_SCAN_CHAIN":
            docTitle = 'DV_2_08_BOUNDRY_SCAN_CHAIN' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev) #update val template with new info
            VRG_Reports.DV_2_08_BOUNDRY_SCAN_CHAIN(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_2_09_INPUT_OUTPUT_LEAKAGE":
            docTitle = 'DV_2_09_INPUT_OUTPUT_LEAKAGE' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev) #update val template with new info
            VRG_Reports.DV_2_09_INPUT_OUTPUT_LEAKAGE(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_2_11_COLUMN_MEMORY":
            docTitle = 'DV_2_11_COLUMN_MEMORY' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev) #update val template with new info
            VRG_Reports.DV_2_11_COLUMN_MEMORY(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_2_12_DIGITAL_TEST_PATTERNS_LEGACY":
            docTitle = 'DV_2_12_DIGITAL_TEST_PATTERNS_LEGACY' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev) #update val template with new info
            VRG_Reports.DV_2_12_DIGITAL_TEST_PATTERNS_LEGACY(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_2_12_DIGITAL_TEST_PATTERNS_TPG":
            docTitle = 'DV_2_12_DIGITAL_TEST_PATTERNS_TPG' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev) #update val template with new info
            VRG_Reports.DV_2_12_DIGITAL_TEST_PATTERNS_TPG(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_2_13_PFA_PROCEDURES_DOCUMENT_VALIDATION":
            docTitle = 'DV_2_13_PFA_PROCEDURES_DOCUMENT_VALIDATION' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev) #update val template with new info
            VRG_Reports.DV_2_13_PFA_PROCEDURES_DOCUMENT_VALIDATION(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_2_14_ALTERNATING_COLUMN_MODE":
            docTitle = 'DV_2_14_ALTERNATING_COLUMN_MODE' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev) #update val template with new info
            VRG_Reports.DV_2_14_ALTERNATING_COLUMN_MODE(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_00_LINEARITY_IMAGE_ANALYSIS":
            docTitle = 'DV_3_00_LINEARITY_IMAGE_ANALYSIS' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev) #update val template with new info
            VRG_Reports.DV_3_00_LINEARITY_IMAGE_ANALYSIS(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_01_DARK_IMAGE_ANALYSIS":
            docTitle = 'DV_3_01_DARK_IMAGE_ANALYSIS' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev) #update val template with new info
            VRG_Reports.DV_3_01_DARK_IMAGE_ANALYSIS(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_02_LOW_MIDLEVEL_IMAGE_ANALYSIS":
            docTitle = 'DV_3_02_LOW_MIDLEVEL_IMAGE_ANALYSIS' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_02_LOW_MIDLEVEL_IMAGE_ANALYSIS(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_03_SATURATED_IMAGE_ANALYSIS":
            docTitle = 'DV_3_03_SATURATED_IMAGE_ANALYSIS' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_03_SATURATED_IMAGE_ANALYSIS(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_04_PIXOUT_AND_ROW_DRIVER_ANALYSIS":
            docTitle = 'DV_3_04_PIXOUT_AND_ROW_DRIVER_ANALYSIS' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_04_PIXOUT_AND_ROW_DRIVER_ANALYSIS(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_04_PIXOUT_ANALYSIS":
            docTitle = 'DV_3_04_PIXOUT_ANALYSIS' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_04_PIXOUT_ANALYSIS(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_05_OFFSET_DAC":
            docTitle = 'DV_3_05_OFFSET_DAC' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_05_OFFSET_DAC(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_06_DATA_PEDESTAL":
            docTitle = 'DV_3_06_DATA_PEDESTAL' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_06_DATA_PEDESTAL(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_07_ADC":
            docTitle = 'DV_3_07_ADC' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_07_ADC(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_07_ADC_E1":
            docTitle = 'DV_3_07_ADC_E1'  # set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_07_ADC_E1(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_3_07_ADC_E2":
            docTitle = 'DV_3_07_ADC_E2'  # set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_07_ADC_E2(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_3_07_ADC_E3":
            docTitle = 'DV_3_07_ADC_E3'  # set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_07_ADC_E3(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_3_07_ADC_T2":
            docTitle = 'DV_3_07_ADC_T2'  # set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_07_ADC_T2(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_3_08_DIGITAL_GAIN":
            docTitle = 'DV_3_08_DIGITAL_GAIN' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_08_DIGITAL_GAIN(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_08_DIGITAL_GAIN_PRE_HDR":
            docTitle = 'DV_3_08_DIGITAL_GAIN_PRE_HDR' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_08_DIGITAL_GAIN_PRE_HDR(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_08_DIGITAL_GAIN_TPG_PRE_HDR":
            docTitle = 'DV_3_08_DIGITAL_GAIN_TPG_PRE_HDR' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_08_DIGITAL_GAIN_TPG_PRE_HDR(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_08_DIGITAL_GAIN_POST_HDR":
            docTitle = 'DV_3_08_DIGITAL_GAIN_POST_HDR' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_08_DIGITAL_GAIN_POST_HDR(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_08_DIGITAL_GAIN_TPG_POST_HDR":
            docTitle = 'DV_3_08_DIGITAL_GAIN_TPG_POST_HDR' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_08_DIGITAL_GAIN_TPG_POST_HDR(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_09_ANALOG_GAIN":
            docTitle = 'DV_3_09_ANALOG_GAIN' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_09_ANALOG_GAIN(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_10_BLACK_LEVEL_OPERATION":
            docTitle = 'DV_3_10_BLACK_LEVEL_OPERATION' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_10_BLACK_LEVEL_OPERATION(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_11_OFFSET_CORRECTION":
            docTitle = 'DV_3_11_OFFSET_CORRECTION' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_11_OFFSET_CORRECTION(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_12_FINE_DIGITAL_CORRECTION":
            docTitle = 'DV_3_12_FINE_DIGITAL_CORRECTION' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_12_FINE_DIGITAL_CORRECTION(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_13_COLUMN_FPN_CORRECTION":
            docTitle = 'DV_3_13_COLUMN_FPN_CORRECTION' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_13_COLUMN_FPN_CORRECTION(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_14_ANALOG_ROW_WISE_CORRECTION":
            docTitle = 'DV_3_14_ANALOG_ROW_WISE_CORRECTION' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_14_ANALOG_ROW_WISE_CORRECTION(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_15_DIGITAL_ROW_WISE_CORRECTION":
            docTitle = 'DV_3_15_DIGITAL_ROW_WISE_CORRECTION' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_15_DIGITAL_ROW_WISE_CORRECTION(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_16_COLUMN_BALANCE":
            docTitle = 'DV_3_16_COLUMN_BALANCE' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_16_COLUMN_BALANCE(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_17_AUTOMATIC_GAIN_SELECTION":
            docTitle = 'DV_3_17_AUTOMATIC_GAIN_SELECTION' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_17_AUTOMATIC_GAIN_SELECTION(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_18_DARK_CURRENT_AND_DELTA_DARK_OPERATION":
            docTitle = 'DV_3_18_DARK_CURRENT_AND_DELTA_DARK_OPERATION' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_18_DARK_CURRENT_AND_DELTA_DARK_OPERATION(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_19_ANTI_ECLIPSE":
            docTitle = 'DV_3_19_ANTI_ECLIPSE' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_19_ANTI_ECLIPSE(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_20_ROW_COLUMN_BANDING":
            docTitle = 'DV_3_20_ROW_COLUMN_BANDING' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_20_ROW_COLUMN_BANDING(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_21_FUSE_BASED_DEFECT_CORRECTION":
            docTitle = 'DV_3_21_FUSE_BASED_DEFECT_CORRECTION' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_21_FUSE_BASED_DEFECT_CORRECTION(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_22_HORIZONTAL_MIRROR":
            docTitle = 'DV_3_22_HORIZONTAL_MIRROR' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_22_HORIZONTAL_MIRROR(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_22_VERTICAL_FLIP":
            docTitle = 'DV_3_22_VERTICAL_FLIP'  # set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_22_VERTICAL_FLIP(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_3_22_HORIZONTAL_MIRROR_AND_VERTICAL_FLIP":
            docTitle = 'DV_3_22_HORIZONTAL_MIRROR_AND_VERTICAL_FLIP' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_22_HORIZONTAL_MIRROR_AND_VERTICAL_FLIP(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_24_VALIDATE_PIXEL_ARRAY_ARCHITECTURE":
            docTitle = 'DV_3_24_VALIDATE_PIXEL_ARRAY_ARCHITECTURE' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_24_VALIDATE_PIXEL_ARRAY_ARCHITECTURE(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_25_PSRR":
            docTitle = 'DV_3_25_PSRR' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_25_PSRR(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_25_PSRR_VAA":
            docTitle = 'DV_3_25_PSRR_VAA'  # set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_25_PSRR_VAA(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_3_25_PSRR_VAAPIX":
            docTitle = 'DV_3_25_PSRR_VAAPIX'  # set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_25_PSRR_VAAPIX(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_3_25_PSRR_VAA2V8":
            docTitle = 'DV_3_25_PSRR_VAA2V8'  # set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_25_PSRR_VAA2V8(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_3_25_PSRR_VAA1V8":
            docTitle = 'DV_3_25_PSRR_VAA1V8'  # set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_25_PSRR_VAA1V8(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_3_25_PSRR_VDD":
            docTitle = 'DV_3_25_PSRR_VDD'  # set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_25_PSRR_VDD(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_3_26_CONTINUOUS_TRIGGER_MODE":
            docTitle = 'DV_3_26_CONTINUOUS_TRIGGER_MODE'  # set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_26_CONTINUOUS_TRIGGER_MODE(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_3_26_PULSE_TRIGGER_MODE":
            docTitle = 'DV_3_26_PULSE_TRIGGER_MODE' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_26_PULSE_TRIGGER_MODE(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_26_SHUTTER_SYNC_TRIGGER_MODE":
            docTitle = 'DV_3_26_SHUTTER_SYNC_TRIGGER_MODE' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_26_SHUTTER_SYNC_TRIGGER_MODE(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_27_GLOBAL_RESET_RELEASE":
            docTitle = 'DV_3_27_GLOBAL_RESET_RELEASE' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_27_GLOBAL_RESET_RELEASE(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_28_FLOATING_NODE_CHECK":
            docTitle = 'DV_3_28_FLOATING_NODE_CHECK' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_28_FLOATING_NODE_CHECK(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_29_COLUMN_BINNING_AND_ROW_SKIPPING":
            docTitle = 'DV_3_29_COLUMN_BINNING_AND_ROW_SKIPPING'  # set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_29_COLUMN_BINNING_AND_ROW_SKIPPING(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_3_29_SKIPPING_SUB_SAMPLING":
            docTitle = 'DV_3_29_SKIPPING_SUB_SAMPLING' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_29_SKIPPING_SUB_SAMPLING(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_30_ANALOG_BINNING":
            docTitle = 'DV_3_30_ANALOG_BINNING' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_30_ANALOG_BINNING(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_31_SCALAR":
            docTitle = 'DV_3_31_SCALAR' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_31_SCALAR(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_32_DYNAMIC_POWER_MODE":
            docTitle = 'DV_3_32_DYNAMIC_POWER_MODE' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_32_DYNAMIC_POWER_MODE(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_33_SLAVE_MODE":
            docTitle = 'DV_3_33_SLAVE_MODE' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_33_SLAVE_MODE(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_34_COLUMN_SHUFFLE_MODE":
            docTitle = 'DV_3_34_COLUMN_SHUFFLE_MODE' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_34_COLUMN_SHUFFLE_MODE(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_35_HORIZONTAL_SHADING_CORRECTION":
            docTitle = 'DV_3_35_HORIZONTAL_SHADING_CORRECTION' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_35_HORIZONTAL_SHADING_CORRECTION(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_36_GLOBAL_GRADIENT_REMOVAL":
            docTitle = 'DV_3_36_GLOBAL_GRADIENT_REMOVAL' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_36_GLOBAL_GRADIENT_REMOVAL(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_37_DIGITAL_CROP_WINDOWING":
            docTitle = 'DV_3_37_DIGITAL_CROP_WINDOWING' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_37_DIGITAL_CROP_WINDOWING(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_39_HDR_MULTIPLE_EXPOSURE":
            docTitle = 'DV_3_39_HDR_MULTIPLE_EXPOSURE' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_39_HDR_MULTIPLE_EXPOSURE(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_39_SE_MULTIPLE_EXPOSURE":
            docTitle = 'DV_3_39_SE_MULTIPLE_EXPOSURE' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_39_SE_MULTIPLE_EXPOSURE(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_40_IHDR_INTERLACED_HDR":
            docTitle = 'DV_3_40_IHDR_INTERLACED_HDR' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_40_IHDR_INTERLACED_HDR(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_41_LINE_INTERLEAVED_HDR_AMBARELLA_READOUT_MODE":
            docTitle = 'DV_3_41_LINE_INTERLEAVED_HDR_AMBARELLA_READOUT_MODE' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_41_LINE_INTERLEAVED_HDR_AMBARELLA_READOUT_MODE(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_41_DUAL_OUTPUT_MODE":
            docTitle = 'DV_3_41_DUAL_OUTPUT_MODE' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_41_DUAL_OUTPUT_MODE(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_42_HDR_COMPANDING":
            docTitle = 'DV_3_42_HDR_COMPANDING' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_42_HDR_COMPANDING(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_43_GLOBAL_SHUTTER":
            docTitle = 'DV_3_43_GLOBAL_SHUTTER' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_43_GLOBAL_SHUTTER(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_44_LED_FLICKER_MITIGATION":
            docTitle = 'DV_3_44_LED_FLICKER_MITIGATION' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_44_LED_FLICKER_MITIGATION(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_45_EXPOSURE_TEST":
            docTitle = 'DV_3_45_EXPOSURE_TEST' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_45_EXPOSURE_TEST(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_45_EXPOSURE_TEST_T1":
            docTitle = 'DV_3_45_EXPOSURE_TEST_T1' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_45_EXPOSURE_TEST_T1(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_45_EXPOSURE_TEST_EXPOSURE_RATIO":
            docTitle = 'DV_3_45_EXPOSURE_TEST_EXPOSURE_RATIO' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_45_EXPOSURE_TEST_EXPOSURE_RATIO(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_45_EXPOSURE_TEST_T2":
            docTitle = 'DV_3_45_EXPOSURE_TEST_T2' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_45_EXPOSURE_TEST_T2(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_46_LAG_CORRECTION":
            docTitle = 'DV_3_46_LAG_CORRECTION'  # set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_46_LAG_CORRECTION(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_3_47_LOW_POWER_MODE":
            docTitle = 'DV_3_47_LOW_POWER_MODE' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_47_LOW_POWER_MODE(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_50_SMART_ROI":
            docTitle = 'DV_3_50_SMART_ROI' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_50_SMART_ROI(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_3_50_EIGHT_ROI":
            docTitle = 'DV_3_50_EIGHT_ROI' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_3_45_EXPOSURE_TEST_T2(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_4_01_DYNAMIC_DEFECT_PIXEL_CORRECTION":
            docTitle = 'DV_4_01_DYNAMIC_DEFECT_PIXEL_CORRECTION' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_4_01_DYNAMIC_DEFECT_PIXEL_CORRECTION(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_4_02_LENS_SHADING_CORRECTION":
            docTitle = 'DV_4_02_LENS_SHADING_CORRECTION' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_4_02_LENS_SHADING_CORRECTION(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_4_03_DYNAMIC_CLUSTER_CORRECTION":
            docTitle = 'DV_4_03_DYNAMIC_CLUSTER_CORRECTION' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_4_03_DYNAMIC_CLUSTER_CORRECTION(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_4_04_FLASH_SUPPORT":
            docTitle = 'DV_4_04_FLASH_SUPPORT' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_4_04_FLASH_SUPPORT(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_4_05_DYNAMIC_SEQUENCER":
            docTitle = 'DV_4_05_DYNAMIC_SEQUENCER' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_4_05_DYNAMIC_SEQUENCER(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_4_06_COLOR_CORRECTION_MATRIX":
            docTitle = 'DV_4_06_COLOR_CORRECTION_MATRIX' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_4_06_COLOR_CORRECTION_MATRIX(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_4_07_AUTO_EXPOSURE":
            docTitle = 'DV_4_07_AUTO_EXPOSURE' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_4_07_AUTO_EXPOSURE(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_4_08_ADACD":
            docTitle = 'DV_4_08_ADACD' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_4_08_ADACD(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_4_09_MOTION_COMPENSATION":
            docTitle = 'DV_4_09_MOTION_COMPENSATION' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_4_09_MOTION_COMPENSATION(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_5_01_POR":
            docTitle = 'DV_5_01_POR' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_5_01_POR(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_5_02_OTPM":
            docTitle = 'DV_5_02_OTPM' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_5_02_OTPM(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_5_03_FIFO_AND_WATERMARK":
            docTitle = 'DV_5_03_FIFO_AND_WATERMARK' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_5_03_FIFO_AND_WATERMARK(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_5_04_PIN_FUNCTIONALITY_AND_IO_PAD_TEST":
            docTitle = 'DV_5_04_PIN_FUNCTIONALITY_AND_IO_PAD_TEST' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_5_04_PIN_FUNCTIONALITY_AND_IO_PAD_TEST(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_5_05_STREAMING_AND_BLANKING":
            docTitle = 'DV_5_05_STREAMING_AND_BLANKING' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_5_05_STREAMING_AND_BLANKING(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_5_06_ITU_R_BTU_656":
            docTitle = 'DV_5_06_ITU_R_BTU_656' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_5_06_ITU_R_BTU_656(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_5_07_DUAL_CAMERA_OPERATION":
            docTitle = 'DV_5_07_DUAL_CAMERA_OPERATION' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_5_07_DUAL_CAMERA_OPERATION(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_5_08_FUSE_ID_AND_CUSTOMER_REVISION":
            docTitle = 'DV_5_08_FUSE_ID_AND_CUSTOMER_REVISION' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_5_08_FUSE_ID_AND_CUSTOMER_REVISION(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_5_09_MIPI":
            docTitle = 'DV_5_09_MIPI' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_5_09_MIPI(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_5_10_VOICE_COIL_MOTOR_VCM_DRIVER":
            docTitle = 'DV_5_10_VOICE_COIL_MOTOR_VCM_DRIVER' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_5_10_VOICE_COIL_MOTOR_VCM_DRIVER(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_5_11_VOLTAGE_REGULATOR":
            docTitle = 'DV_5_11_VOLTAGE_REGULATOR' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_5_11_VOLTAGE_REGULATOR(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_5_11_LDO_OUTPUT_MEASURE":
            docTitle = 'DV_5_11_LDO_OUTPUT_MEASURE' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_5_11_LDO_OUTPUT_MEASURE(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_5_11_LDO_OUTPUT_MEASURE_VS_TRIM":
            docTitle = 'DV_5_11_LDO_OUTPUT_MEASURE_VS_TRIM' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_5_11_LDO_OUTPUT_MEASURE_VS_TRIM(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_5_12_I2C_CCI_CAMERA_CONTROL_INTERFACE":
            docTitle = 'DV_5_12_I2C_CCI_CAMERA_CONTROL_INTERFACE' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_5_12_I2C_CCI_CAMERA_CONTROL_INTERFACE(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_5_14_HISPI_SLVS":
            docTitle = 'DV_5_14_HISPI_SLVS' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_5_14_HISPI_SLVS(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_5_16_STEREO_MODE":
            docTitle = 'DV_5_16_STEREO_MODE' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_5_16_STEREO_MODE(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_5_17_TEMPERATURE_SENSOR":
            docTitle = 'DV_5_17_TEMPERATURE_SENSOR' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_5_17_TEMPERATURE_SENSOR(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_5_17_TEMPERATURE_SENSOR_IP_TEMPSENSOR":
            docTitle = 'DV_5_17_TEMPERATURE_SENSOR_IP_TEMPSENSOR' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_5_17_TEMPERATURE_SENSOR_IP_TEMPSENSOR(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_5_17_TEMPERATURE_SENSOR_DIODE_1":
            docTitle = 'DV_5_17_TEMPERATURE_SENSOR_DIODE_1' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_5_17_TEMPERATURE_SENSOR_DIODE_1(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_5_17_TEMPERATURE_SENSOR_DIODE_2":
            docTitle = 'DV_5_17_TEMPERATURE_SENSOR_DIODE_2' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_5_17_TEMPERATURE_SENSOR_DIODE_2(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_5_17_TEMPERATURE_SENSOR_DIODE_SEQUENCE":
            docTitle = 'DV_5_17_TEMPERATURE_SENSOR_DIODE_SEQUENCE' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_5_17_TEMPERATURE_SENSOR_DIODE_SEQUENCE(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_5_17_TEMPERATURE_SENSOR_SAFETY_PTAT_MODE":
            docTitle = 'DV_5_17_TEMPERATURE_SENSOR_SAFETY_PTAT_MODE' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_5_17_TEMPERATURE_SENSOR_SAFETY_PTAT_MODE(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_5_17_TEMPERATURE_SENSOR_SAFETY_CONSTANT_MODE":
            docTitle = 'DV_5_17_TEMPERATURE_SENSOR_SAFETY_CONSTANT_MODE' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_5_17_TEMPERATURE_SENSOR_SAFETY_CONSTANT_MODE(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_5_17_TEMPERATURE_SENSOR_SAFETY_SEQUENCE":
            docTitle = 'DV_5_17_TEMPERATURE_SENSOR_SAFETY_SEQUENCE' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_5_17_TEMPERATURE_SENSOR_SAFETY_SEQUENCE(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_5_17_TEMPERATURE_SENSOR_SCHMOO":
            docTitle = 'DV_5_17_TEMPERATURE_SENSOR_SCHMOO' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_5_17_TEMPERATURE_SENSOR_SCHMOO(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_5_18_PLL":
            docTitle = 'DV_5_18_PLL' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_5_18_PLL(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_5_19_NTSC":
            docTitle = 'DV_5_19_NTSC' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_5_19_NTSC(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_5_20_THREE_WIRE_SERIAL_INTERFACE":
            docTitle = 'DV_5_20_THREE_WIRE_SERIAL_INTERFACE' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_5_20_THREE_WIRE_SERIAL_INTERFACE(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_5_21_OUTPUT_DATA_COMPRESSION":
            docTitle = 'DV_5_21_OUTPUT_DATA_COMPRESSION' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_5_21_OUTPUT_DATA_COMPRESSION(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_5_22_EMBEDDED_DATA_AND_STATISTICS_ROWS":
            docTitle = 'DV_5_22_EMBEDDED_DATA_AND_STATISTICS_ROWS' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_5_22_EMBEDDED_DATA_AND_STATISTICS_ROWS(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_5_22_EMBEDDED_DATA_ROWS":
            docTitle = 'DV_5_22_EMBEDDED_DATA_ROWS' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_5_22_EMBEDDED_DATA_ROWS(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_5_22_EMBEDDED_STATISTICS_ROWS":
            docTitle = 'DV_5_22_EMBEDDED_STATISTICS_ROWS' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_5_22_EMBEDDED_STATISTICS_ROWS(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_5_23_I2C_FEATURE_LOCK":
            docTitle = 'DV_5_23_I2C_FEATURE_LOCK' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_5_23_I2C_FEATURE_LOCK(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_5_24_ETHERNET":
            docTitle = 'DV_5_24_ETHERNET' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_5_24_ETHERNET(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_5_24_MIPI_LOOPBACK_DPHY":
            docTitle = 'DV_5_24_MIPI_LOOPBACK_DPHY' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_5_24_MIPI_LOOPBACK_DPHY(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_5_24_MIPI_LOOPBACK_DPHY_SDR":
            docTitle = 'DV_5_24_MIPI_LOOPBACK_DPHY_SDR'  # set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_5_24_MIPI_LOOPBACK_DPHY_SDR(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_5_24_MIPI_LOOPBACK_DPHY_DDR":
            docTitle = 'DV_5_24_MIPI_LOOPBACK_DPHY_DDR'  # set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_5_24_MIPI_LOOPBACK_DPHY_DDR(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_5_24_MIPI_LOOPBACK_CPHY":
            docTitle = 'DV_5_24_MIPI_LOOPBACK_CPHY' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_5_24_MIPI_LOOPBACK_CPHY(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_5_25_SERIAL_PERIPHERAL_INTERFACE_SPI":
            docTitle = 'DV_5_25_SERIAL_PERIPHERAL_INTERFACE_SPI' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_5_25_SERIAL_PERIPHERAL_INTERFACE_SPI(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_6_01_LINEAR_FULL_WELL":
            docTitle = 'DV_6_01_LINEAR_FULL_WELL' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_6_01_LINEAR_FULL_WELL(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_6_02_SATURATION_FULL_WELL":
            docTitle = 'DV_6_02_SATURATION_FULL_WELL' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_6_02_SATURATION_FULL_WELL(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_6_03_CONVERSION_GAIN_TF":
            docTitle = 'DV_6_03_CONVERSION_GAIN_TF' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_6_03_CONVERSION_GAIN_TF(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_6_04_ISO_GAINS_MAPPED_TO_ANALOG_DIGITAL_GAINS":
            docTitle = 'DV_6_04_ISO_GAINS_MAPPED_TO_ANALOG_DIGITAL_GAINS' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_6_04_ISO_GAINS_MAPPED_TO_ANALOG_DIGITAL_GAINS(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_6_05_READOUT_NOISE_VS_GAIN_BOTH_ANALOG_AND_ISO":
            docTitle = 'DV_6_05_READOUT_NOISE_VS_GAIN_BOTH_ANALOG_AND_ISO' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_6_05_READOUT_NOISE_VS_GAIN_BOTH_ANALOG_AND_ISO(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_6_06_PTC_FOR_ALL_GAINS_BOTH_ANALOG_AND_ISO":
            docTitle = 'DV_6_06_PTC_FOR_ALL_GAINS_BOTH_ANALOG_AND_ISO' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_6_06_PTC_FOR_ALL_GAINS_BOTH_ANALOG_AND_ISO(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_6_07_RESPONSIVITY_VLUXS_KELUXS":
            docTitle = 'DV_6_07_RESPONSIVITY_VLUXS_KELUXS' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_6_07_RESPONSIVITY_VLUXS_KELUXS(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_6_08_CHARGING_LAG":
            docTitle = 'DV_6_08_CHARGING_LAG' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_6_08_CHARGING_LAG(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_6_09_DISCHARGING_LAG":
            docTitle = 'DV_6_09_DISCHARGING_LAG' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_6_09_DISCHARGING_LAG(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_6_10_CHARGE_SHARING_LAG":
            docTitle = 'DV_6_10_CHARGE_SHARING_LAG' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_6_10_CHARGE_SHARING_LAG(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_6_11_BLOOMING_TEST":
            docTitle = 'DV_6_11_BLOOMING_TEST' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_6_11_BLOOMING_TEST(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_6_12_ROW_BANDING":
            docTitle = 'DV_6_12_ROW_BANDING' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_6_12_ROW_BANDING(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_6_13_COLOR_RATIO_VS_EXPOSURE":
            docTitle = 'DV_6_13_COLOR_RATIO_VS_EXPOSURE' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_6_13_COLOR_RATIO_VS_EXPOSURE(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_6_14_COLOR_RATIO_VS_F_NUMBER":
            docTitle = 'DV_6_14_COLOR_RATIO_VS_F_NUMBER' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_6_14_COLOR_RATIO_VS_F_NUMBER(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_6_15_LINE_CRAWL":
            docTitle = 'DV_6_15_LINE_CRAWL' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_6_15_LINE_CRAWL(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_6_16_QE_PLUS_RELATIVE_RESPONSE_ETC":
            docTitle = 'DV_6_16_QE_PLUS_RELATIVE_RESPONSE_ETC' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_6_16_QE_PLUS_RELATIVE_RESPONSE_ETC(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_6_17_LINEARITY_FOR_DIFFERENT_GAINS":
            docTitle = 'DV_6_17_LINEARITY_FOR_DIFFERENT_GAINS' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_6_17_LINEARITY_FOR_DIFFERENT_GAINS(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_6_18_SPATIAL_NOISE_PFPN_VS_SIGNAL":
            docTitle = 'DV_6_18_SPATIAL_NOISE_PFPN_VS_SIGNAL' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_6_18_SPATIAL_NOISE_PFPN_VS_SIGNAL(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_6_19_BLACK_LEVEL_VS_GAIN":
            docTitle = 'DV_6_19_BLACK_LEVEL_VS_GAIN' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_6_19_BLACK_LEVEL_VS_GAIN(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_6_20_BLACK_LEVEL_UNIFORMITY_VS_GAIN":
            docTitle = 'DV_6_20_BLACK_LEVEL_UNIFORMITY_VS_GAIN' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_6_20_BLACK_LEVEL_UNIFORMITY_VS_GAIN(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_6_21_DARK_CURRENT":
            docTitle = 'DV_6_21_DARK_CURRENT' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_6_21_DARK_CURRENT(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_6_22_S_CURVE":
            docTitle = 'DV_6_22_S_CURVE' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_6_22_S_CURVE(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_6_23_ISO_SNR_COMPLETE_CURVE":
            docTitle = 'DV_6_23_ISO_SNR_COMPLETE_CURVE' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_6_23_ISO_SNR_COMPLETE_CURVE(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_6_24_LATEST_NOKIA_SNR_COMPLETE_CURVE":
            docTitle = 'DV_6_24_LATEST_NOKIA_SNR_COMPLETE_CURVE' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_6_24_LATEST_NOKIA_SNR_COMPLETE_CURVE(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_6_25_APTINA_SNR_COMPLETE_CURVE":
            docTitle = 'DV_6_25_APTINA_SNR_COMPLETE_CURVE' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_6_25_APTINA_SNR_COMPLETE_CURVE(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_6_26_IMAGE_CAPTURE_STAND_SCENE":
            docTitle = 'DV_6_26_IMAGE_CAPTURE_STAND_SCENE' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_6_26_IMAGE_CAPTURE_STAND_SCENE(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_6_27_IMAGE_CAPTURE_IECF_CHART":
            docTitle = 'DV_6_27_IMAGE_CAPTURE_IECF_CHART' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_6_27_IMAGE_CAPTURE_IECF_CHART(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_6_28_IMAGE_CAPTURE_MACBETH":
            docTitle = 'DV_6_28_IMAGE_CAPTURE_MACBETH' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_6_28_IMAGE_CAPTURE_MACBETH(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_6_29_IMAGE_CAPTURE_FLAT_FIELD":
            docTitle = 'DV_6_29_IMAGE_CAPTURE_FLAT_FIELD' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_6_29_IMAGE_CAPTURE_FLAT_FIELD(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_6_30_IMAGE_CAPTURE_RESOLUTION_CHART":
            docTitle = 'DV_6_30_IMAGE_CAPTURE_RESOLUTION_CHART' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_6_30_IMAGE_CAPTURE_RESOLUTION_CHART(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_6_31_IMAGE_CAPTURE_MOAS":
            docTitle = 'DV_6_31_IMAGE_CAPTURE_MOAS' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_6_31_IMAGE_CAPTURE_MOAS(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_6_32_IMAGE_CAPTURE_MACBETH_SCENE_VS_TEMPERATURE":
            docTitle = 'DV_6_32_IMAGE_CAPTURE_MACBETH_SCENE_VS_TEMPERATURE' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_6_32_IMAGE_CAPTURE_MACBETH_SCENE_VS_TEMPERATURE(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_6_33_IMAGE_CAPTURE_FULL_SCC":
            docTitle = 'DV_6_33_IMAGE_CAPTURE_FULL_SCC' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_6_33_IMAGE_CAPTURE_FULL_SCC(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_6_34_IMAGE_CAPTURE_MINI_SCC":
            docTitle = 'DV_6_34_IMAGE_CAPTURE_MINI_SCC' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_6_34_IMAGE_CAPTURE_MINI_SCC(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_6_35_MODULATION_TRANSFER_FUNCTION_MTF":
            docTitle = 'DV_6_35_MODULATION_TRANSFER_FUNCTION_MTF' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_6_35_MODULATION_TRANSFER_FUNCTION_MTF(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_7_01_AC_CHARACTERIZATION_OF_PARALLEL_INTERFACE":
            docTitle = 'DV_7_01_AC_CHARACTERIZATION_OF_PARALLEL_INTERFACE' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_7_01_AC_CHARACTERIZATION_OF_PARALLEL_INTERFACE(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_7_06_DC_CHARACTERIZATION_OF_I_O_LOGIC_LEVELS":
            docTitle = 'DV_7_06_DC_CHARACTERIZATION_OF_I_O_LOGIC_LEVELS' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_7_06_DC_CHARACTERIZATION_OF_I_O_LOGIC_LEVELS(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_8_01_ESD":
            docTitle = 'DV_8_01_ESD' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_8_01_ESD(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_8_02_ABSOLUTE_MAXIMUM_RATINGS":
            docTitle = 'DV_8_02_ABSOLUTE_MAXIMUM_RATINGS' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_8_02_ABSOLUTE_MAXIMUM_RATINGS(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_8_03_HTOL":
            docTitle = 'DV_8_03_HTOL' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_8_03_HTOL(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_8_04_LTOL":
            docTitle = 'DV_8_04_LTOL' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_8_04_LTOL(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_8_05_HAST":
            docTitle = 'DV_8_05_HAST' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_8_05_HAST(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_8_06_T_C":
            docTitle = 'DV_8_06_T_C' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_8_06_T_C(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_8_07_HTOL_PARAMETRIC_DRIFT_ANALYSIS":
            docTitle = 'DV_8_07_HTOL_PARAMETRIC_DRIFT_ANALYSIS' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_8_07_HTOL_PARAMETRIC_DRIFT_ANALYSIS(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_9_01_AUTO_FOCUS_AF":
            docTitle = 'DV_9_01_AUTO_FOCUS_AF' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_9_01_AUTO_FOCUS_AF(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_9_03_JPEG":
            docTitle = 'DV_9_03_JPEG' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_9_03_JPEG(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_9_04_CPIPE_ARCHITECTURE":
            docTitle = 'DV_9_04_CPIPE_ARCHITECTURE' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_9_04_CPIPE_ARCHITECTURE(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_9_07_WHITE_BALANCE":
            docTitle = 'DV_9_07_WHITE_BALANCE' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_9_07_WHITE_BALANCE(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_9_08_COLOR_CORRECTION_MATRIX_CCM":
            docTitle = 'DV_9_08_COLOR_CORRECTION_MATRIX_CCM' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_9_08_COLOR_CORRECTION_MATRIX_CCM(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_9_09_SHARPNESS":
            docTitle = 'DV_9_09_SHARPNESS' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_9_09_SHARPNESS(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_9_10_LENS_SHADING_CORRECTION":
            docTitle = 'DV_9_10_LENS_SHADING_CORRECTION' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_9_10_LENS_SHADING_CORRECTION(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_9_11_DEFECT_CORRECTION":
            docTitle = 'DV_9_11_DEFECT_CORRECTION' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_9_11_DEFECT_CORRECTION(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_9_12_ZOOM":
            docTitle = 'DV_9_12_ZOOM' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_9_12_ZOOM(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_9_13_NOISE_REDUCTION":
            docTitle = 'DV_9_13_NOISE_REDUCTION' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_9_13_NOISE_REDUCTION(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_9_14_SPECIAL_EFFECTS":
            docTitle = 'DV_9_14_SPECIAL_EFFECTS' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_9_14_SPECIAL_EFFECTS(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_9_15_COLOUR_KILL":
            docTitle = 'DV_9_15_COLOUR_KILL' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_9_15_COLOUR_KILL(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_9_16_AUTO_EXPOSURE":
            docTitle = 'DV_9_16_AUTO_EXPOSURE' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_9_16_AUTO_EXPOSURE(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_9_17_DEWARP_STE":
            docTitle = 'DV_9_17_DEWARP_STE' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_9_17_DEWARP_STE(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_9_18_BINNING":
            docTitle = 'DV_9_18_BINNING' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_9_18_BINNING(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_9_19_TONE_MAPPING":
            docTitle = 'DV_9_19_TONE_MAPPING' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_9_19_TONE_MAPPING(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_9_20_GAMMA":
            docTitle = 'DV_9_20_GAMMA' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_9_20_GAMMA(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_9_21_TEMPERATURE_TESTING_WITH_TUNED_CPIPE_SETTINGS":
            docTitle = 'DV_9_21_TEMPERATURE_TESTING_WITH_TUNED_CPIPE_SETTINGS' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_9_21_TEMPERATURE_TESTING_WITH_TUNED_CPIPE_SETTINGS(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_10_01_AUTO_EXPOSURE":
            docTitle = 'DV_10_01_AUTO_EXPOSURE' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_10_01_AUTO_EXPOSURE(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_10_02_AUTO_WHITE_BALANCE":
            docTitle = 'DV_10_02_AUTO_WHITE_BALANCE' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_10_02_AUTO_WHITE_BALANCE(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_10_03_COLOR_CORRECTION":
            docTitle = 'DV_10_03_COLOR_CORRECTION' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_10_03_COLOR_CORRECTION(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_10_04_BLACK_LEVEL_STATS_CONTROL":
            docTitle = 'DV_10_04_BLACK_LEVEL_STATS_CONTROL' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_10_04_BLACK_LEVEL_STATS_CONTROL(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_10_05_DEFECT_CORRECTION_SUPPORT":
            docTitle = 'DV_10_05_DEFECT_CORRECTION_SUPPORT' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_10_05_DEFECT_CORRECTION_SUPPORT(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_10_06_NOISE_REDUCTION_SUPPORT":
            docTitle = 'DV_10_06_NOISE_REDUCTION_SUPPORT' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_10_06_NOISE_REDUCTION_SUPPORT(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_10_07_TONE_MAPPING":
            docTitle = 'DV_10_07_TONE_MAPPING' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_10_07_TONE_MAPPING(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_10_08_CONTRAST_GAMMA":
            docTitle = 'DV_10_08_CONTRAST_GAMMA' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_10_08_CONTRAST_GAMMA(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_10_09_LOWLIGHT_STATS_CONTROL":
            docTitle = 'DV_10_09_LOWLIGHT_STATS_CONTROL' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_10_09_LOWLIGHT_STATS_CONTROL(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_10_10_CAMERA_ADAPTATION":
            docTitle = 'DV_10_10_CAMERA_ADAPTATION' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_10_10_CAMERA_ADAPTATION(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_10_11_CAMERA_CONTROL":
            docTitle = 'DV_10_11_CAMERA_CONTROL' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_10_11_CAMERA_CONTROL(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_10_12_SYSTEM_CONTROL":
            docTitle = 'DV_10_12_SYSTEM_CONTROL' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_10_12_SYSTEM_CONTROL(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_10_13_SYSTEM_CONFIGURATION":
            docTitle = 'DV_10_13_SYSTEM_CONFIGURATION' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_10_13_SYSTEM_CONFIGURATION(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_10_14_HOST_COMMAND_INTERFACE":
            docTitle = 'DV_10_14_HOST_COMMAND_INTERFACE' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_10_14_HOST_COMMAND_INTERFACE(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_10_15_SPI_NVM_SUPPORT":
            docTitle = 'DV_10_15_SPI_NVM_SUPPORT' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_10_15_SPI_NVM_SUPPORT(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_10_16_I2C_MASTER_NVM_SUPPORT":
            docTitle = 'DV_10_16_I2C_MASTER_NVM_SUPPORT' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_10_16_I2C_MASTER_NVM_SUPPORT(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_10_17_OTPM_SUPPORT":
            docTitle = 'DV_10_17_OTPM_SUPPORT' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_10_17_OTPM_SUPPORT(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_10_18_TEMPERATURE_SENSOR_SUPPORT":
            docTitle = 'DV_10_18_TEMPERATURE_SENSOR_SUPPORT' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_10_18_TEMPERATURE_SENSOR_SUPPORT(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_10_19_GPIO_SUPPORT":
            docTitle = 'DV_10_19_GPIO_SUPPORT' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_10_19_GPIO_SUPPORT(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_10_20_CALIBRATION_SUPPORT":
            docTitle = 'DV_10_20_CALIBRATION_SUPPORT' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_10_20_CALIBRATION_SUPPORT(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_10_21_EVENT_MONITORING":
            docTitle = 'DV_10_21_EVENT_MONITORING' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_10_21_EVENT_MONITORING(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_10_22_SENSOR_CONTROL":
            docTitle = 'DV_10_22_SENSOR_CONTROL' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_10_22_SENSOR_CONTROL(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_10_23_UART_CONTROL":
            docTitle = 'DV_10_23_UART_CONTROL' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_10_23_UART_CONTROL(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_10_24_DEWARP_SUPPORT":
            docTitle = 'DV_10_24_DEWARP_SUPPORT' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_10_24_DEWARP_SUPPORT(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_10_25_OVERLAY_SUPPORT":
            docTitle = 'DV_10_25_OVERLAY_SUPPORT' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_10_25_OVERLAY_SUPPORT(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_10_26_DIAGNOSTICS_SUPPORT":
            docTitle = 'DV_10_26_DIAGNOSTICS_SUPPORT' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_10_26_DIAGNOSTICS_SUPPORT(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_11_01_AUTOMOTIVE_VIEWING_DRIVING_DAYTIME":
            docTitle = 'DV_11_01_AUTOMOTIVE_VIEWING_DRIVING_DAYTIME' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_11_01_AUTOMOTIVE_VIEWING_DRIVING_DAYTIME(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_11_02_AUTOMOTIVE_VIEWING_DRIVING_LOW_LIGHT":
            docTitle = 'DV_11_02_AUTOMOTIVE_VIEWING_DRIVING_LOW_LIGHT' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_11_02_AUTOMOTIVE_VIEWING_DRIVING_LOW_LIGHT(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_11_03_SURVEILLANCE_CWF_LIGHTING":
            docTitle = 'DV_11_03_SURVEILLANCE_CWF_LIGHTING' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_11_03_SURVEILLANCE_CWF_LIGHTING(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_11_04_SURVEILLANCE_INDOOR_MIXED_LIGHT":
            docTitle = 'DV_11_04_SURVEILLANCE_INDOOR_MIXED_LIGHT' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_11_04_SURVEILLANCE_INDOOR_MIXED_LIGHT(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_11_05_SURVEILLANCE_PARKING_LOT_IN_LOW_LIGHT":
            docTitle = 'DV_11_05_SURVEILLANCE_PARKING_LOT_IN_LOW_LIGHT' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_11_05_SURVEILLANCE_PARKING_LOT_IN_LOW_LIGHT(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_11_06_SURVEILLANCE_OUTDOOR_MID_DAY":
            docTitle = 'DV_11_06_SURVEILLANCE_OUTDOOR_MID_DAY' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_11_06_SURVEILLANCE_OUTDOOR_MID_DAY(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_11_07_SURVEILLANCE_INDOOR_LOW_LIGHT":
            docTitle = 'DV_11_07_SURVEILLANCE_INDOOR_LOW_LIGHT' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_11_07_SURVEILLANCE_INDOOR_LOW_LIGHT(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_12_0_01_SM_M3ROM_UPLOAD_CRC":
            docTitle = 'DV_12_0_01_SM_M3ROM_UPLOAD_CRC'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_01_SM_M3ROM_UPLOAD_CRC(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_02_SM_OTPROM_UPLOAD_CRC":
            docTitle = 'DV_12_0_02_SM_OTPROM_UPLOAD_CRC'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_02_SM_OTPROM_UPLOAD_CRC(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_03_SM_STANDBY_REGISTER_CRC":
            docTitle = 'DV_12_0_03_SM_STANDBY_REGISTER_CRC'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_03_SM_STANDBY_REGISTER_CRC(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_04_SM_PDI_UPLOAD_CRC":
            docTitle = 'DV_12_0_04_SM_PDI_UPLOAD_CRC'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_04_SM_PDI_UPLOAD_CRC(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_05_SM_STANDBY_BIST_MEMORY":
            docTitle = 'DV_12_0_05_SM_STANDBY_BIST_MEMORY'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_05_SM_STANDBY_BIST_MEMORY(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_06_SM_STANDBY_TEST_FRAME":
            docTitle = 'DV_12_0_06_SM_STANDBY_TEST_FRAME'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_06_SM_STANDBY_TEST_FRAME(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_07_SM_SYS_CHECK":
            docTitle = 'DV_12_0_07_SM_SYS_CHECK'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_07_SM_SYS_CHECK(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_08_SM_AHM_BOOSTER_BANDGAP_MONITOR":
            docTitle = 'DV_12_0_08_SM_AHM_BOOSTER_BANDGAP_MONITOR'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_08_SM_AHM_BOOSTER_BANDGAP_MONITOR(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_09_SM_CHIP_SUPPLY_VOLTAGE_MONITOR":
            docTitle = 'DV_12_0_09_SM_CHIP_SUPPLY_VOLTAGE_MONITOR'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_09_SM_CHIP_SUPPLY_VOLTAGE_MONITOR(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_09_SM_CHIP_SUPPLY_VOLTAGE_MONITOR_SUPPLY_DECREASE":
            docTitle = 'DV_12_0_09_SM_CHIP_SUPPLY_VOLTAGE_MONITOR_SUPPLY_DECREASE'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_09_SM_CHIP_SUPPLY_VOLTAGE_MONITOR_SUPPLY_DECREASE(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_09_SM_CHIP_SUPPLY_VOLTAGE_MONITOR_SUPPLY_INCREASE":
            docTitle = 'DV_12_0_09_SM_CHIP_SUPPLY_VOLTAGE_MONITOR_SUPPLY_INCREASE'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_09_SM_CHIP_SUPPLY_VOLTAGE_MONITOR_SUPPLY_INCREASE(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_10_SM_TEMP_SENSOR":
            docTitle = 'DV_12_0_10_SM_TEMP_SENSOR'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_10_SM_TEMP_SENSOR(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_12_SM_AHM_ROW_ROM":
            docTitle = 'DV_12_0_12_SM_AHM_ROW_ROM'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_12_SM_AHM_ROW_ROM(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_12_SM_AHM_ROW_ROM_IMAGE_DATA":
            docTitle = 'DV_12_0_12_SM_AHM_ROW_ROM_IMAGE_DATA'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_12_SM_AHM_ROW_ROM_IMAGE_DATA(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_15_SM_AHM_SREG_READBACK":
            docTitle = 'DV_12_0_15_SM_AHM_SREG_READBACK'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_15_SM_AHM_SREG_READBACK(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_SM_ANALOG_TEST_ROWS":
            docTitle = 'DV_12_SM_ANALOG_TEST_ROWS'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_SM_ANALOG_TEST_ROWS(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_SM_ANALOG_TEST_ROWS_IMAGE_DATA":
            docTitle = 'DV_12_SM_ANALOG_TEST_ROWS_IMAGE_DATA'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_SM_ANALOG_TEST_ROWS_IMAGE_DATA(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_16_SM_ATR_COLUMN_MEMORY_TESTS":
            docTitle = 'DV_12_0_16_SM_ATR_COLUMN_MEMORY_TESTS'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_16_SM_ATR_COLUMN_MEMORY_TESTS(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_17_SM_ATR_COLUMN_ROM":
            docTitle = 'DV_12_0_17_SM_ATR_COLUMN_ROM'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_17_SM_ATR_COLUMN_ROM(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_18_SM_ATR_FRAME_CHANGE":
            docTitle = 'DV_12_0_18_SM_ATR_FRAME_CHANGE'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_18_SM_ATR_FRAME_CHANGE(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_19_SM_ATR_GRADIENT":
            docTitle = 'DV_12_0_19_SM_ATR_GRADIENT'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_19_SM_ATR_GRADIENT(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_20_SM_ATR_OVERDRIVE_1X":
            docTitle = 'DV_12_0_20_SM_ATR_OVERDRIVE_1X'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_20_SM_ATR_OVERDRIVE_1X(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_21_SM_ATR_OVERDRIVE_AT_GAIN":
            docTitle = 'DV_12_0_21_SM_ATR_OVERDRIVE_AT_GAIN'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_21_SM_ATR_OVERDRIVE_AT_GAIN(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_22_SM_ATR_VERT_PIXOUT_1":
            docTitle = 'DV_12_0_22_SM_ATR_VERT_PIXOUT_1'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_22_SM_ATR_VERT_PIXOUT_1(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_23_SM_ATR_VERT_PIXOUT_2":
            docTitle = 'DV_12_0_23_SM_ATR_VERT_PIXOUT_2'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_23_SM_ATR_VERT_PIXOUT_2(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_24_SM_ATR_ZEBRA_AB":
            docTitle = 'DV_12_0_24_SM_ATR_ZEBRA_AB'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_24_SM_ATR_ZEBRA_AB(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_25_SM_ATR_ZEBRA_BA":
            docTitle = 'DV_12_0_25_SM_ATR_ZEBRA_BA'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_25_SM_ATR_ZEBRA_BA(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_26_SM_ATR_OVERDRIVE_ROW_012345":
            docTitle = 'DV_12_0_26_SM_ATR_OVERDRIVE_ROW_012345'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_26_SM_ATR_OVERDRIVE_ROW_012345(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_27_SM_DIGITAL_FRAME_COUNTER":
            docTitle = 'DV_12_0_27_SM_DIGITAL_FRAME_COUNTER'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_27_SM_DIGITAL_FRAME_COUNTER(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_28_SM_AUTO_CHECK_ATR":
            docTitle = 'DV_12_0_28_SM_AUTO_CHECK_ATR'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_28_SM_AUTO_CHECK_ATR(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_CLOCK_COUNTING":
            docTitle = 'DV_12_CLOCK_COUNTING'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_CLOCK_COUNTING(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_29_SM_COUNT_CLK_OP":
            docTitle = 'DV_12_0_29_SM_COUNT_CLK_OP'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_29_SM_COUNT_CLK_OP(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_30_SM_COUNT_CLK_PIX":
            docTitle = 'DV_12_0_30_SM_COUNT_CLK_PIX'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_30_SM_COUNT_CLK_PIX(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_31_SM_COUNT_CLK_REG":
            docTitle = 'DV_12_0_31_SM_COUNT_CLK_REG'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_31_SM_COUNT_CLK_REG(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_32_SM_COUNT_EXTCLK":
            docTitle = 'DV_12_0_32_SM_COUNT_EXTCLK'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_32_SM_COUNT_EXTCLK(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_33_SM_CLK_PIX_COUNT_100":
            docTitle = 'DV_12_0_33_SM_CLK_PIX_COUNT_100'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_33_SM_CLK_PIX_COUNT_100(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_34_SM_CLK_OP_COUNT_100":
            docTitle = 'DV_12_0_34_SM_CLK_OP_COUNT_100'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_34_SM_CLK_OP_COUNT_100(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_35_SM_CLK_REG_COUNT_100":
            docTitle = 'DV_12_0_35_SM_CLK_REG_COUNT_100'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_35_SM_CLK_REG_COUNT_100(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_36_SM_DELAY_BUFFER_RAM_CRC":
            docTitle = 'DV_12_0_36_SM_DELAY_BUFFER_RAM_CRC'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_36_SM_DELAY_BUFFER_RAM_CRC(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_37_SM_DOUBLE_LOCK":
            docTitle = 'DV_12_0_37_SM_DOUBLE_LOCK'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_SM_50_SM_DOUBLE_LOCK(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_38_SM_DTR":
            docTitle = 'DV_12_0_38_SM_DTR'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_38_SM_DTR(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_38_SM_DTR_IMAGE_DATA":
            docTitle = 'DV_12_0_38_SM_DTR_IMAGE_DATA'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_38_SM_DTR_IMAGE_DATA(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_39_SM_ECC_BLACK_LEVEL_RAM":
            docTitle = 'DV_12_0_39_SM_ECC_BLACK_LEVEL_RAM'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_39_SM_ECC_BLACK_LEVEL_RAM(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_40_SM_ECC_SEQUENCER_RAM":
            docTitle = 'DV_12_0_40_SM_ECC_SEQUENCER_RAM'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_40_SM_ECC_SEQUENCER_RAM(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_41_SM_EMBEDDED_DATA_CRC":
            docTitle = 'DV_12_0_41_SM_EMBEDDED_DATA_CRC'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_41_SM_EMBEDDED_DATA_CRC(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_41_SM_HOST_CHECK_EMBEDDED_REGISTER_DATA":
            docTitle = 'DV_12_0_41_SM_HOST_CHECK_EMBEDDED_REGISTER_DATA'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_41_SM_HOST_CHECK_EMBEDDED_REGISTER_DATA(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_42_SM_HOST_CHECK_INVALID_IMAGE":
            docTitle = 'DV_12_0_42_SM_HOST_CHECK_INVALID_IMAGE'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_42_SM_HOST_CHECK_INVALID_IMAGE(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_43_SM_HOST_CHECK_OPERATING_STATUS":
            docTitle = 'DV_12_0_43_SM_HOST_CHECK_OPERATING_STATUS'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_43_SM_HOST_CHECK_OPERATING_STATUS(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_44_SM_HOST_CHECK_STATISTICS_DATA":
            docTitle = 'DV_12_0_44_SM_HOST_CHECK_STATISTICS_DATA'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_44_SM_HOST_CHECK_STATISTICS_DATA(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_45_SM_I2C_CRC":
            docTitle = 'DV_12_0_45_SM_I2C_CRC'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_45_SM_I2C_CRC(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_46_SM_IMAGE_DATA_CRC":
            docTitle = 'DV_12_0_46_SM_IMAGE_DATA_CRC '
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_46_SM_IMAGE_DATA_CRC (df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_47_SM_TRANSPORT_ROW_TX":
            docTitle = 'DV_12_0_47_SM_TRANSPORT_ROW_TX '
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_47_SM_TRANSPORT_ROW_TX (df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_48_SM_MIPI_HISPI_CRC":
            docTitle = 'DV_12_0_48_SM_MIPI_HISPI_CRC'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_48_SM_MIPI_HISPI_CRC(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_49_SM_OTPM_ECC":
            docTitle = 'DV_12_0_49_SM_OTPM_ECC'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_49_SM_OTPM_ECC(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_50_SM_HOST_CHECK_TEMP_ENABLE":
            docTitle = 'DV_12_0_50_SM_HOST_CHECK_TEMP_ENABLE'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_50_SM_HOST_CHECK_TEMP_ENABLE(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_51_SM_MEC_CRC":
            docTitle = 'DV_12_0_51_SM_MEC_CRC'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_51_SM_MEC_CRC(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_61_SM_DDC_DEF_CNT":
            docTitle = 'DV_12_0_61_SM_DDC_DEF_CNT'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_61_SM_DDC_DEF_CNT(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_62_SM_ATR_ADC_LATCH":
            docTitle = 'DV_12_0_62_SM_ATR_ADC_LATCH'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_62_SM_ATR_ADC_LATCH(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_63_SM_ATR_OVERDRIVE_CODE_012":
            docTitle = 'DV_12_0_63_SM_ATR_OVERDRIVE_CODE_012'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_63_SM_ATR_OVERDRIVE_CODE_012(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_64_SM_ECC_CONTEXT_RAM":
            docTitle = 'DV_12_0_64_SM_ECC_CONTEXT_RAM'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_64_SM_ECC_CONTEXT_RAM(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_65_SM_CDS_MEM_CRC":
            docTitle = 'DV_12_0_65_SM_CDS_MEM_CRC'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_65_SM_CDS_MEM_CRC(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_65_SM_CDS_MEM_CRC_TOP":
            docTitle = 'DV_12_0_65_SM_CDS_MEM_CRC_TOP'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_65_SM_CDS_MEM_CRC_TOP(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_65_SM_CDS_MEM_CRC_BTM":
            docTitle = 'DV_12_0_65_SM_CDS_MEM_CRC_BTM'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_65_SM_CDS_MEM_CRC_BTM(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_66_SM_OFL_MEM_CRC":
            docTitle = 'DV_12_0_66_SM_OFL_MEM_CRC'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_66_SM_OFL_MEM_CRC(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_67_SM_DEF_CORR_RAM_CRC":
            docTitle = 'DV_12_0_67_SM_DEF_CORR_RAM_CRC'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_67_SM_DEF_CORR_RAM_CRC(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_68_SM_MC_RAM":
            docTitle = 'DV_12_0_68_SM_MC_RAM'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_68_SM_MC_RAM(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_69_SM_STATS_RAM_ECC":
            docTitle = 'DV_12_0_69_SM_STATS_RAM_ECC'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_69_SM_STATS_RAM_ECC(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_70_SM_MASTER_STATE_CHA_RES":
            docTitle = 'DV_12_0_70_SM_MASTER_STATE_CHA_RES'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_70_SM_MASTER_STATE_CHA_RES(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_71_SM_ADDR_STATE_CRC":
            docTitle = 'DV_12_0_71_SM_ADDR_STATE_CRC'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_71_SM_ADDR_STATE_CRC(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_72_SM_POWERON_MBIST":
            docTitle = 'DV_12_0_72_SM_POWERON_MBIST'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_72_SM_POWERON_MBIST(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_73_SM_POWERON_MBIST2":
            docTitle = 'DV_12_0_73_SM_POWERON_MBIST2'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_73_SM_POWERON_MBIST2(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_74_SM_HOST_CHECK_GPIO":
            docTitle = 'DV_12_0_74_SM_HOST_CHECK_GPIO'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_74_SM_HOST_CHECK_GPIO(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_75_SM_RESET":
            docTitle = 'DV_12_0_75_SM_RESET'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_75_SM_RESET(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_76_SM_MEC_CRC_NEW":
            docTitle = 'DV_12_0_76_SM_MEC_CRC_NEW'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_76_SM_MEC_CRC_NEW(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_77_SM_PDI_RAM_CRC":
            docTitle = 'DV_12_0_77_SM_PDI_RAM_CRC'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_77_SM_PDI_RAM_CRC(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_78_SM_TEST_FRAME":
            docTitle = 'DV_12_0_78_SM_TEST_FRAME'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_78_SM_TEST_FRAME(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_79_SM_ATR_GRAY_TRANSFER":
            docTitle = 'DV_12_0_79_SM_ATR_GRAY_TRANSFER'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_79_SM_ATR_GRAY_TRANSFER(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_80_SM_LRE_RAM_CRC":
            docTitle = 'DV_12_0_80_SM_LRE_RAM_CRC'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_80_SM_LRE_RAM_CRC(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_81_SM_ODP_BUFFER_CRC":
            docTitle = 'DV_12_0_81_SM_ODP_BUFFER_CRC'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_81_SM_ODP_BUFFER_CRC(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_82_SM_SCALER_RAM_CRC":
            docTitle = 'DV_12_0_82_SM_SCALER_RAM_CRC'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_82_SM_SCALER_RAM_CRC(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_83_SM_PDI_DEF_CNT":
            docTitle = 'DV_12_0_83_SM_PDI_DEF_CNT'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_83_SM_PDI_DEF_CNT(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_84_SM_ATR_OVERDRIVE_012":
            docTitle = 'DV_12_0_84_SM_ATR_OVERDRIVE_012'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_84_SM_ATR_OVERDRIVE_012(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_85_SM_ATR_OVERDRIVE_PSRR":
            docTitle = 'DV_12_0_85_SM_ATR_OVERDRIVE_PSRR'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_85_SM_ATR_OVERDRIVE_PSRR(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_86_SM_DTC":
            docTitle = 'DV_12_0_86_SM_DTC'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_86_SM_DTC(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_90_SM_SMART_CRC":
            docTitle = 'DV_12_0_90_SM_SMART_CRC'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_90_SM_SMART_CRC(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_91_SM_FIFO_CRC":
            docTitle = 'DV_12_0_91_SM_FIFO_CRC'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_91_SM_FIFO_CRC(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_92_SM_ATR_OVERDRIVE_4T":
            docTitle = 'DV_12_0_92_SM_ATR_OVERDRIVE_4T'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_92_SM_ATR_OVERDRIVE_4T(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_93_SM_DTR_MEC":
            docTitle = 'DV_12_0_93_SM_DTR_MEC'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_93_SM_DTR_MEC(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_94_SM_ATR_ECLIPSE":
            docTitle = 'DV_12_0_94_SM_ATR_ECLIPSE'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_94_SM_ATR_ECLIPSE(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_95_SM_ATR_ADAPT":
            docTitle = 'DV_12_0_95_SM_ATR_ADAPT'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_95_SM_ATR_ADAPT(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_97_SM_ATR_OVERDRIVE_3T":
            docTitle = 'DV_12_0_97_SM_ATR_OVERDRIVE_3T'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_97_SM_ATR_OVERDRIVE_3T(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_98_SM_TBRS_RAM_ECC":
            docTitle = 'DV_12_0_98_SM_TBRS_RAM_ECC'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_98_SM_TBRS_RAM_ECC(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_99_SM_TBRS_LOCKED_CRC":
            docTitle = 'DV_12_0_99_SM_TBRS_LOCKED_CRC'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_99_SM_TBRS_LOCKED_CRC(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_100_SM_TBRS_PROCESSING":
            docTitle = 'DV_12_0_100_SM_TBRS_PROCESSING'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_100_SM_TBRS_PROCESSING(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)
        elif test == "DV_12_0_108_SM_LDO_BG_MONITOR":
            docTitle = 'DV_12_0_108_SM_LDO_BG_MONITOR'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_108_SM_LDO_BG_MONITOR(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)
        elif test == "DV_12_0_109_SM_CHIP_SUPPLY_PMU_MONITOR":
            docTitle = 'DV_12_0_109_SM_CHIP_SUPPLY_PMU_MONITOR'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_109_SM_CHIP_SUPPLY_PMU_MONITOR(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)
        elif test == "DV_12_0_110_SM_SENSOR_HISPI_TX_RX_CRC":
            docTitle = 'DV_12_0_110_SM_SENSOR_HISPI_TX_RX_CRC'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_110_SM_SENSOR_HISPI_TX_RX_CRC(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_111_SM_STATS_MON_EXT":
            docTitle = 'DV_12_0_111_SM_STATS_MON_EXT'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_111_SM_STATS_MON_EXT(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_112_SM_DATA_FORMAT":
            docTitle = 'DV_12_0_112_SM_DATA_FORMAT'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_112_SM_DATA_FORMAT(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_113_SM_SENSOR_DATAPATH_BUFFER_CRC":
            docTitle = 'DV_12_0_113_SM_SENSOR_DATAPATH_BUFFER_CRC'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_113_SM_SENSOR_DATAPATH_BUFFER_CRC(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_114_SM_ASIC_DATAPATH_BUFFER_CRC":
            docTitle = 'DV_12_0_114_SM_ASIC_DATAPATH_BUFFER_CRC'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_114_SM_ASIC_DATAPATH_BUFFER_CRC(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_120_SM_BIN2_RAM_CRC":
            docTitle = 'DV_12_0_120_SM_BIN2_RAM_CRC'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_120_SM_BIN2_RAM_CRC(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_121_SM_24_TO_16_BUFFER_CRC":
            docTitle = 'DV_12_0_121_SM_24_TO_16_BUFFER_CRC'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_121_SM_24_TO_16_BUFFER_CRC(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_122_SM_ECC_TPG_RAM":
            docTitle = 'DV_12_0_121_SM_24_TO_16_BUFFER_CRC'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_121_SM_24_TO_16_BUFFER_CRC(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_0_177_SM_PDI_RAM_DED":
            docTitle = 'DV_12_0_177_SM_PDI_RAM_DED'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_0_177_SM_PDI_RAM_DED(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)
        elif test == "DV_12_1_00_SM_UPLOAD_CALIBRATION":
            docTitle = 'DV_12_1_00_SM_UPLOAD_CALIBRATION'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_1_00_SM_UPLOAD_CALIBRATION(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_1_00_SM_RUNTIME_CALIBRATION":
            docTitle = 'DV_12_1_00_SM_RUNTIME_CALIBRATION'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_1_00_SM_RUNTIME_CALIBRATION(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_1_00_SM_FAULT_CALIBRATION":
            docTitle = 'DV_12_1_00_SM_FAULT_CALIBRATION'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_1_00_SM_FAULT_CALIBRATION(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_1_00_SM_UPLOAD_PRE_CALIBRATION":
            docTitle = 'DV_12_1_00_SM_UPLOAD_PRE_CALIBRATION'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_1_00_SM_UPLOAD_PRE_CALIBRATION(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_1_00_SM_UPLOAD_FAULT_PRE_CALIBRATION":
            docTitle = 'DV_12_1_00_SM_UPLOAD_FAULT_PRE_CALIBRATION'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_1_00_SM_UPLOAD_FAULT_PRE_CALIBRATION(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_1_00_SM_UPLOAD":
            docTitle = 'DV_12_1_00_SM_UPLOAD'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_1_00_SM_UPLOAD(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_1_00_SM_UPLOAD_FAULT":
            docTitle = 'DV_12_1_00_SM_UPLOAD_FAULT'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_1_00_SM_UPLOAD_FAULT(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_1_00_SM_UPLOAD_RUNTIME":
            docTitle = 'DV_12_1_00_SM_UPLOAD_RUNTIME'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_1_00_SM_UPLOAD_RUNTIME(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_1_00_SM_TEST_FRAME":
            docTitle = 'DV_12_1_00_SM_TEST_FRAME'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_1_00_SM_TEST_FRAME(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_1_00_SM_TEST_FRAME_FAULT":
            docTitle = 'DV_12_1_00_SM_TEST_FRAME_FAULT'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_1_00_SM_TEST_FRAME_FAULT(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_1_00_SM_RESTORE_TEST_FRAME":
            docTitle = 'DV_12_1_00_SM_RESTORE_TEST_FRAME'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_1_00_SM_RESTORE_TEST_FRAME(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_1_00_SM_FAULT":
            docTitle = 'DV_12_1_00_SM_FAULT'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_1_00_SM_FAULT(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_1_00_SM_RESTORE_FAULT":
            docTitle = 'DV_12_1_00_SM_RESTORE_FAULT'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_1_00_SM_RESTORE_FAULT(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_1_00_SM_RUNTIME":
            docTitle = 'DV_12_1_00_SM_RUNTIME'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_1_00_SM_RUNTIME(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_1_00_SM_SAFE_STATE":
            docTitle = 'DV_12_1_00_SM_SAFE_STATE'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_1_00_SM_SAFE_STATE(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_1_00_SM_SEQUENCE":
            docTitle = 'DV_12_1_00_SM_SEQUENCE'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_1_00_SM_UPLOAD_RUNTIME(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_SM_FAULT_INJECT_ATR":
            docTitle = 'DV_12_SM_FAULT_INJECT_ATR'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_SM_FAULT_INJECT_ATR(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_SM_FAULT_INJECT_RRC":
            docTitle = 'DV_12_SM_FAULT_INJECT_RRC'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_SM_FAULT_INJECT_RRC(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_FAULT_MEMORY_TEST_1":
            docTitle = 'DV_12_FAULT_MEMORY_TEST_1'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_FAULT_MEMORY_TEST_1(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_FAULT_MEMORY_TEST_2":
            docTitle = 'DV_12_FAULT_MEMORY_TEST_2'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_FAULT_MEMORY_TEST_2(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_12_SM_MEMORY_CRC_TEST":
            docTitle = 'DV_12_SM_MEMORY_CRC_TEST'
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_12_SM_MEMORY_CRC_TEST(df, document, imgPath, pltPath)  # Run test
            VRG_Doc.SaveDoc(document, reportFilePath)  # Save def validation template as a new report name
        elif test == "DV_13_1_IMPLANT_RECIPE_VERIFICATION":
            docTitle = 'DV_13_1_IMPLANT_RECIPE_VERIFICATION' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_13_1_IMPLANT_RECIPE_VERIFICATION(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_13_2_INLINE_CD_DATA_COLLECTION_PROCESS_RELEASE":
            docTitle = 'DV_13_2_INLINE_CD_DATA_COLLECTION_PROCESS_RELEASE' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_13_2_INLINE_CD_DATA_COLLECTION_PROCESS_RELEASE(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_13_3_FULL_SCRIBE_PARAM_VERIFICATION":
            docTitle = 'DV_13_3_FULL_SCRIBE_PARAM_VERIFICATION' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_13_3_FULL_SCRIBE_PARAM_VERIFICATION(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_13_4_ANOVA_MODEL_BOXES":
            docTitle = 'DV_13_4_ANOVA_MODEL_BOXES' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_13_4_ANOVA_MODEL_BOXES(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name
        elif test == "DV_13_5_PROBE_SUMMARY":
            docTitle = 'DV_13_5_PROBE_SUMMARY' #set report title
            VRG_Doc.UpdateDoc(document, docTitle, designID, designRev)  # update val template with new info
            VRG_Reports.DV_13_5_PROBE_SUMMARY(df, document, imgPath, pltPath) # Run test
            VRG_Doc.SaveDoc(document, reportFilePath) #Save def validation template as a new report name

        timestamp = time.strftime("%m/%d/%Y %I:%M:%S %p")  # Time stamp
        print("VRG Report Complete: ", timestamp)

        reportTime = (time.time() - startTime)
        print("--- Report Generation Time: %s seconds ---" % reportTime)

        inputFile = open(inputFileListPath, "a")
        trackingFile = open(trackingPathDef + '/VRG_Tracker.txt', "a")  # append to existing one
        inputFile.write("REPORT_TIME" + "\t" + str(reportTime) + "\n")
        inputFile.write("\n")
        inputFile.close()
        trackingFile.write("REPORT_TIME" + "\t" + str(reportTime) + "\n")
        trackingFile.write("\n")
        trackingFile.close()

        acknowledge = messagebox.showinfo("Report Complete", reportFilePath + " Saved Successfully")
        if acknowledge == 'ok':
            window.destroy() # close application

    infileBtn1 = Button(window, text=infileBtnDef1, command=infileClick1, bg=btnBG, fg=btnFG, borderwidth=3, font=btnFont)
    infileBtn1.grid(row=0, column=3, pady=padY, padx=padX, sticky=W)

    infileBtn2 = Button(window, text=infileBtnDef2, command=infileClick2, bg=btnBG, fg=btnFG, borderwidth=3, font=btnFont)
    infileBtn2.grid(row=1, column=3, pady=padY, padx=padX, sticky=W)

    infileBtn3 = Button(window, text=infileBtnDef3, command=infileClick3, bg=btnBG, fg=btnFG, borderwidth=3, font=btnFont)
    infileBtn3.grid(row=2, column=3, pady=padY, padx=padX, sticky=W)

    infileBtn4 = Button(window, text=infileBtnDef4, command=infileClick4, bg=btnBG, fg=btnFG, borderwidth=3, font=btnFont)
    infileBtn4.grid(row=3, column=3, pady=padY, padx=padX, sticky=W)

    infileBtn5 = Button(window, text=infileBtnDef5, command=infileClick5, bg=btnBG, fg=btnFG, borderwidth=3, font=btnFont)
    infileBtn5.grid(row=4, column=3, pady=padY, padx=padX, sticky=W)

    infileBtn6 = Button(window, text=infileBtnDef6, command=infileClick6, bg=btnBG, fg=btnFG, borderwidth=3, font=btnFont)
    infileBtn6.grid(row=5, column=3, pady=padY, padx=padX, sticky=W)

    infileBtn7 = Button(window, text=infileBtnDef7, command=infileClick7, bg=btnBG, fg=btnFG, borderwidth=3, font=btnFont)
    infileBtn7.grid(row=6, column=3, pady=padY, padx=padX, sticky=W)

    infileBtn8 = Button(window, text=infileBtnDef8, command=infileClick8, bg=btnBG, fg=btnFG, borderwidth=3, font=btnFont)
    infileBtn8.grid(row=7, column=3, pady=padY, padx=padX, sticky=W)

    infileBtn9 = Button(window, text=infileBtnDef9, command=infileClick9, bg=btnBG, fg=btnFG, borderwidth=3, font=btnFont)
    infileBtn9.grid(row=8, column=3, pady=padY, padx=padX, sticky=W)

    imgfileBtn = Button(window, text=imgfileBtnDef, command=imgfileDir, bg=btnBG, fg=btnFG, borderwidth=3, font=btnFont)
    imgfileBtn.grid(row=9, column=3, pady=padY, padx=padX, sticky=W)

    outfileBtn1 = Button(window, text=outfileBtnDef1, command=outfileClick1, bg=btnBG, fg=btnFG, borderwidth=3, font=btnFont)
    outfileBtn1.grid(row=10, column=3, pady=padY, padx=padX, sticky=W)

    outfileBtn2 = Button(window, text=outfileBtnDef2, command=outfileClick2, bg=btnBG, fg=btnFG, borderwidth=3, font=btnFont)
    outfileBtn2.grid(row=11, column=3, pady=padY, padx=padX, sticky=W)

    pltfileBtn = Button(window, text=pltfileBtnDef, command=pltfileDir, bg=btnBG, fg=btnFG, borderwidth=3, font=btnFont)
    pltfileBtn.grid(row=12, column=3, pady=padY, padx=padX, sticky=W)

    runBtn = Button(window, text=runBtnDef, command=VRG_Get_Inputs, bg=runBtnBG, fg=runBtnFG, font=runBtnFont, borderwidth=3, width=7, height=2)
    runBtn.grid(row=15, column=3, pady=padY, padx=padX, sticky=W)

    quitBtn = Button(window, text=quitBtnDef, command=window.destroy, bg=quitBtnBG, fg=quitBtnFG, font=quitBtnFont, borderwidth=3, width=7, height=2)
    quitBtn.grid(row=15, column=3, pady=padY, padx=padX, sticky=E)

    mainloop() # Gui loop
