import matplotlib
import matplotlib.pyplot as plt
from matplotlib import pyplot
from docx import Document
from docx.shared import Inches
from docx.shared import Pt
from tkinter import *
from tkinter import filedialog
from tkinter import messagebox
import numpy as np
import csv
import argparse
import os
import pandas as pd
import pixelcrunch as pc
import fivecentplots as fcp
import bokeh
import sys
import io
import multiprocessing
import VRG_Safety_Data
import VRG_Calculate
import VRG_Data_Frame
import VRG_Doc
import VRG_General_Data
import VRG_Image_Analysis
import VRG_Image_Utils
import VRG_Macro_Data
import VRG_OTPM_Data
import VRG_Pins_Data
import VRG_Power_Data
import VRG_Register_Data
import VRG_Stats_Arr
import VRG_Stats_ArrCenter
import VRG_Stats_ArrQuad1
import VRG_Stats_ArrQuad2
import VRG_Stats_ArrQuad3
import VRG_Stats_ArrQuad4
import VRG_Stats_ArrRoi1
import VRG_Stats_ArrRoi2
import VRG_Stats_ArrRoi3
import VRG_Stats_ArrRoi4
import VRG_Stats_ArrRoi5
import VRG_Stats_ArrRoi6
import VRG_Stats_ArrRoi7
import VRG_Stats_ArrRoi8
import VRG_Stats_ArrRoi9
import VRG_Stats_DBLC
import VRG_Stats_Frame
import VRG_Stats_Lag
import VRG_Stats_RNC
import VRG_Stats_Tilt
import VRG_Tempsensor_Data
import VRG_Reports
import time

'''
Digital Gain
'''
def Calc_DigitalGain_Plot(dataFrame, groupBy, document, pltPath, digGainCol, digGain1xVal, dataPedestalVal, showPlt, **kwargs):
    try:
        df = dataFrame

        # 1x Gain Location
        indexer_1x = df[df[digGainCol] == digGain1xVal].index # 1x dig gain value index
        Gr_Gain1x = np.mean(df.loc[indexer_1x, 'Mean_GreenR']) # locate the 1x mean
        R_Gain1x = np.mean(df.loc[indexer_1x, 'Mean_Red']) # locate the 1x mean red
        Gb_Gain1x = np.mean(df.loc[indexer_1x, 'Mean_GreenB']) # locate the 1x mean
        B_Gain1x = np.mean(df.loc[indexer_1x, 'Mean_Blue']) # locate the 1x mean blue

        # Calculated Gain
        df['GreenR_Calc_DigGain'] = (df['Mean_GreenR'] - dataPedestalVal)/Gr_Gain1x # Calculate gain by dividing mean response by 1x response
        df['Red_Calc_DigGain'] = (df['Mean_Red']- dataPedestalVal)/R_Gain1x # Calculate gain by dividing mean response by 1x response
        df['GreenB_Calc_DigGain'] = (df['Mean_GreenB']- dataPedestalVal)/Gb_Gain1x # Calculate gain by dividing mean response by 1x response
        df['Blue_Calc_DigGain'] = (df['Mean_Blue']- dataPedestalVal)/B_Gain1x # Calculate gain by dividing mean response by 1x response

        d1 = 'GreenR_Calc_DigGain'
        d2 = 'Red_Calc_DigGain'
        d3 = 'GreenB_Calc_DigGain'
        d4 = 'Blue_Calc_DigGain'

        sd1 = 'Mean_GreenR'
        sd2 = 'Mean_Red'
        sd3 = 'Mean_GreenB'
        sd4 = 'Mean_Blue'

        figTitle = 'Calc_Dig_Gain'
        ylabel = 'Calc Digital Gain (x)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        tickFontsize = 8

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=digGainCol, y=[eval("d" + str(x)), eval("sd" + str(x))], title=eval("d" + str(x)),
                         show=showPlt, twin_x=True,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         tick_labels_major_font_size=tickFontsize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x=digGainCol, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize, tick_labels_major_font_size=tickFontsize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=digGainCol, y=[eval("d" + str(x)), eval("sd" + str(x))], title=eval("d" + str(x)),
                         legend=groupBy, show=showPlt, twin_x=True,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         tick_labels_major_font_size=tickFontsize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x=digGainCol, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize, tick_labels_major_font_size=tickFontsize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if digGainCol in df.columns:
            document.add_heading("digGainCol Found: " + digGainCol, level=3)  # Add Groupby found
            if digGain1xVal in df[digGainCol].unique():
                document.add_heading("digGain1xVal Found: " + digGain1xVal, level=3)  # Add Groupby found
            else:
                document.add_heading("digGain1xVal Not Found: " + digGain1xVal, level=3)  # Add Groupby not found
        else:
            document.add_heading("digGainCol Not Found: " + digGainCol, level=3)  # Add Groupby not found
        if dataPedestalVal == None:
            document.add_heading("dataPedestalVal Missing", level=3)
        elif dataPedestalVal != None:
            document.add_heading("dataPedestalVal Found" + dataPedestalVal, level=3)

'''
Analog Gain - Active Array
'''
def Calc_AnalogGain_Plot(dataFrame, groupBy, document, pltPath, anaGainCol, anaGain1xVal, dataPedestalVal, showPlt, **kwargs):
    try:
        df = dataFrame

        #1x Gain Location
        indexer_1x = df[df[anaGainCol] == anaGain1xVal].index  # 1x ana gain value index
        Gr_Gain1x = np.mean(df.loc[indexer_1x, 'Mean_GreenR']) # locate the 1x mean greenr
        R_Gain1x = np.mean(df.loc[indexer_1x, 'Mean_Red']) # locate the 1x mean red
        Gb_Gain1x = np.mean(df.loc[indexer_1x, 'Mean_GreenB']) # locate the 1x mean greenb
        B_Gain1x = np.mean(df.loc[indexer_1x, 'Mean_Blue']) # locate the 1x mean blue

        # Calculated Gain
        df['GreenR_Calc_AnaGain'] = (df['Mean_GreenR']-dataPedestalVal)/Gr_Gain1x # Calculate gain by dividing mean response by 1x response after subtracting datapedestal
        df['Red_Calc_AnaGain'] = (df['Mean_Red']-dataPedestalVal)/R_Gain1x # Calculate gain by dividing mean response by 1x response after subtracting datapedestal
        df['GreenB_Calc_AnaGain'] = (df['Mean_GreenB']-dataPedestalVal)/Gb_Gain1x # Calculate gain by dividing mean response by 1x response after subtracting datapedestal
        df['Blue_Calc_AnaGain'] = (df['Mean_Blue']-dataPedestalVal)/B_Gain1x # Calculate gain by dividing mean response by 1x response after subtracting datapedestal

        d1 = 'GreenR_Calc_AnaGain'
        d2 = 'Red_Calc_AnaGain'
        d3 = 'GreenB_Calc_AnaGain'
        d4 = 'Blue_Calc_AnaGain'

        sd1 = 'Mean_GreenR'
        sd2 = 'Mean_Red'
        sd3 = 'Mean_GreenB'
        sd4 = 'Mean_Blue'

        figTitle = 'Calc_Ana_Gain'
        ylabel = 'Calc Analog Gain (x)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        tickFontsize = 8

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=anaGainCol, y=[eval("d" + str(x)), eval("sd" + str(x))], title=eval("d" + str(x)),
                         show=showPlt, twin_x=True,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         tick_labels_major_font_size=tickFontsize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x=anaGainCol, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     tick_labels_major_font_size=tickFontsize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=anaGainCol, y=[eval("d" + str(x)), eval("sd" + str(x))], title=eval("d" + str(x)),
                         legend=groupBy, show=showPlt, twin_x=True,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         tick_labels_major_font_size=tickFontsize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x=anaGainCol, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     tick_labels_major_font_size=tickFontsize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if anaGainCol in df.columns:
            document.add_heading("anaGainCol Found: " + anaGainCol, level=3)  # Add Groupby found
            if anaGain1xVal in df[anaGainCol].unique():
                document.add_heading("anaGain1xVal Found: " + anaGain1xVal, level=3)  # Add Groupby found
            else:
                document.add_heading("anaGain1xVal Not Found: " + anaGain1xVal, level=3)  # Add Groupby not found
        else:
            document.add_heading("anaGainCol Not Found: " + anaGainCol, level=3)  # Add Groupby not found
        if dataPedestalVal == None:
            document.add_heading("dataPedestalVal Missing", level=3)
        elif dataPedestalVal != None:
            document.add_heading("dataPedestalVal Found" + dataPedestalVal, level=3)

def Calc_AnalogGain_Error_Plot(dataFrame, groupBy, document, pltPath, anaGainCol, anaGain1xVal, dataPedestalVal, showPlt, **kwargs):
    try:
        df = dataFrame
        indexer_1x = df[df[anaGainCol] == anaGain1xVal].index  # 1x ana gain value index
        Gr_Gain1x = np.mean(df.loc[indexer_1x, 'Mean_GreenR']) # locate the 1x mean greenr
        Gb_Gain1x = np.mean(df.loc[indexer_1x, 'Mean_GreenB']) # locate the 1x mean greenb
        R_Gain1x = np.mean(df.loc[indexer_1x, 'Mean_Red']) # locate the 1x mean red
        B_Gain1x = np.mean(df.loc[indexer_1x, 'Mean_Blue']) # locate the 1x mean blue

        # Calculated Gain
        df['GreenR_Calc_AnaGain'] = (df['Mean_GreenR']-dataPedestalVal)/Gr_Gain1x # Calculate gain by dividing mean response by 1x response after subtracting datapedestal
        df['Red_Calc_AnaGain'] = (df['Mean_Red']-dataPedestalVal)/R_Gain1x # Calculate gain by dividing mean response by 1x response after subtracting datapedestal
        df['GreenB_Calc_AnaGain'] = (df['Mean_GreenB']-dataPedestalVal)/Gb_Gain1x # Calculate gain by dividing mean response by 1x response after subtracting datapedestal
        df['Blue_Calc_AnaGain'] = (df['Mean_Blue']-dataPedestalVal)/B_Gain1x # Calculate gain by dividing mean response by 1x response after subtracting datapedestal

        # Percent Error
        df['GreenR_Calc_AnaGain_Error'] = abs((df['GreenR_Calc_AnaGain']-df[anaGainCol]) / df[anaGainCol])*100# %error = abs((act - exp)/exp)*100
        df['Red_Calc_AnaGain_Error'] = abs((df['Red_Calc_AnaGain']-df[anaGainCol]) / df[anaGainCol])*100  # %error = abs((act - exp)/exp)*100
        df['GreenB_Calc_AnaGain_Error'] = abs((df['GreenB_Calc_AnaGain']-df[anaGainCol]) / df[anaGainCol])*100 # %error = abs((act - exp)/exp)*100
        df['Blue_Calc_AnaGain_Error'] = abs((df['Blue_Calc_AnaGain']-df[anaGainCol]) / df[anaGainCol])*100  # %error = abs((act - exp)/exp)*100

        d1 = 'GreenR_Calc_AnaGain_Error'
        d2 = 'Red_Calc_AnaGain_Error'
        d3 = 'GreenB_Calc_AnaGain_Error'
        d4 = 'Blue_Calc_AnaGain_Error'

        sd1 = 'GreenR_Calc_AnaGain'
        sd2 = 'Red_Calc_AnaGain'
        sd3 = 'GreenB_Calc_AnaGain'
        sd4 = 'Blue_Calc_AnaGain'

        figTitle = 'Ana_Gain_Error'
        ylabel = 'AnaGain % Error'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        tickFontsize = 8

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=anaGainCol, y=[eval("d" + str(x)), eval("sd" + str(x))], title=eval("d" + str(x)),
                         show=showPlt, twin_x=True,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         tick_labels_major_font_size=tickFontsize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x=anaGainCol, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     tick_labels_major_font_size=tickFontsize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=anaGainCol, y=[eval("d" + str(x)), eval("sd" + str(x))], title=eval("d" + str(x)),
                         legend=groupBy, show=showPlt, twin_x=True, label_y=ylabel,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         tick_labels_major_font_size=tickFontsize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x=anaGainCol, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     tick_labels_major_font_size=tickFontsize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if anaGainCol in df.columns:
            document.add_heading("anaGainCol Found: " + anaGainCol, level=3)  # Add Groupby found
            if anaGain1xVal in df[anaGainCol].unique():
                document.add_heading("anaGain1xVal Found: " + anaGain1xVal, level=3)  # Add Groupby found
            else:
                document.add_heading("anaGain1xVal Not Found: " + anaGain1xVal, level=3)  # Add Groupby not found
        else:
            document.add_heading("anaGainCol Not Found: " + anaGainCol, level=3)  # Add Groupby not found
        if dataPedestalVal == None:
            document.add_heading("dataPedestalVal Missing", level=3)
        elif dataPedestalVal != None:
            document.add_heading("dataPedestalVal Found" + dataPedestalVal, level=3)

'''
Analog Gain - Analog Test Rows
'''
def Calc_AnalogGain_ATR_Plot(dataFrame, groupBy, document, pltPath, anaGainCol, anaGain1xVal, dataPedestalVal, showPlt, **kwargs):
    try:
        df = dataFrame

        #1x Gain Location
        indexer_1x = df[df[anaGainCol] == anaGain1xVal].index  # 1x ana gain value index
        Gr_Gain1x = np.mean(df.loc[indexer_1x, 'Mean_GreenR']) # locate the 1x mean greenr
        R_Gain1x = np.mean(df.loc[indexer_1x, 'Mean_Red']) # locate the 1x mean red
        Gb_Gain1x = np.mean(df.loc[indexer_1x, 'Mean_GreenB']) # locate the 1x mean greenb
        B_Gain1x = np.mean(df.loc[indexer_1x, 'Mean_Blue']) # locate the 1x mean blue

        # Calculated Gain
        df['GreenR_Calc_AnaGain'] = (df['Mean_GreenR']-dataPedestalVal)/Gr_Gain1x # Calculate gain by dividing mean response by 1x response after subtracting datapedestal
        df['Red_Calc_AnaGain'] = (df['Mean_Red']-dataPedestalVal)/R_Gain1x # Calculate gain by dividing mean response by 1x response after subtracting datapedestal
        df['GreenB_Calc_AnaGain'] = (df['Mean_GreenB']-dataPedestalVal)/Gb_Gain1x # Calculate gain by dividing mean response by 1x response after subtracting datapedestal
        df['Blue_Calc_AnaGain'] = (df['Mean_Blue']-dataPedestalVal)/B_Gain1x # Calculate gain by dividing mean response by 1x response after subtracting datapedestal

        d1 = 'GreenR_Calc_AnaGain'
        d2 = 'Red_Calc_AnaGain'
        d3 = 'GreenB_Calc_AnaGain'
        d4 = 'Blue_Calc_AnaGain'

        sd1 = 'Mean_GreenR'
        sd2 = 'Mean_Red'
        sd3 = 'Mean_GreenB'
        sd4 = 'Mean_Blue'

        figTitle = 'Calc_Ana_Gain_ATR'
        ylabel = 'Calc Analog Gain (x)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        tickFontsize = 8

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=anaGainCol, y=[eval("d" + str(x)), eval("sd" + str(x))], title=eval("d" + str(x)),
                         show=showPlt, twin_x=True,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         tick_labels_major_font_size=tickFontsize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x=anaGainCol, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     tick_labels_major_font_size=tickFontsize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=anaGainCol, y=[eval("d" + str(x)), eval("sd" + str(x))], title=eval("d" + str(x)),
                         legend=groupBy, show=showPlt, twin_x=True,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         tick_labels_major_font_size=tickFontsize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x=anaGainCol, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     tick_labels_major_font_size=tickFontsize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
            # Plot combined data in one plot
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if anaGainCol in df.columns:
            document.add_heading("anaGainCol Found: " + anaGainCol, level=3)  # Add Groupby found
            if anaGain1xVal in df[anaGainCol].unique():
                document.add_heading("anaGain1xVal Found: " + anaGain1xVal, level=3)  # Add Groupby found
            else:
                document.add_heading("anaGain1xVal Not Found: " + anaGain1xVal, level=3)  # Add Groupby not found
        else:
            document.add_heading("anaGainCol Not Found: " + anaGainCol, level=3)  # Add Groupby not found
        if dataPedestalVal == None:
            document.add_heading("dataPedestalVal Missing", level=3)
        elif dataPedestalVal != None:
            document.add_heading("dataPedestalVal Found" + dataPedestalVal, level=3)

def Calc_AnalogGain_ATR_Error_Plot(dataFrame, groupBy, document, pltPath, anaGainCol, anaGain1xVal, dataPedestalVal, showPlt, **kwargs):
    try:
        df = dataFrame
        indexer_1x = df[df[anaGainCol] == anaGain1xVal].index  # 1x ana gain value index
        Gr_Gain1x = np.mean(df.loc[indexer_1x, 'Mean_GreenR']) # locate the 1x mean greenr
        Gb_Gain1x = np.mean(df.loc[indexer_1x, 'Mean_GreenB']) # locate the 1x mean greenb
        R_Gain1x = np.mean(df.loc[indexer_1x, 'Mean_Red']) # locate the 1x mean red
        B_Gain1x = np.mean(df.loc[indexer_1x, 'Mean_Blue']) # locate the 1x mean blue

        # Calculated Gain
        df['GreenR_Calc_AnaGain'] = (df['Mean_GreenR']-dataPedestalVal)/Gr_Gain1x # Calculate gain by dividing mean response by 1x response after subtracting datapedestal
        df['Red_Calc_AnaGain'] = (df['Mean_Red']-dataPedestalVal)/R_Gain1x # Calculate gain by dividing mean response by 1x response after subtracting datapedestal
        df['GreenB_Calc_AnaGain'] = (df['Mean_GreenB']-dataPedestalVal)/Gb_Gain1x # Calculate gain by dividing mean response by 1x response after subtracting datapedestal
        df['Blue_Calc_AnaGain'] = (df['Mean_Blue']-dataPedestalVal)/B_Gain1x # Calculate gain by dividing mean response by 1x response after subtracting datapedestal

        # Percent Error
        df['GreenR_Calc_AnaGain_Error'] = abs((df['GreenR_Calc_AnaGain']-df[anaGainCol]) / df[anaGainCol])*100# %error = abs((act - exp)/exp)*100
        df['Red_Calc_AnaGain_Error'] = abs((df['Red_Calc_AnaGain']-df[anaGainCol]) / df[anaGainCol])*100  # %error = abs((act - exp)/exp)*100
        df['GreenB_Calc_AnaGain_Error'] = abs((df['GreenB_Calc_AnaGain']-df[anaGainCol]) / df[anaGainCol])*100 # %error = abs((act - exp)/exp)*100
        df['Blue_Calc_AnaGain_Error'] = abs((df['Blue_Calc_AnaGain']-df[anaGainCol]) / df[anaGainCol])*100  # %error = abs((act - exp)/exp)*100

        d1 = 'GreenR_Calc_AnaGain_Error'
        d2 = 'Red_Calc_AnaGain_Error'
        d3 = 'GreenB_Calc_AnaGain_Error'
        d4 = 'Blue_Calc_AnaGain_Error'

        sd1 = 'GreenR_Calc_AnaGain'
        sd2 = 'Red_Calc_AnaGain'
        sd3 = 'GreenB_Calc_AnaGain'
        sd4 = 'Blue_Calc_AnaGain'

        figTitle = 'Ana_Gain_ATR_Error'
        ylabel = 'AnaGain % Error'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        tickFontsize = 8

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=anaGainCol, y=[eval("d" + str(x)), eval("sd" + str(x))], title=eval("d" + str(x)),
                         show=showPlt, twin_x=True,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         tick_labels_major_font_size=tickFontsize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x=anaGainCol, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     tick_labels_major_font_size=tickFontsize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=anaGainCol, y=[eval("d" + str(x)), eval("sd" + str(x))], title=eval("d" + str(x)),
                         legend=groupBy, show=showPlt, twin_x=True, label_y=ylabel,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         tick_labels_major_font_size=tickFontsize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x=anaGainCol, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     tick_labels_major_font_size=tickFontsize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if anaGainCol in df.columns:
            document.add_heading("anaGainCol Found: " + anaGainCol, level=3)  # Add Groupby found
            if anaGain1xVal in df[anaGainCol].unique():
                document.add_heading("anaGain1xVal Found: " + anaGain1xVal, level=3)  # Add Groupby found
            else:
                document.add_heading("anaGain1xVal Not Found: " + anaGain1xVal, level=3)  # Add Groupby not found
        else:
            document.add_heading("anaGainCol Not Found: " + anaGainCol, level=3)  # Add Groupby not found
        if dataPedestalVal == None:
            document.add_heading("dataPedestalVal Missing", level=3)
        elif dataPedestalVal != None:
            document.add_heading("dataPedestalVal Found" + dataPedestalVal, level=3)

'''
Temperature Coefficient
'''
def Operating_Current_Temperature_Coefficient_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        df = dataFrame

        # Column Names in CSV
        d1 = 'I_VAA2V8(mA)'
        d2 = 'I_VAA1V8(mA)'
        d3 = 'I_VDD(mA)'
        d4 = 'I_VDD_PHY(mA)'
        d5 = 'I_VDD_IO(mA)'
        d6 = 'I_VAA_PIX(mA)'
        d7 = 'I_VDD_SLVS(mA)'
        d8 = 'I_TOTAL(mA)'

        # Calculate Temperature Coefficient for each supply
        df['Tc_I_VAA2V8(mA)'] = df[d1]/df['TemperatureSetPoint']
        df['Tc_I_VAA1V8(mA)'] = df[d2]/df['TemperatureSetPoint']
        df['Tc_I_VDD(mA)'] = df[d3]/df['TemperatureSetPoint']
        df['Tc_I_VDD_PHY(mA)'] = df[d4]/df['TemperatureSetPoint']
        df['Tc_I_VDD_IO(mA)'] = df[d5]/df['TemperatureSetPoint']
        df['Tc_I_VAA_PIX(mA)'] = df[d6]/df['TemperatureSetPoint']
        df['Tc_I_VDD_SLVS(mA)'] = df[d7]/df['TemperatureSetPoint']
        df['Tc_I_TOTAL(mA)'] = df[d8]/df['TemperatureSetPoint']

        # Calculated Temperature Coefficient column names
        sd1 = 'Tc_I_VAA2V8(mA/C)'
        sd2 = 'Tc_I_VAA1V8(mA/C)'
        sd3 = 'Tc_I_VDD(mA/C)'
        sd4 = 'Tc_I_VDD_PHY(mA/C)'
        sd5 = 'Tc_I_VDD_IO(mA/C)'
        sd6 = 'Tc_I_VAA_PIX(mA/C)'
        sd7 = 'Tc_I_VDD_SLVS(mA/C)'
        sd8 = 'Tc_I_TOTAL(mA/C)'

        figTitle = 'Operating_Current_Temperature_Coefficient'
        ylabel = 'Temperature Coefficient (mA/Celsius)'
        numDataCols = 9  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("sd" + str(x)), title=eval("sd" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("sd" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("sd" + str(x)), level=3)
                    document.add_picture(pltPath + eval("sd" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                    fcp.plot(df, x='Step', y=eval("sd" + str(x)), title=eval("sd" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("sd" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("sd" + str(x)), level=3)
                    document.add_picture(pltPath + eval("sd" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        for x in range(1, numDataCols):  # 1 to 4
            if eval("sd" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("sd" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("sd" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

'''
Calculated Datapedestal Error
'''
def Calc_DataPedestal_Error_Plot(dataFrame, groupBy, document, pltPath, dataPedColName, showPlt, **kwargs):
    try:
        df = dataFrame

        dm1 = 'Mean_GreenR'
        dm2 = 'Mean_Red'
        dm3 = 'Mean_GreenB'
        dm4 = 'Mean_Blue'

        d1 = 'GreenR_DataPedestal_Error'
        d2 = 'Red_DataPedestal_Error'
        d3 = 'GreenB_DataPedestal_Error'
        d4 = 'Blue_DataPedestal_Error'

        sd1 = 'GreenR_DataPedestal_Diff'
        sd2 = 'Red_DataPedestal_Diff'
        sd3 = 'GreenB_DataPedestal_Diff'
        sd4 = 'Blue_DataPedestal_Diff'

        # DN Difference
        df[sd1] = abs(df[dm1]-df[dataPedColName])  # Absolute Error
        df[sd2] = abs(df[dm2]-df[dataPedColName])  # Absolute Error
        df[sd3] = abs(df[dm3]-df[dataPedColName])  # Absolute Error
        df[sd4] = abs(df[dm4]-df[dataPedColName])  # Absolute Error

        df[d1] = (abs((df[dm1]-df[dataPedColName]) / df[dataPedColName]))*100  # %error = abs((act - exp)/exp)*100
        df[d2] = (abs((df[dm2]-df[dataPedColName]) / df[dataPedColName]))*100  # %error = abs((act - exp)/exp)*100
        df[d3] = (abs((df[dm3]-df[dataPedColName]) / df[dataPedColName]))*100  # %error = abs((act - exp)/exp)*100
        df[d4] = (abs((df[dm4]-df[dataPedColName]) / df[dataPedColName]))*100  # %error = abs((act - exp)/exp)*100

        df[d1] = df[d1].replace([np.inf, -np.inf], np.nan)  # replace any inf values
        df[d2] = df[d2].replace([np.inf, -np.inf], np.nan)  # replace any inf values
        df[d3] = df[d3].replace([np.inf, -np.inf], np.nan)  # replace any inf values
        df[d4] = df[d4].replace([np.inf, -np.inf], np.nan)  # replace any inf values
        df[d1].dropna(inplace=True)  # drop rows that are NaN
        df[d2].dropna(inplace=True)  # drop rows that are NaN
        df[d3].dropna(inplace=True)  # drop rows that are NaN
        df[d4].dropna(inplace=True)  # drop rows that are NaN

        figTitle = 'DataPedestal_Error'
        ylabel = 'DataPedestal Percent Error (%)'
        ylabel2 = 'DataPedestal Absolute Error (DN)'
        numDataCols = 5  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        tickFontsize = 8

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        # Plot combined data in one plot
        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=dataPedColName, y=eval("d" + str(x)), title=eval("d" + str(x)),
                         show=showPlt, label_y=ylabel,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         tick_labels_major_font_size=tickFontsize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x=dataPedColName, y=[d1, d2, d3, d4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     tick_labels_major_font_size=tickFontsize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=dataPedColName, y=eval("d" + str(x)), title=eval("d" + str(x)),
                         legend=groupBy, show=showPlt, label_y=ylabel,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         tick_labels_major_font_size=tickFontsize,
                         **kwargs, filename=pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("d" + str(x)), level=3)
                document.add_picture(pltPath + eval("d" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x=dataPedColName, y=[d1, d2, d3, d4], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     tick_labels_major_font_size=tickFontsize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(d1 + ' ' + d2 + ' ' + d3 + ' ' + d4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=dataPedColName, y=eval("sd" + str(x)), title=eval("sd" + str(x)),
                         show=showPlt, label_y=ylabel2,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         tick_labels_major_font_size=tickFontsize,
                         **kwargs, filename=pltPath + eval("sd" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("sd" + str(x)), level=3)
                document.add_picture(pltPath + eval("sd" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x=dataPedColName, y=[sd1, sd2, sd3, sd4], title=figTitle, show=showPlt, inline=showPlt,
                     label_y=ylabel2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     tick_labels_major_font_size=tickFontsize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(sd1 + ' ' + sd2 + ' ' + sd3 + ' ' + sd4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to 4
                fcp.plot(df, x=dataPedColName, y=eval("sd" + str(x)), title=eval("sd" + str(x)),
                         legend=groupBy, show=showPlt, label_y=ylabel2,
                         inline=showPlt, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                         label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                         tick_labels_major_font_size=tickFontsize,
                         **kwargs, filename=pltPath + eval("sd" + str(x)) + '_' + timestamp + '.png')
                document.add_heading(eval("sd" + str(x)), level=3)
                document.add_picture(pltPath + eval("sd" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
            fcp.plot(df, x=dataPedColName, y=[sd1, sd2, sd3, sd4], title=figTitle, legend=groupBy, show=showPlt,
                     inline=showPlt,
                     label_y=ylabel2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                     label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     tick_labels_major_font_size=tickFontsize,
                     **kwargs, filename=pltPath + figTitle + '_' + timestamp + '.png')
            document.add_heading(sd1 + ' ' + sd2 + ' ' + sd3 + ' ' + sd4, level=3)
            document.add_picture(pltPath + figTitle + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        for x in range(1, numDataCols):  # 1 to 4
            if eval("sd" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("sd" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("sd" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if dataPedColName in df.columns:
            document.add_heading("dataPedColName Found: " + dataPedColName, level=3)  #  found
        else:
            document.add_heading("dataPedColName Not Found: " + dataPedColName, level=3)  # A not found

'''
Calculated Frame Size
'''
def Calc_FrameSize_Plot(dataFrame, groupBy, document, pltPath, xAddrStartCol, xAddrEndCol, yAddrStartCol, yAddrEndCol, showPlt, **kwargs):
    try:
        df = dataFrame

        d1 = 'FrameWidth'
        d2 = 'FrameHeight'

        df['Calc_FrameWidth'] = df[xAddrEndCol] - df[xAddrStartCol] # Frame width
        df['Calc_FrameHeight'] = df[yAddrEndCol] - df[yAddrStartCol] # Frame height

        sd1 = 'Calc_FrameWidth'
        sd2 = 'Calc_FrameHeight'

        figTitle = 'Calculated_FrameSize'
        ylabel = 'Frame Width (Cols)'
        ylabel2 = 'Frame Height (Rows)'
        numDataCols = 3  # Number of columns + 1 to loop through (last col + 1)
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                if x == 1:
                    fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("sd" + str(x))], title=eval("sd" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("sd" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("sd" + str(x)), level=3)
                    document.add_picture(pltPath + eval("sd" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
                elif x == 2:
                    fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("sd" + str(x))], title=eval("sd" + str(x)), show=showPlt,
                             inline=showPlt, label_y=ylabel2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("sd" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("sd" + str(x)), level=3)
                    document.add_picture(pltPath + eval("sd" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each data frame column
            for x in range(1, numDataCols):  # 1 to N
                if x == 1:
                    fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("sd" + str(x))], title=eval("sd" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("sd" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("sd" + str(x)), level=3)
                    document.add_picture(pltPath + eval("sd" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
                elif x == 2:
                    fcp.plot(df, x='Step', y=[eval("d" + str(x)), eval("sd" + str(x))], title=eval("sd" + str(x)), legend=groupBy, show=showPlt,
                             inline=showPlt, label_y=ylabel2, title_font_size=titleFontSize, label_x_font_size=xFontsize,
                             label_y_font_size=yFontsize, legend_font_size=legFontSize, legend_marker_size=legFontSize,
                             **kwargs, filename=pltPath + eval("sd" + str(x)) + '_' + timestamp + '.png')
                    document.add_heading(eval("sd" + str(x)), level=3)
                    document.add_picture(pltPath + eval("sd" + str(x)) + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        for x in range(1, numDataCols):  # 1 to 4
            if eval("sd" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("sd" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("sd" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if xAddrStartCol in df.columns:
            document.add_heading("xAddrStartCol Found: " + xAddrStartCol, level=3)  #  found
        else:
            document.add_heading("xAddrStartCol Not Found: " + xAddrStartCol, level=3)  # A not found
        if xAddrEndCol in df.columns:
            document.add_heading("xAddrEndCol Found: " + xAddrEndCol, level=3)  #  found
        else:
            document.add_heading("xAddrEndCol Not Found: " + xAddrEndCol, level=3)  # A not found
        if yAddrStartCol in df.columns:
            document.add_heading("yAddrStartCol Found: " + yAddrStartCol, level=3)  #  found
        else:
            document.add_heading("yAddrStartCol Not Found: " + yAddrStartCol, level=3)  # A not found
        if yAddrEndCol in df.columns:
            document.add_heading("yAddrEndCol Found: " + yAddrEndCol, level=3)  #  found
        else:
            document.add_heading("yAddrEndCol Not Found: " + yAddrEndCol, level=3)  # A not found

'''
Calculated Array Quadrant Mean Differences
'''
def Calc_ArrQuad_Difference(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    None

'''
Calculated Array Roi Mean Differences
'''
def Calc_ArrRoi_Difference(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    None
