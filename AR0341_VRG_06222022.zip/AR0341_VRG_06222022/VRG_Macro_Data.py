import matplotlib
import matplotlib.pyplot as plt
from matplotlib import pyplot
from docx import Document
from docx.shared import Inches
from docx.shared import Pt
from tkinter import *
from tkinter import filedialog
from tkinter import messagebox
import numpy as np
import csv
import argparse
import os
import pandas as pd
import pixelcrunch as pc
import fivecentplots as fcp
import bokeh
import sys
import io
import multiprocessing
import VRG_Safety_Data
import VRG_Calculate
import VRG_Data_Frame
import VRG_Doc
import VRG_General_Data
import VRG_Image_Analysis
import VRG_Image_Utils
import VRG_Macro_Data
import VRG_OTPM_Data
import VRG_Pins_Data
import VRG_Power_Data
import VRG_Register_Data
import VRG_Stats_Arr
import VRG_Stats_ArrCenter
import VRG_Stats_ArrQuad1
import VRG_Stats_ArrQuad2
import VRG_Stats_ArrQuad3
import VRG_Stats_ArrQuad4
import VRG_Stats_ArrRoi1
import VRG_Stats_ArrRoi2
import VRG_Stats_ArrRoi3
import VRG_Stats_ArrRoi4
import VRG_Stats_ArrRoi5
import VRG_Stats_ArrRoi6
import VRG_Stats_ArrRoi7
import VRG_Stats_ArrRoi8
import VRG_Stats_ArrRoi9
import VRG_Stats_DBLC
import VRG_Stats_Frame
import VRG_Stats_Lag
import VRG_Stats_RNC
import VRG_Stats_Tilt
import VRG_Tempsensor_Data
import VRG_Reports
import time



'''
Register vs. Macro Plots
'''

def Reg_vs_Macro_Plot(dataFrame, groupBy, document, pltPath, register, macro, showPlt, **kwargs):
    try:
        d1 = register
        d2 = macro

        figTitle = 'Register_Vs_Macro'
        numDataCols = 3
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame

        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)

        document.add_heading(figTitle, level=2)  # Add section title to docx report

        if groupBy == None:  # Remove Legend= keyword
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=[d1, d2], title=figTitle, show=showPlt, inline=showPlt, twin_x=True,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + d2 + '_' + timestamp + '.png')
            document.add_heading(d1 + ' vs. ' + d2, level=3)
            document.add_picture(pltPath + d1 + '_' + d2 + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=[d1, d2], title=figTitle, legend=groupBy, show=showPlt, inline=showPlt,
                     twin_x=True,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + d2 + '_' + timestamp + '.png')
            document.add_heading(d1 + ' vs. ' + d2, level=3)
            document.add_picture(pltPath + d1 + '_' + d2 + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
        for x in range(1, numDataCols):  # 1 to 4
            if eval("d" + str(x)) in df.columns:
                document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
            else:
                document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
        if groupBy == None:
            document.add_heading("Groupby Not Used", level=3)
        elif groupBy != None:
            if groupBy in df.columns:
                document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
            else:
                document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
        if register in df.columns:
            document.add_heading("register Found: " + register, level=3)  # Add register found
        else:
            document.add_heading("register Not Found: " + register, level=3)  # Add register not found


'''
Macro Plots
'''
def Macro_vs_Step_Plot(dataFrame, groupBy, document, pltPath, macro, showPlt, **kwargs):
    try:
        d1 = macro
    
        figTitle = 'Macro_Vs_Step'
        ylabel = macro
        numDataCols = 2
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame
    
        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)
    
        document.add_heading(figTitle, level=2) # Add section title to docx report
    
        if groupBy == None:  # Remove Legend= keyword
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_heading(d1, level=3)
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, legend=groupBy, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_heading(d1, level=3)
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
    for x in range(1, numDataCols):  # 1 to 4
        if eval("d" + str(x)) in df.columns:
            document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
        else:
            document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
    if groupBy == None:
        document.add_heading("Groupby Not Used", level=3)
    elif groupBy != None:
        if groupBy in df.columns:
            document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
        else:
            document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found
    if macro in df.columns:
        document.add_heading("macro Found: " + macro, level=3)  # Add Groupby found
    else:
        document.add_heading("macro Not Found: " + macro, level=3)  # Add Groupby not found

def MetaData_Enable_Plot(dataFrame, groupBy, document, pltPath, showPlt, **kwargs):
    try:
        # Column Names in CSV
        d1 = 'DVM_Meta_Data'
    
        figTitle = 'MetaData'
        ylabel = 'MetaData Enabled (T/F)'
        numDataCols = 2
        titleFontSize = 14
        yFontsize = 12
        xFontsize = 12
        legFontSize = 6
        df = dataFrame
    
        currTime = time.strftime("%m%d%Y-%H%M%S")  # Time stamp for repeatedly saved plots
        fractime = time.process_time()
        timestamp = currTime + '_' + str(fractime)
    
        document.add_heading(figTitle, level=2)  # Add section title to docx report
    
        if groupBy == None:  # Remove Legend= keyword
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
        elif groupBy != None:
            # Plot each color plane separately & then together
            fcp.plot(df, x='Step', y=d1, title=d1, legend=groupBy, show=showPlt, inline=showPlt, label_y=ylabel,
                     title_font_size=titleFontSize, label_x_font_size=xFontsize, label_y_font_size=yFontsize,
                     legend_font_size=legFontSize, legend_marker_size=legFontSize,
                     **kwargs, filename=pltPath + d1 + '_' + timestamp + '.png')
            document.add_picture(pltPath + d1 + '_' + timestamp + '.png')  # Add figure to report
    except:
        document.add_heading("Failed Plotting: " + figTitle, level=2)  # Add figtitle that failed
    for x in range(1, numDataCols):  # 1 to 4
        if eval("d" + str(x)) in df.columns:
            document.add_heading("Column Found: " + eval("d" + str(x)), level=3)  # Add columns found
        else:
            document.add_heading("Column Not Found: " + eval("d" + str(x)), level=3)  # Add columns not found
    if groupBy == None:
        document.add_heading("Groupby Not Used", level=3)
    elif groupBy != None:
        if groupBy in df.columns:
            document.add_heading("Groupby Found: " + groupBy, level=3)  # Add Groupby found
        else:
            document.add_heading("Groupby Not Found: " + groupBy, level=3)  # Add Groupby not found

